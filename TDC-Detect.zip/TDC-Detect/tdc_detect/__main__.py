"""CSV scoring entry point: python -m tdc_detect --help."""
import argparse
import csv
from pathlib import Path
from .readout import DetectorState, FEATURES


def main():
    parser = argparse.ArgumentParser(description='Score precomputed TDC-v2 features with a frozen readout.')
    parser.add_argument('--state', type=Path, required=True, help='Condition-specific state JSON')
    parser.add_argument('--input', type=Path, required=True, help='CSV containing all 21 named features')
    parser.add_argument('--output', type=Path, required=True, help='New output CSV (will not overwrite files)')
    args = parser.parse_args()
    try:
        if args.output.exists():
            raise ValueError(f'Output already exists: {args.output}')
        state = DetectorState.load(args.state)
        with args.input.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            names = reader.fieldnames or []
            if len(set(names)) != len(names) or not set(FEATURES).issubset(names):
                raise ValueError('CSV requires unique column names including all 21 features.')
            rows = list(reader)
        scores, flags = state.predict(rows)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with args.output.open('x', encoding='utf8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=['sample_id', 'attack', 'score', 'threshold', 'predicted_adv'])
            writer.writeheader()
            for i, (row, score, flag) in enumerate(zip(rows, scores, flags)):
                writer.writerow({'sample_id': row.get('sample_id', str(i)), 'attack': row.get('attack', ''),
                                 'score': float(score), 'threshold': state.threshold, 'predicted_adv': int(flag)})
        print(f'Scored {len(rows)} rows -> {args.output}')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))


if __name__ == '__main__':
    main()
