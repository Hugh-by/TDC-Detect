"""Portable interface to the calibrated TDC-Detect readout."""
from .readout import DetectorState, FEATURES

__all__ = ['DetectorState', 'FEATURES']
