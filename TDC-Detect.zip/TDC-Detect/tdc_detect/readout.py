"""Apply the archived float64 standardizer and logistic readout to 21 features."""
from pathlib import Path
import json
import numpy as np

FEATURES = (
    'R_model', 'R_label_change', 'R_conf_var', 'R_uniform_shift',
    'R_fft_conf_high', 'R_fft_conf_entropy', 'R_fft_vlad_high', 'R_fft_vlad_entropy',
    'R_local_conf_max', 'R_local_conf_top2', 'R_local_shift_max', 'R_local_shift_top2',
    'R_vlm', 'vlad_original', 'R_sem_mean', 'R_sem_max', 'R_sem_var',
    'R_fft_sem_high', 'R_fft_sem_entropy', 'R_local_sem_max', 'R_local_sem_top2',
)


class DetectorState:
    """A fitted, condition-specific readout. No fitting occurs during prediction."""

    def __init__(self, state):
        if tuple(state['feature_order']) != FEATURES:
            raise ValueError('State must use the canonical 21-feature order.')
        self.mean = self._vector(state['scaler_mean'], 'scaler_mean')
        self.scale = self._vector(state['scaler_scale'], 'scaler_scale')
        self.coef = self._vector(state['lr_coef'], 'lr_coef')
        self.intercept = float(state['lr_intercept'])
        self.threshold = float(state['threshold'])
        if np.any(self.scale <= 0):
            raise ValueError('Scaler values must be positive.')
        if not np.isfinite(self.intercept) or not np.isfinite(self.threshold):
            raise ValueError('Intercept and threshold must be finite.')
        if not 0 <= self.threshold <= 1:
            raise ValueError('Threshold must be a probability.')

    @staticmethod
    def _vector(values, name):
        values = np.asarray(values, dtype=np.float64)
        if values.shape != (len(FEATURES),) or not np.isfinite(values).all():
            raise ValueError(f'{name} must contain 21 finite values.')
        return values

    @classmethod
    def load(cls, path):
        return cls(json.loads(Path(path).read_text(encoding='utf-8-sig')))

    def predict(self, rows):
        """Return scores and Boolean flags for an iterable of feature mappings."""
        rows = list(rows)
        if not rows:
            raise ValueError('At least one feature row is required.')
        try:
            x = np.asarray([[float(row[key]) for key in FEATURES] for row in rows], dtype=np.float64)
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError('Each row must contain all 21 numeric features.') from exc
        if not np.isfinite(x).all():
            raise ValueError('Features must be finite; NaN and infinity are invalid.')
        with np.errstate(over='ignore', invalid='ignore'):
            logits = ((x - self.mean) / self.scale) @ self.coef + self.intercept
        if not np.isfinite(logits).all():
            raise ValueError('Feature magnitude exceeds the finite readout range.')
        scores = 1.0 / (1.0 + np.exp(-np.clip(logits, -700.0, 700.0)))
        return scores, scores > self.threshold
