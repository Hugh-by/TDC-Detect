"""Regression checks against independently archived experimental scores."""
from pathlib import Path
import json
import unittest
import numpy as np
from tdc_detect import DetectorState, FEATURES

ROOT = Path(__file__).resolve().parents[1]


class ReadoutTests(unittest.TestCase):
    def test_archived_scores_and_decisions(self):
        cases = json.loads((ROOT / 'examples/expected_scores.json').read_text())
        conditions = set()
        for case in cases:
            conditions.add(case['state'])
            detector = DetectorState.load(ROOT / 'states' / case['state'])
            scores, flags = detector.predict([case['features']])
            self.assertAlmostEqual(scores[0], case['expected_score'], delta=1e-12)
            self.assertEqual(int(flags[0]), case['expected_decision'])
        self.assertEqual(len(conditions), 8)

    def test_strict_threshold(self):
        # A score exactly equal to the threshold must remain unflagged.
        detector = DetectorState(dict(feature_order=FEATURES, scaler_mean=[0]*21,
                                      scaler_scale=[1]*21, lr_coef=[0]*21,
                                      lr_intercept=0, threshold=0.5))
        scores, flags = detector.predict([dict.fromkeys(FEATURES, 0)])
        self.assertEqual(scores[0], 0.5)
        self.assertFalse(flags[0])

    def test_invalid_input(self):
        detector = DetectorState.load(ROOT / 'states/k400_csn_r101.json')
        for rows in ([], [{}], [dict.fromkeys(FEATURES, np.nan)]):
            with self.assertRaises(ValueError):
                detector.predict(rows)
        state = json.loads((ROOT / 'states/k400_csn_r101.json').read_text())
        state['feature_order'] = state['feature_order'][::-1]
        with self.assertRaises(ValueError):
            DetectorState(state)


if __name__ == '__main__':
    unittest.main()
