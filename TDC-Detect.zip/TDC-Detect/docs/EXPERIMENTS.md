# Experiment guide

## Entry points

Paths below are relative to the repository root. Original scripts retain their recorded behavior and server-path assumptions. Prepare a writable experiment directory and its inputs before running them.

| Task | Entry point | Included evidence |
|---|---|---|
| Feature extraction and temporal probes | `TSC_Detect/run_final_extract.py`, `tsc_features.py`, `tsc_sampling.py` | Original implementation |
| Main evaluation and historical ablations | `scripts/eval_final_e1_e5.py` | `results/main/`, `states/` |
| Same-feature learned/fixed readouts and DFT controls | `experiments/revision/code/run_c03_c05a_c09.py` | `results/main/`, revision model states |
| Raw-response/PCA and probe-density studies | `experiments/revision/code/run_cache_cpu_tasks.py`, `repair_c04_roundtrip.py` | Revision code, protocols and states |
| Exact full-detector forward and BPDA | `experiments/revision/code/gpu_full_detector.py` | Shared by revised GPU workers |
| G02 detector-aware attack | `experiments/revision/code/run_g02_full_worker.py` | Protocol and source states |
| G02 original-detector rescoring | `experiments/revision/code/run_g02_legacy_rescore_worker.py` | Corrected rescoring source |
| G03 runtime | `experiments/revision/code/run_g03_full_method.py` | `results/runtime/` |
| G04 extended OFA/Flicker attacks | `experiments/revision/code/run_g04_full_corrected_worker.py` | Corrected code and protocol |
| G05 unfiltered clean inputs | `experiments/revision/code/run_g05_v2_worker.py` | Corrected code and frozen states |
| HMDB51 transfer | `experiments/hmdb51/code/worker.py`, `resume_worker.py`, `summarize.py` | `results/hmdb51/` and transfer protocol |

Pilot and superseded scripts remain available for their import dependencies and provenance. Use the final entry points above for the revised experiments. `experiments/historical_snapshot/` contains source versions that differ from the canonical root modules and extra orchestration code; it is not the default import root.

## Environments

The quick-start readout requires only NumPy and was verified locally with Python 3.12.14 and NumPy 2.3.5. The `requirements.txt` file covers this portable path.

Recorded experiments used Python 3.12.3 and the following principal packages:

| Package | Recorded version |
|---|---|
| NumPy | 2.3.2 |
| pandas | 3.0.3 |
| scikit-learn | 1.8.0 |
| PyTorch | 2.8.0+cu128 |
| torchvision | 0.23.0+cu128 |
| PyTorchVideo | 0.1.5 |
| Transformers | 5.8.1 |
| PyAV (HMDB51) | 17.0.1 |

Detailed records are in `environments/historical/`, `environments/revision/`, `environments/hmdb51.json` and `environments/supplement.txt`. These are provenance records, not a newly tested cross-platform environment lock. Configure PyTorch/CUDA for the target GPU and restore the recorded experiment dependencies before model inference or refitting.

## Paths and external inputs

Several revision scripts read these environment variables:

| Variable | Expected contents |
|---|---|
| `TDC_PROJECT_ROOT` | This repository root, containing `TSC_Detect/` |
| `TDC_RUN_ROOT` | Writable revision working tree with `code/`, `models/`, `protocols/`, `manifests/` and generated `results/` |
| `TDC_BASE_ROOT` | Original E1–E10 result tree, including calibration and test feature CSVs |
| `TDC_PROTOCOL_ROOT` | Historical protocol tree; the included snapshot is `experiments/historical_protocol/` |
| `TDC_SUPPLEMENT_ROOT` | Supplementary response-cache and result tree |
| `TDC_CLASS_MANIFEST` | Class manifest accepted by the relevant worker |

`experiments/revision/` provides the code/state/protocol part of the revision working tree. Restore the required input results and response caches before starting a worker. Some workers also contain path constants: review `PROJECT`, `BASE_PROTOCOL`, `CLASSES`, `PREDICTIONS`, `RUN` and `OLD` in G03/G05 and HMDB51 scripts, plus paths inside dataset manifests. Environment variables alone do not configure every historical entry point.

For GPU workers, explicitly set the intended `CUDA_VISIBLE_DEVICES` before launch: the shared CPU helper defaults it to an empty string when unset. Add the repository root and the revision `code/` directory to the Python import path as required by the selected script.

The bundled historical `protocols/authorization.json` is experiment execution metadata used by existing worker guards; it is not a server credential. HMDB51 protocol gate files are also preserved as historical records. Validate the new machine's data and decoding configuration before reusing those protocols.

Prepare these external inputs for full reproduction:

- Kinetics-400, UCF101 and HMDB51 videos with the required split/manifest correspondence.
- Pretrained action-recognition weights and CLIP ViT-B/32 weights; checkpoint records are in the historical environment files.
- E1 calibration/test feature tables and response caches for refitting and cache-based ablations.
- Selected attack tensors for G02/G04 rescoring, and the original clean-prediction pool for G05.
- Complete per-source outputs when regenerating experiment-wide summaries. Only selected final summary tables are included here.

The eight `states/` files correspond to main Kinetics-400/UCF101 conditions. Frozen Kinetics-to-HMDB51 transfer uses `experiments/hmdb51/protocols/frozen_states/`, whose full21 states were verified identical to `experiments/revision/protocols/G05_v2_frozen_states/`. Keep these experiment-specific state choices intact.

## Verification scope

`validation/archived_alignment.json` records the earlier 59,805-row state-to-score audit, clean-threshold checks and source-state identity checks. Its paths refer to the original evidence archive; `provenance/source_files.json` maps retained files into this repository. `validation/release_checks.json` records verification of this repository's portable scorer and source copies. Neither report represents a fresh GPU experiment.
