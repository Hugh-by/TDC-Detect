from __future__ import annotations

import argparse
import csv
import hashlib
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames, probabilities
from TSC_Detect.run_final_extract import PROTOCOL_ID, SEED
from TSC_Detect.run_tsc_detect import FIELDNAMES, choose_device, load_real_models, score_frames
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
from TSC_Detect.utils_video import load_frames, read_class_names


STRENGTHS = (2, 4, 8, 16)
ATTACKS = ("fgsm", "pgd")
FIELDS = [
    "protocol_id", "experiment", "action_model", "pair_id", "relative_path", "video_path",
    "row_type", "is_adv", "attack", "epsilon_255", "epsilon", "alpha", "steps", "attack_seed",
    "clean_pred", "attacked_pred", "attack_success", "measured_linf", "attack_seconds", "score_seconds",
] + [name for name in FIELDNAMES if name not in {"video_path", "label", "is_adv", "score", "score_mode"}]


def stable_seed(path: str, model: str, attack: str, strength: int) -> int:
    digest = hashlib.sha256(f"{path}|{model}|{attack}|{strength}|{SEED}".encode()).digest()
    return (SEED + int.from_bytes(digest[:4], "little")) % (2**31)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--model", choices=sorted(ACTION_MODEL_PROFILES), required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    device = choose_device(args.device)
    torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True, warn_only=True)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    classes = read_class_names(args.class_names)
    model, clip_model, clip_processor = load_real_models(device, args.model)
    with args.manifest.open(encoding="utf-8-sig", newline="") as handle:
        manifest = list(csv.DictReader(handle))
    score_args = argparse.Namespace(
        seed=SEED, protocol_id=PROTOCOL_ID, num_frames=ACTION_MODEL_PROFILES[args.model].num_frames,
        num_random=0, max_global_views=None, base_views_only=False, num_local_windows=4,
        local_window_frames=None, mock_models=False, prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
        prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8,
    )
    done = set()
    if args.resume and args.output.exists():
        with args.output.open(encoding="utf-8", newline="") as handle:
            done = {(row["pair_id"], row["attack"], row["epsilon_255"]) for row in csv.DictReader(handle)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if args.resume and args.output.exists() else "w"
    with args.output.open(mode, encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        if mode == "w" or args.output.stat().st_size == 0: writer.writeheader()
        for index, row in enumerate(manifest, 1):
            path = Path(row["path"]); relative = row["relative_path"]
            pair_id = hashlib.sha256(f"k400|{args.model}|{relative}".encode()).hexdigest()
            source = load_frames(path)
            clean_tensor = prepare_attack_frames(source, args.model, device).detach()
            with torch.no_grad(): clean_pred = int(probabilities(model, clean_tensor, args.model)[0].argmax())
            if (pair_id, "clean", "0") not in done:
                start = time.perf_counter()
                features = score_frames(clean_tensor.cpu().numpy().astype(np.float32), classes, score_args, model, clip_model, clip_processor, device, str(path))
                score_seconds = time.perf_counter() - start
                record = {"protocol_id": PROTOCOL_ID, "experiment": "E6", "action_model": args.model, "pair_id": pair_id, "relative_path": relative, "video_path": str(path), "row_type": "clean", "is_adv": 0, "attack": "clean", "epsilon_255": 0, "clean_pred": clean_pred, "score_seconds": score_seconds, **features}
                writer.writerow({name: record.get(name, "") for name in FIELDS}); handle.flush()
            for attack in ATTACKS:
                for strength in STRENGTHS:
                    if (pair_id, attack, str(strength)) in done: continue
                    eps = strength / 255; alpha = 2 / 255; steps = 1 if attack == "fgsm" else 40
                    seed = stable_seed(relative, args.model, attack, strength)
                    start = time.perf_counter()
                    result = make_attack(model, source, args.model, device, attack, eps, eps if attack == "fgsm" else alpha, steps, seed)
                    attack_seconds = time.perf_counter() - start
                    start = time.perf_counter()
                    features = score_frames(result.rgb, classes, score_args, model, clip_model, clip_processor, device, str(path))
                    score_seconds = time.perf_counter() - start
                    record = {"protocol_id": PROTOCOL_ID, "experiment": "E6", "action_model": args.model, "pair_id": pair_id, "relative_path": relative, "video_path": str(path), "row_type": "adversarial", "is_adv": 1, "attack": attack, "epsilon_255": strength, "epsilon": eps, "alpha": eps if attack == "fgsm" else alpha, "steps": steps, "attack_seed": seed, "clean_pred": result.clean_pred, "attacked_pred": result.adv_pred, "attack_success": int(result.attack_success), "measured_linf": result.linf, "attack_seconds": attack_seconds, "score_seconds": score_seconds, **features}
                    writer.writerow({name: record.get(name, "") for name in FIELDS}); handle.flush()
            print(f"{args.model} E6 {index}/{len(manifest)}", flush=True)


if __name__ == "__main__": main()
