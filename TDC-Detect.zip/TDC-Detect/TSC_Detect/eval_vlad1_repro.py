from __future__ import annotations

import argparse
import csv
from pathlib import Path

from TSC_Detect.utils_metrics import binary_metrics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate pure VLAD-1 reproduction CSV files.")
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--success-only", action="store_true")
    return parser.parse_args()


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def group_rows(rows: list[dict]) -> dict[str, list[dict]]:
    groups: dict[str, list[dict]] = {}
    for row in rows:
        attack = row.get("attack") or row.get("split") or "unknown"
        if attack == "clean":
            continue
        groups.setdefault(attack, []).append(row)
    return groups


def metrics_for_attack(rows: list[dict], attack_rows: list[dict], success_only: bool) -> dict:
    clean_rows = [row for row in rows if str(row.get("is_adv", "0")) == "0"]
    adv_rows = attack_rows
    if success_only:
        adv_rows = [row for row in adv_rows if str(row.get("attack_success", "")) == "1"]
    labels = [0] * len(clean_rows) + [1] * len(adv_rows)
    scores = [float(row["vlad1_score"]) for row in clean_rows + adv_rows]
    result = binary_metrics(labels, scores)
    result.update(
        {
            "n_clean": len(clean_rows),
            "n_adv": len(adv_rows),
            "attack_success_total": sum(1 for row in attack_rows if str(row.get("attack_success", "")) == "1"),
            "attack_raw_total": len(attack_rows),
        }
    )
    return result


def main() -> None:
    args = parse_args()
    rows = read_rows(args.inputs)
    output_path = Path(args.output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "setting",
        "attack",
        "roc_auc",
        "pr_auc",
        "fpr_at_95_tpr",
        "tpr_at_1_fpr",
        "n_clean",
        "n_adv",
        "attack_success_total",
        "attack_raw_total",
        "clean_mean",
        "clean_std",
        "adv_mean",
        "adv_std",
    ]
    grouped = group_rows(rows)
    with output_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        for attack, attack_rows in sorted(grouped.items()):
            result = metrics_for_attack(rows, attack_rows, args.success_only)
            result["setting"] = "success_only" if args.success_only else "full"
            result["attack"] = attack
            writer.writerow({name: result.get(name, "") for name in fieldnames})
    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
