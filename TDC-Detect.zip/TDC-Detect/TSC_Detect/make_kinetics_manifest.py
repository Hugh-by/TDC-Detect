from __future__ import annotations

import argparse
import csv
from pathlib import Path

from TSC_Detect.utils_video import VIDEO_SUFFIXES, read_class_names


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a Kinetics-style manifest from class-named video folders.")
    parser.add_argument("--data-root", required=True, help="Directory containing one subdirectory per Kinetics class.")
    parser.add_argument("--class-names", default="kinetics-labels.txt")
    parser.add_argument("--output", required=True)
    parser.add_argument("--split", default="val")
    parser.add_argument("--strict", action="store_true", help="Fail if a class directory is not in class-names.")
    return parser.parse_args()


def normalize_name(name: str) -> str:
    return name.replace("_", " ").strip().lower()


def main() -> None:
    args = parse_args()
    data_root = Path(args.data_root)
    class_names = read_class_names(args.class_names)
    normalized = {normalize_name(name): (idx, name) for idx, name in enumerate(class_names)}
    rows: list[dict] = []
    skipped: list[str] = []

    for class_dir in sorted(path for path in data_root.iterdir() if path.is_dir()):
        key = normalize_name(class_dir.name)
        if key not in normalized:
            skipped.append(class_dir.name)
            if args.strict:
                raise SystemExit(f"Class directory is not in class-names: {class_dir.name}")
            continue
        label_index, class_name = normalized[key]
        for video_path in sorted(path for path in class_dir.rglob("*") if path.suffix.lower() in VIDEO_SUFFIXES):
            rows.append(
                {
                    "split": args.split,
                    "label": class_name,
                    "label_index": label_index,
                    "class_name": class_name,
                    "path": str(video_path),
                }
            )

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["split", "label", "label_index", "class_name", "path"])
        writer.writeheader()
        writer.writerows(rows)

    print(f"Saved {len(rows)} rows to {output}")
    if skipped:
        print(f"Skipped {len(skipped)} class dirs not found in class-names: {', '.join(skipped[:20])}")


if __name__ == "__main__":
    main()
