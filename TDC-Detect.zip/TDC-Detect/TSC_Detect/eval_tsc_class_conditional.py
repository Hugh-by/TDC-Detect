from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path

import numpy as np

from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


FEATURES = [
    "vlad_original",
    "R_sem_mean",
    "R_sem_var",
    "R_uniform_shift",
    "R_model",
    "R_conf_var",
    "R_label_change",
]

LOGISTIC_FEATURES = [
    "vlad_original",
    "R_sem_var",
    "R_uniform_shift",
    "R_model",
    "R_conf_var",
    "R_label_change",
]


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def matrix(rows: list[dict], features: list[str]) -> np.ndarray:
    return np.asarray([[float(row[name]) for name in features] for row in rows], dtype=np.float64)


def grouped_indices(rows: list[dict]) -> list[np.ndarray]:
    groups: dict[str, list[int]] = {}
    for idx, row in enumerate(rows):
        groups.setdefault(row["video_path"], []).append(idx)
    return [np.asarray(indices, dtype=np.int64) for _, indices in sorted(groups.items())]


def fit_clean_stats(calib_rows: list[dict], features: list[str], min_class_count: int) -> dict:
    global_x = matrix(calib_rows, features)
    stats = {
        "__global__": {
            "mean": global_x.mean(axis=0),
            "std": np.maximum(global_x.std(axis=0), 1e-6),
            "n": len(calib_rows),
        }
    }
    by_label: dict[str, list[dict]] = defaultdict(list)
    for row in calib_rows:
        by_label[row.get("label", "")].append(row)
    for label, label_rows in by_label.items():
        if len(label_rows) < min_class_count:
            continue
        x = matrix(label_rows, features)
        stats[label] = {
            "mean": x.mean(axis=0),
            "std": np.maximum(x.std(axis=0), 1e-6),
            "n": len(label_rows),
        }
    return stats


def positive_z(rows: list[dict], features: list[str], stats: dict, class_conditional: bool) -> np.ndarray:
    x = matrix(rows, features)
    z = np.zeros_like(x)
    global_stats = stats["__global__"]
    for idx, row in enumerate(rows):
        row_stats = stats.get(row.get("label", ""), global_stats) if class_conditional else global_stats
        z[idx] = (x[idx] - row_stats["mean"]) / row_stats["std"]
    return np.maximum(z, 0.0)


def fixed_score_variants(rows: list[dict], stats: dict, class_conditional: bool) -> dict[str, np.ndarray]:
    z = positive_z(rows, FEATURES, stats, class_conditional=class_conditional)
    idx = {name: i for i, name in enumerate(FEATURES)}
    prefix = "class" if class_conditional else "global"
    vlad = z[:, idx["vlad_original"]]
    temporal = (
        0.45 * z[:, idx["R_uniform_shift"]]
        + 0.25 * z[:, idx["R_model"]]
        + 0.20 * z[:, idx["R_label_change"]]
        + 0.10 * z[:, idx["R_conf_var"]]
    )
    semantic_temporal = (
        0.55 * z[:, idx["vlad_original"]]
        + 0.20 * z[:, idx["R_sem_var"]]
        + 0.15 * z[:, idx["R_uniform_shift"]]
        + 0.10 * z[:, idx["R_label_change"]]
    )
    vlad_light_tsc = (
        vlad
        + 0.12 * z[:, idx["R_uniform_shift"]]
        + 0.08 * z[:, idx["R_model"]]
        + 0.10 * z[:, idx["R_label_change"]]
    )
    return {
        f"{prefix}_z_vlad": vlad,
        f"{prefix}_temporal_only": temporal,
        f"{prefix}_semantic_temporal": semantic_temporal,
        f"{prefix}_vlad_light_tsc": vlad_light_tsc,
    }


def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-np.clip(x, -50, 50)))


def fit_logistic_x(
    x: np.ndarray,
    y: np.ndarray,
    steps: int,
    lr: float,
    l2: float,
) -> dict:
    mean = x.mean(axis=0)
    std = np.maximum(x.std(axis=0), 1e-6)
    z = (x - mean) / std
    w = np.zeros(z.shape[1], dtype=np.float64)
    b = 0.0
    for _ in range(steps):
        p = sigmoid(z @ w + b)
        err = p - y
        w -= lr * ((z.T @ err) / len(y) + l2 * w)
        b -= lr * float(err.mean())
    return {"mean": mean, "std": std, "weights": w, "bias": b}


def logistic_predict_x(x: np.ndarray, model: dict) -> np.ndarray:
    z = (x - model["mean"]) / model["std"]
    return sigmoid(z @ model["weights"] + float(model["bias"]))


def logistic_lovo_scores(
    rows: list[dict],
    x: np.ndarray,
    labels: np.ndarray,
    steps: int,
    lr: float,
    l2: float,
) -> np.ndarray:
    scores = np.zeros(len(rows), dtype=np.float64)
    all_indices = np.arange(len(rows))
    for group in grouped_indices(rows):
        mask = np.ones(len(rows), dtype=bool)
        mask[group] = False
        model = fit_logistic_x(x[mask], labels[mask].astype(np.float64), steps=steps, lr=lr, l2=l2)
        scores[group] = logistic_predict_x(x[group], model)
    return scores


def bootstrap_delta(
    labels: np.ndarray,
    baseline: np.ndarray,
    scores: np.ndarray,
    groups: list[np.ndarray],
    n_boot: int,
    seed: int,
) -> dict:
    rng = np.random.default_rng(seed)
    deltas = np.zeros(n_boot, dtype=np.float64)
    aucs = np.zeros(n_boot, dtype=np.float64)
    for i in range(n_boot):
        sampled = rng.integers(0, len(groups), size=len(groups))
        indices = np.concatenate([groups[j] for j in sampled])
        y = labels[indices]
        if len(np.unique(y)) < 2:
            deltas[i] = np.nan
            aucs[i] = np.nan
            continue
        base_auc = roc_auc_np(y, baseline[indices])
        auc = roc_auc_np(y, scores[indices])
        aucs[i] = auc
        deltas[i] = auc - base_auc
    deltas = deltas[~np.isnan(deltas)]
    aucs = aucs[~np.isnan(aucs)]
    return {
        "auc_ci_low": float(np.quantile(aucs, 0.025)),
        "auc_ci_high": float(np.quantile(aucs, 0.975)),
        "delta_ci_low": float(np.quantile(deltas, 0.025)),
        "delta_ci_high": float(np.quantile(deltas, 0.975)),
        "p_delta_le_0": float(np.mean(deltas <= 0.0)),
    }


def clean_vlad_borderline_mask(
    rows: list[dict],
    calib_rows: list[dict],
    stats: dict,
    low_q: float,
    high_q: float,
    class_conditional: bool,
) -> np.ndarray:
    if not class_conditional:
        calib_scores = np.asarray([float(row["vlad_original"]) for row in calib_rows], dtype=np.float64)
        low = float(np.quantile(calib_scores, low_q))
        high = float(np.quantile(calib_scores, high_q))
        scores = np.asarray([float(row["vlad_original"]) for row in rows], dtype=np.float64)
        return (scores >= low) & (scores <= high)

    feat_idx = FEATURES.index("vlad_original")
    global_stats = stats["__global__"]
    calib_by_label: dict[str, list[float]] = defaultdict(list)
    for row in calib_rows:
        row_stats = stats.get(row.get("label", ""), global_stats)
        value = max((float(row["vlad_original"]) - row_stats["mean"][feat_idx]) / row_stats["std"][feat_idx], 0.0)
        calib_by_label[row.get("label", "")].append(value)
    global_calib = [value for values in calib_by_label.values() for value in values]

    mask = np.zeros(len(rows), dtype=bool)
    for idx, row in enumerate(rows):
        label = row.get("label", "")
        calib_values = np.asarray(calib_by_label.get(label, global_calib), dtype=np.float64)
        low = float(np.quantile(calib_values, low_q))
        high = float(np.quantile(calib_values, high_q))
        row_stats = stats.get(label, global_stats)
        value = max((float(row["vlad_original"]) - row_stats["mean"][feat_idx]) / row_stats["std"][feat_idx], 0.0)
        mask[idx] = low <= value <= high
    return mask


def add_metrics(
    out: list[dict],
    setting: str,
    region: str,
    labels: np.ndarray,
    baseline: np.ndarray,
    scores_by_name: dict[str, np.ndarray],
    rows: list[dict],
    n_boot: int,
    seed: int,
) -> None:
    groups = grouped_indices(rows)
    base_auc = binary_metrics(labels, baseline)["roc_auc"]
    for method, scores in scores_by_name.items():
        metric = binary_metrics(labels, scores)
        row = {
            "setting": setting,
            "region": region,
            "method": method,
            "n_rows": len(labels),
            "n_clean": int(np.sum(labels == 0)),
            "n_adv": int(np.sum(labels == 1)),
            **metric,
            "delta_vs_vlad": metric["roc_auc"] - base_auc,
            "auc_ci_low": "",
            "auc_ci_high": "",
            "delta_ci_low": "",
            "delta_ci_high": "",
            "p_delta_le_0": "",
        }
        if method != "vlad_original":
            boot = bootstrap_delta(labels, baseline, scores, groups, n_boot=n_boot, seed=seed)
            row.update(boot)
        out.append(row)


def write_csv(path: str, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate class-conditional TSC calibration and borderline regions.")
    parser.add_argument("--calib-clean", required=True)
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--min-class-count", type=int, default=10)
    parser.add_argument("--logistic-steps", type=int, default=1000)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    parser.add_argument("--n-boot", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    calib_rows = read_rows([args.calib_clean])
    rows = read_rows(args.inputs)
    labels = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.int64)
    stats = fit_clean_stats(calib_rows, FEATURES, min_class_count=args.min_class_count)

    raw_x = matrix(rows, LOGISTIC_FEATURES)
    feature_idx = {name: idx for idx, name in enumerate(FEATURES)}
    logistic_cols = [feature_idx[name] for name in LOGISTIC_FEATURES]
    global_z = positive_z(rows, FEATURES, stats, class_conditional=False)[:, logistic_cols]
    class_z = positive_z(rows, FEATURES, stats, class_conditional=True)[:, logistic_cols]

    scores: dict[str, np.ndarray] = {
        "vlad_original": np.asarray([float(row["vlad_original"]) for row in rows], dtype=np.float64),
        "tsc_score_current": np.asarray([float(row["score"]) for row in rows], dtype=np.float64),
        "logistic_raw_lovo": logistic_lovo_scores(
            rows, raw_x, labels, steps=args.logistic_steps, lr=args.logistic_lr, l2=args.logistic_l2
        ),
        "logistic_global_z_lovo": logistic_lovo_scores(
            rows, global_z, labels, steps=args.logistic_steps, lr=args.logistic_lr, l2=args.logistic_l2
        ),
        "logistic_class_z_lovo": logistic_lovo_scores(
            rows, class_z, labels, steps=args.logistic_steps, lr=args.logistic_lr, l2=args.logistic_l2
        ),
    }
    scores.update(fixed_score_variants(rows, stats, class_conditional=False))
    scores.update(fixed_score_variants(rows, stats, class_conditional=True))

    out: list[dict] = []
    add_metrics(out, args.name, "all", labels, scores["vlad_original"], scores, rows, args.n_boot, args.seed)

    for region_name, low_q, high_q in [
        ("global_clean_q75_q975", 0.75, 0.975),
        ("class_clean_q75_q975", 0.75, 0.975),
        ("class_clean_q50_q95", 0.50, 0.95),
    ]:
        class_region = region_name.startswith("class")
        mask = clean_vlad_borderline_mask(
            rows,
            calib_rows,
            stats,
            low_q=low_q,
            high_q=high_q,
            class_conditional=class_region,
        )
        if len(np.unique(labels[mask])) < 2:
            continue
        masked_rows = [row for row, keep in zip(rows, mask) if keep]
        masked_scores = {name: values[mask] for name, values in scores.items()}
        add_metrics(
            out,
            args.name,
            region_name,
            labels[mask],
            masked_scores["vlad_original"],
            masked_scores,
            masked_rows,
            args.n_boot,
            args.seed + 17,
        )

    write_csv(args.output_csv, out)

    for region in ["all", "global_clean_q75_q975", "class_clean_q75_q975", "class_clean_q50_q95"]:
        print(f"\n{args.name} {region}")
        for row in out:
            if row["region"] != region:
                continue
            if row["method"] in {
                "vlad_original",
                "tsc_score_current",
                "global_vlad_light_tsc",
                "class_vlad_light_tsc",
                "logistic_raw_lovo",
                "logistic_class_z_lovo",
            }:
                print(
                    f"{row['method']:24s} n={row['n_rows']:4d} "
                    f"AUC={row['roc_auc']:.4f} delta={row['delta_vs_vlad']:+.4f} "
                    f"FPR95={row['fpr_at_95_tpr']:.3f}"
                )


if __name__ == "__main__":
    main()
