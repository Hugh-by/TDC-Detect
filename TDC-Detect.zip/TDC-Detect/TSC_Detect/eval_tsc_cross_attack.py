from __future__ import annotations

import argparse
import csv
from pathlib import Path

from TSC_Detect.tsc_calibration import (
    DEFAULT_FEATURES,
    clean_gate_scores,
    fit_clean_stats,
    fit_logistic_regression,
    logistic_scores,
)
from TSC_Detect.utils_metrics import binary_metrics


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train TSC calibrators on one attack set and evaluate on another.")
    parser.add_argument("--train-inputs", nargs="+", required=True)
    parser.add_argument("--test-inputs", nargs="+", required=True)
    parser.add_argument("--train-name", default="train")
    parser.add_argument("--test-name", default="test")
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_cross_attack_summary.csv")
    parser.add_argument("--features", nargs="+", default=DEFAULT_FEATURES)
    parser.add_argument("--logistic-steps", type=int, default=3000)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def add_metrics(rows: list[dict], method: str, scores) -> dict:
    labels = [int(row["is_adv"]) for row in rows]
    return {"method": method, **binary_metrics(labels, scores)}


def main() -> None:
    args = parse_args()
    train_rows = read_rows(args.train_inputs)
    test_rows = read_rows(args.test_inputs)

    logistic = fit_logistic_regression(
        train_rows,
        args.features,
        lr=args.logistic_lr,
        steps=args.logistic_steps,
        l2=args.logistic_l2,
    )
    clean_stats = fit_clean_stats(train_rows, args.features)

    results = [
        add_metrics(test_rows, "vlad_original", [float(row["vlad_original"]) for row in test_rows]),
        add_metrics(test_rows, "tsc_score_current", [float(row["score"]) for row in test_rows]),
        add_metrics(test_rows, "clean_gate_logsumexp", clean_gate_scores(test_rows, clean_stats, mode="logsumexp")),
        add_metrics(test_rows, "logistic_cross_attack", logistic_scores(test_rows, logistic)),
    ]
    for row in results:
        row["train"] = args.train_name
        row["test"] = args.test_name

    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "train",
        "test",
        "method",
        "roc_auc",
        "pr_auc",
        "fpr_at_95_tpr",
        "tpr_at_1_fpr",
        "clean_mean",
        "clean_std",
        "adv_mean",
        "adv_std",
    ]
    write_header = not output.exists()
    with output.open("a", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerows(results)

    for row in results:
        print(
            f"{args.train_name:10s}->{args.test_name:10s} {row['method']:22s} "
            f"AUC={row['roc_auc']:.4f} PR={row['pr_auc']:.4f} "
            f"FPR95={row['fpr_at_95_tpr']:.3f} TPR1={row['tpr_at_1_fpr']:.3f} "
            f"clean={row['clean_mean']:.4f} adv={row['adv_mean']:.4f}"
        )
    print(f"Saved {output}")


if __name__ == "__main__":
    main()

