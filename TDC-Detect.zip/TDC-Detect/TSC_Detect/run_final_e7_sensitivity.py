from __future__ import annotations

import argparse
import csv
import hashlib
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames, probabilities
from TSC_Detect.run_final_extract import PROTOCOL_ID, SEED, stable_seed
from TSC_Detect.run_tsc_detect import FIELDNAMES, choose_device, load_real_models, score_frames
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
from TSC_Detect.utils_video import load_frames, read_class_names


CONFIGS = tuple((global_views, local_windows) for global_views in (1, 3, 5) for local_windows in (0, 2, 4))
FIELDS = [
    "protocol_id", "experiment", "action_model", "pair_id", "relative_path", "video_path",
    "row_type", "is_adv", "attack", "config", "global_views", "local_windows", "attack_seed",
    "clean_pred", "attacked_pred", "attack_success", "measured_linf", "attack_seconds", "score_seconds",
] + [name for name in FIELDNAMES if name not in {"video_path", "label", "is_adv", "score", "score_mode"}]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--model", choices=sorted(ACTION_MODEL_PROFILES), required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    device = choose_device(args.device)
    torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED); torch.use_deterministic_algorithms(True, warn_only=True)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    classes = read_class_names(args.class_names)
    model, clip_model, clip_processor = load_real_models(device, args.model)
    with args.manifest.open(encoding="utf-8-sig", newline="") as handle: manifest = list(csv.DictReader(handle))
    done = set()
    if args.resume and args.output.exists():
        with args.output.open(encoding="utf-8", newline="") as handle:
            done = {(row["pair_id"], row["attack"], row["config"]) for row in csv.DictReader(handle)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if args.resume and args.output.exists() else "w"
    with args.output.open(mode, encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        if mode == "w" or args.output.stat().st_size == 0: writer.writeheader()
        for index, row in enumerate(manifest, 1):
            path = Path(row["path"]); relative = row["relative_path"]
            pair_id = hashlib.sha256(f"k400|{args.model}|{relative}".encode()).hexdigest()
            source = load_frames(path)
            clean_tensor = prepare_attack_frames(source, args.model, device).detach()
            clean_rgb = clean_tensor.cpu().numpy().astype(np.float32)
            with torch.no_grad(): clean_pred = int(probabilities(model, clean_tensor, args.model)[0].argmax())
            inputs = [("clean", clean_rgb, None, 0.0)]
            for attack, internal, steps in (("pgd", "pgd", 40), ("flicker-style", "flick", 10)):
                seed = stable_seed(relative, args.model, attack)
                start = time.perf_counter()
                result = make_attack(model, source, args.model, device, internal, 8 / 255, 2 / 255, steps, seed)
                inputs.append((attack, result.rgb, result, time.perf_counter() - start))
            for attack, frames, result, attack_seconds in inputs:
                for global_views, local_windows in CONFIGS:
                    config = f"g{global_views}_l{local_windows}"
                    if (pair_id, attack, config) in done: continue
                    score_args = argparse.Namespace(
                        seed=SEED, protocol_id=PROTOCOL_ID, num_frames=ACTION_MODEL_PROFILES[args.model].num_frames,
                        num_random=0, max_global_views=global_views, base_views_only=False, num_local_windows=local_windows,
                        local_window_frames=None, mock_models=False, prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
                        prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8,
                    )
                    start = time.perf_counter()
                    features = score_frames(frames, classes, score_args, model, clip_model, clip_processor, device, str(path))
                    score_seconds = time.perf_counter() - start
                    record = {"protocol_id": PROTOCOL_ID, "experiment": "E7", "action_model": args.model, "pair_id": pair_id, "relative_path": relative, "video_path": str(path), "row_type": "clean" if result is None else "adversarial", "is_adv": int(result is not None), "attack": attack, "config": config, "global_views": global_views, "local_windows": local_windows, "attack_seed": "" if result is None else stable_seed(relative, args.model, attack), "clean_pred": clean_pred, "attacked_pred": "" if result is None else result.adv_pred, "attack_success": "" if result is None else int(result.attack_success), "measured_linf": "" if result is None else result.linf, "attack_seconds": attack_seconds, "score_seconds": score_seconds, **features}
                    writer.writerow({name: record.get(name, "") for name in FIELDS}); handle.flush()
            print(f"{args.model} E7 {index}/{len(manifest)}", flush=True)


if __name__ == "__main__": main()
