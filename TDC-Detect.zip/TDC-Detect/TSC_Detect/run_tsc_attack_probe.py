from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames
from TSC_Detect.run_tsc_detect import FIELDNAMES, choose_device, load_real_models, score_frames
from TSC_Detect.tsc_features import score_features
from TSC_Detect.utils_video import load_frames, read_class_names, read_manifest


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate clean/attack TSC rows for a small local probe.")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--manifest-splits", nargs="*", default=("test",))
    parser.add_argument("--class-names", default="kinetics-labels.txt")
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_attack_probe.csv")
    parser.add_argument("--max-videos", type=int, default=None)
    parser.add_argument("--num-frames", type=int, default=32)
    parser.add_argument("--num-random", type=int, default=1)
    parser.add_argument("--device", default="cpu", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--action-model", default="csn_r101", choices=["csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4"])
    parser.add_argument("--attack", default="fgsm", choices=["fgsm", "pgd", "ofa", "flick"])
    parser.add_argument("--attack-split-name", default=None)
    parser.add_argument("--eps", type=float, default=0.03)
    parser.add_argument("--alpha", type=float, default=2 / 255)
    parser.add_argument("--iters", type=int, default=1)
    parser.add_argument("--score-mode", default="max_evidence", choices=["max_evidence", "sum", "logsumexp"])
    parser.add_argument("--prompt-template", default="a video of a person {}")
    parser.add_argument("--prompt-templates", nargs="*", default=None)
    parser.add_argument("--max-clip-frames", type=int, default=8)
    parser.add_argument("--base-views-only", action="store_true")
    parser.add_argument("--num-local-windows", type=int, default=0)
    parser.add_argument("--local-window-frames", type=int, default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--resume", action="store_true", help="Append to an existing CSV and skip already completed clean/adv pairs.")
    return parser.parse_args()


def tensor_to_frames(video: torch.Tensor) -> np.ndarray:
    frames = video.detach().clamp(0, 1)
    frames = (frames[0].permute(1, 2, 3, 0) * 255).round().to(torch.uint8)
    return frames.cpu().numpy()


def write_row(writer: csv.DictWriter, path: Path, label: str, split: str, features: dict, args: argparse.Namespace) -> None:
    is_adv = "0" if split == "clean" else "1"
    row = {
        "video_path": str(path),
        "label": label,
        "is_adv": is_adv,
        "score": score_features(features, mode=args.score_mode),
        "score_mode": args.score_mode,
        **features,
    }
    writer.writerow({name: row.get(name, "") for name in FIELDNAMES})


def existing_progress(path: Path) -> dict[str, dict[str, bool]]:
    progress: dict[str, dict[str, bool]] = {}
    if not path.exists():
        return progress
    with path.open("r", encoding="utf-8", newline="") as file:
        for row in csv.DictReader(file):
            video_path = row.get("video_path")
            if not video_path:
                continue
            entry = progress.setdefault(video_path, {"clean": False, "adv": False})
            if str(row.get("is_adv", "")) == "0":
                entry["clean"] = True
            elif str(row.get("is_adv", "")) == "1":
                entry["adv"] = True
    return progress


def main() -> None:
    args = parse_args()
    device = choose_device(args.device)
    class_names = read_class_names(args.class_names)
    action_model, clip_model, clip_processor = load_real_models(device, args.action_model)
    rows = read_manifest(args.manifest, args.manifest_splits, args.max_videos)
    output_path = Path(args.output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Reuse the run_tsc_detect scoring path by passing this args namespace.
    args.mock_models = False

    progress = existing_progress(output_path) if args.resume else {}
    mode = "a" if args.resume and output_path.exists() else "w"
    needs_header = mode == "w" or output_path.stat().st_size == 0

    with output_path.open(mode, encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        if needs_header:
            writer.writeheader()
        for index, row in enumerate(rows, 1):
            path = Path(row["path"])
            state = progress.get(str(path), {"clean": False, "adv": False})
            if state["adv"]:
                continue
            label = row.get("label", "")
            print(f"[{index}/{len(rows)}] clean+{args.attack}: {path}")
            source_frames = load_frames(path)
            clean_frames = (
                prepare_attack_frames(source_frames, args.action_model, device)
                .mul(255).round().to(torch.uint8).cpu().numpy()
            )
            if not state["clean"]:
                clean_features = score_frames(
                    clean_frames,
                    class_names,
                    args,
                    action_model=action_model,
                    clip_model=clip_model,
                    clip_processor=clip_processor,
                    device=device,
                )
                write_row(writer, path, label, "clean", clean_features, args)
                file.flush()

            attack_result = make_attack(
                action_model,
                source_frames,
                model_name=args.action_model,
                device=device,
                attack_name=args.attack,
                eps=args.eps,
                alpha=args.alpha,
                iters=args.iters,
                seed=args.seed + index,
            )
            attacked_frames = attack_result.frames
            print(
                f"  clean_pred={attack_result.clean_pred} adv_pred={attack_result.adv_pred} "
                f"success={attack_result.attack_success} linf={attack_result.linf:.6f}"
            )
            attack_features = score_frames(
                attacked_frames,
                class_names,
                args,
                action_model=action_model,
                clip_model=clip_model,
                clip_processor=clip_processor,
                device=device,
            )
            split = args.attack_split_name or (args.attack if args.attack == "fgsm" else f"pgd{args.iters}")
            write_row(writer, path, label, split, attack_features, args)
            file.flush()
    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
