from __future__ import annotations

import argparse
import csv
from pathlib import Path

from TSC_Detect.utils_metrics import binary_metrics, save_roc_plot


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate TSC-Detect CSV output.")
    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--output-dir", default="outputs/eval_tsc")
    parser.add_argument("--score-column", default="score")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    with Path(args.input_csv).open("r", encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))
    labels = [int(row["is_adv"]) for row in rows]
    scores = [float(row[args.score_column]) for row in rows]
    metrics = binary_metrics(labels, scores)
    metrics_path = output_dir / "metrics.csv"
    with metrics_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(metrics.keys()))
        writer.writeheader()
        writer.writerow(metrics)
    save_roc_plot(labels, scores, output_dir / "roc.png")
    for key, value in metrics.items():
        print(f"{key}: {value:.6f}")
    print(f"Saved {metrics_path}")


if __name__ == "__main__":
    main()

