from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

import numpy as np


@dataclass(frozen=True)
class ActionModelProfile:
    num_frames: int
    sampling_rate: int
    crop_size: int
    slowfast_alpha: int | None = None
    output_is_probability: bool = False


# PyTorchVideo Kinetics model-zoo inference contracts.  Temporal views are
# resampled to the model input length here; video decoding/sampling rate is a
# separate experiment-level concern and must be recorded in the run manifest.
ACTION_MODEL_PROFILES = {
    "csn_r101": ActionModelProfile(num_frames=32, sampling_rate=2, crop_size=224),
    "slowfast_r50": ActionModelProfile(num_frames=32, sampling_rate=2, crop_size=256, slowfast_alpha=4),
    # The hub X3D head includes Softmax; applying another Softmax destroys
    # confidence and KL-based detector features.
    "x3d_m": ActionModelProfile(num_frames=16, sampling_rate=5, crop_size=256, output_is_probability=True),
    "mvit_base_16x4": ActionModelProfile(num_frames=16, sampling_rate=4, crop_size=224),
}


def install_deterministic_attack_pooling(model) -> None:
    """Use exact CPU max-pool autograd during attacks.

    CUDA MaxPool3d backward is nondeterministic for overlapping 3x3 pools in
    MViT and SlowFast. The forward operator remains max-pooling and
    inference remains on CUDA; only gradient-enabled pool calls cross to CPU.
    """
    import torch
    import torch.nn.functional as F

    class DeterministicGradientMaxPool3d(torch.nn.Module):
        def __init__(self, source: torch.nn.MaxPool3d):
            super().__init__()
            self.kernel_size = source.kernel_size
            self.stride = source.stride
            self.padding = source.padding
            self.dilation = source.dilation
            self.ceil_mode = source.ceil_mode

        def forward(self, value):
            kwargs = dict(
                kernel_size=self.kernel_size, stride=self.stride, padding=self.padding,
                dilation=self.dilation, ceil_mode=self.ceil_mode,
            )
            if value.is_cuda and torch.is_grad_enabled() and value.requires_grad:
                return F.max_pool3d(value.to("cpu"), **kwargs).to(value.device)
            return F.max_pool3d(value, **kwargs)

    def replace(module) -> None:
        for name, child in list(module.named_children()):
            if isinstance(child, torch.nn.MaxPool3d):
                setattr(module, name, DeterministicGradientMaxPool3d(child))
            else:
                replace(child)

    replace(model)


install_deterministic_mvit_pooling = install_deterministic_attack_pooling


def _model_name(model, explicit_name: str | None) -> str:
    name = explicit_name or getattr(model, "_tdc_action_model_name", None)
    if name not in ACTION_MODEL_PROFILES:
        raise ValueError(
            "Action model name is required for protocol-correct preprocessing; "
            f"got {name!r}. Expected one of {sorted(ACTION_MODEL_PROFILES)}."
        )
    return str(name)


def process_action_view(view: np.ndarray, model_name: str, device):
    """Convert uint8 RGB [T,H,W,C] frames to a model-zoo compatible input."""
    import torch
    import torch.nn.functional as F

    profile = ACTION_MODEL_PROFILES[model_name]
    if view.ndim != 4 or view.shape[-1] != 3 or len(view) == 0:
        raise ValueError(f"Expected non-empty RGB [T,H,W,C] input, got {view.shape}.")

    video = torch.as_tensor(np.ascontiguousarray(view), device=device)
    video = video.permute(0, 3, 1, 2).float()  # T,C,H,W
    if not np.issubdtype(view.dtype, np.floating) or float(np.max(view)) > 1.0 + 1e-6:
        video.div_(255.0)
    required_span = (profile.num_frames - 1) * profile.sampling_rate + 1
    if len(video) >= required_span:
        start = (len(video) - required_span) // 2
        temporal = start + torch.arange(profile.num_frames, device=device) * profile.sampling_rate
        video = video.index_select(0, temporal)
    else:
        # Frozen short probes are linearly interpolated over their complete
        # temporal support. A native 16/32-frame model clip is an identity case.
        video = video.permute(1, 0, 2, 3).unsqueeze(0)
        video = F.interpolate(
            video,
            size=(profile.num_frames, video.shape[-2], video.shape[-1]),
            mode="trilinear",
            align_corners=True,
        )[0].permute(1, 0, 2, 3)

    height, width = video.shape[-2:]
    short_side = min(height, width)
    scale = profile.crop_size / short_side
    resized_h, resized_w = round(height * scale), round(width * scale)
    video = F.interpolate(video, size=(resized_h, resized_w), mode="bilinear", align_corners=False)
    top = (resized_h - profile.crop_size) // 2
    left = (resized_w - profile.crop_size) // 2
    video = video[:, :, top : top + profile.crop_size, left : left + profile.crop_size]

    mean = video.new_tensor((0.45, 0.45, 0.45)).view(1, 3, 1, 1)
    std = video.new_tensor((0.225, 0.225, 0.225)).view(1, 3, 1, 1)
    video = ((video - mean) / std).permute(1, 0, 2, 3).unsqueeze(0)  # B,C,T,H,W
    if profile.slowfast_alpha is not None:
        slow_indices = torch.linspace(
            0, profile.num_frames - 1, profile.num_frames // profile.slowfast_alpha, device=device
        ).long()
        return [video.index_select(2, slow_indices), video]
    return video


def get_action_probs(
    model,
    view: np.ndarray,
    device,
    process_video_fn=None,
    model_name: str | None = None,
) -> Tuple[np.ndarray, int, float]:
    """Return action-recognition softmax probabilities for a temporal view."""
    import torch

    if process_video_fn is None:
        tensor = process_action_view(view, _model_name(model, model_name), device)
    else:
        tensor = process_video_fn(view, device=device)
    with torch.no_grad():
        output = model(tensor)
        profile = ACTION_MODEL_PROFILES[_model_name(model, model_name)]
        probs_tensor = output if profile.output_is_probability else output.softmax(dim=1)
        probs = probs_tensor[0].detach().cpu().numpy()
    pred_label = int(np.argmax(probs))
    confidence = float(np.max(probs))
    return probs.astype(np.float64), pred_label, confidence


def mock_action_probs(view: np.ndarray, num_classes: int = 400, seed: int = 0) -> Tuple[np.ndarray, int, float]:
    """Deterministic mock for local pipeline checks without loading heavy models."""
    rng = np.random.default_rng(seed + int(np.mean(view)))
    logits = rng.normal(size=num_classes)
    logits -= logits.max()
    probs = np.exp(logits)
    probs /= probs.sum()
    return probs, int(np.argmax(probs)), float(np.max(probs))
