from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Keep only clean/adv pairs where the attack changes AR top-1.")
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--pred-field", default="pred_uniform")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = read_rows(args.inputs)
    if not rows:
        raise SystemExit("No rows to filter.")

    by_video: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        by_video[row["video_path"]].append(row)

    kept: list[dict] = []
    total_pairs = 0
    success_pairs = 0
    for video_rows in by_video.values():
        clean_rows = [row for row in video_rows if int(row["is_adv"]) == 0]
        adv_rows = [row for row in video_rows if int(row["is_adv"]) == 1]
        if not clean_rows:
            continue
        clean = clean_rows[0]
        clean_pred = clean.get(args.pred_field, "")
        for adv in adv_rows:
            total_pairs += 1
            if clean_pred != "" and adv.get(args.pred_field, "") != "" and adv[args.pred_field] != clean_pred:
                kept.append(clean)
                kept.append(adv)
                success_pairs += 1

    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(kept)

    print(f"total_pairs={total_pairs} success_pairs={success_pairs} kept_rows={len(kept)}")
    print(f"Saved {output}")


if __name__ == "__main__":
    main()
