from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build clean-correct VLAD reproduction splits from run_vlad1_repro clean output.")
    parser.add_argument("--input-csv", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--calib-ratio", type=float, default=0.8)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--max-per-class", type=int, default=20)
    parser.add_argument("--min-per-class", type=int, default=3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    with Path(args.input_csv).open("r", encoding="utf-8", newline="") as file:
        rows = [row for row in csv.DictReader(file) if row.get("is_adv") == "0" and row.get("clean_correct") == "1"]

    by_class: dict[str, list[dict]] = {}
    for row in rows:
        by_class.setdefault(row.get("class_name") or row.get("label") or "", []).append(row)

    rng = random.Random(args.seed)
    out_rows: list[dict] = []
    skipped_classes = 0
    for class_name, class_rows in sorted(by_class.items()):
        rng.shuffle(class_rows)
        selected = class_rows[: args.max_per_class]
        if len(selected) < args.min_per_class:
            skipped_classes += 1
            continue
        cut = max(1, min(len(selected) - 1, round(len(selected) * args.calib_ratio)))
        for index, row in enumerate(selected):
            split = "calib" if index < cut else "test"
            out_rows.append(
                {
                    "split": split,
                    "label": row.get("label", class_name),
                    "label_index": row.get("label_index", ""),
                    "class_name": class_name,
                    "path": row["video_path"],
                }
            )

    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["split", "label", "label_index", "class_name", "path"])
        writer.writeheader()
        writer.writerows(out_rows)

    print(f"Saved {len(out_rows)} rows to {output}")
    print(f"Skipped {skipped_classes} classes with fewer than {args.min_per_class} correctly classified videos")


if __name__ == "__main__":
    main()
