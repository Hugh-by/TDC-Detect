from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.run_tsc_detect import choose_device
from TSC_Detect.tsc_action_model import get_action_probs
from TSC_Detect.utils_video import load_frames, read_class_names, read_manifest


FIELDNAMES = [
    "split",
    "label",
    "label_index",
    "class_name",
    "path",
    "action_model",
    "pred_action",
    "pred_action_name",
    "conf_action",
    "clean_correct",
    "error",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Filter a Kinetics manifest to samples correctly classified by an action model.")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--data-root", default=None, help="Prefix for manifest relative_path entries.")
    parser.add_argument("--manifest-splits", nargs="*", default=("val",))
    parser.add_argument("--class-names", default="kinetics-labels.txt")
    parser.add_argument("--output-all", required=True)
    parser.add_argument("--output-correct", required=True)
    parser.add_argument("--action-model", required=True, choices=["csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4"])
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--num-frames", type=int, default=32)
    parser.add_argument("--max-videos", type=int, default=None)
    parser.add_argument("--skip-errors", action="store_true")
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def load_action_model(device: torch.device, action_model_name: str) -> torch.nn.Module:
    import pytorchvideo.models.hub as models

    factories = {
        "csn_r101": models.csn_r101,
        "slowfast_r50": models.slowfast_r50,
        "x3d_m": models.x3d_m,
        "mvit_base_16x4": models.mvit_base_16x4,
    }
    base_model = factories[action_model_name](True).eval().to(device)
    base_model._tdc_action_model_name = action_model_name
    return base_model


def parse_label_index(row: dict, class_names: list[str]) -> int | None:
    raw = row.get("label_index") or row.get("label_id") or row.get("target") or ""
    if raw != "":
        try:
            return int(raw)
        except ValueError:
            pass
    label = row.get("label") or row.get("class_name") or ""
    if label in class_names:
        return class_names.index(label)
    return None


def name_at(class_names: list[str], index: int | None) -> str:
    if index is None or index < 0 or index >= len(class_names):
        return ""
    return class_names[index]


def completed_paths(path: Path) -> set[str]:
    if not path.exists():
        return set()
    with path.open("r", encoding="utf-8", newline="") as file:
        return {row["path"] for row in csv.DictReader(file) if row.get("path")}


def rewrite_correct(output_all: Path, output_correct: Path) -> int:
    output_correct.parent.mkdir(parents=True, exist_ok=True)
    count = 0
    with output_all.open("r", encoding="utf-8", newline="") as src, output_correct.open("w", encoding="utf-8", newline="") as dst:
        reader = csv.DictReader(src)
        writer = csv.DictWriter(dst, fieldnames=FIELDNAMES)
        writer.writeheader()
        for row in reader:
            if row.get("clean_correct") == "1":
                writer.writerow(row)
                count += 1
    return count


def main() -> None:
    args = parse_args()
    class_names = read_class_names(args.class_names)
    rows = read_manifest(args.manifest, args.manifest_splits, args.max_videos)
    output_all = Path(args.output_all)
    output_correct = Path(args.output_correct)
    output_all.parent.mkdir(parents=True, exist_ok=True)

    done = completed_paths(output_all) if args.resume else set()
    mode = "a" if args.resume and output_all.exists() else "w"
    needs_header = mode == "w" or output_all.stat().st_size == 0

    device = choose_device(args.device)
    torch.backends.cudnn.benchmark = True
    model = load_action_model(device, args.action_model)

    with output_all.open(mode, encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        if needs_header:
            writer.writeheader()
        for index, row in enumerate(rows, 1):
            path = row.get("path") or row.get("video_path")
            if not path and row.get("relative_path") and args.data_root:
                path = str(Path(args.data_root) / row["relative_path"])
            if not path:
                raise ValueError("Manifest row needs path/video_path or relative_path with --data-root")
            if path in done:
                continue
            label_idx = parse_label_index(row, class_names)
            print(f"[{index}/{len(rows)}] {args.action_model}: {path}", flush=True)
            try:
                frames = load_frames(path)
                _, pred, conf = get_action_probs(model, frames, device)
                correct = int(label_idx is not None and pred == label_idx)
                error = ""
            except Exception as exc:
                if not args.skip_errors:
                    raise
                pred = -1
                conf = 0.0
                correct = 0
                error = f"{type(exc).__name__}: {exc}"
                print(f"Skipping failed video: {path} ({error})", flush=True)

            writer.writerow(
                {
                    "split": row.get("split", ""),
                    "label": row.get("label", ""),
                    "label_index": "" if label_idx is None else label_idx,
                    "class_name": row.get("class_name") or row.get("label", ""),
                    "path": path,
                    "action_model": args.action_model,
                    "pred_action": "" if pred < 0 else pred,
                    "pred_action_name": name_at(class_names, pred),
                    "conf_action": conf,
                    "clean_correct": correct,
                    "error": error,
                }
            )
            file.flush()
            if str(device).startswith("cuda"):
                torch.cuda.empty_cache()

    correct_count = rewrite_correct(output_all, output_correct)
    print(f"Saved all predictions to {output_all}")
    print(f"Saved {correct_count} clean-correct rows to {output_correct}")


if __name__ == "__main__":
    main()
