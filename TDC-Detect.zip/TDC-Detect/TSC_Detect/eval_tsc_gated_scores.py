from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.tsc_calibration import matrix_from_rows
from TSC_Detect.utils_metrics import binary_metrics


FEATURES = [
    "vlad_original",
    "R_uniform_shift",
    "R_model",
    "R_label_change",
    "R_conf_var",
    "R_sem_var",
]


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def clean_stats(rows: list[dict]) -> tuple[np.ndarray, np.ndarray]:
    x = matrix_from_rows(rows, FEATURES)
    return x.mean(axis=0), np.maximum(x.std(axis=0), 1e-6)


def positive_z(rows: list[dict], mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    x = matrix_from_rows(rows, FEATURES)
    return np.maximum((x - mean) / std, 0.0)


def bell_gate(z_vlad: np.ndarray, center: float, width: float) -> np.ndarray:
    width = max(float(width), 1e-6)
    return np.exp(-0.5 * ((z_vlad - center) / width) ** 2)


def window_gate(z_vlad: np.ndarray, low: float, high: float, softness: float = 0.5) -> np.ndarray:
    softness = max(float(softness), 1e-6)
    left = 1.0 / (1.0 + np.exp(-(z_vlad - low) / softness))
    right = 1.0 / (1.0 + np.exp((z_vlad - high) / softness))
    return left * right


def score_variants(rows: list[dict], calib_rows: list[dict]) -> dict[str, np.ndarray]:
    mean, std = clean_stats(calib_rows)
    z = positive_z(rows, mean, std)
    calib_z = positive_z(calib_rows, mean, std)
    idx = {name: i for i, name in enumerate(FEATURES)}

    z_vlad = z[:, idx["vlad_original"]]
    temporal = (
        0.45 * z[:, idx["R_uniform_shift"]]
        + 0.25 * z[:, idx["R_model"]]
        + 0.20 * z[:, idx["R_label_change"]]
        + 0.10 * z[:, idx["R_conf_var"]]
    )
    temporal_sem = temporal + 0.15 * z[:, idx["R_sem_var"]]

    calib_vlad = calib_z[:, idx["vlad_original"]]
    q75 = float(np.quantile(calib_vlad, 0.75))
    q90 = float(np.quantile(calib_vlad, 0.90))
    q95 = float(np.quantile(calib_vlad, 0.95))
    q975 = float(np.quantile(calib_vlad, 0.975))
    width = max(q975 - q75, 0.75)

    gate_q90 = bell_gate(z_vlad, center=q90, width=width)
    gate_q95 = bell_gate(z_vlad, center=q95, width=width)
    gate_window = window_gate(z_vlad, low=q75, high=q975, softness=0.5)

    raw_vlad = np.asarray([float(row["vlad_original"]) for row in rows], dtype=np.float64)
    current = np.asarray([float(row["score"]) for row in rows], dtype=np.float64)

    return {
        "vlad_original": raw_vlad,
        "z_vlad_clean": z_vlad,
        "tsc_score_current": current,
        "gated_q90_light": z_vlad + 0.10 * gate_q90 * temporal,
        "gated_q90_medium": z_vlad + 0.20 * gate_q90 * temporal,
        "gated_q95_light": z_vlad + 0.10 * gate_q95 * temporal,
        "gated_q95_sem": z_vlad + 0.12 * gate_q95 * temporal_sem,
        "gated_window_light": z_vlad + 0.10 * gate_window * temporal,
        "gated_window_sem": z_vlad + 0.12 * gate_window * temporal_sem,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate clean-calibrated gated TSC correction scores.")
    parser.add_argument("--calib-clean", required=True)
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--names", nargs="+", default=None)
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_gated_score_summary.csv")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    calib_rows = read_rows([args.calib_clean])
    names = args.names or [Path(path).stem for path in args.inputs]
    if len(names) != len(args.inputs):
        raise SystemExit("--names length must match --inputs length.")

    out_rows = []
    for path, setting in zip(args.inputs, names):
        rows = read_rows([path])
        labels = [int(row["is_adv"]) for row in rows]
        n_clean = sum(label == 0 for label in labels)
        n_adv = sum(label == 1 for label in labels)
        for method, scores in score_variants(rows, calib_rows).items():
            out_rows.append(
                {
                    "setting": setting,
                    "method": method,
                    "n_clean": n_clean,
                    "n_adv": n_adv,
                    **binary_metrics(labels, scores),
                }
            )

    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "setting",
        "method",
        "n_clean",
        "n_adv",
        "roc_auc",
        "pr_auc",
        "fpr_at_95_tpr",
        "tpr_at_1_fpr",
        "clean_mean",
        "clean_std",
        "adv_mean",
        "adv_std",
    ]
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(out_rows)

    for row in out_rows:
        print(
            f"{row['setting']:12s} {row['method']:22s} "
            f"AUC={row['roc_auc']:.4f} PR={row['pr_auc']:.4f} "
            f"FPR95={row['fpr_at_95_tpr']:.3f} TPR1={row['tpr_at_1_fpr']:.3f}"
        )
    print(f"Saved {output}")


if __name__ == "__main__":
    main()

