from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.eval_tsc_v2_features import collect_scores
from TSC_Detect.utils_metrics import binary_metrics


ATTACKS = [
    ("fgsm_eps001", "FGSM eps=0.01"),
    ("fgsm", "FGSM eps=0.03"),
    ("fgsm_eps005", "FGSM eps=0.05"),
    ("pgd5_eps003", "PGD5 eps=0.03"),
    ("pgd10_eps003", "PGD10 eps=0.03"),
    ("pgd40", "PGD40 eps=0.03"),
]


def read_rows(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def success_paths_from_vlad(rows: list[dict]) -> set[str]:
    return {
        row["video_path"]
        for row in rows
        if int(row["is_adv"]) == 1 and str(row.get("attack_success", "")) in {"1", "1.0", "True", "true"}
    }


def filter_setting(rows: list[dict], setting: str, success_paths: set[str]) -> list[dict]:
    if setting == "full":
        return rows
    return [row for row in rows if int(row["is_adv"]) == 0 or row["video_path"] in success_paths]


def assert_same_rows(vlad_rows: list[dict], tsc_rows: list[dict], tag: str, setting: str) -> None:
    for is_adv in (0, 1):
        v = {row["video_path"] for row in vlad_rows if int(row["is_adv"]) == is_adv}
        t = {row["video_path"] for row in tsc_rows if int(row["is_adv"]) == is_adv}
        if v != t:
            raise ValueError(f"{tag} {setting} is_adv={is_adv}: pure_only={len(v-t)} tsc_only={len(t-v)}")


def metric_row(
    *,
    attack: str,
    setting: str,
    method: str,
    labels: np.ndarray,
    scores: np.ndarray,
    pure_auc: float,
) -> dict:
    metric = binary_metrics(labels, scores)
    return {
        "attack": attack,
        "setting": setting,
        "method": method,
        "n_clean": int(np.sum(labels == 0)),
        "n_adv": int(np.sum(labels == 1)),
        "roc_auc": metric["roc_auc"],
        "pr_auc": metric["pr_auc"],
        "fpr_at_95_tpr": metric["fpr_at_95_tpr"],
        "tpr_at_1_fpr": metric["tpr_at_1_fpr"],
        "delta_vs_pure_vlad": metric["roc_auc"] - pure_auc,
    }


def build_rows(args: argparse.Namespace) -> list[dict]:
    out: list[dict] = []
    base = Path(args.outputs_dir)
    for tag, label in ATTACKS:
        vlad_path = base / f"vlad1_sym_kinetics400_40c50_{tag}_raw.csv"
        tsc_path = base / f"tsc_v2_kinetics400_40c50_{tag}.csv"
        if not vlad_path.exists() or not tsc_path.exists():
            print(f"Skipping missing attack {tag}: {vlad_path.exists()=} {tsc_path.exists()=}")
            continue
        vlad_all = read_rows(vlad_path)
        tsc_all = read_rows(tsc_path)
        success_paths = success_paths_from_vlad(vlad_all)
        for setting in ("full", "success_only"):
            vlad_rows = filter_setting(vlad_all, setting, success_paths)
            tsc_rows = filter_setting(tsc_all, setting, success_paths)
            assert_same_rows(vlad_rows, tsc_rows, tag, setting)
            labels = np.asarray([int(row["is_adv"]) for row in vlad_rows], dtype=np.int64)
            pure_scores = np.asarray([float(row["vlad1_score"]) for row in vlad_rows], dtype=np.float64)
            pure_auc = binary_metrics(labels, pure_scores)["roc_auc"]
            out.append(metric_row(attack=label, setting=setting, method="Pure VLAD-1", labels=labels, scores=pure_scores, pure_auc=pure_auc))
            scores_by_name = collect_scores(
                tsc_rows,
                steps=args.logistic_steps,
                lr=args.logistic_lr,
                l2=args.logistic_l2,
                include_lovo=True,
            )
            for score_name, method in [
                ("vlad_original", "TSC path VLAD"),
                ("logistic_v1_lovo", "TSC v1 LOVO"),
                ("logistic_v2_lovo", "TSC v2 LOVO"),
            ]:
                out.append(metric_row(attack=label, setting=setting, method=method, labels=labels, scores=scores_by_name[score_name], pure_auc=pure_auc))
    return out


def write_csv(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {path}")


def write_markdown(path: Path, rows: list[dict]) -> None:
    lines = [
        "# Kinetics-400 40c50 Attack-Strength Table - 2026-06-05",
        "",
        "| Attack | Setting | Method | Clean | Adv | ROC-AUC | Delta vs Pure VLAD |",
        "|---|---|---|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            f"| {row['attack']} | {row['setting']} | {row['method']} | {row['n_clean']} | {row['n_adv']} | {row['roc_auc']:.4f} | {row['delta_vs_pure_vlad']:+.4f} |"
        )
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved {path}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build K400 40c50 attack-strength table after all attack runs finish.")
    parser.add_argument("--outputs-dir", default="/root/autodl-tmp/tsc/outputs")
    parser.add_argument("--output-csv", default="/root/autodl-tmp/tsc/outputs/kinetics400_40c50_attack_strength_table.csv")
    parser.add_argument("--output-md", default="/root/TSC/docs/kinetics400_40c50_attack_strength_table_2026-06-05.md")
    parser.add_argument("--logistic-steps", type=int, default=1500)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = build_rows(args)
    if not rows:
        raise SystemExit("No rows built.")
    write_csv(Path(args.output_csv), rows)
    write_markdown(Path(args.output_md), rows)


if __name__ == "__main__":
    main()
