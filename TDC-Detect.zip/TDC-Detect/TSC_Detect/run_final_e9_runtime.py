from __future__ import annotations

import argparse
import csv
import sys
import time
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_final_extract import PROTOCOL_ID, SEED
from TSC_Detect.run_temporal_shuffle_probe import score_temporal_shuffle
from TSC_Detect.run_tsc_detect import choose_device, score_frames
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES, get_action_probs, install_deterministic_attack_pooling
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES, get_vlm_context_probs
from TSC_Detect.utils_video import load_frames, read_class_names


METHODS = ("action_only", "temporal_shuffle", "strict_vlad", "tdc_v2")
FIELDS = ["protocol_id", "experiment", "dataset", "action_model", "method", "repeat", "video_index", "relative_path", "seconds", "peak_memory_bytes"]


def load_action_model(device, name: str):
    import pytorchvideo.models.hub as models

    factories = {
        "csn_r101": models.csn_r101, "slowfast_r50": models.slowfast_r50,
        "x3d_m": models.x3d_m, "mvit_base_16x4": models.mvit_base_16x4,
    }
    model = factories[name](True).eval().to(device)
    install_deterministic_attack_pooling(model)
    model._tdc_action_model_name = name
    for parameter in model.parameters(): parameter.requires_grad_(False)
    return model


def load_clip(device):
    from transformers import CLIPModel, CLIPProcessor

    model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").eval().to(device)
    for parameter in model.parameters(): parameter.requires_grad_(False)
    return model, CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--dataset", choices=["k400", "ucf101"], required=True)
    parser.add_argument("--model", choices=sorted(ACTION_MODEL_PROFILES), required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--warmups", type=int, default=10)
    parser.add_argument("--repeats", type=int, default=5)
    args = parser.parse_args()
    device = choose_device(args.device)
    torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True, warn_only=True)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    classes = read_class_names(args.class_names)
    action_model = load_action_model(device, args.model)
    clip_model = clip_processor = None
    with args.manifest.open(encoding="utf-8-sig", newline="") as handle: rows = list(csv.DictReader(handle))
    if len(rows) != 100:
        raise ValueError(f"E9 requires exactly 100 fixed clean clips, got {len(rows)} from {args.manifest}")
    prepared = []
    for row in rows:
        rgb = prepare_attack_frames(load_frames(row["path"]), args.model, device).detach().cpu().numpy().astype(np.float32)
        prepared.append((row, rgb))
    score_args = argparse.Namespace(
        seed=SEED, protocol_id=PROTOCOL_ID, num_frames=ACTION_MODEL_PROFILES[args.model].num_frames,
        num_random=0, max_global_views=None, base_views_only=False, num_local_windows=4,
        local_window_frames=None, mock_models=False, prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
        prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8,
    )

    def call(method: str, rgb: np.ndarray) -> None:
        if method == "action_only":
            get_action_probs(action_model, rgb, device)
        elif method == "strict_vlad":
            get_action_probs(action_model, rgb, device)
            get_vlm_context_probs(clip_model, clip_processor, rgb, classes, device, prompt_template=DEFAULT_PROMPT_TEMPLATES[0], prompt_templates=None, max_clip_frames=32)
        elif method == "temporal_shuffle":
            score_temporal_shuffle(rgb, action_model, device, clean_pred_reference=None)
        elif method == "tdc_v2":
            score_frames(rgb, classes, score_args, action_model, clip_model, clip_processor, device)
        else:
            raise KeyError(method)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS); writer.writeheader()
        for method in METHODS:
            if method in {"strict_vlad", "tdc_v2"} and clip_model is None:
                clip_model, clip_processor = load_clip(device)
            for index in range(args.warmups):
                call(method, prepared[index % len(prepared)][1])
            torch.cuda.synchronize(device)
            for repeat in range(args.repeats):
                for index, (row, rgb) in enumerate(prepared):
                    torch.cuda.reset_peak_memory_stats(device); torch.cuda.synchronize(device)
                    start = time.perf_counter(); call(method, rgb); torch.cuda.synchronize(device)
                    writer.writerow({"protocol_id": PROTOCOL_ID, "experiment": "E9", "dataset": args.dataset, "action_model": args.model, "method": method, "repeat": repeat, "video_index": index, "relative_path": row["relative_path"], "seconds": time.perf_counter() - start, "peak_memory_bytes": torch.cuda.max_memory_allocated(device)})
                    handle.flush()
                print(f"E9 {args.dataset}/{args.model}/{method} repeat {repeat + 1}/{args.repeats}", flush=True)


if __name__ == "__main__": main()
