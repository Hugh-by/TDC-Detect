from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames
from TSC_Detect.hevc_codec import hevc_roundtrip_frames
from TSC_Detect.run_tsc_detect import FIELDNAMES, choose_device, load_real_models, score_frames
from TSC_Detect.tsc_features import score_features
from TSC_Detect.utils_video import load_frames, read_class_names, read_manifest, sample_or_pad


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate clean/attack TSC rows after HEVC recompression.")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--manifest-splits", nargs="*", default=("test",))
    parser.add_argument("--class-names", default="kinetics-labels.txt")
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--max-videos", type=int, default=5)
    parser.add_argument("--num-frames", type=int, default=32)
    parser.add_argument("--num-random", type=int, default=1)
    parser.add_argument("--device", default="cpu", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--attack", default="fgsm", choices=["fgsm", "pgd"])
    parser.add_argument("--attack-split-name", default=None)
    parser.add_argument("--eps", type=float, default=0.03)
    parser.add_argument("--alpha", type=float, default=2 / 255)
    parser.add_argument("--iters", type=int, default=1)
    parser.add_argument("--score-mode", default="max_evidence", choices=["max_evidence", "sum", "logsumexp"])
    parser.add_argument("--prompt-template", default="a video of a person {}")
    parser.add_argument("--prompt-templates", nargs="*", default=None)
    parser.add_argument("--max-clip-frames", type=int, default=8)
    parser.add_argument("--base-views-only", action="store_true")
    parser.add_argument("--num-local-windows", type=int, default=0)
    parser.add_argument("--local-window-frames", type=int, default=None)
    parser.add_argument("--hevc-crf", type=int, default=28)
    parser.add_argument("--hevc-preset", default="medium")
    parser.add_argument("--hevc-fps", type=int, default=8)
    parser.add_argument("--hevc-work-dir", default="/root/autodl-tmp/tsc/tmp/hevc_roundtrip")
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def tensor_to_frames(video: torch.Tensor) -> np.ndarray:
    frames = video.detach().clamp(0, 1)
    frames = (frames[0].permute(1, 2, 3, 0) * 255).round().to(torch.uint8)
    return frames.cpu().numpy()


def write_row(writer: csv.DictWriter, path: Path, label: str, split: str, features: dict, args: argparse.Namespace) -> None:
    is_adv = "0" if split == "clean" else "1"
    row = {
        "video_path": str(path),
        "label": label,
        "is_adv": is_adv,
        "score": score_features(features, mode=args.score_mode),
        "score_mode": args.score_mode,
        **features,
    }
    writer.writerow({name: row.get(name, "") for name in FIELDNAMES})


def score_hevc_frames(
    frames: np.ndarray,
    class_names: list[str],
    args: argparse.Namespace,
    *,
    action_model,
    clip_model,
    clip_processor,
    device,
) -> dict:
    hevc_frames = hevc_roundtrip_frames(
        frames,
        crf=args.hevc_crf,
        preset=args.hevc_preset,
        fps=args.hevc_fps,
        work_dir=args.hevc_work_dir,
        num_frames=args.num_frames,
    )
    return score_frames(
        hevc_frames,
        class_names,
        args,
        action_model=action_model,
        clip_model=clip_model,
        clip_processor=clip_processor,
        device=device,
    )


def main() -> None:
    args = parse_args()
    args.mock_models = False
    device = choose_device(args.device)
    class_names = read_class_names(args.class_names)
    action_model, clip_model, clip_processor = load_real_models(device)
    rows = read_manifest(args.manifest, args.manifest_splits, args.max_videos)
    output_path = Path(args.output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with output_path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        writer.writeheader()
        for index, row in enumerate(rows, 1):
            path = Path(row["path"])
            label = row.get("label", "")
            print(f"[{index}/{len(rows)}] hevc clean+{args.attack}: {path}")
            raw = load_frames(path)
            clean_frames = prepare_attack_frames(raw, "csn_r101", device).mul(255).round().to(torch.uint8).cpu().numpy()
            clean_features = score_hevc_frames(
                clean_frames,
                class_names,
                args,
                action_model=action_model,
                clip_model=clip_model,
                clip_processor=clip_processor,
                device=device,
            )
            write_row(writer, path, label, "clean", clean_features, args)
            file.flush()

            attack_result = make_attack(
                action_model,
                raw,
                model_name="csn_r101",
                device=device,
                attack_name=args.attack,
                eps=args.eps,
                alpha=args.alpha,
                iters=args.iters,
                seed=args.seed + index,
            )
            attacked_frames = attack_result.frames
            attack_features = score_hevc_frames(
                attacked_frames,
                class_names,
                args,
                action_model=action_model,
                clip_model=clip_model,
                clip_processor=clip_processor,
                device=device,
            )
            split = args.attack_split_name or (args.attack if args.attack == "fgsm" else f"pgd{args.iters}")
            write_row(writer, path, label, split, attack_features, args)
            file.flush()
    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
