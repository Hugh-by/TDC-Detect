from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import torch
import torch.nn.functional as F

from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES


@dataclass(frozen=True)
class AttackResult:
    frames: np.ndarray
    rgb: np.ndarray
    clean_pred: int
    adv_pred: int
    clean_conf: float
    adv_conf: float
    linf: float
    attack_success: bool
    attacked_frame: int | None = None


def prepare_attack_frames(frames: np.ndarray, model_name: str, device) -> torch.Tensor:
    """Return native model clip as RGB [T,H,W,C] float values in [0,1]."""
    profile = ACTION_MODEL_PROFILES[model_name]
    if frames.ndim != 4 or frames.shape[-1] != 3 or len(frames) == 0:
        raise ValueError(f"Expected non-empty RGB [T,H,W,C], got {frames.shape}.")
    value = torch.as_tensor(np.ascontiguousarray(frames), device=device).float().div_(255.0)
    required_span = (profile.num_frames - 1) * profile.sampling_rate + 1
    if len(value) >= required_span:
        start = (len(value) - required_span) // 2
        indices = start + torch.arange(profile.num_frames, device=device) * profile.sampling_rate
    else:
        indices = torch.linspace(0, len(value) - 1, profile.num_frames, device=device).long()
    value = value.index_select(0, indices).permute(0, 3, 1, 2)
    height, width = value.shape[-2:]
    scale = profile.crop_size / min(height, width)
    resized_h, resized_w = round(height * scale), round(width * scale)
    value = F.interpolate(value, (resized_h, resized_w), mode="bilinear", align_corners=False)
    top, left = (resized_h - profile.crop_size) // 2, (resized_w - profile.crop_size) // 2
    return value[:, :, top : top + profile.crop_size, left : left + profile.crop_size].permute(0, 2, 3, 1)


def model_input(rgb: torch.Tensor, model_name: str):
    """Apply the same normalization/pathway contract as inference to prepared RGB."""
    profile = ACTION_MODEL_PROFILES[model_name]
    value = rgb.permute(0, 3, 1, 2)
    mean = value.new_tensor((0.45, 0.45, 0.45)).view(1, 3, 1, 1)
    std = value.new_tensor((0.225, 0.225, 0.225)).view(1, 3, 1, 1)
    value = ((value - mean) / std).permute(1, 0, 2, 3).unsqueeze(0)
    if profile.slowfast_alpha is None:
        return value
    indices = torch.linspace(
        0, profile.num_frames - 1, profile.num_frames // profile.slowfast_alpha, device=value.device
    ).long()
    return [value.index_select(2, indices), value]


def probabilities(model, rgb: torch.Tensor, model_name: str) -> torch.Tensor:
    output = model(model_input(rgb, model_name))
    if ACTION_MODEL_PROFILES[model_name].output_is_probability:
        return output.clamp_min(1e-12)
    return output.softmax(dim=1)


def _untargeted_loss(model, rgb: torch.Tensor, model_name: str, label: torch.Tensor) -> torch.Tensor:
    probs = probabilities(model, rgb, model_name)
    return -probs[0, label].log()


def make_attack(
    model,
    frames: np.ndarray,
    model_name: str,
    device,
    attack_name: str,
    eps: float = 0.03,
    alpha: float = 2 / 255,
    iters: int = 1,
    seed: int = 0,
) -> AttackResult:
    """Create an untargeted white-box attack in raw RGB [0,1] space.

    `ofa` changes one temporal frame only. `flick` learns one spatially
    constant RGB offset per frame. All attacks obey an L-inf RGB budget.
    """
    if attack_name not in {"fgsm", "pgd", "ofa", "flick"}:
        raise ValueError(f"Unknown attack: {attack_name}")
    if eps < 0 or alpha <= 0 or iters <= 0:
        raise ValueError("Require eps >= 0, alpha > 0, and iters > 0.")

    clean = prepare_attack_frames(frames, model_name, device).detach()
    with torch.no_grad():
        clean_probs = probabilities(model, clean, model_name)[0]
    clean_pred = int(clean_probs.argmax())
    label = torch.tensor(clean_pred, device=device)
    steps = 1 if attack_name == "fgsm" else iters
    step_size = eps if attack_name == "fgsm" else alpha
    attacked_frame: int | None = None

    if attack_name == "flick":
        delta = torch.zeros((len(clean), 1, 1, 3), device=device, requires_grad=True)
    else:
        delta = torch.zeros_like(clean, requires_grad=True)
        if attack_name == "pgd" and eps:
            generator = torch.Generator(device=device).manual_seed(seed)
            delta.data.uniform_(-eps, eps, generator=generator)
            delta.data.copy_((clean + delta.data).clamp(0, 1) - clean)

    for _ in range(steps):
        adv = (clean + delta).clamp(0, 1)
        loss = _untargeted_loss(model, adv, model_name, label)
        gradient = torch.autograd.grad(loss, delta, only_inputs=True)[0]
        if attack_name == "ofa":
            if attacked_frame is None:
                attacked_frame = int(gradient.abs().flatten(1).mean(1).argmax())
            mask = torch.zeros_like(gradient)
            mask[attacked_frame] = 1
            gradient = gradient * mask
        delta = (delta.detach() + step_size * gradient.sign()).clamp(-eps, eps)
        if attack_name == "flick":
            delta = delta.requires_grad_(True)
        else:
            delta = ((clean + delta).clamp(0, 1) - clean).detach().requires_grad_(True)

    adv = (clean + delta.detach()).clamp(0, 1)
    with torch.no_grad():
        adv_probs = probabilities(model, adv, model_name)[0]
    frames_out = (adv * 255).round().to(torch.uint8).cpu().numpy()
    return AttackResult(
        frames=frames_out,
        rgb=adv.detach().cpu().numpy().astype(np.float32),
        clean_pred=clean_pred,
        adv_pred=int(adv_probs.argmax()),
        clean_conf=float(clean_probs.max()),
        adv_conf=float(adv_probs.max()),
        linf=float((adv - clean).abs().max()),
        attack_success=int(adv_probs.argmax()) != clean_pred,
        attacked_frame=attacked_frame,
    )
