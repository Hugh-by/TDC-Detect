from __future__ import annotations

import argparse
import csv
import hashlib
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames, probabilities
from TSC_Detect.run_tsc_detect import FIELDNAMES, choose_device, load_real_models, score_frames
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES
from TSC_Detect.tsc_action_model import get_action_probs
from TSC_Detect.tsc_features import score_features, symmetric_kl
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES, get_vlm_context_probs
from TSC_Detect.run_temporal_shuffle_probe import score_temporal_shuffle
from TSC_Detect.utils_video import load_frames, read_class_names


PROTOCOL_ID = "tdc-final-20260714"
SEED = 20260714
ATTACK_SETTINGS = {
    "fgsm": {"internal": "fgsm", "eps": 8 / 255, "alpha": 8 / 255, "iters": 1},
    "pgd": {"internal": "pgd", "eps": 8 / 255, "alpha": 2 / 255, "iters": 40},
    "ofa-style": {"internal": "ofa", "eps": 8 / 255, "alpha": 2 / 255, "iters": 10},
    "flicker-style": {"internal": "flick", "eps": 8 / 255, "alpha": 2 / 255, "iters": 10},
}

METADATA_FIELDS = [
    "protocol_id", "dataset", "action_model", "partition", "pair_id", "relative_path",
    "video_path", "label", "row_type", "is_adv", "attack", "attack_seed", "epsilon",
    "alpha", "steps", "clip_frames", "clean_pred", "clean_conf", "attacked_pred",
    "attacked_conf", "attack_success", "selected_frame", "measured_linf", "score", "score_mode",
]
OUTPUT_FIELDS = METADATA_FIELDS + [field for field in FIELDNAMES if field not in {"video_path", "label", "is_adv", "score", "score_mode"}]
BASELINE_FIELDS = [
    "strict_vlad1", "strict_vlad2", "prompt_matched_vlad",
    "ts_prob_shift_mean", "ts_prob_shift_max", "ts_label_change", "ts_conf_drop",
    "ts_conf_var", "ts_vote_entropy", "ts_defense_vote_pred", "num_shuffle_views",
]
OUTPUT_FIELDS += BASELINE_FIELDS


def stable_seed(relative_path: str, model: str, attack: str) -> int:
    digest = hashlib.sha256(f"{relative_path}|{model}|{attack}|{SEED}".encode()).digest()
    return (SEED + int.from_bytes(digest[:4], "little")) % (2**31)


def read_manifest(path: Path, partition: str, max_videos: int | None) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = [row for row in csv.DictReader(handle) if row.get("split") == partition]
    return rows[:max_videos] if max_videos else rows


def completed_rows(path: Path) -> set[tuple[str, str]]:
    if not path.exists():
        return set()
    with path.open("r", encoding="utf-8", newline="") as handle:
        return {(row["pair_id"], row["attack"]) for row in csv.DictReader(handle)}


def feature_row(base: dict[str, object], features: dict[str, float], score_mode: str) -> dict[str, object]:
    return {**base, "score": score_features(features, mode=score_mode), "score_mode": score_mode, **features}


def all_features(frames: np.ndarray, class_names: list[str], score_args: argparse.Namespace, action_model, clip_model, clip_processor, device, video_id: str, clean_pred: int) -> dict[str, float]:
    features = score_frames(frames, class_names, score_args, action_model, clip_model, clip_processor, device, video_id)
    action_probs, pred, _ = get_action_probs(action_model, frames, device)
    strict_vlm = get_vlm_context_probs(
        clip_model, clip_processor, frames, class_names, device,
        prompt_template=DEFAULT_PROMPT_TEMPLATES[0], prompt_templates=None, max_clip_frames=32,
    )
    onehot = np.zeros_like(action_probs)
    onehot[pred] = 1.0
    temporal = score_temporal_shuffle(frames, action_model, device, clean_pred_reference=clean_pred)
    features.update({
        "strict_vlad1": symmetric_kl(action_probs, strict_vlm),
        "strict_vlad2": symmetric_kl(onehot, strict_vlm),
        "prompt_matched_vlad": features["vlad_original"],
        **{name: temporal[name] for name in BASELINE_FIELDS if name in temporal},
    })
    return features


def main() -> None:
    parser = argparse.ArgumentParser(description="Unified extractor for protocol tdc-final-20260714")
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--dataset", choices=["k400", "ucf101"], required=True)
    parser.add_argument("--partition", choices=["calibration", "test"], required=True)
    parser.add_argument("--action-model", choices=sorted(ACTION_MODEL_PROFILES), required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output-csv", type=Path, required=True)
    parser.add_argument("--attacks", nargs="+", choices=sorted(ATTACK_SETTINGS), default=list(ATTACK_SETTINGS))
    parser.add_argument("--max-videos", type=int)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--mock-models", action="store_true")
    args = parser.parse_args()

    device = choose_device(args.device)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True, warn_only=True)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    class_names = read_class_names(args.class_names)
    action_model, clip_model, clip_processor = load_real_models(device, args.action_model)
    rows = read_manifest(args.manifest, args.partition, args.max_videos)

    score_args = argparse.Namespace(
        seed=SEED,
        protocol_id=PROTOCOL_ID,
        num_frames=ACTION_MODEL_PROFILES[args.action_model].num_frames,
        num_random=0,
        max_global_views=None,
        base_views_only=False,
        num_local_windows=4,
        local_window_frames=None,
        mock_models=False,
        prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
        prompt_templates=DEFAULT_PROMPT_TEMPLATES,
        max_clip_frames=8,
    )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    done = completed_rows(args.output_csv) if args.resume else set()
    mode = "a" if args.resume and args.output_csv.exists() else "w"
    needs_header = mode == "w" or args.output_csv.stat().st_size == 0

    with args.output_csv.open(mode, encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=OUTPUT_FIELDS)
        if needs_header:
            writer.writeheader()
        for index, manifest_row in enumerate(rows, 1):
            path = Path(manifest_row["path"])
            relative_path = manifest_row.get("relative_path") or path.name
            pair_id = hashlib.sha256(f"{args.dataset}|{args.action_model}|{relative_path}".encode()).hexdigest()
            print(f"[{index}/{len(rows)}] {args.dataset}/{args.action_model}/{args.partition}: {relative_path}", flush=True)
            source_frames = load_frames(path)
            clean_tensor = prepare_attack_frames(source_frames, args.action_model, device).detach()
            clean_rgb = clean_tensor.cpu().numpy().astype(np.float32)
            with torch.no_grad():
                clean_probs = probabilities(action_model, clean_tensor, args.action_model)[0]
            clean_pred = int(clean_probs.argmax())
            clean_conf = float(clean_probs.max())
            common = {
                "protocol_id": PROTOCOL_ID,
                "dataset": args.dataset,
                "action_model": args.action_model,
                "partition": args.partition,
                "pair_id": pair_id,
                "relative_path": relative_path,
                "video_path": str(path),
                "label": manifest_row.get("label", ""),
                "clip_frames": ACTION_MODEL_PROFILES[args.action_model].num_frames,
                "clean_pred": clean_pred,
                "clean_conf": clean_conf,
            }
            if (pair_id, "clean") not in done:
                features = all_features(clean_rgb, class_names, score_args, action_model, clip_model, clip_processor, device, str(path), clean_pred)
                writer.writerow({field: feature_row({**common, "row_type": "clean", "is_adv": 0, "attack": "clean"}, features, "max_evidence").get(field, "") for field in OUTPUT_FIELDS})
                handle.flush()

            for attack in args.attacks:
                if (pair_id, attack) in done:
                    continue
                setting = ATTACK_SETTINGS[attack]
                attack_seed = stable_seed(relative_path, args.action_model, attack)
                result = make_attack(
                    action_model, source_frames, args.action_model, device, setting["internal"],
                    eps=setting["eps"], alpha=setting["alpha"], iters=setting["iters"], seed=attack_seed,
                )
                features = all_features(result.rgb, class_names, score_args, action_model, clip_model, clip_processor, device, str(path), clean_pred)
                base = {
                    **common,
                    "row_type": "adversarial", "is_adv": 1, "attack": attack,
                    "attack_seed": attack_seed, "epsilon": setting["eps"], "alpha": setting["alpha"],
                    "steps": setting["iters"], "attacked_pred": result.adv_pred,
                    "attacked_conf": result.adv_conf, "attack_success": int(result.attack_success),
                    "selected_frame": "" if result.attacked_frame is None else result.attacked_frame,
                    "measured_linf": result.linf,
                }
                writer.writerow({field: feature_row(base, features, "max_evidence").get(field, "") for field in OUTPUT_FIELDS})
                handle.flush()
    print(f"Saved {args.output_csv}", flush=True)


if __name__ == "__main__":
    main()
