from __future__ import annotations

import argparse
import csv
from pathlib import Path

from TSC_Detect.utils_metrics import binary_metrics


DEFAULT_METHODS = [
    "score",
    "vlad_original",
    "R_sem_mean",
    "R_sem_max",
    "R_sem_var",
    "R_uniform_shift",
    "R_model",
    "R_conf_var",
    "R_label_change",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Summarize TSC method columns across probe CSV files.")
    parser.add_argument("--inputs", nargs="+", required=True, help="CSV files from run_tsc_attack_probe.py.")
    parser.add_argument("--names", nargs="+", default=None, help="Display names for each input.")
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_method_summary.csv")
    parser.add_argument("--methods", nargs="+", default=DEFAULT_METHODS)
    return parser.parse_args()


def summarize_one(path: str, setting: str, methods: list[str]) -> list[dict]:
    rows = list(csv.DictReader(open(path, newline="", encoding="utf-8")))
    labels = [int(row["is_adv"]) for row in rows]
    out = []
    n_clean = sum(label == 0 for label in labels)
    n_adv = sum(label == 1 for label in labels)
    for method in methods:
        scores = [float(row[method]) for row in rows]
        metrics = binary_metrics(labels, scores)
        out.append(
            {
                "setting": setting,
                "method": method,
                "n_clean": n_clean,
                "n_adv": n_adv,
                **metrics,
            }
        )
    return out


def main() -> None:
    args = parse_args()
    names = args.names or [Path(path).stem for path in args.inputs]
    if len(names) != len(args.inputs):
        raise SystemExit("--names length must match --inputs length.")
    rows = []
    for path, name in zip(args.inputs, names):
        rows.extend(summarize_one(path, name, args.methods))
    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "setting",
        "method",
        "n_clean",
        "n_adv",
        "roc_auc",
        "pr_auc",
        "fpr_at_95_tpr",
        "tpr_at_1_fpr",
        "clean_mean",
        "clean_std",
        "adv_mean",
        "adv_std",
    ]
    with output.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    for row in rows:
        print(
            f"{row['setting']:8s} {row['method']:16s} "
            f"AUC={row['roc_auc']:.4f} PR={row['pr_auc']:.4f} "
            f"FPR95={row['fpr_at_95_tpr']:.3f} TPR1={row['tpr_at_1_fpr']:.3f} "
            f"clean={row['clean_mean']:.4f} adv={row['adv_mean']:.4f}"
        )
    print(f"Saved {output}")


if __name__ == "__main__":
    main()

