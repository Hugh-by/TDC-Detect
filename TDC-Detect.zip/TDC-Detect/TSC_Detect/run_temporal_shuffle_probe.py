from __future__ import annotations

import argparse
import csv
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames
from TSC_Detect.run_tsc_detect import choose_device
from TSC_Detect.tsc_action_model import get_action_probs
from TSC_Detect.tsc_features import symmetric_kl
from TSC_Detect.utils_video import load_frames, read_class_names, read_manifest


SHUFFLE_VIEW_NAMES = [
    "reverse",
    "segment_shuffle_8",
    "random_perm_seed0",
    "random_perm_seed1",
    "random_perm_seed2",
    "random_perm_seed3",
]

FIELDNAMES = [
    "video_path",
    "label",
    "is_adv",
    "attack",
    "clean_pred_reference",
    "attack_success",
    "pred_original",
    "conf_original",
    "ts_prob_shift_mean",
    "ts_prob_shift_max",
    "ts_label_change",
    "ts_conf_drop",
    "ts_conf_var",
    "ts_vote_entropy",
    "ts_defense_vote_pred",
    "ts_defense_correct",
    "num_shuffle_views",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Temporal Shuffle Consistency attack-detection baseline.")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--manifest-splits", nargs="*", default=("test",))
    parser.add_argument("--class-names", default="kinetics-labels.txt")
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--max-videos", type=int, default=None)
    parser.add_argument("--num-frames", type=int, default=32)
    parser.add_argument("--device", default="cpu", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--action-model", default="csn_r101", choices=["csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4"])
    parser.add_argument("--attack", default="fgsm", choices=["fgsm", "pgd", "ofa", "flick"])
    parser.add_argument("--attack-split-name", default=None)
    parser.add_argument("--eps", type=float, default=0.03)
    parser.add_argument("--alpha", type=float, default=2 / 255)
    parser.add_argument("--iters", type=int, default=1)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--resume", action="store_true")
    return parser.parse_args()


def load_action_model_only(device, action_model_name: str):
    import pytorchvideo.models.hub as models

    factories = {
        "csn_r101": models.csn_r101,
        "slowfast_r50": models.slowfast_r50,
        "x3d_m": models.x3d_m,
        "mvit_base_16x4": models.mvit_base_16x4,
    }
    base_model = factories[action_model_name](True).eval().to(device)
    base_model._tdc_action_model_name = action_model_name
    return base_model


def segment_shuffle_indices(length: int, num_segments: int = 8, seed: int = 0) -> np.ndarray:
    indices = np.arange(length)
    segments = np.array_split(indices, num_segments)
    order = np.arange(len(segments))
    rng = np.random.default_rng(seed)
    rng.shuffle(order)
    return np.concatenate([segments[idx] for idx in order])


def shuffled_views(frames: np.ndarray) -> dict[str, np.ndarray]:
    length = len(frames)
    views: dict[str, np.ndarray] = {
        "reverse": np.ascontiguousarray(frames[::-1]),
        "segment_shuffle_8": np.ascontiguousarray(frames[segment_shuffle_indices(length, 8, seed=0)]),
    }
    for seed in range(4):
        rng = np.random.default_rng(seed)
        views[f"random_perm_seed{seed}"] = np.ascontiguousarray(frames[rng.permutation(length)])
    return views


def vote_entropy(preds: list[int]) -> float:
    if not preds:
        return 0.0
    counts = np.asarray(list(Counter(preds).values()), dtype=np.float64)
    probs = counts / counts.sum()
    if len(probs) <= 1:
        return 0.0
    return float(-np.sum(probs * np.log(probs + 1e-12)) / math.log(len(preds)))


def majority_vote(preds: list[int]) -> int:
    counts = Counter(preds)
    return int(sorted(counts.items(), key=lambda item: (-item[1], item[0]))[0][0])


def score_temporal_shuffle(
    frames: np.ndarray,
    action_model,
    device,
    clean_pred_reference: int | None,
) -> dict:
    original_probs, pred_original, conf_original = get_action_probs(action_model, frames, device)
    shifts: list[float] = []
    preds: list[int] = []
    confs: list[float] = []
    for view in shuffled_views(frames).values():
        probs, pred, conf = get_action_probs(action_model, view, device)
        shifts.append(symmetric_kl(original_probs, probs))
        preds.append(pred)
        confs.append(conf)

    vote_pred = majority_vote(preds)
    mean_conf = float(np.mean(confs)) if confs else 0.0
    ref_pred = pred_original if clean_pred_reference is None else int(clean_pred_reference)
    return {
        "pred_original": pred_original,
        "conf_original": conf_original,
        "ts_prob_shift_mean": float(np.mean(shifts)) if shifts else 0.0,
        "ts_prob_shift_max": float(np.max(shifts)) if shifts else 0.0,
        "ts_label_change": float(np.mean([pred != pred_original for pred in preds])) if preds else 0.0,
        "ts_conf_drop": max(0.0, conf_original - mean_conf),
        "ts_conf_var": float(np.var(confs)) if confs else 0.0,
        "ts_vote_entropy": vote_entropy(preds),
        "ts_defense_vote_pred": vote_pred,
        "ts_defense_correct": int(vote_pred == ref_pred),
        "num_shuffle_views": len(preds),
    }


def existing_progress(path: Path) -> dict[str, dict[str, bool | int | None]]:
    progress: dict[str, dict[str, bool | int | None]] = {}
    if not path.exists():
        return progress
    with path.open("r", encoding="utf-8", newline="") as file:
        for row in csv.DictReader(file):
            video_path = row.get("video_path")
            if not video_path:
                continue
            entry = progress.setdefault(video_path, {"clean": False, "adv": False, "clean_pred": None})
            if str(row.get("is_adv", "")) == "0":
                entry["clean"] = True
                value = row.get("pred_original", "")
                entry["clean_pred"] = int(value) if value != "" else None
            elif str(row.get("is_adv", "")) == "1":
                entry["adv"] = True
    return progress


def write_row(
    writer: csv.DictWriter,
    path: Path,
    label: str,
    is_adv: int,
    attack_name: str,
    clean_pred_reference: int,
    attack_success_value: str | int,
    features: dict,
) -> None:
    row = {
        "video_path": str(path),
        "label": label,
        "is_adv": is_adv,
        "attack": attack_name if is_adv else "clean",
        "clean_pred_reference": clean_pred_reference,
        "attack_success": attack_success_value,
        **features,
    }
    writer.writerow({name: row.get(name, "") for name in FIELDNAMES})


def main() -> None:
    args = parse_args()
    device = choose_device(args.device)
    read_class_names(args.class_names)  # Keep the same validation surface as TSC runs.
    action_model = load_action_model_only(device, args.action_model)
    rows = read_manifest(args.manifest, args.manifest_splits, args.max_videos)
    output_path = Path(args.output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    progress = existing_progress(output_path) if args.resume else {}
    mode = "a" if args.resume and output_path.exists() else "w"
    needs_header = mode == "w" or output_path.stat().st_size == 0
    attack_tag = args.attack_split_name or args.attack

    with output_path.open(mode, encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        if needs_header:
            writer.writeheader()
        for index, row in enumerate(rows, 1):
            path = Path(row["path"])
            state = progress.get(str(path), {"clean": False, "adv": False, "clean_pred": None})
            if state["adv"]:
                continue
            label = row.get("label", row.get("class_name", ""))
            print(f"[{index}/{len(rows)}] temporal-shuffle {args.action_model}/{attack_tag}: {path}")
            source_frames = load_frames(path)
            clean_frames = (
                prepare_attack_frames(source_frames, args.action_model, device)
                .mul(255).round().to(torch.uint8).cpu().numpy()
            )

            clean_features = None
            if not state["clean"]:
                clean_features = score_temporal_shuffle(clean_frames, action_model, device, clean_pred_reference=None)
                clean_pred = int(clean_features["pred_original"])
                write_row(writer, path, label, 0, attack_tag, clean_pred, "", clean_features)
                file.flush()
            else:
                # Reuse the persisted clean prediction. This avoids seven
                # redundant action-model forwards when clean rows are seeded
                # from another attack file or when a run resumes mid-file.
                if state.get("clean_pred") is None:
                    raise RuntimeError(f"Missing persisted clean prediction for {path}")
                clean_pred = int(state["clean_pred"])

            attack_result = make_attack(
                action_model,
                source_frames,
                model_name=args.action_model,
                device=device,
                attack_name=args.attack,
                eps=args.eps,
                alpha=args.alpha,
                iters=args.iters,
                seed=args.seed + index,
            )
            attacked_frames = attack_result.frames
            attack_features = score_temporal_shuffle(attacked_frames, action_model, device, clean_pred_reference=clean_pred)
            attack_success = int(int(attack_features["pred_original"]) != clean_pred)
            write_row(writer, path, label, 1, attack_tag, clean_pred, attack_success, attack_features)
            file.flush()

    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
