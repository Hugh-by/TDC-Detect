from __future__ import annotations

import io
from typing import Literal

import numpy as np
from PIL import Image, ImageFilter


def _jpeg_frame(frame: np.ndarray, quality: int) -> np.ndarray:
    image = Image.fromarray(frame.astype(np.uint8), mode="RGB")
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=quality)
    buffer.seek(0)
    return np.asarray(Image.open(buffer).convert("RGB"))


def apply_recovery_transform(
    frames: np.ndarray,
    method: Literal["jpeg", "gaussian_blur", "median", "resize"] = "jpeg",
    quality: int = 75,
) -> np.ndarray:
    """Lightweight recovery transform for later consistency checks."""
    out = []
    for frame in frames:
        image = Image.fromarray(frame.astype(np.uint8), mode="RGB")
        if method == "jpeg":
            out.append(_jpeg_frame(frame, quality))
        elif method == "gaussian_blur":
            out.append(np.asarray(image.filter(ImageFilter.GaussianBlur(radius=1.0))))
        elif method == "median":
            out.append(np.asarray(image.filter(ImageFilter.MedianFilter(size=3))))
        elif method == "resize":
            w, h = image.size
            small = image.resize((max(w // 2, 1), max(h // 2, 1)), Image.BILINEAR)
            out.append(np.asarray(small.resize((w, h), Image.BILINEAR)))
        else:
            raise ValueError(f"Unsupported recovery method: {method}")
    return np.stack(out, axis=0)

