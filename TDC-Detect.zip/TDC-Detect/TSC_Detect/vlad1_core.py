from __future__ import annotations

from pathlib import Path
from typing import Optional, Sequence

import numpy as np

from TSC_Detect.tsc_action_model import get_action_probs, mock_action_probs
from TSC_Detect.tsc_sampling import uniform_indices
from TSC_Detect.tsc_vlm import get_vlm_context_probs, mock_vlm_probs
from TSC_Detect.utils_video import load_frames


def _normalize_probs(values: np.ndarray, eps: float) -> np.ndarray:
    probs = np.asarray(values, dtype=np.float64)
    probs = np.clip(probs, eps, 1.0)
    return probs / probs.sum()


def kl_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-12) -> float:
    p = _normalize_probs(p, eps)
    q = _normalize_probs(q, eps)
    return float(np.sum(p * np.log(p / q)))


def kl_pa_pt(pa: np.ndarray, pt: np.ndarray, eps: float = 1e-12) -> float:
    """Forward diagnostic: KL(action probability || CLIP/text probability)."""
    return kl_divergence(pa, pt, eps=eps)


def vlad1_symmetric_kl(pa: np.ndarray, pt: np.ndarray, eps: float = 1e-12) -> float:
    """Paper VLAD-1 score: 0.5 * [KL(pa || pt) + KL(pt || pa)]."""
    return 0.5 * (kl_divergence(pa, pt, eps=eps) + kl_divergence(pt, pa, eps=eps))


def vlad1_components(pa: np.ndarray, pt: np.ndarray, eps: float = 1e-12) -> dict:
    """Return paper score plus directional KL diagnostics."""
    p = np.asarray(pa, dtype=np.float64)
    q = np.asarray(pt, dtype=np.float64)
    forward = kl_divergence(p, q, eps=eps)
    reverse = kl_divergence(q, p, eps=eps)
    return {
        "vlad1_score": 0.5 * (forward + reverse),
        "vlad1_forward_kl": forward,
        "vlad1_reverse_kl": reverse,
    }


def select_uniform_frames(frames: np.ndarray, num_frames: int) -> np.ndarray:
    return frames[uniform_indices(len(frames), num_frames)]


def resolve_video_path(path_value: str, manifest_path: str | Path, data_root: Optional[str | Path] = None) -> Path:
    path = Path(path_value)
    if path.exists():
        return path
    if data_root is not None:
        candidate = Path(data_root) / path
        if candidate.exists():
            return candidate
    candidate = Path(manifest_path).resolve().parent / path
    if candidate.exists():
        return candidate
    return path


def score_vlad1_frames(
    frames: np.ndarray,
    class_names: Sequence[str],
    *,
    action_model=None,
    clip_model=None,
    clip_processor=None,
    device=None,
    num_frames: int = 32,
    max_clip_frames: int = 32,
    prompt_template: str = "a video of a person {}",
    prompt_templates: Optional[Sequence[str]] = None,
    mock_models: bool = False,
    seed: int = 0,
) -> dict:
    view = select_uniform_frames(frames, num_frames)
    if mock_models:
        pa, pred_action, conf_action = mock_action_probs(view, len(class_names), seed=seed)
        pt = mock_vlm_probs(view, len(class_names), seed=seed + 1000)
    else:
        pa, pred_action, conf_action = get_action_probs(action_model, view, device)
        pt = get_vlm_context_probs(
            clip_model,
            clip_processor,
            view,
            class_names,
            device,
            prompt_template=prompt_template,
            prompt_templates=prompt_templates,
            max_clip_frames=max_clip_frames,
        )
    pred_clip = int(np.argmax(pt))
    scores = vlad1_components(pa, pt)
    return {
        **scores,
        "pred_action": pred_action,
        "pred_clip": pred_clip,
        "conf_action": conf_action,
        "conf_clip": float(np.max(pt)),
        "num_frames": num_frames,
        "max_clip_frames": max_clip_frames,
    }


def score_vlad1_video(path: str | Path, class_names: Sequence[str], **kwargs) -> dict:
    frames = load_frames(path)
    return score_vlad1_frames(frames, class_names, **kwargs)
