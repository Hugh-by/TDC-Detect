from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.eval_tsc_fixed_scores import fixed_scores
from TSC_Detect.eval_tsc_gated_scores import score_variants as gated_score_variants
from TSC_Detect.tsc_calibration import DEFAULT_FEATURES, fit_logistic_regression, logistic_scores
from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def grouped_indices(rows: list[dict]) -> list[np.ndarray]:
    groups: dict[str, list[int]] = {}
    for idx, row in enumerate(rows):
        groups.setdefault(row["video_path"], []).append(idx)
    return [np.asarray(indices, dtype=np.int64) for _, indices in sorted(groups.items())]


def logistic_lovo_scores(
    rows: list[dict],
    features: list[str],
    steps: int,
    lr: float,
    l2: float,
) -> np.ndarray:
    groups = grouped_indices(rows)
    scores = np.zeros(len(rows), dtype=np.float64)
    all_indices = np.arange(len(rows))
    for group in groups:
        mask = np.ones(len(rows), dtype=bool)
        mask[group] = False
        train = [rows[idx] for idx in all_indices[mask]]
        test = [rows[idx] for idx in group]
        model = fit_logistic_regression(train, features, lr=lr, steps=steps, l2=l2)
        scores[group] = logistic_scores(test, model)
    return scores


def collect_scores(
    rows: list[dict],
    calib_rows: list[dict],
    include_lovo: bool,
    logistic_steps: int,
    logistic_lr: float,
    logistic_l2: float,
) -> dict[str, np.ndarray]:
    scores: dict[str, np.ndarray] = {
        "vlad_original": np.asarray([float(row["vlad_original"]) for row in rows], dtype=np.float64),
        "tsc_score_current": np.asarray([float(row["score"]) for row in rows], dtype=np.float64),
    }
    fixed = fixed_scores(rows, calib_rows)
    gated = gated_score_variants(rows, calib_rows)
    for name in ["fixed_vlad_light_tsc", "fixed_semantic_temporal", "fixed_weak_balanced"]:
        scores[name] = fixed[name]
    for name in ["gated_q90_medium", "gated_window_light"]:
        scores[name] = gated[name]
    train_eval = fit_logistic_regression(rows, DEFAULT_FEATURES, lr=logistic_lr, steps=logistic_steps, l2=logistic_l2)
    scores["logistic_train_eval"] = logistic_scores(rows, train_eval)
    if include_lovo:
        scores["logistic_lovo"] = logistic_lovo_scores(rows, DEFAULT_FEATURES, logistic_steps, logistic_lr, logistic_l2)
    return scores


def bootstrap_auc(
    labels: np.ndarray,
    scores_by_name: dict[str, np.ndarray],
    groups: list[np.ndarray],
    baseline: str,
    n_boot: int,
    seed: int,
) -> list[dict]:
    rng = np.random.default_rng(seed)
    names = list(scores_by_name)
    auc_samples = {name: np.zeros(n_boot, dtype=np.float64) for name in names}
    delta_samples = {name: np.zeros(n_boot, dtype=np.float64) for name in names if name != baseline}
    group_count = len(groups)

    for boot in range(n_boot):
        sampled = rng.integers(0, group_count, size=group_count)
        indices = np.concatenate([groups[idx] for idx in sampled])
        y = labels[indices]
        if len(np.unique(y)) < 2:
            for name in names:
                auc_samples[name][boot] = np.nan
            for name in delta_samples:
                delta_samples[name][boot] = np.nan
            continue
        base_auc = roc_auc_np(y, scores_by_name[baseline][indices])
        for name in names:
            auc = roc_auc_np(y, scores_by_name[name][indices])
            auc_samples[name][boot] = auc
            if name != baseline:
                delta_samples[name][boot] = auc - base_auc

    rows = []
    for name in names:
        samples = auc_samples[name]
        samples = samples[~np.isnan(samples)]
        metric = binary_metrics(labels, scores_by_name[name])
        out = {
            "method": name,
            "auc": metric["roc_auc"],
            "auc_ci_low": float(np.quantile(samples, 0.025)),
            "auc_ci_high": float(np.quantile(samples, 0.975)),
            "delta_vs_vlad": 0.0 if name == baseline else metric["roc_auc"] - binary_metrics(labels, scores_by_name[baseline])["roc_auc"],
            "delta_ci_low": "",
            "delta_ci_high": "",
            "p_delta_le_0": "",
            "fpr_at_95_tpr": metric["fpr_at_95_tpr"],
            "tpr_at_1_fpr": metric["tpr_at_1_fpr"],
        }
        if name != baseline:
            deltas = delta_samples[name]
            deltas = deltas[~np.isnan(deltas)]
            out["delta_ci_low"] = float(np.quantile(deltas, 0.025))
            out["delta_ci_high"] = float(np.quantile(deltas, 0.975))
            out["p_delta_le_0"] = float(np.mean(deltas <= 0.0))
        rows.append(out)
    return rows


def borderline_rows(
    rows: list[dict],
    scores_by_name: dict[str, np.ndarray],
    calib_rows: list[dict],
    quantiles: list[tuple[str, float, float]],
) -> list[dict]:
    labels = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.int64)
    calib_vlad = np.asarray([float(row["vlad_original"]) for row in calib_rows], dtype=np.float64)
    vlad = scores_by_name["vlad_original"]
    out = []
    for region_name, low_q, high_q in quantiles:
        low = float(np.quantile(calib_vlad, low_q))
        high = float(np.quantile(calib_vlad, high_q))
        mask = (vlad >= low) & (vlad <= high)
        if len(np.unique(labels[mask])) < 2:
            continue
        for method, scores in scores_by_name.items():
            metric = binary_metrics(labels[mask], scores[mask])
            out.append(
                {
                    "region": region_name,
                    "low_quantile": low_q,
                    "high_quantile": high_q,
                    "low_score": low,
                    "high_score": high,
                    "method": method,
                    "n_rows": int(mask.sum()),
                    "n_clean": int(np.sum(labels[mask] == 0)),
                    "n_adv": int(np.sum(labels[mask] == 1)),
                    **metric,
                }
            )
    return out


def write_csv(path: str, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    fieldnames = list(rows[0].keys())
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Bootstrap and VLAD-borderline analysis for TSC scores.")
    parser.add_argument("--calib-clean", required=True)
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output-prefix", required=True)
    parser.add_argument("--n-boot", type=int, default=2000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--include-lovo", action="store_true")
    parser.add_argument("--logistic-steps", type=int, default=1500)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = read_rows(args.inputs)
    calib_rows = read_rows([args.calib_clean])
    labels = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.int64)
    scores = collect_scores(
        rows,
        calib_rows,
        include_lovo=args.include_lovo,
        logistic_steps=args.logistic_steps,
        logistic_lr=args.logistic_lr,
        logistic_l2=args.logistic_l2,
    )
    groups = grouped_indices(rows)
    boot_rows = bootstrap_auc(labels, scores, groups, "vlad_original", args.n_boot, args.seed)
    for row in boot_rows:
        row["setting"] = args.name
    border_rows = borderline_rows(
        rows,
        scores,
        calib_rows,
        quantiles=[
            ("clean_q50_q95", 0.50, 0.95),
            ("clean_q75_q975", 0.75, 0.975),
            ("clean_q90_q995", 0.90, 0.995),
        ],
    )
    for row in border_rows:
        row["setting"] = args.name

    write_csv(f"{args.output_prefix}_bootstrap.csv", boot_rows)
    write_csv(f"{args.output_prefix}_borderline.csv", border_rows)

    print(f"\n{args.name} bootstrap summary")
    for row in boot_rows:
        delta = row["delta_vs_vlad"]
        delta_ci = (
            ""
            if row["method"] == "vlad_original"
            else f" delta={delta:.4f} [{row['delta_ci_low']:.4f},{row['delta_ci_high']:.4f}] p<=0={row['p_delta_le_0']:.3f}"
        )
        print(
            f"{row['method']:24s} AUC={row['auc']:.4f} "
            f"[{row['auc_ci_low']:.4f},{row['auc_ci_high']:.4f}]"
            f"{delta_ci}"
        )

    print(f"\n{args.name} borderline summary")
    for region in sorted({row["region"] for row in border_rows}):
        subset = [row for row in border_rows if row["region"] == region and row["method"] in {"vlad_original", "fixed_vlad_light_tsc", "gated_q90_medium", "logistic_lovo", "logistic_train_eval"}]
        for row in subset:
            print(
                f"{region:16s} {row['method']:24s} n={row['n_rows']:4d} "
                f"clean={row['n_clean']:3d} adv={row['n_adv']:3d} AUC={row['roc_auc']:.4f} "
                f"FPR95={row['fpr_at_95_tpr']:.3f}"
            )


if __name__ == "__main__":
    main()
