from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.tsc_calibration import fit_logistic_regression, logistic_scores
from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


TS_FEATURES = [
    "ts_prob_shift_mean",
    "ts_prob_shift_max",
    "ts_label_change",
    "ts_conf_drop",
    "ts_conf_var",
    "ts_vote_entropy",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate Temporal Shuffle Consistency raw CSV.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output-prefix", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--n-boot", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--logistic-steps", type=int, default=1500)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def read_rows(path: str) -> list[dict]:
    with Path(path).open("r", encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def write_csv(path: str | Path, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def grouped_indices(rows: list[dict]) -> list[np.ndarray]:
    groups: dict[str, list[int]] = {}
    for idx, row in enumerate(rows):
        groups.setdefault(row["video_path"], []).append(idx)
    return [np.asarray(indices, dtype=np.int64) for _, indices in sorted(groups.items())]


def logistic_lovo_scores(rows: list[dict], steps: int, lr: float, l2: float) -> np.ndarray:
    groups = grouped_indices(rows)
    scores = np.zeros(len(rows), dtype=np.float64)
    all_indices = np.arange(len(rows))
    for group in groups:
        mask = np.ones(len(rows), dtype=bool)
        mask[group] = False
        train = [rows[idx] for idx in all_indices[mask]]
        test = [rows[idx] for idx in group]
        model = fit_logistic_regression(train, TS_FEATURES, lr=lr, steps=steps, l2=l2)
        scores[group] = logistic_scores(test, model)
    return scores


def success_rows(rows: list[dict]) -> list[dict]:
    by_video: dict[str, list[dict]] = {}
    for row in rows:
        by_video.setdefault(row["video_path"], []).append(row)
    kept: list[dict] = []
    for video_rows in by_video.values():
        clean = next((row for row in video_rows if int(row["is_adv"]) == 0), None)
        if clean is None:
            continue
        clean_pred = str(clean.get("pred_original", ""))
        for adv in [row for row in video_rows if int(row["is_adv"]) == 1]:
            if str(adv.get("pred_original", "")) != clean_pred:
                kept.append(clean)
                kept.append(adv)
    return kept


def collect_scores(rows: list[dict], steps: int, lr: float, l2: float) -> dict[str, np.ndarray]:
    scores = {
        "ts_prob_shift_mean": np.asarray([float(row["ts_prob_shift_mean"]) for row in rows], dtype=np.float64),
        "ts_prob_shift_max": np.asarray([float(row["ts_prob_shift_max"]) for row in rows], dtype=np.float64),
        "ts_label_change": np.asarray([float(row["ts_label_change"]) for row in rows], dtype=np.float64),
    }
    model = fit_logistic_regression(rows, TS_FEATURES, lr=lr, steps=steps, l2=l2)
    scores["ts_logistic_train_eval"] = logistic_scores(rows, model)
    scores["ts_logistic_lovo"] = logistic_lovo_scores(rows, steps=steps, lr=lr, l2=l2)
    return scores


def defense_metrics(rows: list[dict]) -> dict:
    clean_rows = [row for row in rows if int(row["is_adv"]) == 0]
    adv_rows = [row for row in rows if int(row["is_adv"]) == 1]
    success = [row for row in adv_rows if str(row.get("attack_success", "")) == "1"]

    def mean_bool(values: list[bool]) -> float:
        return float(np.mean(values)) if values else 0.0

    return {
        "clean_shuffle_vote_acc": mean_bool([str(row.get("ts_defense_correct", "")) == "1" for row in clean_rows]),
        "clean_acc_drop": 1.0 - mean_bool([str(row.get("ts_defense_correct", "")) == "1" for row in clean_rows]),
        "adv_original_acc": mean_bool([str(row.get("pred_original", "")) == str(row.get("clean_pred_reference", "")) for row in adv_rows]),
        "ts_defense_robust_acc": mean_bool([str(row.get("ts_defense_correct", "")) == "1" for row in adv_rows]),
        "recovery_rate": mean_bool([str(row.get("ts_defense_correct", "")) == "1" for row in success]),
        "attack_success_total": len(success),
        "attack_raw_total": len(adv_rows),
    }


def bootstrap_rows(
    labels: np.ndarray,
    scores_by_name: dict[str, np.ndarray],
    groups: list[np.ndarray],
    n_boot: int,
    seed: int,
) -> list[dict]:
    rng = np.random.default_rng(seed)
    samples_by_name: dict[str, list[float]] = {name: [] for name in scores_by_name}
    for _ in range(n_boot):
        sampled = rng.integers(0, len(groups), size=len(groups))
        indices = np.concatenate([groups[idx] for idx in sampled])
        y = labels[indices]
        if len(np.unique(y)) < 2:
            continue
        for name, scores in scores_by_name.items():
            samples_by_name[name].append(roc_auc_np(y, scores[indices]))

    rows: list[dict] = []
    for name, scores in scores_by_name.items():
        metric = binary_metrics(labels, scores)
        samples = np.asarray(samples_by_name[name], dtype=np.float64)
        rows.append(
            {
                "method": name,
                "roc_auc": metric["roc_auc"],
                "auc_ci_low": float(np.quantile(samples, 0.025)) if len(samples) else "",
                "auc_ci_high": float(np.quantile(samples, 0.975)) if len(samples) else "",
                "pr_auc": metric["pr_auc"],
                "fpr_at_95_tpr": metric["fpr_at_95_tpr"],
                "tpr_at_1_fpr": metric["tpr_at_1_fpr"],
                "clean_mean": metric["clean_mean"],
                "clean_std": metric["clean_std"],
                "adv_mean": metric["adv_mean"],
                "adv_std": metric["adv_std"],
            }
        )
    return rows


def evaluate_split(rows: list[dict], name: str, args: argparse.Namespace) -> list[dict]:
    labels = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.int64)
    scores = collect_scores(rows, steps=args.logistic_steps, lr=args.logistic_lr, l2=args.logistic_l2)
    groups = grouped_indices(rows)
    summary = bootstrap_rows(labels, scores, groups, n_boot=args.n_boot, seed=args.seed)
    dmetrics = defense_metrics(rows)
    n_clean = int(np.sum(labels == 0))
    n_adv = int(np.sum(labels == 1))
    for row in summary:
        row.update(
            {
                "setting": name,
                "n_clean": n_clean,
                "n_adv": n_adv,
                **dmetrics,
            }
        )
    return summary


def main() -> None:
    args = parse_args()
    rows = read_rows(args.input)
    if not rows:
        raise SystemExit("No rows to evaluate.")

    full = evaluate_split(rows, f"{args.name}_full", args)
    success = success_rows(rows)
    success_summary = evaluate_split(success, f"{args.name}_success", args) if success else []

    write_csv(f"{args.output_prefix}_full_summary.csv", full)
    write_csv(f"{args.output_prefix}_success_summary.csv", success_summary)

    for title, summary in [("full", full), ("success", success_summary)]:
        print(f"\n{args.name} {title}")
        for row in summary:
            if row["method"] in {"ts_prob_shift_mean", "ts_logistic_lovo"}:
                print(
                    f"{row['method']:24s} AUC={float(row['roc_auc']):.4f} "
                    f"n_clean={row['n_clean']} n_adv={row['n_adv']} "
                    f"robust={float(row['ts_defense_robust_acc']):.4f}"
                )


if __name__ == "__main__":
    main()
