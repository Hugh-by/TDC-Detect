from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.tsc_calibration import fit_logistic_regression, logistic_scores
from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


V1_FEATURES = [
    "vlad_original",
    "R_sem_var",
    "R_uniform_shift",
    "R_model",
    "R_conf_var",
    "R_label_change",
]

V2_FEATURES = V1_FEATURES + [
    "R_fft_conf_high",
    "R_fft_conf_entropy",
    "R_fft_sem_high",
    "R_fft_sem_entropy",
    "R_fft_vlad_high",
    "R_fft_vlad_entropy",
    "R_local_sem_max",
    "R_local_sem_top2",
    "R_local_conf_max",
    "R_local_conf_top2",
    "R_local_shift_max",
    "R_local_shift_top2",
]

SINGLE_FEATURES = [
    "score",
    "R_sem_var",
    "R_uniform_shift",
    "R_conf_var",
    "R_fft_conf_high",
    "R_fft_conf_entropy",
    "R_fft_sem_high",
    "R_fft_sem_entropy",
    "R_fft_vlad_high",
    "R_fft_vlad_entropy",
    "R_local_sem_max",
    "R_local_sem_top2",
    "R_local_conf_max",
    "R_local_conf_top2",
    "R_local_shift_max",
    "R_local_shift_top2",
]


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def grouped_indices(rows: list[dict]) -> list[np.ndarray]:
    groups: dict[str, list[int]] = {}
    for idx, row in enumerate(rows):
        groups.setdefault(row["video_path"], []).append(idx)
    return [np.asarray(indices, dtype=np.int64) for _, indices in sorted(groups.items())]


def logistic_lovo_scores(rows: list[dict], features: list[str], steps: int, lr: float, l2: float) -> np.ndarray:
    groups = grouped_indices(rows)
    scores = np.zeros(len(rows), dtype=np.float64)
    all_indices = np.arange(len(rows))
    for group in groups:
        mask = np.ones(len(rows), dtype=bool)
        mask[group] = False
        train = [rows[idx] for idx in all_indices[mask]]
        test = [rows[idx] for idx in group]
        model = fit_logistic_regression(train, features, lr=lr, steps=steps, l2=l2)
        scores[group] = logistic_scores(test, model)
    return scores


def bootstrap_auc(
    labels: np.ndarray,
    scores_by_name: dict[str, np.ndarray],
    groups: list[np.ndarray],
    baseline: str,
    n_boot: int,
    seed: int,
) -> list[dict]:
    rng = np.random.default_rng(seed)
    base_auc = binary_metrics(labels, scores_by_name[baseline])["roc_auc"]
    rows: list[dict] = []
    samples_by_name: dict[str, list[float]] = {name: [] for name in scores_by_name}
    deltas_by_name: dict[str, list[float]] = {name: [] for name in scores_by_name if name != baseline}

    for _ in range(n_boot):
        sampled = rng.integers(0, len(groups), size=len(groups))
        indices = np.concatenate([groups[idx] for idx in sampled])
        y = labels[indices]
        if len(np.unique(y)) < 2:
            continue
        boot_base = roc_auc_np(y, scores_by_name[baseline][indices])
        for name, scores in scores_by_name.items():
            auc = roc_auc_np(y, scores[indices])
            samples_by_name[name].append(auc)
            if name != baseline:
                deltas_by_name[name].append(auc - boot_base)

    for name, scores in scores_by_name.items():
        metric = binary_metrics(labels, scores)
        samples = np.asarray(samples_by_name[name], dtype=np.float64)
        out = {
            "method": name,
            "roc_auc": metric["roc_auc"],
            "auc_ci_low": float(np.quantile(samples, 0.025)),
            "auc_ci_high": float(np.quantile(samples, 0.975)),
            "delta_vs_vlad": metric["roc_auc"] - base_auc,
            "delta_ci_low": "",
            "delta_ci_high": "",
            "p_delta_le_0": "",
            "pr_auc": metric["pr_auc"],
            "fpr_at_95_tpr": metric["fpr_at_95_tpr"],
            "tpr_at_1_fpr": metric["tpr_at_1_fpr"],
        }
        if name != baseline:
            deltas = np.asarray(deltas_by_name[name], dtype=np.float64)
            out["delta_ci_low"] = float(np.quantile(deltas, 0.025))
            out["delta_ci_high"] = float(np.quantile(deltas, 0.975))
            out["p_delta_le_0"] = float(np.mean(deltas <= 0.0))
        rows.append(out)
    return rows


def collect_scores(rows: list[dict], steps: int, lr: float, l2: float, include_lovo: bool) -> dict[str, np.ndarray]:
    scores: dict[str, np.ndarray] = {
        "vlad_original": np.asarray([float(row["vlad_original"]) for row in rows], dtype=np.float64),
        "vlad1_original_prob": np.asarray([float(row.get("vlad1_original_prob", row["vlad_original"])) for row in rows], dtype=np.float64),
        "vlad2_onehot_pred": np.asarray([float(row.get("vlad2_onehot_pred", row["vlad_original"])) for row in rows], dtype=np.float64),
    }
    for name in SINGLE_FEATURES:
        scores[f"single_{name}"] = np.asarray([float(row[name]) for row in rows], dtype=np.float64)

    v1_model = fit_logistic_regression(rows, V1_FEATURES, lr=lr, steps=steps, l2=l2)
    v2_model = fit_logistic_regression(rows, V2_FEATURES, lr=lr, steps=steps, l2=l2)
    scores["logistic_v1_train_eval"] = logistic_scores(rows, v1_model)
    scores["logistic_v2_train_eval"] = logistic_scores(rows, v2_model)
    if include_lovo:
        scores["logistic_v1_lovo"] = logistic_lovo_scores(rows, V1_FEATURES, steps=steps, lr=lr, l2=l2)
        scores["logistic_v2_lovo"] = logistic_lovo_scores(rows, V2_FEATURES, steps=steps, lr=lr, l2=l2)
    return scores


def borderline_rows(
    rows: list[dict],
    calib_rows: list[dict],
    scores_by_name: dict[str, np.ndarray],
    quantiles: list[tuple[str, float, float]],
) -> list[dict]:
    labels = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.int64)
    calib_vlad = np.asarray([float(row["vlad_original"]) for row in calib_rows], dtype=np.float64)
    vlad = scores_by_name["vlad_original"]
    out: list[dict] = []
    keep_methods = [
        "vlad_original",
        "vlad1_original_prob",
        "vlad2_onehot_pred",
        "single_score",
        "single_R_local_sem_max",
        "single_R_local_shift_max",
        "single_R_fft_vlad_high",
        "logistic_v1_lovo",
        "logistic_v2_lovo",
        "logistic_v1_train_eval",
        "logistic_v2_train_eval",
    ]
    for region, low_q, high_q in quantiles:
        low = float(np.quantile(calib_vlad, low_q))
        high = float(np.quantile(calib_vlad, high_q))
        mask = (vlad >= low) & (vlad <= high)
        if len(np.unique(labels[mask])) < 2:
            continue
        for method in keep_methods:
            if method not in scores_by_name:
                continue
            metric = binary_metrics(labels[mask], scores_by_name[method][mask])
            out.append(
                {
                    "region": region,
                    "low_quantile": low_q,
                    "high_quantile": high_q,
                    "low_score": low,
                    "high_score": high,
                    "method": method,
                    "n_rows": int(mask.sum()),
                    "n_clean": int(np.sum(labels[mask] == 0)),
                    "n_adv": int(np.sum(labels[mask] == 1)),
                    **metric,
                }
            )
    return out


def write_csv(path: str, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        return
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate local-window and FFT TSC-v2 features.")
    parser.add_argument("--calib-clean", required=True)
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--output-prefix", required=True)
    parser.add_argument("--n-boot", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--include-lovo", action="store_true")
    parser.add_argument("--logistic-steps", type=int, default=1500)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = read_rows(args.inputs)
    calib_rows = read_rows([args.calib_clean])
    labels = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.int64)
    scores = collect_scores(
        rows,
        steps=args.logistic_steps,
        lr=args.logistic_lr,
        l2=args.logistic_l2,
        include_lovo=args.include_lovo,
    )
    groups = grouped_indices(rows)
    summary = bootstrap_auc(labels, scores, groups, "vlad_original", n_boot=args.n_boot, seed=args.seed)
    for row in summary:
        row["setting"] = args.name
    border = borderline_rows(
        rows,
        calib_rows,
        scores,
        [
            ("clean_q50_q95", 0.50, 0.95),
            ("clean_q75_q975", 0.75, 0.975),
            ("clean_q90_q995", 0.90, 0.995),
        ],
    )
    for row in border:
        row["setting"] = args.name

    write_csv(f"{args.output_prefix}_summary.csv", summary)
    write_csv(f"{args.output_prefix}_borderline.csv", border)

    print(f"\n{args.name} full-distribution summary")
    for row in summary:
        if row["method"] in {
            "vlad_original",
            "vlad1_original_prob",
            "vlad2_onehot_pred",
            "single_score",
            "single_R_local_sem_max",
            "single_R_local_shift_max",
            "single_R_fft_vlad_high",
            "logistic_v1_lovo",
            "logistic_v2_lovo",
            "logistic_v1_train_eval",
            "logistic_v2_train_eval",
        }:
            delta = "" if row["method"] == "vlad_original" else f" delta={row['delta_vs_vlad']:+.4f}"
            print(f"{row['method']:28s} AUC={row['roc_auc']:.4f}{delta}")

    print(f"\n{args.name} borderline summary")
    for row in border:
        if row["region"] == "clean_q75_q975":
            print(
                f"{row['region']:15s} {row['method']:28s} "
                f"n={row['n_rows']:3d} clean={row['n_clean']:3d} adv={row['n_adv']:3d} "
                f"AUC={row['roc_auc']:.4f}"
            )


if __name__ == "__main__":
    main()
