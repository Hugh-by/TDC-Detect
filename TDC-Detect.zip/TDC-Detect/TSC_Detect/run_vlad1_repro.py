from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames
from TSC_Detect.run_tsc_detect import choose_device, load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names, read_manifest, sample_or_pad
from TSC_Detect.vlad1_core import resolve_video_path, score_vlad1_frames


FIELDNAMES = [
    "video_path",
    "label",
    "label_index",
    "class_name",
    "split",
    "is_adv",
    "attack",
    "vlad1_score",
    "vlad1_forward_kl",
    "vlad1_reverse_kl",
    "pred_action",
    "pred_action_name",
    "pred_clip",
    "pred_clip_name",
    "conf_action",
    "conf_clip",
    "clean_pred_action",
    "clean_correct",
    "attack_success",
    "num_frames",
    "max_clip_frames",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Strict pure VLAD-1 runner: uniform frames + symmetric KL(pa, pt).")
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--manifest-splits", nargs="*", default=("test",))
    parser.add_argument("--data-root", default=None, help="Prefix for relative paths in the manifest.")
    parser.add_argument("--class-names", default="kinetics-labels.txt")
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--max-videos", type=int, default=None)
    parser.add_argument("--num-frames", type=int, default=32)
    parser.add_argument("--max-clip-frames", type=int, default=32)
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    parser.add_argument("--action-model", default="csn_r101", choices=["csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4"])
    parser.add_argument("--prompt-template", default="a video of a person {}")
    parser.add_argument("--prompt-templates", nargs="*", default=None)
    parser.add_argument("--attack", choices=["none", "fgsm", "pgd", "ofa", "flick"], default="none")
    parser.add_argument("--attack-split-name", default=None)
    parser.add_argument("--eps", type=float, default=0.03)
    parser.add_argument("--alpha", type=float, default=2 / 255)
    parser.add_argument("--iters", type=int, default=1)
    parser.add_argument("--success-only", action="store_true", help="Write attacked rows only if the clean row is correct and attack changes the prediction.")
    parser.add_argument("--skip-errors", action="store_true", help="Skip videos that fail decoding or scoring.")
    parser.add_argument("--mock-models", action="store_true")
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--resume", action="store_true", help="Append to an existing CSV and skip already completed clean/adv pairs.")
    return parser.parse_args()


def label_index(row: dict, class_names: list[str]) -> int | None:
    raw = row.get("label_index") or row.get("label_id") or row.get("target") or ""
    if raw != "":
        try:
            return int(raw)
        except ValueError:
            pass
    label = row.get("label") or row.get("class_name") or ""
    if label in class_names:
        return class_names.index(label)
    return None


def name_at(class_names: list[str], index: int | None) -> str:
    if index is None or index < 0 or index >= len(class_names):
        return ""
    return class_names[index]


def make_output_row(
    *,
    path: Path,
    source_row: dict,
    class_names: list[str],
    split: str,
    is_adv: int,
    attack_name: str,
    score: dict,
    clean_pred_action: int | None,
    clean_correct: bool | None,
    attack_success: bool | None,
) -> dict:
    label_idx = label_index(source_row, class_names)
    pred_action = int(score["pred_action"])
    pred_clip = int(score["pred_clip"])
    return {
        "video_path": str(path),
        "label": source_row.get("label", ""),
        "label_index": "" if label_idx is None else label_idx,
        "class_name": source_row.get("class_name") or source_row.get("label", ""),
        "split": split,
        "is_adv": is_adv,
        "attack": attack_name,
        "vlad1_score": score["vlad1_score"],
        "vlad1_forward_kl": score.get("vlad1_forward_kl", ""),
        "vlad1_reverse_kl": score.get("vlad1_reverse_kl", ""),
        "pred_action": pred_action,
        "pred_action_name": name_at(class_names, pred_action),
        "pred_clip": pred_clip,
        "pred_clip_name": name_at(class_names, pred_clip),
        "conf_action": score["conf_action"],
        "conf_clip": score["conf_clip"],
        "clean_pred_action": "" if clean_pred_action is None else clean_pred_action,
        "clean_correct": "" if clean_correct is None else int(clean_correct),
        "attack_success": "" if attack_success is None else int(attack_success),
        "num_frames": score["num_frames"],
        "max_clip_frames": score["max_clip_frames"],
    }


def score_frames(frames: np.ndarray, class_names: list[str], args: argparse.Namespace, action_model, clip_model, clip_processor, device, seed: int) -> dict:
    return score_vlad1_frames(
        frames,
        class_names,
        action_model=action_model,
        clip_model=clip_model,
        clip_processor=clip_processor,
        device=device,
        num_frames=args.num_frames,
        max_clip_frames=args.max_clip_frames,
        prompt_template=args.prompt_template,
        prompt_templates=args.prompt_templates,
        mock_models=args.mock_models,
        seed=seed,
    )


def existing_progress(path: Path) -> dict[str, dict[str, object]]:
    progress: dict[str, dict[str, object]] = {}
    if not path.exists():
        return progress
    with path.open("r", encoding="utf-8", newline="") as file:
        for row in csv.DictReader(file):
            video_path = row.get("video_path")
            if not video_path:
                continue
            entry = progress.setdefault(video_path, {"clean": False, "adv": False, "clean_pred_action": None, "clean_correct": None})
            if str(row.get("is_adv", "")) == "0":
                entry["clean"] = True
                raw_pred = row.get("clean_pred_action") or row.get("pred_action") or ""
                if raw_pred != "":
                    try:
                        entry["clean_pred_action"] = int(raw_pred)
                    except ValueError:
                        pass
                raw_correct = row.get("clean_correct")
                if raw_correct != "":
                    entry["clean_correct"] = raw_correct == "1"
            elif str(row.get("is_adv", "")) == "1":
                entry["adv"] = True
    return progress


def main() -> None:
    args = parse_args()
    class_names = read_class_names(args.class_names)
    rows = read_manifest(args.manifest, args.manifest_splits, args.max_videos)
    output_path = Path(args.output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    device = None
    action_model = clip_model = clip_processor = None
    if not args.mock_models:
        device = choose_device(args.device)
        action_model, clip_model, clip_processor = load_real_models(device, args.action_model)

    progress = existing_progress(output_path) if args.resume else {}
    mode = "a" if args.resume and output_path.exists() else "w"
    needs_header = mode == "w" or output_path.stat().st_size == 0

    with output_path.open(mode, encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        if needs_header:
            writer.writeheader()
        for index, row in enumerate(rows, 1):
            path = resolve_video_path(row.get("path") or row.get("video_path"), args.manifest, args.data_root)
            state = progress.get(str(path), {"clean": False, "adv": False, "clean_pred_action": None, "clean_correct": None})
            if args.attack == "none" and state["clean"]:
                continue
            if args.attack != "none" and state["adv"]:
                continue
            print(f"[{index}/{len(rows)}] VLAD1 clean: {path}")
            try:
                raw = load_frames(path)
                clean_frames = (
                    prepare_attack_frames(raw, args.action_model, device)
                    .mul(255).round().to(torch.uint8).cpu().numpy()
                    if not args.mock_models else sample_or_pad(raw, args.num_frames)
                )
                clean_score = None
                if not state["clean"]:
                    clean_score = score_frames(clean_frames, class_names, args, action_model, clip_model, clip_processor, device, args.seed + index)
            except Exception as exc:
                if not args.skip_errors:
                    raise
                print(f"Skipping failed clean video: {path} ({type(exc).__name__}: {exc})")
                continue
            clean_pred = int(clean_score["pred_action"]) if clean_score is not None else state.get("clean_pred_action")
            label_idx = label_index(row, class_names)
            clean_correct = state.get("clean_correct")
            if clean_correct is None:
                clean_correct = None if label_idx is None or clean_pred is None else clean_pred == label_idx
            if clean_score is not None:
                writer.writerow(
                    make_output_row(
                        path=path,
                        source_row=row,
                        class_names=class_names,
                        split=row.get("split", "clean"),
                        is_adv=0,
                        attack_name="clean",
                        score=clean_score,
                        clean_pred_action=clean_pred,
                        clean_correct=clean_correct,
                        attack_success=None,
                    )
                )
                file.flush()

            if args.attack == "none":
                continue
            try:
                if args.mock_models:
                    attacked_frames = clean_frames
                else:
                    attack_result = make_attack(
                        action_model,
                        raw,
                        model_name=args.action_model,
                        device=device,
                        attack_name=args.attack,
                        eps=args.eps,
                        alpha=args.alpha,
                        iters=args.iters,
                        seed=args.seed + index,
                    )
                    attacked_frames = attack_result.frames

                attack_label = args.attack_split_name or (args.attack if args.attack == "fgsm" else f"pgd{args.iters}")
                print(f"[{index}/{len(rows)}] VLAD1 {attack_label}: {path}")
                adv_score = score_frames(attacked_frames, class_names, args, action_model, clip_model, clip_processor, device, args.seed + 10000 + index)
            except Exception as exc:
                if not args.skip_errors:
                    raise
                print(f"Skipping failed attack video: {path} ({type(exc).__name__}: {exc})")
                continue
            adv_pred = int(adv_score["pred_action"])
            attack_success = None
            if clean_correct is not None:
                attack_success = bool(clean_correct and adv_pred != label_idx)
            if args.success_only and not attack_success:
                continue
            writer.writerow(
                make_output_row(
                    path=path,
                    source_row=row,
                    class_names=class_names,
                    split=attack_label,
                    is_adv=1,
                    attack_name=attack_label,
                    score=adv_score,
                    clean_pred_action=clean_pred,
                    clean_correct=clean_correct,
                    attack_success=attack_success,
                )
            )
            file.flush()
            if device is not None and str(device).startswith("cuda"):
                torch.cuda.empty_cache()
    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
