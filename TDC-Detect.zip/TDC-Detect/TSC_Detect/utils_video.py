from __future__ import annotations

import csv
from pathlib import Path
from typing import Iterable, List, Optional

import numpy as np


VIDEO_SUFFIXES = {".avi", ".mp4", ".mov", ".mkv", ".npy"}


def sample_or_pad(frames: np.ndarray, num_frames: int) -> np.ndarray:
    if len(frames) == 0:
        raise ValueError("Cannot load an empty video.")
    if len(frames) >= num_frames:
        idx = np.linspace(0, len(frames) - 1, num_frames).astype(np.int64)
        return frames[idx]
    pad = np.repeat(frames[-1:], num_frames - len(frames), axis=0)
    return np.concatenate([frames, pad], axis=0)


def load_frames(path: str | Path, decode_all: bool = True, fallback_num_frames: int = 32) -> np.ndarray:
    path = Path(path)
    if path.suffix.lower() == ".npy":
        arr = np.load(path)
        if arr.ndim != 4:
            raise ValueError(f"Expected npy frames shaped [T,H,W,C], got {arr.shape}.")
        return arr
    if path.suffix.lower() not in VIDEO_SUFFIXES:
        raise ValueError(f"Unsupported video suffix: {path.suffix}")
    import av

    frames = []
    with av.open(str(path)) as container:
        for frame in container.decode(video=0):
            frames.append(frame.to_ndarray(format="rgb24"))
    arr = np.asarray(frames)
    return arr if decode_all else sample_or_pad(arr, fallback_num_frames)


def read_class_names(path: str | Path) -> List[str]:
    path = Path(path)
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="") as file:
            rows = list(csv.DictReader(file))
        if rows and "label_index" in rows[0]:
            mapping = {
                int(row["label_index"]): row.get("label") or row.get("class_name", "")
                for row in rows
            }
            if sorted(mapping) != list(range(len(mapping))) or any(not mapping[i] for i in mapping):
                raise ValueError(f"Invalid contiguous label mapping in {path}")
            return [mapping[i] for i in range(len(mapping))]
    with path.open("r", encoding="utf-8") as file:
        return [line.strip() for line in file if line.strip()]


def list_video_files(video_dir: str | Path, max_videos: Optional[int] = None) -> List[Path]:
    root = Path(video_dir)
    paths = sorted(path for path in root.rglob("*") if path.suffix.lower() in VIDEO_SUFFIXES)
    return paths[:max_videos] if max_videos else paths


def read_manifest(path: str | Path, split_names: Optional[Iterable[str]] = None, max_videos: Optional[int] = None) -> list[dict]:
    with Path(path).open("r", encoding="utf-8-sig", newline="") as file:
        rows = list(csv.DictReader(file))
    if split_names:
        split_set = set(split_names)
        rows = [row for row in rows if row.get("split") in split_set]
    return rows[:max_videos] if max_videos else rows
