from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

import numpy as np

from TSC_Detect.utils_video import load_frames, sample_or_pad


def require_ffmpeg() -> None:
    if shutil.which("ffmpeg") is None:
        raise RuntimeError("ffmpeg is required for HEVC probing, but it was not found on PATH.")


def _even_sized_frames(frames: np.ndarray) -> np.ndarray:
    if frames.ndim != 4 or frames.shape[-1] != 3:
        raise ValueError(f"Expected frames shaped [T,H,W,3], got {frames.shape}.")
    height = frames.shape[1] - (frames.shape[1] % 2)
    width = frames.shape[2] - (frames.shape[2] % 2)
    if height <= 0 or width <= 0:
        raise ValueError(f"Invalid frame size for HEVC encoding: {frames.shape[1:3]}.")
    return np.ascontiguousarray(frames[:, :height, :width, :].astype(np.uint8, copy=False))


def hevc_roundtrip_frames(
    frames: np.ndarray,
    *,
    crf: int = 28,
    preset: str = "medium",
    fps: int = 8,
    work_dir: str | Path | None = None,
    num_frames: int | None = None,
) -> np.ndarray:
    """Encode frames with HEVC/H.265 and decode them back to RGB frames."""
    require_ffmpeg()
    frames = _even_sized_frames(frames)
    height, width = frames.shape[1:3]
    parent = Path(work_dir) if work_dir else None
    if parent:
        parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(dir=str(parent) if parent else None) as tmp:
        output = Path(tmp) / "roundtrip_hevc.mp4"
        cmd = [
            "ffmpeg",
            "-hide_banner",
            "-loglevel",
            "error",
            "-y",
            "-f",
            "rawvideo",
            "-vcodec",
            "rawvideo",
            "-pix_fmt",
            "rgb24",
            "-s",
            f"{width}x{height}",
            "-r",
            str(fps),
            "-i",
            "-",
            "-an",
            "-c:v",
            "libx265",
            "-preset",
            preset,
            "-crf",
            str(crf),
            "-pix_fmt",
            "yuv420p",
            str(output),
        ]
        proc = subprocess.run(cmd, input=frames.tobytes(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if proc.returncode != 0:
            stderr = proc.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(f"ffmpeg HEVC encode failed: {stderr}")
        decoded = load_frames(output)
    if num_frames is not None:
        decoded = sample_or_pad(decoded, num_frames)
    return decoded
