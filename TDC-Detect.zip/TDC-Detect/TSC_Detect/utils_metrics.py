from __future__ import annotations

from pathlib import Path
from typing import Iterable

import numpy as np


def roc_curve_np(labels: Iterable[int], scores: Iterable[float]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    y = np.asarray(list(labels), dtype=np.int64)
    s = np.asarray(list(scores), dtype=np.float64)
    order = np.argsort(-s)
    y = y[order]
    s = s[order]
    positives = max(int(np.sum(y == 1)), 1)
    negatives = max(int(np.sum(y == 0)), 1)
    tp = np.cumsum(y == 1)
    fp = np.cumsum(y == 0)
    tpr = np.concatenate([[0.0], tp / positives, [1.0]])
    fpr = np.concatenate([[0.0], fp / negatives, [1.0]])
    thresholds = np.concatenate([[np.inf], s, [-np.inf]])
    return fpr, tpr, thresholds


def roc_auc_np(labels: Iterable[int], scores: Iterable[float]) -> float:
    fpr, tpr, _ = roc_curve_np(labels, scores)
    return float(np.trapezoid(tpr, fpr))


def average_precision_np(labels: Iterable[int], scores: Iterable[float]) -> float:
    y = np.asarray(list(labels), dtype=np.int64)
    s = np.asarray(list(scores), dtype=np.float64)
    order = np.argsort(-s)
    y = y[order]
    positives = int(np.sum(y == 1))
    if positives == 0:
        return 0.0
    tp = np.cumsum(y == 1)
    precision = tp / np.arange(1, len(y) + 1)
    return float(np.sum(precision[y == 1]) / positives)


def binary_metrics(labels: Iterable[int], scores: Iterable[float]) -> dict:
    y = np.asarray(list(labels), dtype=np.int64)
    s = np.asarray(list(scores), dtype=np.float64)
    fpr, tpr, thresholds = roc_curve_np(y, s)
    idx_95 = np.where(tpr >= 0.95)[0]
    fpr_at_95 = float(fpr[idx_95[0]]) if len(idx_95) else 1.0
    idx_1 = np.where(fpr <= 0.01)[0]
    tpr_at_1 = float(np.max(tpr[idx_1])) if len(idx_1) else 0.0
    return {
        "roc_auc": roc_auc_np(y, s),
        "pr_auc": average_precision_np(y, s),
        "fpr_at_95_tpr": fpr_at_95,
        "tpr_at_1_fpr": tpr_at_1,
        "clean_mean": float(np.mean(s[y == 0])) if np.any(y == 0) else 0.0,
        "clean_std": float(np.std(s[y == 0])) if np.any(y == 0) else 0.0,
        "adv_mean": float(np.mean(s[y == 1])) if np.any(y == 1) else 0.0,
        "adv_std": float(np.std(s[y == 1])) if np.any(y == 1) else 0.0,
    }


def save_roc_plot(labels: Iterable[int], scores: Iterable[float], output_path: str | Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except ModuleNotFoundError:
        return

    y = np.asarray(list(labels), dtype=np.int64)
    s = np.asarray(list(scores), dtype=np.float64)
    fpr, tpr, _ = roc_curve_np(y, s)
    plt.figure(figsize=(5, 4))
    plt.plot(fpr, tpr, label="ROC")
    plt.plot([0, 1], [0, 1], "--", color="0.7", label="chance")
    plt.xlabel("FPR")
    plt.ylabel("TPR")
    plt.title("TSC-Detect ROC")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=180)
    plt.close()
