from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Mapping

import numpy as np


DEFAULT_FEATURES = [
    "vlad_original",
    "R_sem_var",
    "R_uniform_shift",
    "R_model",
    "R_conf_var",
    "R_label_change",
]


@dataclass
class CleanStats:
    features: list[str]
    mean: np.ndarray
    std: np.ndarray


def matrix_from_rows(rows: list[Mapping[str, str]], features: Iterable[str]) -> np.ndarray:
    names = list(features)
    return np.asarray([[float(row[name]) for name in names] for row in rows], dtype=np.float64)


def fit_clean_stats(rows: list[Mapping[str, str]], features: Iterable[str] = DEFAULT_FEATURES, eps: float = 1e-6) -> CleanStats:
    names = list(features)
    clean = [row for row in rows if int(row["is_adv"]) == 0]
    if not clean:
        raise ValueError("Clean calibration requires at least one clean row.")
    x = matrix_from_rows(clean, names)
    return CleanStats(features=names, mean=x.mean(axis=0), std=np.maximum(x.std(axis=0), eps))


def clean_z_scores(rows: list[Mapping[str, str]], stats: CleanStats) -> np.ndarray:
    x = matrix_from_rows(rows, stats.features)
    return (x - stats.mean) / stats.std


def clean_gate_scores(rows: list[Mapping[str, str]], stats: CleanStats, mode: str = "logsumexp") -> np.ndarray:
    z = clean_z_scores(rows, stats)
    if mode == "max":
        return z.max(axis=1)
    if mode == "mean":
        return z.mean(axis=1)
    if mode == "positive_mean":
        return np.maximum(z, 0.0).mean(axis=1)
    if mode == "logsumexp":
        shift = z.max(axis=1, keepdims=True)
        return (shift[:, 0] + np.log(np.exp(z - shift).sum(axis=1))).astype(np.float64)
    raise ValueError(f"Unknown clean gate mode: {mode}")


def fit_logistic_regression(
    rows: list[Mapping[str, str]],
    features: Iterable[str] = DEFAULT_FEATURES,
    lr: float = 0.1,
    steps: int = 3000,
    l2: float = 1e-3,
) -> dict:
    """Small NumPy logistic regression to avoid adding a sklearn dependency."""
    names = list(features)
    x = matrix_from_rows(rows, names)
    y = np.asarray([int(row["is_adv"]) for row in rows], dtype=np.float64)
    mean = x.mean(axis=0)
    std = np.maximum(x.std(axis=0), 1e-6)
    z = (x - mean) / std
    w = np.zeros(z.shape[1], dtype=np.float64)
    b = 0.0
    for _ in range(steps):
        logits = z @ w + b
        p = 1.0 / (1.0 + np.exp(-np.clip(logits, -50, 50)))
        error = p - y
        grad_w = (z.T @ error) / len(y) + l2 * w
        grad_b = float(error.mean())
        w -= lr * grad_w
        b -= lr * grad_b
    return {"features": names, "mean": mean, "std": std, "weights": w, "bias": b}


def logistic_scores(rows: list[Mapping[str, str]], model: dict) -> np.ndarray:
    x = matrix_from_rows(rows, model["features"])
    z = (x - model["mean"]) / model["std"]
    logits = z @ model["weights"] + float(model["bias"])
    return 1.0 / (1.0 + np.exp(-np.clip(logits, -50, 50)))

