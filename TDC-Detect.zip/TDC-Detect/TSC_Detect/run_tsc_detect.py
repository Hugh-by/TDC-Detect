from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path
from typing import Dict

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from TSC_Detect.tsc_action_model import get_action_probs, install_deterministic_attack_pooling, mock_action_probs
from TSC_Detect.tsc_features import compute_tsc_features, local_window_features, score_features
from TSC_Detect.tsc_sampling import (
    build_frozen_global_views,
    build_frozen_local_views,
    build_local_window_views,
    build_sampling_views,
    uniform_indices,
    video_seed,
)
from TSC_Detect.tsc_vlm import get_vlm_context_probs, mock_vlm_probs
from TSC_Detect.utils_video import list_video_files, load_frames, read_class_names, read_manifest


FIELDNAMES = [
    "video_path",
    "label",
    "is_adv",
    "score",
    "score_mode",
    "R_model",
    "R_vlm",
    "R_sem_mean",
    "R_sem_max",
    "R_sem_var",
    "R_label_change",
    "R_conf_var",
    "R_uniform_shift",
    "vlad_original",
    "vlad1_original_prob",
    "vlad2_onehot_pred",
    "R_fft_conf_high",
    "R_fft_conf_entropy",
    "R_fft_sem_high",
    "R_fft_sem_entropy",
    "R_fft_vlad_high",
    "R_fft_vlad_entropy",
    "R_local_sem_max",
    "R_local_sem_top2",
    "R_local_conf_max",
    "R_local_conf_top2",
    "R_local_shift_max",
    "R_local_shift_top2",
    "pred_uniform",
    "conf_uniform",
    "msp_score",
    "predictive_entropy",
    "num_views",
]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run TSC-Detect on videos or a manifest.")
    parser.add_argument("--video-dir", default=None)
    parser.add_argument("--manifest", default=None, help="CSV with path plus optional label/is_adv/split columns.")
    parser.add_argument("--manifest-splits", nargs="*", default=None)
    parser.add_argument("--class-names", default="../kinetics-labels.txt")
    parser.add_argument("--output-csv", default="outputs/tsc_results.csv")
    parser.add_argument("--num-frames", type=int, default=32)
    parser.add_argument("--num-random", type=int, default=2)
    parser.add_argument("--max-videos", type=int, default=None)
    parser.add_argument("--device", default="auto", choices=["auto", "cuda", "cpu"])
    parser.add_argument(
        "--action-model",
        default="csn_r101",
        choices=["csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4"],
        help="Kinetics-400 action model used as the defended classifier.",
    )
    parser.add_argument("--score-mode", default="max_evidence", choices=["max_evidence", "sum", "logsumexp"])
    parser.add_argument("--mock-models", action="store_true", help="Use deterministic random probabilities for pipeline checks.")
    parser.add_argument("--prompt-template", default="a video of a person {}")
    parser.add_argument("--prompt-templates", nargs="*", default=None)
    parser.add_argument("--max-clip-frames", type=int, default=8)
    parser.add_argument(
        "--max-global-views",
        type=int,
        default=None,
        help="Keep only the first N deterministic global views (for sensitivity studies).",
    )
    parser.add_argument("--base-views-only", action="store_true")
    parser.add_argument("--num-local-windows", type=int, default=0)
    parser.add_argument("--local-window-frames", type=int, default=None)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--resume", action="store_true", help="Append to an existing CSV and skip already processed videos.")
    return parser.parse_args()


def choose_device(name: str):
    import torch

    if name == "auto":
        name = "cuda" if torch.cuda.is_available() else "cpu"
    if name == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested, but torch.cuda.is_available() is False.")
    return torch.device(name)


def load_real_models(device, action_model_name: str = "csn_r101"):
    from transformers import CLIPModel, CLIPProcessor
    import torch
    import pytorchvideo.models.hub as models

    factories = {
        "csn_r101": models.csn_r101,
        "slowfast_r50": models.slowfast_r50,
        "x3d_m": models.x3d_m,
        "mvit_base_16x4": models.mvit_base_16x4,
    }
    action_model = factories[action_model_name](True).eval().to(device)
    install_deterministic_attack_pooling(action_model)
    action_model._tdc_action_model_name = action_model_name
    clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").eval().to(device)
    clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")
    return action_model, clip_model, clip_processor


def input_rows(args: argparse.Namespace) -> list[dict]:
    if args.manifest:
        rows = read_manifest(args.manifest, args.manifest_splits, args.max_videos)
        for row in rows:
            row.setdefault("label", "")
            if "is_adv" not in row or row["is_adv"] == "":
                split = row.get("split", "").lower()
                row["is_adv"] = "1" if split.startswith(("adv", "fgsm", "pgd", "cw", "attack")) else "0"
        return rows
    if not args.video_dir:
        raise SystemExit("Provide either --manifest or --video-dir.")
    rows = []
    for path in list_video_files(args.video_dir, args.max_videos):
        rows.append({"path": str(path), "label": "", "is_adv": ""})
    return rows


def process_one_video(
    row: dict,
    class_names: list[str],
    args: argparse.Namespace,
    action_model=None,
    clip_model=None,
    clip_processor=None,
    device=None,
) -> dict:
    path = Path(row.get("path") or row.get("video_path"))
    frames = load_frames(path)
    features = score_frames(
        frames,
        class_names,
        args,
        action_model=action_model,
        clip_model=clip_model,
        clip_processor=clip_processor,
        device=device,
        video_id=str(path),
    )
    score = score_features(features, mode=args.score_mode)
    out = {
        "video_path": str(path),
        "label": row.get("label", ""),
        "is_adv": row.get("is_adv", ""),
        "score": score,
        "score_mode": args.score_mode,
        **features,
    }
    return out


def completed_video_paths(path: Path) -> set[str]:
    if not path.exists():
        return set()
    with path.open("r", encoding="utf-8", newline="") as file:
        return {row["video_path"] for row in csv.DictReader(file) if row.get("video_path")}


def score_frames(
    frames: np.ndarray,
    class_names: list[str],
    args: argparse.Namespace,
    action_model=None,
    clip_model=None,
    clip_processor=None,
    device=None,
    video_id: str | None = None,
) -> dict:
    seed = video_seed(args.seed, video_id) if video_id is not None else args.seed
    frozen_protocol = getattr(args, "protocol_id", None) == "tdc-final-20260714"
    if frozen_protocol:
        views = build_frozen_global_views(frames)
    elif getattr(args, "base_views_only", False):
        views = {"uniform": frames}
    else:
        views = build_sampling_views(frames, num_frames=args.num_frames, num_random=args.num_random, seed=seed)
    max_global_views = getattr(args, "max_global_views", None)
    if max_global_views is not None:
        if max_global_views < 1:
            raise ValueError("max_global_views must be at least 1.")
        views = dict(list(views.items())[:max_global_views])

    action_probs: Dict[str, np.ndarray] = {}
    vlm_probs: Dict[str, np.ndarray] = {}
    for index, (name, view) in enumerate(views.items()):
        if args.mock_models:
            pa, _, _ = mock_action_probs(view, len(class_names), seed=seed + index)
            pc = mock_vlm_probs(view, len(class_names), seed=seed + 1000 + index)
        else:
            pa, _, _ = get_action_probs(action_model, view, device)
            pc = get_vlm_context_probs(
                clip_model,
                clip_processor,
                view,
                class_names,
                device,
                prompt_template=args.prompt_template,
                prompt_templates=getattr(args, "prompt_templates", None),
                max_clip_frames=args.max_clip_frames,
            )
        action_probs[name] = pa
        vlm_probs[name] = pc

    primary_view = "original" if frozen_protocol else "uniform"
    features = compute_tsc_features(action_probs, vlm_probs, primary_view=primary_view)

    if frozen_protocol:
        frozen_locals = build_frozen_local_views(frames)
        requested_locals = getattr(args, "num_local_windows", 4)
        if requested_locals not in {0, 2, 4}:
            raise ValueError("Frozen protocol sensitivity permits 0, 2, or 4 local windows.")
        local_views = dict(list(frozen_locals.items())[:requested_locals])
    else:
        local_views = build_local_window_views(
            frames,
            num_windows=getattr(args, "num_local_windows", 0),
            num_frames=getattr(args, "local_window_frames", None) or args.num_frames,
        )
    local_action_probs: Dict[str, np.ndarray] = {}
    local_vlm_probs: Dict[str, np.ndarray] = {}
    for index, (name, view) in enumerate(local_views.items()):
        if args.mock_models:
            pa, _, _ = mock_action_probs(view, len(class_names), seed=args.seed + 2000 + index)
            pc = mock_vlm_probs(view, len(class_names), seed=args.seed + 3000 + index)
        else:
            pa, _, _ = get_action_probs(action_model, view, device)
            pc = get_vlm_context_probs(
                clip_model,
                clip_processor,
                view,
                class_names,
                device,
                prompt_template=args.prompt_template,
                prompt_templates=getattr(args, "prompt_templates", None),
                max_clip_frames=args.max_clip_frames,
            )
        local_action_probs[name] = pa
        local_vlm_probs[name] = pc
    features.update(local_window_features(local_action_probs, local_vlm_probs, reference_action_probs=action_probs.get(primary_view)))
    return features


def main() -> None:
    args = parse_args()
    class_names = read_class_names(args.class_names)
    output_path = Path(args.output_csv)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    device = None
    action_model = clip_model = clip_processor = None
    if not args.mock_models:
        device = choose_device(args.device)
        action_model, clip_model, clip_processor = load_real_models(device, args.action_model)

    rows = input_rows(args)
    completed = completed_video_paths(output_path) if args.resume else set()
    mode = "a" if args.resume and output_path.exists() else "w"
    needs_header = mode == "w" or output_path.stat().st_size == 0

    with output_path.open(mode, encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=FIELDNAMES)
        if needs_header:
            writer.writeheader()
        for index, row in enumerate(rows, 1):
            video_path = row.get("path") or row.get("video_path")
            if video_path in completed:
                continue
            print(f"[{index}/{len(rows)}] {video_path}")
            result = process_one_video(row, class_names, args, action_model, clip_model, clip_processor, device)
            writer.writerow({name: result.get(name, "") for name in FIELDNAMES})
            file.flush()
    print(f"Saved {output_path}")


if __name__ == "__main__":
    main()
