from __future__ import annotations

from typing import Optional, Sequence

import numpy as np


_TEXT_FEATURE_CACHE: dict[tuple[int, tuple[str, ...], tuple[str, ...], str], object] = {}


DEFAULT_PROMPT_TEMPLATES = (
    "a video of a person {}",
    "a video of {}",
    "an action of {}",
)


def _prompt_texts(class_names: Sequence[str], templates: Sequence[str]) -> list[str]:
    return [template.format(name) for template in templates for name in class_names]


def _feature_tensor(output):
    """Handle tensor returns in Transformers 4.x and pooled outputs in 5.x."""
    return output.pooler_output if hasattr(output, "pooler_output") else output


def _cached_text_features(clip_model, clip_processor, class_names, templates, device):
    import torch

    key = (id(clip_model), tuple(class_names), tuple(templates), str(device))
    cached = _TEXT_FEATURE_CACHE.get(key)
    if cached is not None:
        return cached
    inputs = clip_processor(
        text=_prompt_texts(class_names, templates), return_tensors="pt", padding=True
    )
    inputs = {key: value.to(device) for key, value in inputs.items() if torch.is_tensor(value)}
    with torch.no_grad():
        features = _feature_tensor(clip_model.get_text_features(**inputs))
        features = features / features.norm(dim=-1, keepdim=True)
        features = features.reshape(len(templates), len(class_names), -1)
    _TEXT_FEATURE_CACHE[key] = features
    return features


def get_vlm_context_probs(
    clip_model,
    clip_processor,
    view: np.ndarray,
    class_names: Sequence[str],
    device,
    prompt_template: str = DEFAULT_PROMPT_TEMPLATES[0],
    prompt_templates: Optional[Sequence[str]] = None,
    max_clip_frames: Optional[int] = 8,
) -> np.ndarray:
    """Compute CLIP context probabilities for a temporal view."""
    import torch

    frames = view
    if np.issubdtype(frames.dtype, np.floating) and float(np.max(frames)) <= 1.0 + 1e-6:
        frames = np.rint(np.clip(frames, 0.0, 1.0) * 255.0).astype(np.uint8)
    if max_clip_frames and len(frames) > max_clip_frames:
        idx = np.linspace(0, len(frames) - 1, max_clip_frames).astype(np.int64)
        frames = frames[idx]
    templates = tuple(prompt_templates) if prompt_templates else (prompt_template,)
    text_features = _cached_text_features(clip_model, clip_processor, class_names, templates, device)
    inputs = clip_processor(images=list(frames), return_tensors="pt")
    pixel_values = inputs["pixel_values"].to(device)
    with torch.no_grad():
        image_features = _feature_tensor(clip_model.get_image_features(pixel_values=pixel_values))
        image_features = image_features / image_features.norm(dim=-1, keepdim=True)
        scale = clip_model.logit_scale.exp()
        logits = scale * torch.einsum("id,tcd->itc", image_features, text_features)
        mean_logits = logits.mean(dim=(0, 1))
        probs = mean_logits.softmax(dim=0).detach().cpu().numpy()
    probs = probs.astype(np.float64)
    return probs / probs.sum()


def mock_vlm_probs(view: np.ndarray, num_classes: int = 400, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed + int(np.std(view)))
    logits = rng.normal(size=num_classes)
    logits -= logits.max()
    probs = np.exp(logits)
    probs /= probs.sum()
    return probs.astype(np.float64)
