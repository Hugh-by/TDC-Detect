from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a balanced subset manifest by split and label.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--split", default="test")
    parser.add_argument("--per-class", type=int, default=10)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    with Path(args.input).open("r", encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))
        fieldnames = rows[0].keys()
    groups = defaultdict(list)
    for row in rows:
        if row.get("split") == args.split:
            groups[row.get("label", "")].append(row)
    selected = []
    for label in sorted(groups):
        selected.extend(groups[label][: args.per_class])
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(selected)
    print(f"Saved {len(selected)} rows to {output}")
    for label in sorted(groups):
        print(label, min(len(groups[label]), args.per_class))


if __name__ == "__main__":
    main()

