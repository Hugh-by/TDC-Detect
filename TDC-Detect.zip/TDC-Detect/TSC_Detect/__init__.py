"""TSC-Detect: Temporal Sampling Consistency Detection."""

