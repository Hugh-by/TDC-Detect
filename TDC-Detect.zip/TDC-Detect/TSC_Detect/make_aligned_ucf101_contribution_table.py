from __future__ import annotations

import argparse
import csv
from pathlib import Path

import pandas as pd


METHOD_NAMES = {
    "vlad_original": "VLAD-1 logit-mean",
    "single_score": "TSC-v2 raw score",
    "logistic_v1_lovo": "TSC logistic v1 LOVO",
    "logistic_v2_lovo": "TSC logistic v2 LOVO",
}


def read_summary(path: str | Path) -> dict[str, dict]:
    with Path(path).open("r", encoding="utf-8", newline="") as file:
        return {row["method"]: row for row in csv.DictReader(file)}


def count_rows(path: str | Path) -> tuple[int, int]:
    data = pd.read_csv(path)
    return int((data["is_adv"] == 0).sum()), int((data["is_adv"] == 1).sum())


def verify_alignment(vlad_path: str | Path, tsc_path: str | Path, *, max_vlad_diff: float) -> dict:
    vlad = pd.read_csv(vlad_path)
    tsc = pd.read_csv(tsc_path)
    if len(vlad) != len(tsc):
        raise ValueError(f"Row count mismatch: {vlad_path} has {len(vlad)}, {tsc_path} has {len(tsc)}")
    ordered = (vlad["video_path"].astype(str).to_numpy() == tsc["video_path"].astype(str).to_numpy()) & (
        vlad["is_adv"].to_numpy() == tsc["is_adv"].to_numpy()
    )
    if not bool(ordered.all()):
        bad = int((~ordered).sum())
        raise ValueError(f"Ordered row mismatch between {vlad_path} and {tsc_path}: {bad} rows differ")
    vlad_diff = float((vlad["vlad_original"] - tsc["vlad_original"]).abs().max())
    if vlad_diff > max_vlad_diff:
        raise ValueError(f"VLAD score mismatch too large for {vlad_path}: max_diff={vlad_diff}")
    return {
        "rows": len(vlad),
        "n_clean": int((vlad["is_adv"] == 0).sum()),
        "n_adv": int((vlad["is_adv"] == 1).sum()),
        "duplicate_path_is_adv": int(vlad.duplicated(["video_path", "is_adv"]).sum()),
        "max_vlad_score_diff": vlad_diff,
    }


def add_rows(out: list[dict], *, attack: str, setting: str, summary_path: str, n_clean: int, n_adv: int) -> None:
    summary = read_summary(summary_path)
    for method_key, method_name in METHOD_NAMES.items():
        row = summary[method_key]
        out.append(
            {
                "dataset": "UCF101-101c-c20-t10",
                "attack": attack,
                "setting": setting,
                "method": method_name,
                "score_source": method_key,
                "n_clean": n_clean,
                "n_adv": n_adv,
                "roc_auc": float(row["roc_auc"]),
                "auc_ci_low": float(row["auc_ci_low"]),
                "auc_ci_high": float(row["auc_ci_high"]),
                "delta_vs_vlad": float(row["delta_vs_vlad"]),
                "delta_ci_low": row["delta_ci_low"],
                "delta_ci_high": row["delta_ci_high"],
                "p_delta_le_0": row["p_delta_le_0"],
                "pr_auc": float(row["pr_auc"]),
                "fpr_at_95_tpr": float(row["fpr_at_95_tpr"]),
                "tpr_at_1_fpr": float(row["tpr_at_1_fpr"]),
            }
        )


def write_csv(path: str | Path, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def write_md(path: str | Path, rows: list[dict], checks: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# Aligned UCF101 Contribution Table - 2026-06-04",
        "",
        "This table uses the corrected UCF101 101-class c20/t10 logit-mean outputs. Before writing the table, the script verifies that the VLAD-1 and TSC-v2 raw CSVs have identical ordered `video_path` and `is_adv` rows.",
        "",
        "| Attack | Setting | Method | Clean | Adv | ROC-AUC | 95% CI | Delta vs VLAD | Delta 95% CI | p(delta<=0) |",
        "|---|---|---|---:|---:|---:|---|---:|---|---:|",
    ]
    for row in rows:
        delta_ci = "-"
        p_value = "-"
        if row["method"] != "VLAD-1 logit-mean":
            delta_ci = f"[{float(row['delta_ci_low']):.4f}, {float(row['delta_ci_high']):.4f}]"
            p_value = f"{float(row['p_delta_le_0']):.4f}"
        lines.append(
            "| {attack} | {setting} | {method} | {n_clean} | {n_adv} | {roc_auc:.4f} | [{auc_ci_low:.4f}, {auc_ci_high:.4f}] | {delta_vs_vlad:+.4f} | {delta_ci} | {p_value} |".format(
                **row,
                delta_ci=delta_ci,
                p_value=p_value,
            )
        )
    lines.extend(
        [
            "",
            "Alignment checks:",
            "",
            "| Attack | Setting | Rows | Clean | Adv | Duplicate path/is_adv rows | Max VLAD score diff |",
            "|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for check in checks:
        lines.append(
            "| {attack} | {setting} | {rows} | {n_clean} | {n_adv} | {duplicate_path_is_adv} | {max_vlad_score_diff:.6f} |".format(
                **check
            )
        )
    lines.extend(
        [
            "",
            "Main reading:",
            "",
            "- The strongest conservative contribution row is `weak success`, where TSC logistic v2 LOVO improves from VLAD `0.7573` to `0.8270`.",
            "- The gain is consistent for FGSM and PGD-1 success-only rows, with positive bootstrap delta intervals.",
            "- `weak` combines FGSM and PGD-1, so duplicate `video_path/is_adv` entries are expected; ordered row alignment is used for that setting.",
        ]
    )
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved {output}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create a row-aligned UCF101 contribution table from existing summaries.")
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--max-vlad-diff", type=float, default=0.002)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    base = Path("/root/autodl-tmp/tsc/outputs")
    settings = [
        (
            "FGSM",
            "full",
            base / "server_vlad1_logitmean_fgsm_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_fgsm_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_eval_101c_c20_t10_fgsm_full_summary.csv",
        ),
        (
            "PGD-1",
            "full",
            base / "server_vlad1_logitmean_pgd1_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_pgd1_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_eval_101c_c20_t10_pgd1_full_summary.csv",
        ),
        (
            "Weak",
            "full",
            base / "server_vlad1_logitmean_weak_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_weak_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_eval_101c_c20_t10_weak_full_summary.csv",
        ),
        (
            "FGSM",
            "success_only",
            base / "server_vlad1_logitmean_fgsm_success_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_fgsm_success_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_eval_101c_c20_t10_fgsm_success_summary.csv",
        ),
        (
            "PGD-1",
            "success_only",
            base / "server_vlad1_logitmean_pgd1_success_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_pgd1_success_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_eval_101c_c20_t10_pgd1_success_summary.csv",
        ),
        (
            "Weak",
            "success_only",
            base / "server_vlad1_logitmean_weak_success_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_weak_success_ucf101_101c_c20_t10.csv",
            base / "server_tsc_v2_logitmean_eval_101c_c20_t10_weak_success_summary.csv",
        ),
    ]

    rows: list[dict] = []
    checks: list[dict] = []
    for attack, setting, vlad_path, tsc_path, summary_path in settings:
        check = verify_alignment(vlad_path, tsc_path, max_vlad_diff=args.max_vlad_diff)
        check["attack"] = attack
        check["setting"] = setting
        checks.append(check)
        add_rows(rows, attack=attack, setting=setting, summary_path=str(summary_path), n_clean=check["n_clean"], n_adv=check["n_adv"])

    write_csv(args.output_csv, rows)
    write_md(args.output_md, rows, checks)


if __name__ == "__main__":
    main()
