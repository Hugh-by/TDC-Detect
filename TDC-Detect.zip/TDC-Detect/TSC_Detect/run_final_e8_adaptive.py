from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from eval_final_e1_e5 import PROTOCOL, SEED, TDC_V2, fit_model, threshold_at_clean_fpr
from TSC_Detect.attack_rgb import model_input, prepare_attack_frames, probabilities
from TSC_Detect.run_final_extract import PROTOCOL_ID
from TSC_Detect.run_tsc_detect import choose_device, load_real_models, score_frames
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES
from TSC_Detect.tsc_sampling import frozen_motion_indices
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
from TSC_Detect.utils_video import load_frames, read_class_names


E8_MODELS = ("csn_r101", "mvit_base_16x4")
LAMBDAS = (0.1, 1.0, 10.0)
EPSILON = 8 / 255
ALPHA = 2 / 255
STEPS = 40
RESTARTS = 3
EOT_VIEWS = (
    "early_crop", "late_crop", "temporal_sparse", "motion_aware",
    "local_0", "local_1", "local_2", "local_3",
)
FIELDS = [
    "protocol_id", "experiment", "stage", "action_model", "pair_id", "relative_path",
    "video_path", "tradeoff_lambda", "restart", "attack_seed", "epsilon", "alpha",
    "steps", "eot_views", "bpda_semantic", "clean_pred", "clean_conf", "attacked_pred",
    "attacked_conf", "attack_success", "measured_linf", "detector_score",
    "deployment_threshold", "detector_evaded", "attack_seconds", "score_seconds",
] + TDC_V2


def stable_seed(relative_path: str, model: str, stage: str, tradeoff: float, restart: int) -> int:
    payload = f"{relative_path}|{model}|E8|{stage}|{tradeoff:g}|{restart}|{SEED}"
    digest = hashlib.sha256(payload.encode()).digest()
    return (SEED + int.from_bytes(digest[:4], "little")) % (2**31)


def symmetric_kl_torch(p: torch.Tensor, q: torch.Tensor) -> torch.Tensor:
    p = p.clamp_min(1e-8); q = q.clamp_min(1e-8)
    p = p / p.sum(); q = q / q.sum()
    return 0.5 * ((p * (p / q).log()).sum() + (q * (q / p).log()).sum())


def temporal_probe(adv: torch.Tensor, name: str, motion_indices: torch.Tensor) -> torch.Tensor:
    length = len(adv)
    crop = 3 * length // 4
    if name == "early_crop":
        view = adv[:crop]
    elif name == "late_crop":
        view = adv[length - crop:]
    elif name == "temporal_sparse":
        view = adv[::2]
    elif name == "motion_aware":
        view = adv.index_select(0, motion_indices)
    elif name.startswith("local_"):
        index = int(name.rsplit("_", 1)[1])
        start, end = index * length // 4, (index + 1) * length // 4
        view = adv[start:end]
    else:
        raise KeyError(name)
    if len(view) == length:
        return view
    # Frozen short probes are linearly interpolated across their full support.
    value = view.permute(3, 0, 1, 2).unsqueeze(0)
    value = F.interpolate(value, size=(length, view.shape[1], view.shape[2]), mode="trilinear", align_corners=True)
    return value[0].permute(1, 2, 3, 0)


def action_probabilities(model, rgb: torch.Tensor, model_name: str) -> torch.Tensor:
    output = model(model_input(rgb, model_name))
    if ACTION_MODEL_PROFILES[model_name].output_is_probability:
        value = output[0].clamp_min(1e-12)
        return value / value.sum()
    return output[0].softmax(dim=0)


def detector_gradient_weights(classifier) -> dict[str, float]:
    scaler = classifier.named_steps["scaler"]
    logistic = classifier.named_steps["logistic"]
    values = logistic.coef_[0] / scaler.scale_
    return {feature: float(value) for feature, value in zip(TDC_V2, values)}


def surrogate_logit(
    original: torch.Tensor,
    probe: torch.Tensor,
    probe_name: str,
    weights: dict[str, float],
) -> torch.Tensor:
    zero = probe.sum() * 0.0
    pair = torch.stack((original, probe), dim=0)
    original_label = int(original.argmax())
    competitors = torch.cat((probe[:original_label], probe[original_label + 1:]))
    soft_change = torch.sigmoid((competitors.max() - probe[original_label]) / 0.05)
    shift = symmetric_kl_torch(original, probe)
    confidence = probe.max()
    is_local = probe_name.startswith("local_")
    features = {name: zero for name in TDC_V2}
    features["R_model"] = pair.var(dim=0, unbiased=False).mean()
    features["R_label_change"] = soft_change
    features["R_conf_var"] = torch.stack((original.max(), confidence)).var(unbiased=False)
    if is_local:
        features["R_local_conf_max"] = confidence
        features["R_local_conf_top2"] = confidence
        features["R_local_shift_max"] = shift
        features["R_local_shift_top2"] = shift
    else:
        features["R_uniform_shift"] = shift
    # Semantic/CLIP and spectrum/order terms use a zero-gradient BPDA path.
    return sum(features[name] * weights[name] for name in TDC_V2)


def adaptive_candidate(
    model,
    clean: torch.Tensor,
    model_name: str,
    clean_pred: int,
    tradeoff: float,
    restart: int,
    seed: int,
    weights: dict[str, float],
    motion_indices: torch.Tensor,
) -> tuple[np.ndarray, int, float, float, float]:
    generator = torch.Generator(device=clean.device).manual_seed(seed)
    delta = torch.empty_like(clean).uniform_(-EPSILON, EPSILON, generator=generator)
    delta = ((clean + delta).clamp(0, 1) - clean).detach()
    label = torch.tensor(clean_pred, device=clean.device)
    last_surrogate = 0.0
    for step in range(STEPS):
        adv_cls = (clean + delta).clamp(0, 1).detach().requires_grad_(True)
        p_original = action_probabilities(model, adv_cls, model_name)
        classification_loss = -p_original[label].clamp_min(1e-12).log()
        classification_gradient = torch.autograd.grad(classification_loss, adv_cls, only_inputs=True)[0]
        p_reference = p_original.detach()

        probe_name = EOT_VIEWS[(step + restart) % len(EOT_VIEWS)]
        adv_det = (clean + delta).clamp(0, 1).detach().requires_grad_(True)
        probe_rgb = temporal_probe(adv_det, probe_name, motion_indices)
        p_probe = action_probabilities(model, probe_rgb, model_name)
        detector_logit = surrogate_logit(p_reference, p_probe, probe_name, weights)
        detector_gradient = torch.autograd.grad(detector_logit, adv_det, only_inputs=True)[0]
        gradient = classification_gradient - tradeoff * detector_gradient
        delta = (delta + ALPHA * gradient.sign()).clamp(-EPSILON, EPSILON)
        delta = ((clean + delta).clamp(0, 1) - clean).detach()
        last_surrogate = float(detector_logit.detach())
    adv = (clean + delta).clamp(0, 1).detach()
    with torch.no_grad():
        probs = probabilities(model, adv, model_name)[0]
    return (
        adv.cpu().numpy().astype(np.float32), int(probs.argmax()), float(probs.max()),
        float((adv - clean).abs().max()), last_surrogate,
    )


def completed(path: Path) -> set[tuple[str, str, float, int]]:
    if not path.exists():
        return set()
    with path.open(encoding="utf-8", newline="") as handle:
        return {
            (row["stage"], row["pair_id"], float(row["tradeoff_lambda"]), int(row["restart"]))
            for row in csv.DictReader(handle)
        }


def select_candidate(group: pd.DataFrame) -> pd.Series:
    successful = group[group.attack_success == 1]
    pool = successful if len(successful) else group
    return pool.sort_values(["detector_score", "restart"], ascending=[True, True]).iloc[0]


def select_lambda(frame: pd.DataFrame, threshold: float) -> tuple[float, list[dict[str, float]]]:
    summary = []
    for tradeoff in LAMBDAS:
        subset = frame[np.isclose(frame.tradeoff_lambda, tradeoff)]
        selected = pd.DataFrame([select_candidate(group) for _, group in subset.groupby("pair_id", sort=True)])
        successful = selected.attack_success.to_numpy(int) == 1
        evaded = selected.detector_score.to_numpy(float) <= threshold
        success_scores = selected.loc[successful, "detector_score"].to_numpy(float)
        summary.append({
            "tradeoff_lambda": tradeoff,
            "joint_success_evasion_rate": float(np.mean(successful & evaded)),
            "attack_success_rate": float(np.mean(successful)),
            "evasion_given_success": float(np.mean(evaded[successful])) if successful.any() else 0.0,
            "mean_detector_score_success": float(np.mean(success_scores)) if len(success_scores) else 1.0,
        })
    # Pre-specified lexicographic calibration-only selection.
    chosen = min(
        summary,
        key=lambda row: (
            -row["joint_success_evasion_rate"], -row["attack_success_rate"],
            row["mean_detector_score_success"], row["tradeoff_lambda"],
        ),
    )
    return float(chosen["tradeoff_lambda"]), summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--calibration-manifest", type=Path, required=True)
    parser.add_argument("--test-manifest", type=Path, required=True)
    parser.add_argument("--e1-calibration", type=Path, required=True)
    parser.add_argument("--model", choices=E8_MODELS, required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--tuning-json", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    device = choose_device(args.device)
    torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True, warn_only=True)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False

    calibration = pd.read_csv(args.e1_calibration)
    if set(calibration.protocol_id) != {PROTOCOL}:
        raise ValueError("E1 calibration protocol mismatch")
    classifier = fit_model(calibration, TDC_V2)
    calibration_scores = classifier.predict_proba(calibration[TDC_V2].to_numpy(float))[:, 1]
    threshold = threshold_at_clean_fpr(calibration.is_adv.to_numpy(int), calibration_scores)
    weights = detector_gradient_weights(classifier)
    classes = read_class_names(args.class_names)
    model, clip_model, clip_processor = load_real_models(device, args.model)
    for parameter in model.parameters():
        parameter.requires_grad_(False)
    for parameter in clip_model.parameters():
        parameter.requires_grad_(False)
    with args.calibration_manifest.open(encoding="utf-8-sig", newline="") as handle:
        calibration_manifest = list(csv.DictReader(handle))
    with args.test_manifest.open(encoding="utf-8-sig", newline="") as handle:
        test_manifest = list(csv.DictReader(handle))
    if len(calibration_manifest) != 20 or len(test_manifest) != 100:
        raise ValueError(f"E8 requires fixed calibration20/test100, got {len(calibration_manifest)}/{len(test_manifest)}")

    score_args = argparse.Namespace(
        seed=SEED, protocol_id=PROTOCOL_ID, num_frames=ACTION_MODEL_PROFILES[args.model].num_frames,
        num_random=0, max_global_views=None, base_views_only=False, num_local_windows=4,
        local_window_frames=None, mock_models=False, prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
        prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.tuning_json.parent.mkdir(parents=True, exist_ok=True)
    done = completed(args.output) if args.resume else set()
    mode = "a" if args.resume and args.output.exists() else "w"

    def run_stage(writer, handle, stage: str, manifest: list[dict[str, str]], tradeoffs: tuple[float, ...]) -> None:
        for video_index, row in enumerate(manifest, 1):
            path = Path(row["path"]); relative = row["relative_path"]
            pair_id = hashlib.sha256(f"k400|{args.model}|{relative}".encode()).hexdigest()
            source = load_frames(path)
            clean = prepare_attack_frames(source, args.model, device).detach()
            clean_numpy = clean.cpu().numpy().astype(np.float32)
            motion = torch.as_tensor(frozen_motion_indices(clean_numpy), device=device, dtype=torch.long)
            with torch.no_grad():
                clean_probs = probabilities(model, clean, args.model)[0]
            clean_pred = int(clean_probs.argmax()); clean_conf = float(clean_probs.max())
            for tradeoff in tradeoffs:
                for restart in range(RESTARTS):
                    key = (stage, pair_id, float(tradeoff), restart)
                    if key in done:
                        continue
                    seed = stable_seed(relative, args.model, stage, tradeoff, restart)
                    started = time.perf_counter()
                    adv, attacked_pred, attacked_conf, linf, _ = adaptive_candidate(
                        model, clean, args.model, clean_pred, tradeoff, restart, seed, weights, motion,
                    )
                    attack_seconds = time.perf_counter() - started
                    started = time.perf_counter()
                    features = score_frames(adv, classes, score_args, model, clip_model, clip_processor, device, str(path))
                    detector_score = float(classifier.predict_proba(np.asarray([[features[name] for name in TDC_V2]], dtype=float))[0, 1])
                    score_seconds = time.perf_counter() - started
                    record = {
                        "protocol_id": PROTOCOL_ID, "experiment": "E8", "stage": stage,
                        "action_model": args.model, "pair_id": pair_id, "relative_path": relative,
                        "video_path": str(path), "tradeoff_lambda": tradeoff, "restart": restart,
                        "attack_seed": seed, "epsilon": EPSILON, "alpha": ALPHA, "steps": STEPS,
                        "eot_views": len(EOT_VIEWS), "bpda_semantic": 1, "clean_pred": clean_pred,
                        "clean_conf": clean_conf, "attacked_pred": attacked_pred,
                        "attacked_conf": attacked_conf, "attack_success": int(attacked_pred != clean_pred),
                        "measured_linf": linf, "detector_score": detector_score,
                        "deployment_threshold": threshold, "detector_evaded": int(detector_score <= threshold),
                        "attack_seconds": attack_seconds, "score_seconds": score_seconds, **features,
                    }
                    writer.writerow({name: record.get(name, "") for name in FIELDS}); handle.flush()
                    print(
                        f"E8 {args.model} {stage} {video_index}/{len(manifest)} "
                        f"lambda={tradeoff:g} restart={restart + 1}/{RESTARTS}", flush=True,
                    )

    with args.output.open(mode, encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        if mode == "w" or args.output.stat().st_size == 0:
            writer.writeheader()
        run_stage(writer, handle, "tuning", calibration_manifest, LAMBDAS)

    tuning_frame = pd.read_csv(args.output)
    tuning_frame = tuning_frame[tuning_frame.stage == "tuning"]
    expected_tuning = len(calibration_manifest) * len(LAMBDAS) * RESTARTS
    if len(tuning_frame) != expected_tuning or tuning_frame.duplicated(["pair_id", "tradeoff_lambda", "restart"]).any():
        raise RuntimeError(f"Incomplete E8 tuning candidates: {len(tuning_frame)}/{expected_tuning}")
    chosen_lambda, tuning_summary = select_lambda(tuning_frame, threshold)
    tuning_record = {
        "protocol_id": PROTOCOL_ID, "experiment": "E8", "action_model": args.model,
        "selection_partition": "calibration", "calibration_videos": len(calibration_manifest),
        "candidate_lambdas": list(LAMBDAS), "selection_rule": (
            "maximize joint attack-success-and-evasion; then attack success; then minimize "
            "mean detector score among successes; then smallest lambda"
        ),
        "chosen_lambda": chosen_lambda, "deployment_threshold": threshold,
        "adaptive_definition": {"epsilon": EPSILON, "alpha": ALPHA, "steps": STEPS, "restarts": RESTARTS, "eot_views": list(EOT_VIEWS)},
        "bpda_documentation": (
            "The exact classification gradient is combined with a deterministic EOT action-response surrogate. "
            "CLIP/semantic and unavailable full-spectrum terms use a zero-gradient BPDA approximation; this is not an exact full-detector gradient."
        ),
        "tuning_summary": tuning_summary,
    }
    args.tuning_json.write_text(json.dumps(tuning_record, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    # Reopen after lambda selection so an interrupted test stage remains resumable.
    done = completed(args.output)
    with args.output.open("a", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        run_stage(writer, handle, "test", test_manifest, (chosen_lambda,))
    final = pd.read_csv(args.output)
    expected_total = expected_tuning + len(test_manifest) * RESTARTS
    if len(final) != expected_total:
        raise RuntimeError(f"Incomplete E8 candidates: {len(final)}/{expected_total}")
    if not np.isfinite(final[["measured_linf", "detector_score", *TDC_V2]].to_numpy(float)).all():
        raise RuntimeError("Non-finite E8 output")
    if (final.measured_linf > EPSILON + 1 / 255 + 1e-8).any():
        raise RuntimeError("E8 perturbation budget exceeded")
    print(f"Saved {args.output}; chosen lambda={chosen_lambda:g}", flush=True)


if __name__ == "__main__":
    main()
