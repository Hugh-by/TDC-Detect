from __future__ import annotations

import argparse
import csv
from pathlib import Path

from TSC_Detect.tsc_calibration import (
    DEFAULT_FEATURES,
    clean_gate_scores,
    fit_clean_stats,
    fit_logistic_regression,
    logistic_scores,
)
from TSC_Detect.utils_metrics import binary_metrics


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate clean-only and logistic TSC calibrators.")
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_calibrator_summary.csv")
    parser.add_argument("--features", nargs="+", default=DEFAULT_FEATURES)
    parser.add_argument("--clean-gate-mode", default="logsumexp", choices=["max", "mean", "positive_mean", "logsumexp"])
    parser.add_argument("--logistic-steps", type=int, default=3000)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def add_metric(rows: list[dict], method: str, scores) -> dict:
    labels = [int(row["is_adv"]) for row in rows]
    metrics = binary_metrics(labels, scores)
    return {"method": method, **metrics}


def main() -> None:
    args = parse_args()
    rows = read_rows(args.inputs)
    clean_stats = fit_clean_stats(rows, args.features)
    logistic = fit_logistic_regression(
        rows,
        args.features,
        lr=args.logistic_lr,
        steps=args.logistic_steps,
        l2=args.logistic_l2,
    )
    results = [
        add_metric(rows, "vlad_original", [float(row["vlad_original"]) for row in rows]),
        add_metric(rows, "tsc_score_current", [float(row["score"]) for row in rows]),
        add_metric(rows, f"clean_gate_{args.clean_gate_mode}", clean_gate_scores(rows, clean_stats, mode=args.clean_gate_mode)),
        add_metric(rows, "logistic_regression", logistic_scores(rows, logistic)),
    ]
    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["method", "roc_auc", "pr_auc", "fpr_at_95_tpr", "tpr_at_1_fpr", "clean_mean", "clean_std", "adv_mean", "adv_std"]
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    for row in results:
        print(
            f"{row['method']:24s} AUC={row['roc_auc']:.4f} PR={row['pr_auc']:.4f} "
            f"FPR95={row['fpr_at_95_tpr']:.3f} TPR1={row['tpr_at_1_fpr']:.3f} "
            f"clean={row['clean_mean']:.4f} adv={row['adv_mean']:.4f}"
        )
    print("logistic weights:")
    for name, weight in zip(logistic["features"], logistic["weights"]):
        print(f"  {name}: {weight:.4f}")
    print(f"  bias: {logistic['bias']:.4f}")
    print(f"Saved {output}")


if __name__ == "__main__":
    main()

