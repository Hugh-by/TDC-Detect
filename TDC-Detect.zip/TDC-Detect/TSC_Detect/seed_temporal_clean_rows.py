from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description="Seed missing Temporal Shuffle clean rows from a completed attack CSV.")
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    with args.source.open(newline="", encoding="utf-8") as stream:
        source_rows = list(csv.DictReader(stream))
        fieldnames = stream.seek(0) or next(csv.reader(stream), None)
    if not source_rows:
        raise SystemExit(f"No source rows in {args.source}")
    fieldnames = list(source_rows[0])
    clean_rows = [row for row in source_rows if int(row["is_adv"]) == 0]

    existing: set[str] = set()
    if args.output.exists():
        with args.output.open(newline="", encoding="utf-8") as stream:
            existing = {
                row["video_path"] for row in csv.DictReader(stream)
                if int(row["is_adv"]) == 0
            }
    mode = "a" if args.output.exists() else "w"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open(mode, newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        if mode == "w":
            writer.writeheader()
        writer.writerows(row for row in clean_rows if row["video_path"] not in existing)
    print(f"Seeded {len(clean_rows) - len(existing.intersection({r['video_path'] for r in clean_rows}))} clean rows into {args.output}")


if __name__ == "__main__":
    main()
