from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
import pandas as pd

from TSC_Detect.utils_metrics import binary_metrics


UCF_TO_KINETICS = {
    "Archery": ["archery"],
    "BabyCrawling": ["crawling baby"],
    "BandMarching": ["marching"],
    "BaseballPitch": ["hitting baseball", "catching or throwing baseball"],
    "Basketball": ["playing basketball", "dribbling basketball", "shooting basketball"],
    "BasketballDunk": ["dunking basketball"],
    "BenchPress": ["bench pressing"],
    "Biking": ["riding a bike", "riding mountain bike"],
    "BlowingCandles": ["blowing out candles"],
    "BodyWeightSquats": ["squat"],
    "Bowling": ["bowling"],
    "BoxingPunchingBag": ["punching bag"],
    "BoxingSpeedBag": ["punching bag"],
    "BreastStroke": ["swimming breast stroke"],
    "BrushingTeeth": ["brushing teeth"],
    "CleanAndJerk": ["clean and jerk"],
    "CliffDiving": ["diving cliff"],
    "CricketBowling": ["playing cricket"],
    "CricketShot": ["playing cricket"],
    "Diving": ["springboard diving"],
    "Drumming": ["playing drums", "air drumming"],
    "Fencing": ["sword fighting"],
    "FloorGymnastics": ["gymnastics tumbling"],
    "FrisbeeCatch": ["catching or throwing frisbee"],
    "GolfSwing": ["golf driving", "golf chipping", "golf putting"],
    "Haircut": ["getting a haircut"],
    "HammerThrow": ["hammer throw"],
    "HeadMassage": ["massaging person's head"],
    "HighJump": ["high jump"],
    "HorseRace": ["riding or walking with horse"],
    "HorseRiding": ["riding or walking with horse"],
    "HulaHoop": ["hula hooping"],
    "IceDancing": ["ice skating"],
    "JavelinThrow": ["javelin throw"],
    "JugglingBalls": ["juggling balls"],
    "JumpRope": ["skipping rope"],
    "Kayaking": ["canoeing or kayaking"],
    "Knitting": ["knitting"],
    "LongJump": ["long jump"],
    "Lunges": ["lunge"],
    "MilitaryParade": ["marching"],
    "MoppingFloor": ["mopping floor"],
    "PizzaTossing": ["making pizza"],
    "PlayingCello": ["playing cello"],
    "PlayingFlute": ["playing flute"],
    "PlayingGuitar": ["playing guitar", "strumming guitar"],
    "PlayingPiano": ["playing piano"],
    "PlayingViolin": ["playing violin"],
    "PoleVault": ["pole vault"],
    "PullUps": ["pull ups"],
    "Punch": ["punching person (boxing)"],
    "PushUps": ["push up"],
    "RockClimbingIndoor": ["rock climbing"],
    "RopeClimbing": ["climbing a rope"],
    "SalsaSpin": ["salsa dancing"],
    "ShavingBeard": ["trimming or shaving beard"],
    "Shotput": ["shot put"],
    "SkateBoarding": ["skateboarding"],
    "Skiing": ["skiing (not slalom or crosscountry)", "skiing slalom", "skiing crosscountry"],
    "Skijet": ["jetskiing"],
    "SkyDiving": ["skydiving"],
    "SoccerJuggling": ["juggling soccer ball"],
    "SoccerPenalty": ["shooting goal (soccer)", "kicking soccer ball"],
    "SumoWrestling": ["wrestling"],
    "Surfing": ["surfing water"],
    "Swing": ["swinging on something"],
    "TaiChi": ["tai chi"],
    "TennisSwing": ["playing tennis"],
    "ThrowDiscus": ["throwing discus"],
    "TrampolineJumping": ["bouncing on trampoline"],
    "VolleyballSpiking": ["playing volleyball"],
    "WalkingWithDog": ["walking the dog"],
    "WallPushups": ["push up"],
    "WritingOnBoard": ["writing"],
}


FILES = {
    "FGSM success": "/root/autodl-tmp/tsc/outputs/server_tsc_v2_logitmean_fgsm_success_ucf101_101c_c20_t10.csv",
    "PGD-1 success": "/root/autodl-tmp/tsc/outputs/server_tsc_v2_logitmean_pgd1_success_ucf101_101c_c20_t10.csv",
    "Weak success": "/root/autodl-tmp/tsc/outputs/server_tsc_v2_logitmean_weak_success_ucf101_101c_c20_t10.csv",
}


def read_kinetics_labels(path: str | Path) -> list[str]:
    return [line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines() if line.strip()]


def mapped_indices(labels: list[str]) -> dict[str, set[int]]:
    index = {name: idx for idx, name in enumerate(labels)}
    out: dict[str, set[int]] = {}
    for ucf_label, kinetics_names in UCF_TO_KINETICS.items():
        indices = {index[name] for name in kinetics_names if name in index}
        if indices:
            out[ucf_label] = indices
    return out


def class_coverage(rows: pd.DataFrame, labels: list[str]) -> dict:
    ucf_classes = sorted(rows["label"].unique())
    exact = sum(label in labels for label in ucf_classes)
    lower = {label.lower(): label for label in labels}
    normalized = {
        label.replace("_", " ").replace("-", " ").lower(): label
        for label in labels
    }
    loose = sum(
        (label.lower() in lower)
        or (label.replace("_", " ").replace("-", " ").lower() in normalized)
        for label in ucf_classes
    )
    mapped = sum(label in UCF_TO_KINETICS for label in ucf_classes)
    return {
        "ucf_classes": len(ucf_classes),
        "kinetics_classes": len(labels),
        "exact_class_name_matches": exact,
        "loose_name_matches": loose,
        "manual_semantic_mapped_classes": mapped,
    }


def metrics_row(setting: str, subset: str, score_name: str, rows: pd.DataFrame) -> dict:
    metrics = binary_metrics(rows["is_adv"].astype(int), rows[score_name].astype(float))
    return {
        "setting": setting,
        "subset": subset,
        "score": score_name,
        "n_rows": int(len(rows)),
        "n_clean": int((rows["is_adv"] == 0).sum()),
        "n_adv": int((rows["is_adv"] == 1).sum()),
        **metrics,
    }


def add_pair_id(rows: pd.DataFrame) -> pd.DataFrame:
    rows = rows.copy()
    rows["_pair_id"] = rows.groupby(["video_path", "is_adv"]).cumcount()
    return rows


def filter_mapped(rows: pd.DataFrame, mapping: dict[str, set[int]]) -> pd.DataFrame:
    return rows[rows["label"].isin(mapping)].copy()


def filter_clean_correct_pairs(rows: pd.DataFrame, mapping: dict[str, set[int]]) -> pd.DataFrame:
    mapped = add_pair_id(filter_mapped(rows, mapping))
    clean = mapped[mapped["is_adv"] == 0].copy()
    clean["_mapped_correct"] = [
        int(pred) in mapping.get(label, set())
        for label, pred in zip(clean["label"], clean["pred_uniform"])
    ]
    keep_keys = set(
        zip(
            clean.loc[clean["_mapped_correct"], "video_path"],
            clean.loc[clean["_mapped_correct"], "_pair_id"],
        )
    )
    return mapped[
        [
            (video_path, pair_id) in keep_keys
            for video_path, pair_id in zip(mapped["video_path"], mapped["_pair_id"])
        ]
    ].copy()


def pair_overlap_stats(rows: pd.DataFrame, score_name: str) -> dict:
    clean = rows[rows["is_adv"] == 0][score_name].astype(float)
    adv = rows[rows["is_adv"] == 1][score_name].astype(float)
    return {
        "score": score_name,
        "n_clean": int(len(clean)),
        "n_adv": int(len(adv)),
        "clean_median": float(clean.median()) if len(clean) else 0.0,
        "adv_median": float(adv.median()) if len(adv) else 0.0,
        "adv_le_clean_median": float((adv <= clean.median()).mean()) if len(clean) and len(adv) else 0.0,
        "clean_ge_adv_median": float((clean >= adv.median()).mean()) if len(clean) and len(adv) else 0.0,
    }


def write_csv(path: str | Path, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError(f"No rows to write: {path}")
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def write_markdown(path: str | Path, coverage: dict, metrics: list[dict], overlaps: list[dict]) -> None:
    output = Path(path)
    lines = [
        "# UCF101 VLAD Protocol Validation - 2026-06-04",
        "",
        "These checks test whether the lower UCF101 VLAD score is plausibly caused by protocol and label-space mismatch rather than a broken detector implementation.",
        "",
        "## Label-Space Coverage",
        "",
        "| Check | Count |",
        "|---|---:|",
    ]
    for key, value in coverage.items():
        lines.append(f"| {key} | {value} |")

    lines.extend(
        [
            "",
            "## Control Metrics",
            "",
            "| Setting | Subset | Score | Clean | Adv | ROC-AUC | PR-AUC | FPR@95TPR | TPR@1FPR |",
            "|---|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in metrics:
        lines.append(
            "| {setting} | {subset} | {score} | {n_clean} | {n_adv} | {roc_auc:.4f} | {pr_auc:.4f} | {fpr_at_95_tpr:.4f} | {tpr_at_1_fpr:.4f} |".format(
                **row
            )
        )

    lines.extend(
        [
            "",
            "## Distribution Overlap",
            "",
            "| Setting | Subset | Score | Clean | Adv | Clean median | Adv median | Adv<=clean median | Clean>=adv median |",
            "|---|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in overlaps:
        lines.append(
            "| {setting} | {subset} | {score} | {n_clean} | {n_adv} | {clean_median:.4f} | {adv_median:.4f} | {adv_le_clean_median:.4f} | {clean_ge_adv_median:.4f} |".format(
                **row
            )
        )

    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "- Exact UCF101 class-name overlap with Kinetics is near zero, so UCF101 is not a paper-equivalent VLAD reproduction setting.",
            "- The manual semantic mapped subset and mapped clean-correct subset are protocol controls. If they improve over the all-class score, the weak UCF101 VLAD result is driven by label/protocol mismatch.",
            "- `vlad2_onehot_pred` is an oracle/predicted-label control already stored in the outputs. If it is not better than `vlad_original`, replacing CLIP text probability with a one-hot action label is not a sufficient fix.",
        ]
    )
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved {output}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate UCF101 VLAD protocol and label-space controls.")
    parser.add_argument("--kinetics-labels", default="/root/TSC/VLAD-master/kinetics-labels.txt")
    parser.add_argument("--output-prefix", default="/root/autodl-tmp/tsc/outputs/ucf101_vlad_protocol_validation")
    parser.add_argument("--output-md", default="/root/TSC/docs/ucf101_vlad_protocol_validation_2026-06-04.md")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    labels = read_kinetics_labels(args.kinetics_labels)
    mapping = mapped_indices(labels)
    first_rows = pd.read_csv(next(iter(FILES.values())))
    coverage = class_coverage(first_rows, labels)

    metric_rows: list[dict] = []
    overlap_rows: list[dict] = []
    score_names = ["vlad_original", "vlad2_onehot_pred"]
    for setting, path in FILES.items():
        rows = pd.read_csv(path)
        subsets = {
            "all_classes": rows,
            "semantic_mapped_classes": filter_mapped(rows, mapping),
            "mapped_clean_correct_pairs": filter_clean_correct_pairs(rows, mapping),
        }
        for subset_name, subset_rows in subsets.items():
            if subset_rows.empty or subset_rows["is_adv"].nunique() < 2:
                continue
            for score_name in score_names:
                metric_rows.append(metrics_row(setting, subset_name, score_name, subset_rows))
                overlap = pair_overlap_stats(subset_rows, score_name)
                overlap["setting"] = setting
                overlap["subset"] = subset_name
                overlap_rows.append(overlap)

    prefix = Path(args.output_prefix)
    write_csv(f"{prefix}_metrics.csv", metric_rows)
    write_csv(f"{prefix}_overlap.csv", overlap_rows)
    write_markdown(args.output_md, coverage, metric_rows, overlap_rows)


if __name__ == "__main__":
    main()
