from __future__ import annotations

from collections import Counter
from typing import Dict, Mapping

import numpy as np


def symmetric_kl(p: np.ndarray, q: np.ndarray, eps: float = 1e-8) -> float:
    p = np.clip(np.asarray(p, dtype=np.float64), eps, 1.0)
    q = np.clip(np.asarray(q, dtype=np.float64), eps, 1.0)
    p = p / p.sum()
    q = q / q.sum()
    return float(0.5 * (np.sum(p * np.log(p / q)) + np.sum(q * np.log(q / p))))


def js_divergence(p: np.ndarray, q: np.ndarray, eps: float = 1e-8) -> float:
    p = np.clip(np.asarray(p, dtype=np.float64), eps, 1.0)
    q = np.clip(np.asarray(q, dtype=np.float64), eps, 1.0)
    p = p / p.sum()
    q = q / q.sum()
    m = 0.5 * (p + q)
    return float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))


def _label_change(pred_labels: np.ndarray) -> float:
    if len(pred_labels) == 0:
        return 0.0
    count = Counter(int(x) for x in pred_labels)
    return float(1.0 - max(count.values()) / len(pred_labels))


def _fft_features(values: np.ndarray) -> tuple[float, float]:
    values = np.asarray(values, dtype=np.float64)
    if len(values) < 4 or float(np.std(values)) < 1e-12:
        return 0.0, 0.0
    centered = values - float(np.mean(values))
    power = np.abs(np.fft.rfft(centered)) ** 2
    if len(power) <= 1 or float(np.sum(power[1:])) <= 1e-12:
        return 0.0, 0.0
    non_dc = power[1:]
    midpoint = max(len(non_dc) // 2, 1)
    high_ratio = float(np.sum(non_dc[midpoint:]) / np.sum(non_dc))
    probs = non_dc / np.sum(non_dc)
    entropy = float(-np.sum(probs * np.log(probs + 1e-12)) / np.log(len(probs))) if len(probs) > 1 else 0.0
    return high_ratio, entropy


def response_spectrum_features(
    action_probs: Mapping[str, np.ndarray],
    vlm_probs: Mapping[str, np.ndarray],
    primary_view: str = "uniform",
) -> Dict[str, float]:
    view_names = list(action_probs.keys())
    if not view_names:
        return {
            "R_fft_conf_high": 0.0,
            "R_fft_conf_entropy": 0.0,
            "R_fft_sem_high": 0.0,
            "R_fft_sem_entropy": 0.0,
            "R_fft_vlad_high": 0.0,
            "R_fft_vlad_entropy": 0.0,
        }
    if primary_view not in action_probs:
        primary_view = view_names[0]
    uniform_pa = action_probs[primary_view]
    confidences = np.asarray([np.max(action_probs[name]) for name in view_names], dtype=np.float64)
    sem_kl = np.asarray([symmetric_kl(action_probs[name], vlm_probs[name]) for name in view_names], dtype=np.float64)
    vlad_shift = np.asarray([symmetric_kl(uniform_pa, action_probs[name]) for name in view_names], dtype=np.float64)
    conf_high, conf_entropy = _fft_features(confidences)
    sem_high, sem_entropy = _fft_features(sem_kl)
    vlad_high, vlad_entropy = _fft_features(vlad_shift)
    return {
        "R_fft_conf_high": conf_high,
        "R_fft_conf_entropy": conf_entropy,
        "R_fft_sem_high": sem_high,
        "R_fft_sem_entropy": sem_entropy,
        "R_fft_vlad_high": vlad_high,
        "R_fft_vlad_entropy": vlad_entropy,
    }


def local_window_features(
    local_action_probs: Mapping[str, np.ndarray],
    local_vlm_probs: Mapping[str, np.ndarray],
    reference_action_probs: np.ndarray | None = None,
) -> Dict[str, float]:
    view_names = list(local_action_probs.keys())
    if not view_names:
        return {
            "R_local_sem_max": 0.0,
            "R_local_sem_top2": 0.0,
            "R_local_conf_max": 0.0,
            "R_local_conf_top2": 0.0,
            "R_local_shift_max": 0.0,
            "R_local_shift_top2": 0.0,
        }
    sem = np.asarray([symmetric_kl(local_action_probs[name], local_vlm_probs[name]) for name in view_names], dtype=np.float64)
    conf = np.asarray([np.max(local_action_probs[name]) for name in view_names], dtype=np.float64)
    if reference_action_probs is None:
        shift = np.zeros(len(view_names), dtype=np.float64)
    else:
        shift = np.asarray([symmetric_kl(reference_action_probs, local_action_probs[name]) for name in view_names], dtype=np.float64)

    def top2(values: np.ndarray) -> float:
        values = np.sort(values)
        return float(np.mean(values[-min(2, len(values)) :]))

    return {
        "R_local_sem_max": float(np.max(sem)),
        "R_local_sem_top2": top2(sem),
        "R_local_conf_max": float(np.max(conf)),
        "R_local_conf_top2": top2(conf),
        "R_local_shift_max": float(np.max(shift)),
        "R_local_shift_top2": top2(shift),
    }


def compute_tsc_features(
    action_probs: Mapping[str, np.ndarray],
    vlm_probs: Mapping[str, np.ndarray],
    primary_view: str = "uniform",
) -> Dict[str, float]:
    view_names = list(action_probs.keys())
    if not view_names:
        raise ValueError("No views were provided.")
    pa = np.stack([action_probs[name] for name in view_names], axis=0)
    pc = np.stack([vlm_probs[name] for name in view_names], axis=0)
    sem_kl = np.asarray([symmetric_kl(action_probs[name], vlm_probs[name]) for name in view_names], dtype=np.float64)
    pred_labels = np.argmax(pa, axis=1)
    confidences = np.max(pa, axis=1)

    if primary_view not in action_probs:
        primary_view = view_names[0]
    uniform_pa = action_probs[primary_view]
    uniform_shift = np.asarray(
        [symmetric_kl(uniform_pa, action_probs[name]) for name in view_names if name != primary_view],
        dtype=np.float64,
    )

    pred_uniform = int(np.argmax(action_probs[primary_view]))
    conf_uniform = float(np.max(action_probs[primary_view]))
    action_entropy = float(-np.sum(np.clip(action_probs[primary_view], 1e-12, 1.0) * np.log(np.clip(action_probs[primary_view], 1e-12, 1.0))))
    onehot_uniform = np.zeros_like(action_probs[primary_view], dtype=np.float64)
    onehot_uniform[pred_uniform] = 1.0

    features = {
        "R_model": float(np.mean(np.var(pa, axis=0))),
        "R_vlm": float(np.mean(np.var(pc, axis=0))),
        "R_sem_mean": float(np.mean(sem_kl)),
        "R_sem_max": float(np.max(sem_kl)),
        "R_sem_var": float(np.var(sem_kl)),
        "R_label_change": _label_change(pred_labels),
        "R_conf_var": float(np.var(confidences)),
        "R_uniform_shift": float(np.mean(uniform_shift)) if len(uniform_shift) else 0.0,
        "pred_uniform": pred_uniform,
        "conf_uniform": conf_uniform,
        "msp_score": 1.0 - conf_uniform,
        "predictive_entropy": action_entropy,
        "num_views": len(view_names),
        "vlad_original": float(sem_kl[view_names.index(primary_view)]),
        "vlad1_original_prob": float(sem_kl[view_names.index(primary_view)]),
        "vlad2_onehot_pred": symmetric_kl(onehot_uniform, vlm_probs[primary_view]),
    }
    features.update(response_spectrum_features(action_probs, vlm_probs, primary_view=primary_view))
    return features


def score_features(features: Mapping[str, float], mode: str = "max_evidence") -> float:
    evidence = [
        float(features["R_model"]),
        float(features["R_sem_mean"]),
        float(features["R_sem_var"]),
        float(features["R_label_change"]),
        float(features["R_conf_var"]),
        float(features["R_uniform_shift"]),
    ]
    if mode == "sum":
        return float(sum(evidence))
    if mode == "max_evidence":
        return float(max(evidence))
    if mode == "logsumexp":
        arr = np.asarray(evidence, dtype=np.float64)
        shift = float(np.max(arr))
        return float(shift + np.log(np.sum(np.exp(arr - shift))))
    raise ValueError(f"Unknown score mode: {mode}")
