from __future__ import annotations

from dataclasses import dataclass
import hashlib
from typing import Dict, Iterable, List

import numpy as np


def video_seed(base_seed: int, video_id: str) -> int:
    """Return a stable per-video seed independent of processing order/workers."""
    digest = hashlib.blake2s(video_id.encode("utf-8"), digest_size=4).digest()
    return (int(base_seed) + int.from_bytes(digest, "little")) % (2**32)


def _sample_indices(length: int, indices: np.ndarray, num_frames: int) -> np.ndarray:
    if length <= 0:
        raise ValueError("Cannot sample from an empty video.")
    indices = np.asarray(indices, dtype=np.int64)
    indices = np.clip(indices, 0, length - 1)
    if len(indices) >= num_frames:
        return indices[:num_frames]
    pad = np.full(num_frames - len(indices), indices[-1] if len(indices) else length - 1, dtype=np.int64)
    return np.concatenate([indices, pad])


def uniform_indices(length: int, num_frames: int) -> np.ndarray:
    return np.linspace(0, max(length - 1, 0), num_frames).astype(np.int64)


def random_start_indices(length: int, num_frames: int, rng: np.random.Generator) -> np.ndarray:
    if length <= num_frames:
        return _sample_indices(length, np.arange(length), num_frames)
    start = int(rng.integers(0, length - num_frames + 1))
    return np.arange(start, start + num_frames)


def random_sparse_indices(length: int, num_frames: int, rng: np.random.Generator) -> np.ndarray:
    if length <= num_frames:
        return _sample_indices(length, np.arange(length), num_frames)
    return np.sort(rng.choice(length, size=num_frames, replace=False))


def stride_indices(length: int, num_frames: int, stride: int) -> np.ndarray:
    if length <= 0:
        raise ValueError("Cannot sample from an empty video.")
    total_span = (num_frames - 1) * stride + 1
    start = max((length - total_span) // 2, 0)
    return _sample_indices(length, start + np.arange(num_frames) * stride, num_frames)


def segment_center_indices(length: int, num_frames: int) -> np.ndarray:
    edges = np.linspace(0, length, num_frames + 1)
    centers = ((edges[:-1] + edges[1:]) / 2.0).astype(np.int64)
    return _sample_indices(length, centers, num_frames)


def _frame_luma(frames: np.ndarray) -> np.ndarray:
    frames_f = frames.astype(np.float32)
    return 0.299 * frames_f[..., 0] + 0.587 * frames_f[..., 1] + 0.114 * frames_f[..., 2]


def keyframe_indices(frames: np.ndarray, num_frames: int) -> np.ndarray:
    """Simple keyframe sampler based on adjacent luma differences.

    It divides the video into num_frames temporal segments and chooses the
    frame closest to each segment's local mean motion magnitude. This keeps
    the implementation lightweight while preserving a content-aware view.
    """
    length = len(frames)
    if length <= num_frames:
        return _sample_indices(length, np.arange(length), num_frames)
    luma = _frame_luma(frames)
    diffs = np.zeros(length, dtype=np.float32)
    diffs[1:] = np.mean(np.abs(luma[1:] - luma[:-1]), axis=(1, 2))
    edges = np.linspace(0, length, num_frames + 1).astype(np.int64)
    chosen: List[int] = []
    for start, end in zip(edges[:-1], edges[1:]):
        end = max(end, start + 1)
        local = diffs[start:end]
        target = float(local.mean())
        chosen.append(start + int(np.argmin(np.abs(local - target))))
    return _sample_indices(length, np.asarray(chosen), num_frames)


def build_sampling_views(
    frames: np.ndarray,
    num_frames: int = 32,
    num_random: int = 4,
    seed: int = 0,
    strides: Iterable[int] = (2, 4),
) -> Dict[str, np.ndarray]:
    """Build temporal sampling views from frames shaped [T, H, W, C]."""
    if frames.ndim != 4:
        raise ValueError(f"Expected frames with shape [T,H,W,C], got {frames.shape}.")
    rng = np.random.default_rng(seed)
    length = len(frames)
    views: Dict[str, np.ndarray] = {}

    # Keep the reference view at native temporal resolution. The action-model
    # adapter applies its own model-zoo sampling rate, while CLIP selects its
    # configured context frames. Pre-sampling this view to a shared 32 frames
    # silently breaks the four models' different temporal contracts.
    views["uniform"] = frames
    for idx in range(num_random):
        views[f"random_start_{idx}"] = frames[random_start_indices(length, num_frames, rng)]
        views[f"random_sparse_{idx}"] = frames[random_sparse_indices(length, num_frames, rng)]
    for stride in strides:
        views[f"stride_{stride}"] = frames[stride_indices(length, num_frames, stride)]
    views["segment_center"] = frames[segment_center_indices(length, num_frames)]
    views["keyframe"] = frames[keyframe_indices(frames, num_frames)]
    return views


def build_local_window_views(
    frames: np.ndarray,
    num_windows: int,
    num_frames: int,
) -> Dict[str, np.ndarray]:
    """Build contiguous local temporal windows for response-profile features."""
    if num_windows <= 0:
        return {}
    if frames.ndim != 4:
        raise ValueError(f"Expected frames with shape [T,H,W,C], got {frames.shape}.")
    length = len(frames)
    edges = np.linspace(0, length, num_windows + 1).astype(np.int64)
    views: Dict[str, np.ndarray] = {}
    for idx, (start, end) in enumerate(zip(edges[:-1], edges[1:])):
        end = max(end, start + 1)
        local_indices = np.linspace(start, end - 1, num_frames).astype(np.int64)
        views[f"local_{idx}"] = frames[_sample_indices(length, local_indices, num_frames)]
    return views


def _motion_scores(frames: np.ndarray) -> np.ndarray:
    """Return deterministic per-frame luma motion scores."""
    luma = _frame_luma(frames)
    scores = np.zeros(len(frames), dtype=np.float64)
    if len(frames) > 1:
        scores[1:] = np.mean(np.abs(luma[1:] - luma[:-1]), axis=(1, 2), dtype=np.float64)
    return scores


def frozen_motion_indices(frames: np.ndarray) -> np.ndarray:
    """Endpoints plus the highest-motion frames, in chronological order."""
    length = len(frames)
    if length < 4:
        raise ValueError("Frozen model-input clips must contain at least four frames.")
    target = length // 2
    selected = {0, length - 1}
    scores = _motion_scores(frames)
    candidates = sorted(range(1, length - 1), key=lambda index: (-scores[index], index))
    selected.update(candidates[: max(target - 2, 0)])
    return np.asarray(sorted(selected), dtype=np.int64)


def build_frozen_global_views(frames: np.ndarray) -> Dict[str, np.ndarray]:
    """Build the five deterministic views frozen by protocol tdc-final-20260714.

    The input is the native 16/32-frame RGB model clip. Short views are kept at
    their natural length; the action adapter interpolates them over their full
    temporal support.
    """
    if frames.ndim != 4 or frames.shape[-1] != 3:
        raise ValueError(f"Expected RGB [T,H,W,C], got {frames.shape}.")
    length = len(frames)
    if length not in {16, 32}:
        raise ValueError(f"Frozen protocol requires a 16/32-frame model-input clip, got {length}.")
    crop_length = (3 * length) // 4
    return {
        "original": frames,
        "early_crop": frames[:crop_length],
        "late_crop": frames[length - crop_length :],
        "temporal_sparse": frames[::2],
        "motion_aware": frames[frozen_motion_indices(frames)],
    }


def build_frozen_local_views(frames: np.ndarray) -> Dict[str, np.ndarray]:
    """Return the four chronological, non-overlapping clip quarters."""
    if frames.ndim != 4 or frames.shape[-1] != 3:
        raise ValueError(f"Expected RGB [T,H,W,C], got {frames.shape}.")
    if len(frames) not in {16, 32}:
        raise ValueError(f"Frozen protocol requires a 16/32-frame model-input clip, got {len(frames)}.")
    edges = np.linspace(0, len(frames), 5, dtype=np.int64)
    return {f"local_{index}": frames[start:end] for index, (start, end) in enumerate(zip(edges[:-1], edges[1:]))}
