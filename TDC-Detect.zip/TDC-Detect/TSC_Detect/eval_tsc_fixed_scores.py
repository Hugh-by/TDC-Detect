from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.tsc_calibration import matrix_from_rows
from TSC_Detect.utils_metrics import binary_metrics


FIXED_FEATURES = [
    "vlad_original",
    "R_sem_mean",
    "R_sem_var",
    "R_uniform_shift",
    "R_model",
    "R_conf_var",
    "R_label_change",
]


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def clean_stats(rows: list[dict], features: list[str]) -> tuple[np.ndarray, np.ndarray]:
    x = matrix_from_rows(rows, features)
    return x.mean(axis=0), np.maximum(x.std(axis=0), 1e-6)


def positive_z(rows: list[dict], features: list[str], mean: np.ndarray, std: np.ndarray) -> np.ndarray:
    x = matrix_from_rows(rows, features)
    return np.maximum((x - mean) / std, 0.0)


def fixed_scores(rows: list[dict], calib_rows: list[dict]) -> dict[str, np.ndarray]:
    mean, std = clean_stats(calib_rows, FIXED_FEATURES)
    z = positive_z(rows, FIXED_FEATURES, mean, std)
    idx = {name: i for i, name in enumerate(FIXED_FEATURES)}
    raw = {name: np.asarray([float(row[name]) for row in rows], dtype=np.float64) for name in FIXED_FEATURES}

    # Weak attacks often show small temporal-instability cues rather than the large semantic KL shifts
    # that make stronger PGD easy for VLAD. These formulas are fixed, clean-normalized probes.
    temporal = (
        0.45 * z[:, idx["R_uniform_shift"]]
        + 0.25 * z[:, idx["R_model"]]
        + 0.20 * z[:, idx["R_label_change"]]
        + 0.10 * z[:, idx["R_conf_var"]]
    )
    semantic_temporal = (
        0.55 * z[:, idx["vlad_original"]]
        + 0.20 * z[:, idx["R_sem_var"]]
        + 0.15 * z[:, idx["R_uniform_shift"]]
        + 0.10 * z[:, idx["R_label_change"]]
    )
    weak_balanced = (
        0.45 * z[:, idx["vlad_original"]]
        + 0.20 * z[:, idx["R_uniform_shift"]]
        + 0.15 * z[:, idx["R_sem_var"]]
        + 0.10 * z[:, idx["R_model"]]
        + 0.10 * z[:, idx["R_label_change"]]
    )
    weak_margin = weak_balanced - 0.20 * z[:, idx["R_sem_mean"]]
    vlad_label = z[:, idx["vlad_original"]] + 0.20 * z[:, idx["R_label_change"]]
    vlad_uniform = z[:, idx["vlad_original"]] + 0.20 * z[:, idx["R_uniform_shift"]]
    vlad_light_tsc = (
        z[:, idx["vlad_original"]]
        + 0.12 * z[:, idx["R_uniform_shift"]]
        + 0.08 * z[:, idx["R_model"]]
        + 0.10 * z[:, idx["R_label_change"]]
    )

    return {
        "vlad_original": raw["vlad_original"],
        "tsc_score_current": np.asarray([float(row["score"]) for row in rows], dtype=np.float64),
        "fixed_temporal_only": temporal,
        "fixed_semantic_temporal": semantic_temporal,
        "fixed_weak_balanced": weak_balanced,
        "fixed_weak_margin": weak_margin,
        "fixed_vlad_label": vlad_label,
        "fixed_vlad_uniform": vlad_uniform,
        "fixed_vlad_light_tsc": vlad_light_tsc,
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Evaluate fixed clean-calibrated TSC scores.")
    parser.add_argument("--calib-clean", required=True, help="Clean-only calibration CSV.")
    parser.add_argument("--inputs", nargs="+", required=True, help="Attack probe CSVs.")
    parser.add_argument("--names", nargs="+", default=None)
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_fixed_score_summary.csv")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    calib_rows = read_rows([args.calib_clean])
    names = args.names or [Path(path).stem for path in args.inputs]
    if len(names) != len(args.inputs):
        raise SystemExit("--names length must match --inputs length.")

    out_rows = []
    for path, setting in zip(args.inputs, names):
        rows = read_rows([path])
        labels = [int(row["is_adv"]) for row in rows]
        scores_by_name = fixed_scores(rows, calib_rows)
        n_clean = sum(label == 0 for label in labels)
        n_adv = sum(label == 1 for label in labels)
        for method, scores in scores_by_name.items():
            out_rows.append(
                {
                    "setting": setting,
                    "method": method,
                    "n_clean": n_clean,
                    "n_adv": n_adv,
                    **binary_metrics(labels, scores),
                }
            )

    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "setting",
        "method",
        "n_clean",
        "n_adv",
        "roc_auc",
        "pr_auc",
        "fpr_at_95_tpr",
        "tpr_at_1_fpr",
        "clean_mean",
        "clean_std",
        "adv_mean",
        "adv_std",
    ]
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(out_rows)

    for row in out_rows:
        print(
            f"{row['setting']:8s} {row['method']:24s} "
            f"AUC={row['roc_auc']:.4f} PR={row['pr_auc']:.4f} "
            f"FPR95={row['fpr_at_95_tpr']:.3f} TPR1={row['tpr_at_1_fpr']:.3f}"
        )
    print(f"Saved {output}")


if __name__ == "__main__":
    main()
