from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.tsc_calibration import DEFAULT_FEATURES, fit_logistic_regression, logistic_scores
from TSC_Detect.utils_metrics import binary_metrics


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Leave-one-video-out CV for TSC logistic calibrator.")
    parser.add_argument("--inputs", nargs="+", required=True)
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/tsc_calibrator_cv_summary.csv")
    parser.add_argument("--features", nargs="+", default=DEFAULT_FEATURES)
    parser.add_argument("--logistic-steps", type=int, default=3000)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = read_rows(args.inputs)
    groups = sorted({row["video_path"] for row in rows})
    cv_scores = np.zeros(len(rows), dtype=np.float64)
    for group in groups:
        train = [row for row in rows if row["video_path"] != group]
        test_indices = [idx for idx, row in enumerate(rows) if row["video_path"] == group]
        test = [rows[idx] for idx in test_indices]
        model = fit_logistic_regression(
            train,
            args.features,
            lr=args.logistic_lr,
            steps=args.logistic_steps,
            l2=args.logistic_l2,
        )
        cv_scores[test_indices] = logistic_scores(test, model)

    labels = [int(row["is_adv"]) for row in rows]
    results = [
        {"method": "vlad_original", **binary_metrics(labels, [float(row["vlad_original"]) for row in rows])},
        {"method": "tsc_score_current", **binary_metrics(labels, [float(row["score"]) for row in rows])},
        {"method": "logistic_leave_one_video_out", **binary_metrics(labels, cv_scores)},
    ]

    output = Path(args.output_csv)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["method", "roc_auc", "pr_auc", "fpr_at_95_tpr", "tpr_at_1_fpr", "clean_mean", "clean_std", "adv_mean", "adv_std"]
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    for row in results:
        print(
            f"{row['method']:30s} AUC={row['roc_auc']:.4f} PR={row['pr_auc']:.4f} "
            f"FPR95={row['fpr_at_95_tpr']:.3f} TPR1={row['tpr_at_1_fpr']:.3f} "
            f"clean={row['clean_mean']:.4f} adv={row['adv_mean']:.4f}"
        )
    print(f"Saved {output}")


if __name__ == "__main__":
    main()

