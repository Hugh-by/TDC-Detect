from __future__ import annotations

import argparse
import csv
import random
from collections import defaultdict
from pathlib import Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Create calib/test splits from a clean-correct manifest.")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--calib-frac", type=float, default=0.8)
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rng = random.Random(args.seed)
    with Path(args.input).open("r", encoding="utf-8", newline="") as file:
        rows = list(csv.DictReader(file))
        fieldnames = list(rows[0].keys()) if rows else []
    if not rows:
        raise SystemExit(f"No rows in {args.input}")
    if "split" not in fieldnames:
        fieldnames.insert(0, "split")

    groups: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        groups[row.get("class_name") or row.get("label", "")].append(row)

    selected: list[dict] = []
    for label in sorted(groups):
        group = groups[label]
        rng.shuffle(group)
        if len(group) == 1:
            n_calib = 0
        else:
            n_calib = max(1, min(len(group) - 1, round(len(group) * args.calib_frac)))
        for index, row in enumerate(group):
            out = dict(row)
            out["split"] = "calib" if index < n_calib else "test"
            selected.append(out)

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(selected)

    calib = sum(row["split"] == "calib" for row in selected)
    test = sum(row["split"] == "test" for row in selected)
    print(f"Saved {len(selected)} rows to {output}")
    print(f"classes={len(groups)} calib={calib} test={test}")


if __name__ == "__main__":
    main()
