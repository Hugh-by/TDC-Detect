from __future__ import annotations

import argparse
import csv
import hashlib
import math
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames
from TSC_Detect.run_final_extract import ATTACK_SETTINGS, PROTOCOL_ID, SEED, stable_seed
from TSC_Detect.run_tsc_detect import choose_device, load_real_models
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES
from TSC_Detect.utils_video import load_frames


FIELDS = ["protocol_id", "experiment", "action_model", "pair_id", "relative_path", "attack", "attack_seed", "clean_pred", "attacked_pred", "attack_success", "selected_frame", "measured_linf", "psnr", "mean_ssim", "min_ssim"]


def perceptual(clean: np.ndarray, adv: np.ndarray, device) -> tuple[float, float, float]:
    mse = float(np.mean((clean.astype(np.float64) - adv.astype(np.float64)) ** 2))
    psnr = float("inf") if mse == 0 else float(10 * math.log10(1.0 / mse))
    x = torch.as_tensor(clean, device=device).permute(0, 3, 1, 2)
    y = torch.as_tensor(adv, device=device).permute(0, 3, 1, 2)
    coordinates = torch.arange(11, device=device, dtype=x.dtype) - 5
    gaussian = torch.exp(-(coordinates**2) / (2 * 1.5**2)); gaussian /= gaussian.sum()
    kernel = (gaussian[:, None] * gaussian[None, :]).expand(3, 1, 11, 11).contiguous()
    mu_x = F.conv2d(x, kernel, padding=5, groups=3); mu_y = F.conv2d(y, kernel, padding=5, groups=3)
    var_x = F.conv2d(x * x, kernel, padding=5, groups=3) - mu_x * mu_x
    var_y = F.conv2d(y * y, kernel, padding=5, groups=3) - mu_y * mu_y
    cov = F.conv2d(x * y, kernel, padding=5, groups=3) - mu_x * mu_y
    c1, c2 = 0.01**2, 0.03**2
    values = (((2 * mu_x * mu_y + c1) * (2 * cov + c2)) / ((mu_x * mu_x + mu_y * mu_y + c1) * (var_x + var_y + c2))).mean(dim=(1, 2, 3)).detach().cpu().numpy()
    return psnr, float(np.mean(values)), float(np.min(values))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--model", choices=sorted(ACTION_MODEL_PROFILES), required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args(); device = choose_device(args.device)
    torch.manual_seed(SEED); torch.cuda.manual_seed_all(SEED); torch.use_deterministic_algorithms(True, warn_only=True)
    torch.backends.cudnn.deterministic = True; torch.backends.cudnn.benchmark = False
    action_model, _, _ = load_real_models(device, args.model)
    with args.manifest.open(encoding="utf-8-sig", newline="") as handle: rows = list(csv.DictReader(handle))
    if len(rows) != 200:
        raise ValueError(f"E10 requires exactly 200 fixed K400 clips, got {len(rows)} from {args.manifest}")
    done = set()
    if args.resume and args.output.exists():
        with args.output.open(encoding="utf-8", newline="") as handle: done = {(row["pair_id"], row["attack"]) for row in csv.DictReader(handle)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if args.resume and args.output.exists() else "w"
    with args.output.open(mode, encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        if mode == "w" or args.output.stat().st_size == 0: writer.writeheader()
        for index, row in enumerate(rows, 1):
            relative = row["relative_path"]; pair_id = hashlib.sha256(f"k400|{args.model}|{relative}".encode()).hexdigest()
            source = load_frames(row["path"])
            clean = prepare_attack_frames(source, args.model, device).detach().cpu().numpy().astype(np.float32)
            for attack, setting in ATTACK_SETTINGS.items():
                if (pair_id, attack) in done: continue
                seed = stable_seed(relative, args.model, attack)
                result = make_attack(action_model, source, args.model, device, setting["internal"], setting["eps"], setting["alpha"], setting["iters"], seed)
                psnr, mean_ssim, min_ssim = perceptual(clean, result.rgb, device)
                writer.writerow({"protocol_id": PROTOCOL_ID, "experiment": "E10", "action_model": args.model, "pair_id": pair_id, "relative_path": relative, "attack": attack, "attack_seed": seed, "clean_pred": result.clean_pred, "attacked_pred": result.adv_pred, "attack_success": int(result.attack_success), "selected_frame": "" if result.attacked_frame is None else result.attacked_frame, "measured_linf": result.linf, "psnr": psnr, "mean_ssim": mean_ssim, "min_ssim": min_ssim})
                handle.flush()
            print(f"E10 {args.model} {index}/{len(rows)}", flush=True)


if __name__ == "__main__": main()
