from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path

import numpy as np

from TSC_Detect.eval_tsc_fixed_scores import fixed_scores
from TSC_Detect.eval_tsc_gated_scores import score_variants as gated_score_variants
from TSC_Detect.tsc_calibration import DEFAULT_FEATURES, fit_logistic_regression, logistic_scores
from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


def read_rows(paths: list[str]) -> list[dict]:
    rows: list[dict] = []
    for path in paths:
        with Path(path).open("r", encoding="utf-8", newline="") as file:
            rows.extend(csv.DictReader(file))
    return rows


def video_id(path: str) -> str:
    stem = Path(path).stem
    if stem.startswith("v_"):
        return stem
    return path


def stable_random_value(text: str, seed: int) -> float:
    digest = hashlib.sha256(f"{seed}:{text}".encode("utf-8")).digest()
    value = int.from_bytes(digest[:8], "big")
    return value / float(2**64 - 1)


def split_by_video(rows: list[dict], val_fraction: float, seed: int) -> tuple[list[dict], list[dict]]:
    videos = sorted({video_id(row["video_path"]) for row in rows})
    if not videos:
        raise ValueError("No video_path values found.")
    ranked = sorted(videos, key=lambda name: stable_random_value(name, seed))
    n_val = int(round(len(ranked) * val_fraction))
    n_val = min(max(n_val, 1), len(ranked) - 1)
    val_videos = set(ranked[:n_val])
    val_rows = [row for row in rows if video_id(row["video_path"]) in val_videos]
    test_rows = [row for row in rows if video_id(row["video_path"]) not in val_videos]
    return val_rows, test_rows


def grouped_indices(rows: list[dict]) -> list[np.ndarray]:
    groups: dict[str, list[int]] = {}
    for idx, row in enumerate(rows):
        groups.setdefault(video_id(row["video_path"]), []).append(idx)
    return [np.asarray(indices, dtype=np.int64) for _, indices in sorted(groups.items())]


def bootstrap_delta(
    labels: np.ndarray,
    baseline_scores: np.ndarray,
    method_scores: np.ndarray,
    groups: list[np.ndarray],
    n_boot: int,
    seed: int,
) -> dict:
    rng = np.random.default_rng(seed)
    deltas = np.zeros(n_boot, dtype=np.float64)
    aucs = np.zeros(n_boot, dtype=np.float64)
    base_aucs = np.zeros(n_boot, dtype=np.float64)
    group_count = len(groups)
    for boot in range(n_boot):
        sampled = rng.integers(0, group_count, size=group_count)
        indices = np.concatenate([groups[idx] for idx in sampled])
        y = labels[indices]
        if len(np.unique(y)) < 2:
            deltas[boot] = np.nan
            aucs[boot] = np.nan
            base_aucs[boot] = np.nan
            continue
        base_auc = roc_auc_np(y, baseline_scores[indices])
        auc = roc_auc_np(y, method_scores[indices])
        base_aucs[boot] = base_auc
        aucs[boot] = auc
        deltas[boot] = auc - base_auc
    deltas = deltas[~np.isnan(deltas)]
    aucs = aucs[~np.isnan(aucs)]
    base_aucs = base_aucs[~np.isnan(base_aucs)]
    return {
        "auc_ci_low": float(np.quantile(aucs, 0.025)),
        "auc_ci_high": float(np.quantile(aucs, 0.975)),
        "baseline_auc_ci_low": float(np.quantile(base_aucs, 0.025)),
        "baseline_auc_ci_high": float(np.quantile(base_aucs, 0.975)),
        "delta_ci_low": float(np.quantile(deltas, 0.025)),
        "delta_ci_high": float(np.quantile(deltas, 0.975)),
        "p_delta_le_0": float(np.mean(deltas <= 0.0)),
    }


def clean_calibrated_scores(rows: list[dict], calib_rows: list[dict]) -> dict[str, np.ndarray]:
    fixed = fixed_scores(rows, calib_rows)
    gated = gated_score_variants(rows, calib_rows)
    return {
        "fixed_vlad_light_tsc": fixed["fixed_vlad_light_tsc"],
        "fixed_semantic_temporal": fixed["fixed_semantic_temporal"],
        "gated_q90_medium": gated["gated_q90_medium"],
        "gated_window_light": gated["gated_window_light"],
    }


def evaluate_setting(
    setting: str,
    rows: list[dict],
    calib_rows: list[dict],
    val_fraction: float,
    seed: int,
    n_boot: int,
    logistic_steps: int,
    logistic_lr: float,
    logistic_l2: float,
) -> list[dict]:
    val_rows, test_rows = split_by_video(rows, val_fraction, seed)
    if len({int(row["is_adv"]) for row in val_rows}) < 2 or len({int(row["is_adv"]) for row in test_rows}) < 2:
        raise ValueError(f"{setting}: val/test split does not contain both classes.")

    logistic = fit_logistic_regression(
        val_rows,
        DEFAULT_FEATURES,
        lr=logistic_lr,
        steps=logistic_steps,
        l2=logistic_l2,
    )

    labels = np.asarray([int(row["is_adv"]) for row in test_rows], dtype=np.int64)
    scores: dict[str, np.ndarray] = {
        "vlad_original": np.asarray([float(row["vlad_original"]) for row in test_rows], dtype=np.float64),
        "tsc_score_current": np.asarray([float(row["score"]) for row in test_rows], dtype=np.float64),
        "vlad_tsc_logistic_val": logistic_scores(test_rows, logistic),
    }
    scores.update(clean_calibrated_scores(test_rows, calib_rows))
    groups = grouped_indices(test_rows)
    baseline = scores["vlad_original"]

    out = []
    for method, method_scores in scores.items():
        metric = binary_metrics(labels, method_scores)
        row = {
            "setting": setting,
            "seed": seed,
            "method": method,
            "n_val_rows": len(val_rows),
            "n_test_rows": len(test_rows),
            "n_val_videos": len({video_id(row["video_path"]) for row in val_rows}),
            "n_test_videos": len({video_id(row["video_path"]) for row in test_rows}),
            "n_test_clean": int(np.sum(labels == 0)),
            "n_test_adv": int(np.sum(labels == 1)),
            **metric,
            "delta_vs_vlad": metric["roc_auc"] - binary_metrics(labels, baseline)["roc_auc"],
            "auc_ci_low": "",
            "auc_ci_high": "",
            "delta_ci_low": "",
            "delta_ci_high": "",
            "p_delta_le_0": "",
        }
        if method != "vlad_original":
            boot = bootstrap_delta(labels, baseline, method_scores, groups, n_boot=n_boot, seed=seed + 1009)
            row.update(
                {
                    "auc_ci_low": boot["auc_ci_low"],
                    "auc_ci_high": boot["auc_ci_high"],
                    "delta_ci_low": boot["delta_ci_low"],
                    "delta_ci_high": boot["delta_ci_high"],
                    "p_delta_le_0": boot["p_delta_le_0"],
                }
            )
        else:
            boot = bootstrap_delta(labels, baseline, method_scores, groups, n_boot=n_boot, seed=seed + 1009)
            row["auc_ci_low"] = boot["baseline_auc_ci_low"]
            row["auc_ci_high"] = boot["baseline_auc_ci_high"]
        out.append(row)
    return out


def write_csv(path: str, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "setting",
        "seed",
        "method",
        "n_val_rows",
        "n_test_rows",
        "n_val_videos",
        "n_test_videos",
        "n_test_clean",
        "n_test_adv",
        "roc_auc",
        "pr_auc",
        "fpr_at_95_tpr",
        "tpr_at_1_fpr",
        "clean_mean",
        "clean_std",
        "adv_mean",
        "adv_std",
        "delta_vs_vlad",
        "auc_ci_low",
        "auc_ci_high",
        "delta_ci_low",
        "delta_ci_high",
        "p_delta_le_0",
    ]
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Held-out protocol for VLAD-TSC calibration.")
    parser.add_argument("--calib-clean", required=True)
    parser.add_argument("--fgsm", required=True)
    parser.add_argument("--pgd1", required=True)
    parser.add_argument("--pgd2", default=None)
    parser.add_argument("--output-csv", default="TSC_Detect/outputs/vlad_tsc_protocol.csv")
    parser.add_argument("--val-fraction", type=float, default=0.5)
    parser.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    parser.add_argument("--n-boot", type=int, default=1000)
    parser.add_argument("--logistic-steps", type=int, default=1500)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    calib_rows = read_rows([args.calib_clean])
    datasets = [
        ("FGSM", read_rows([args.fgsm])),
        ("PGD-1", read_rows([args.pgd1])),
        ("FGSM+PGD-1", read_rows([args.fgsm, args.pgd1])),
    ]
    if args.pgd2:
        datasets.extend(
            [
                ("PGD-2", read_rows([args.pgd2])),
                ("FGSM+PGD-1+PGD-2", read_rows([args.fgsm, args.pgd1, args.pgd2])),
            ]
        )

    rows = []
    for seed in args.seeds:
        for setting, setting_rows in datasets:
            rows.extend(
                evaluate_setting(
                    setting,
                    setting_rows,
                    calib_rows,
                    val_fraction=args.val_fraction,
                    seed=seed,
                    n_boot=args.n_boot,
                    logistic_steps=args.logistic_steps,
                    logistic_lr=args.logistic_lr,
                    logistic_l2=args.logistic_l2,
                )
            )
    write_csv(args.output_csv, rows)

    for setting in sorted({row["setting"] for row in rows}):
        print(f"\n{setting}")
        subset = [row for row in rows if row["setting"] == setting]
        for method in ["vlad_original", "tsc_score_current", "fixed_vlad_light_tsc", "gated_q90_medium", "vlad_tsc_logistic_val"]:
            method_rows = [row for row in subset if row["method"] == method]
            aucs = np.asarray([float(row["roc_auc"]) for row in method_rows], dtype=np.float64)
            deltas = np.asarray([float(row["delta_vs_vlad"]) for row in method_rows], dtype=np.float64)
            print(
                f"{method:24s} AUC={aucs.mean():.4f}+-{aucs.std():.4f} "
                f"delta={deltas.mean():+.4f}+-{deltas.std():.4f}"
            )


if __name__ == "__main__":
    main()
