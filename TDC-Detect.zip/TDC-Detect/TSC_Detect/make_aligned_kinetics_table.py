from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np

from TSC_Detect.eval_tsc_v2_features import collect_scores
from TSC_Detect.utils_metrics import binary_metrics


KEEP_TSC_METHODS = {
    "vlad_original": "TSC path VLAD baseline",
    "single_score": "TSC-v2 raw score",
    "logistic_v1_lovo": "TSC logistic v1 LOVO",
    "logistic_v2_lovo": "TSC logistic v2 LOVO",
}


def read_rows(path: str | Path) -> list[dict]:
    with Path(path).open("r", encoding="utf-8", newline="") as file:
        return list(csv.DictReader(file))


def write_csv(path: str | Path, rows: list[dict]) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {output}")


def write_markdown(path: str | Path, rows: list[dict], title: str) -> None:
    output = Path(path)
    output.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        f"# {title}",
        "",
        "All rows below are evaluated on the same Kinetics-400 pilot split. For success-only, the clean side keeps all 54 clean test videos, and the adversarial side keeps only successful attacks.",
        "",
        "| Attack | Setting | Method | Clean | Adv | ROC-AUC | PR-AUC | FPR@95TPR | TPR@1FPR | Delta vs pure VLAD |",
        "|---|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for row in rows:
        lines.append(
            "| {attack} | {setting} | {method} | {n_clean} | {n_adv} | {roc_auc:.4f} | {pr_auc:.4f} | {fpr_at_95_tpr:.4f} | {tpr_at_1_fpr:.4f} | {delta_vs_pure_vlad:+.4f} |".format(
                **row
            )
        )
    lines.extend(
        [
            "",
            "Notes:",
            "",
            "- `Pure VLAD-1 symmetric KL` is the paper-aligned reproduction score.",
            "- `TSC path VLAD baseline` uses the TSC feature extraction path; formula is symmetric KL, but preprocessing differs from the pure runner.",
            "- LOVO rows are held-out by video path and are the honest logistic-fusion rows for this pilot.",
        ]
    )
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"Saved {output}")


def filter_rows(rows: list[dict], setting: str, success_paths: set[str]) -> list[dict]:
    if setting == "full":
        return rows
    if setting != "success_only":
        raise ValueError(f"Unknown setting: {setting}")
    out: list[dict] = []
    for row in rows:
        if int(row["is_adv"]) == 0 or row["video_path"] in success_paths:
            out.append(row)
    return out


def success_paths_from_vlad(rows: list[dict]) -> set[str]:
    return {
        row["video_path"]
        for row in rows
        if int(row["is_adv"]) == 1 and str(row.get("attack_success", "")) in {"1", "1.0", "True", "true"}
    }


def assert_same_rows(vlad_rows: list[dict], tsc_rows: list[dict], attack: str, setting: str) -> None:
    for is_adv in (0, 1):
        vlad_paths = {row["video_path"] for row in vlad_rows if int(row["is_adv"]) == is_adv}
        tsc_paths = {row["video_path"] for row in tsc_rows if int(row["is_adv"]) == is_adv}
        if vlad_paths != tsc_paths:
            raise ValueError(
                f"{attack} {setting} is_adv={is_adv} row mismatch: "
                f"pure_only={len(vlad_paths - tsc_paths)} tsc_only={len(tsc_paths - vlad_paths)}"
            )


def metric_row(
    *,
    attack: str,
    setting: str,
    method: str,
    score_source: str,
    labels: np.ndarray,
    scores: np.ndarray,
    pure_auc: float,
) -> dict:
    metrics = binary_metrics(labels, scores)
    return {
        "attack": attack,
        "setting": setting,
        "method": method,
        "score_source": score_source,
        "n_clean": int(np.sum(labels == 0)),
        "n_adv": int(np.sum(labels == 1)),
        "roc_auc": metrics["roc_auc"],
        "pr_auc": metrics["pr_auc"],
        "fpr_at_95_tpr": metrics["fpr_at_95_tpr"],
        "tpr_at_1_fpr": metrics["tpr_at_1_fpr"],
        "clean_mean": metrics["clean_mean"],
        "adv_mean": metrics["adv_mean"],
        "delta_vs_pure_vlad": metrics["roc_auc"] - pure_auc,
    }


def build_rows(args: argparse.Namespace) -> list[dict]:
    all_rows: list[dict] = []
    attacks = [
        ("fgsm", args.vlad_fgsm, args.tsc_fgsm),
        ("pgd40", args.vlad_pgd40, args.tsc_pgd40),
    ]
    for attack, vlad_path, tsc_path in attacks:
        vlad_all = read_rows(vlad_path)
        tsc_all = read_rows(tsc_path)
        success_paths = success_paths_from_vlad(vlad_all)
        for setting in ("full", "success_only"):
            vlad_rows = filter_rows(vlad_all, setting, success_paths)
            tsc_rows = filter_rows(tsc_all, setting, success_paths)
            assert_same_rows(vlad_rows, tsc_rows, attack, setting)

            labels = np.asarray([int(row["is_adv"]) for row in vlad_rows], dtype=np.int64)
            pure_scores = np.asarray([float(row["vlad1_score"]) for row in vlad_rows], dtype=np.float64)
            pure_auc = binary_metrics(labels, pure_scores)["roc_auc"]
            all_rows.append(
                metric_row(
                    attack=attack,
                    setting=setting,
                    method="Pure VLAD-1 symmetric KL",
                    score_source="vlad1_score",
                    labels=labels,
                    scores=pure_scores,
                    pure_auc=pure_auc,
                )
            )

            tsc_labels = np.asarray([int(row["is_adv"]) for row in tsc_rows], dtype=np.int64)
            if not np.array_equal(labels, tsc_labels):
                raise ValueError(f"{attack} {setting} label mismatch after row alignment.")
            scores_by_name = collect_scores(
                tsc_rows,
                steps=args.logistic_steps,
                lr=args.logistic_lr,
                l2=args.logistic_l2,
                include_lovo=True,
            )
            for score_name, method_name in KEEP_TSC_METHODS.items():
                all_rows.append(
                    metric_row(
                        attack=attack,
                        setting=setting,
                        method=method_name,
                        score_source=score_name,
                        labels=labels,
                        scores=scores_by_name[score_name],
                        pure_auc=pure_auc,
                    )
                )
    return all_rows


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build a sample-aligned Kinetics pilot method table.")
    parser.add_argument("--vlad-fgsm", required=True)
    parser.add_argument("--vlad-pgd40", required=True)
    parser.add_argument("--tsc-fgsm", required=True)
    parser.add_argument("--tsc-pgd40", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-md", required=True)
    parser.add_argument("--title", default="Aligned Kinetics-400 Pilot Main Table - 2026-06-04")
    parser.add_argument("--logistic-steps", type=int, default=1500)
    parser.add_argument("--logistic-lr", type=float, default=0.1)
    parser.add_argument("--logistic-l2", type=float, default=1e-3)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    rows = build_rows(args)
    write_csv(args.output_csv, rows)
    write_markdown(args.output_md, rows, args.title)


if __name__ == "__main__":
    main()
