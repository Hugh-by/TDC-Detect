from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


METHODS = (
    "vlad_original",
    "vlad2_onehot_pred",
    "logistic_v1_train_eval",
    "logistic_v2_train_eval",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Build repaired evaluation summary tables.")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path("/root/autodl-tmp/tsc/outputs/repaired_k400_eval"),
    )
    parser.add_argument("--dataset", default="k400")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    root = args.root
    dataset = args.dataset
    detailed = []
    grouped = defaultdict(list)
    for path in sorted(root.glob("*_summary.csv")):
        stem = path.name.removesuffix("_summary.csv")
        if not stem.startswith(("x3d_m_", "mvit_base_16x4_", "slowfast_r50_", "csn_r101_")):
            continue
        setting = "success" if stem.endswith("_success") else "full"
        core = stem.removesuffix("_success").removesuffix("_full")
        attack = next(a for a in ("fgsm_v", "pgd_v", "ofa", "flick") if f"_{a}" in core)
        model = core.removesuffix(f"_{attack}")
        rows = {row["method"]: row for row in csv.DictReader(path.open())}
        out = {"model": model, "attack": attack, "setting": setting}
        for method in METHODS:
            row = rows[method]
            out[f"{method}_auc"] = row["roc_auc"]
            out[f"{method}_ci_low"] = row["auc_ci_low"]
            out[f"{method}_ci_high"] = row["auc_ci_high"]
            grouped[(setting, method)].append(float(row["roc_auc"]))
        detailed.append(out)

    detail_path = root / f"repaired_{dataset}_auc_detailed.csv"
    with detail_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(detailed[0]))
        writer.writeheader(); writer.writerows(detailed)

    summary = []
    for (setting, method), values in sorted(grouped.items()):
        summary.append({
            "setting": setting,
            "method": method,
            "n_model_attack_rows": len(values),
            "macro_mean_auc": sum(values) / len(values),
            "min_auc": min(values),
            "max_auc": max(values),
        })
    summary_path = root / f"repaired_{dataset}_auc_summary.csv"
    with summary_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
        writer.writeheader(); writer.writerows(summary)
    for row in summary:
        print(row)

    group_rows = []
    group_values = defaultdict(list)
    for path in sorted(root.glob("*_group5.csv")):
        stem = path.name.removesuffix("_group5.csv")
        if not stem.startswith(("x3d_m_", "mvit_base_16x4_", "slowfast_r50_", "csn_r101_")):
            continue
        setting = "success" if stem.endswith("_success") else "full"
        core = stem.removesuffix("_success").removesuffix("_full")
        attack = next(a for a in ("fgsm_v", "pgd_v", "ofa", "flick") if f"_{a}" in core)
        model = core.removesuffix(f"_{attack}")
        for row in csv.DictReader(path.open()):
            out = {"model": model, "attack": attack, "setting": setting, **row}
            group_rows.append(out)
            group_values[(setting, row["method"])].append(float(row["roc_auc"]))
    group_detail_path = root / f"repaired_{dataset}_group5_detailed.csv"
    with group_detail_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(group_rows[0]))
        writer.writeheader(); writer.writerows(group_rows)
    group_summary = [
        {
            "setting": setting, "method": method, "n_model_attack_rows": len(values),
            "macro_mean_auc": sum(values) / len(values), "min_auc": min(values), "max_auc": max(values),
        }
        for (setting, method), values in sorted(group_values.items())
    ]
    group_summary_path = root / f"repaired_{dataset}_group5_summary.csv"
    with group_summary_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(group_summary[0]))
        writer.writeheader(); writer.writerows(group_summary)
    print("GROUP5")
    for row in group_summary:
        print(row)
    print(detail_path)
    print(summary_path)
    print(group_detail_path)
    print(group_summary_path)


if __name__ == "__main__":
    main()
