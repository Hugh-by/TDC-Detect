from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.run_final_e8_adaptive import EOT_VIEWS, TDC_V2, select_lambda, surrogate_logit, temporal_probe


class FinalAdaptiveHelperTests(unittest.TestCase):
    def test_all_eot_probes_resample_to_native_length(self) -> None:
        clip = torch.arange(16 * 4 * 5 * 3, dtype=torch.float32).reshape(16, 4, 5, 3)
        motion = torch.tensor([0, 2, 5, 7, 8, 10, 13, 15])
        outputs = [temporal_probe(clip, name, motion) for name in EOT_VIEWS]
        self.assertTrue(all(tuple(value.shape) == tuple(clip.shape) for value in outputs))
        self.assertTrue(all(torch.isfinite(value).all() for value in outputs))

    def test_action_surrogate_has_finite_probe_gradient(self) -> None:
        original = torch.softmax(torch.linspace(-1, 1, 400), dim=0)
        logits = torch.linspace(1, -1, 400, requires_grad=True)
        probe = torch.softmax(logits, dim=0)
        score = surrogate_logit(original, probe, "local_0", {name: 0.1 for name in TDC_V2})
        gradient = torch.autograd.grad(score, logits)[0]
        self.assertTrue(torch.isfinite(gradient).all())
        self.assertGreater(float(gradient.abs().sum()), 0.0)

    def test_lambda_selection_uses_calibration_lexicographic_rule(self) -> None:
        rows = []
        for tradeoff, base in ((0.1, 0.3), (1.0, 0.1), (10.0, 0.2)):
            for video in range(4):
                for restart in range(3):
                    rows.append({
                        "tradeoff_lambda": tradeoff, "pair_id": f"v{video}", "restart": restart,
                        "attack_success": int(restart < 2), "detector_score": base + restart / 100,
                    })
        chosen, summary = select_lambda(pd.DataFrame(rows), threshold=0.25)
        self.assertEqual(chosen, 1.0)
        self.assertEqual(len(summary), 3)
        self.assertTrue(np.isfinite([row["joint_success_evasion_rate"] for row in summary]).all())


if __name__ == "__main__":
    unittest.main()
