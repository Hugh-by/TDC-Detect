from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames


class MeanClassifier(torch.nn.Module):
    def forward(self, value):
        mean = value.mean(dim=(1, 2, 3, 4))
        return torch.stack((mean, -mean), dim=1)


class AttackTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.frames = np.full((80, 48, 64, 3), 160, dtype=np.uint8)
        cls.model = MeanClassifier().eval()
        cls.device = torch.device("cpu")

    def run_attack(self, name: str):
        return make_attack(
            self.model,
            self.frames,
            "mvit_base_16x4",
            self.device,
            name,
            eps=0.03,
            alpha=0.01,
            iters=2,
            seed=4,
        )

    def test_all_attacks_obey_rgb_budget(self) -> None:
        clean = prepare_attack_frames(self.frames, "mvit_base_16x4", self.device).numpy()
        for name in ("fgsm", "pgd", "ofa", "flick"):
            with self.subTest(name=name):
                result = self.run_attack(name)
                adv = result.frames.astype(np.float32) / 255
                self.assertLessEqual(float(np.max(np.abs(adv - clean))), 0.03 + 1 / 255)
                self.assertLessEqual(result.linf, 0.03 + 1e-6)

    def test_one_frame_attack_changes_only_one_frame(self) -> None:
        clean = prepare_attack_frames(self.frames, "mvit_base_16x4", self.device).numpy()
        result = self.run_attack("ofa")
        adv = result.frames.astype(np.float32) / 255
        changed = np.flatnonzero(np.max(np.abs(adv - clean), axis=(1, 2, 3)) > 1 / 510)
        self.assertLessEqual(len(changed), 1)
        self.assertEqual(result.attacked_frame, int(changed[0]))

    def test_flicker_is_spatially_uniform_per_frame(self) -> None:
        clean = prepare_attack_frames(self.frames, "mvit_base_16x4", self.device).numpy()
        result = self.run_attack("flick")
        delta = result.frames.astype(np.float32) / 255 - clean
        self.assertLess(float(delta.var(axis=(1, 2)).max()), 1e-10)


if __name__ == "__main__":
    unittest.main()
