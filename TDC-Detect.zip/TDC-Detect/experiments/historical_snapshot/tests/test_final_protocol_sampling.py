from __future__ import annotations

import hashlib
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.tsc_sampling import build_frozen_global_views, build_frozen_local_views


def signature(value: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


class FinalProtocolSamplingTests(unittest.TestCase):
    def make_clip(self, length: int) -> np.ndarray:
        rng = np.random.default_rng(20260714 + length)
        clip = rng.integers(0, 256, (length, 12, 16, 3), dtype=np.uint8)
        clip[:, 0, 0, 0] = np.arange(length)
        return clip

    def test_five_global_views_are_distinct_at_both_native_lengths(self) -> None:
        for length in (16, 32):
            with self.subTest(length=length):
                views = build_frozen_global_views(self.make_clip(length))
                self.assertEqual(list(views), ["original", "early_crop", "late_crop", "temporal_sparse", "motion_aware"])
                self.assertEqual(len({signature(value) for value in views.values()}), 5)
                self.assertEqual([len(value) for value in views.values()], [length, 3 * length // 4, 3 * length // 4, length // 2, length // 2])

    def test_four_local_views_are_exact_disjoint_quarters(self) -> None:
        for length in (16, 32):
            clip = self.make_clip(length)
            views = build_frozen_local_views(clip)
            self.assertEqual(len(views), 4)
            self.assertTrue(np.array_equal(np.concatenate(list(views.values())), clip))
            self.assertTrue(all(len(value) == length // 4 for value in views.values()))

    def test_invalid_timeline_is_rejected_without_padding(self) -> None:
        with self.assertRaises(ValueError):
            build_frozen_global_views(self.make_clip(16)[:15])


if __name__ == "__main__":
    unittest.main()
