from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.eval_tsc_v2_features import V1_FEATURES, V2_FEATURES
from TSC_Detect.tsc_calibration import matrix_from_rows
from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


def grouped_folds(rows: list[dict], n_folds: int, seed: int):
    videos = sorted({row["video_path"] for row in rows})
    rng = np.random.default_rng(seed)
    rng.shuffle(videos)
    fold_by_video = {video: i % n_folds for i, video in enumerate(videos)}
    return np.asarray([fold_by_video[row["video_path"]] for row in rows]), videos


def cross_validated_scores(rows, features, folds, n_folds):
    x = matrix_from_rows(rows, features)
    y = np.asarray([int(row["is_adv"]) for row in rows])
    scores = np.zeros(len(rows), dtype=np.float64)
    for fold in range(n_folds):
        train, test = folds != fold, folds == fold
        model = make_pipeline(
            StandardScaler(),
            LogisticRegression(C=1000.0, max_iter=1000, solver="lbfgs"),
        )
        model.fit(x[train], y[train])
        scores[test] = model.predict_proba(x[test])[:, 1]
    return scores


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--n-boot", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    rows = list(csv.DictReader(args.input.open(encoding="utf-8", newline="")))
    y = np.asarray([int(row["is_adv"]) for row in rows])
    fold_ids, videos = grouped_folds(rows, args.folds, args.seed)
    scores = {
        "vlad_original": np.asarray([float(row["vlad_original"]) for row in rows]),
        "vlad2_onehot_pred": np.asarray([float(row["vlad2_onehot_pred"]) for row in rows]),
        "logistic_v1_group5": cross_validated_scores(rows, V1_FEATURES, fold_ids, args.folds),
        "logistic_v2_group5": cross_validated_scores(rows, V2_FEATURES, fold_ids, args.folds),
    }
    indices_by_video = {
        video: np.flatnonzero(np.asarray([row["video_path"] == video for row in rows]))
        for video in videos
    }
    rng = np.random.default_rng(args.seed)
    boot = {name: [] for name in scores}
    delta = {name: [] for name in scores if name != "vlad_original"}
    for _ in range(args.n_boot):
        sampled = rng.choice(videos, size=len(videos), replace=True)
        idx = np.concatenate([indices_by_video[video] for video in sampled])
        base = roc_auc_np(y[idx], scores["vlad_original"][idx])
        for name, value in scores.items():
            auc = roc_auc_np(y[idx], value[idx]); boot[name].append(auc)
            if name != "vlad_original": delta[name].append(auc - base)
    base_auc = roc_auc_np(y, scores["vlad_original"])
    output_rows = []
    for name, value in scores.items():
        metric = binary_metrics(y, value)
        auc = metric["roc_auc"]; samples = np.asarray(boot[name])
        ds = np.asarray(delta.get(name, []))
        output_rows.append({
            "method": name,
            "roc_auc": auc,
            "auc_ci_low": np.quantile(samples, 0.025),
            "auc_ci_high": np.quantile(samples, 0.975),
            "delta_vs_vlad": auc - base_auc,
            "delta_ci_low": "" if not len(ds) else np.quantile(ds, 0.025),
            "delta_ci_high": "" if not len(ds) else np.quantile(ds, 0.975),
            "p_delta_le_0": "" if not len(ds) else np.mean(ds <= 0.0),
            "pr_auc": metric["pr_auc"],
            "fpr_at_95_tpr": metric["fpr_at_95_tpr"],
            "tpr_at_1_fpr": metric["tpr_at_1_fpr"],
            "n_rows": len(rows),
            "n_videos": len(videos),
            "n_folds": args.folds,
        })
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]))
        writer.writeheader(); writer.writerows(output_rows)
    print(args.output, [(r["method"], round(r["roc_auc"], 4)) for r in output_rows])


if __name__ == "__main__":
    main()
