from __future__ import annotations

import csv
from pathlib import Path


SOURCE = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/ucf101_exact_3030.csv")
VIDEO_ROOT = Path("/root/autodl-tmp/tsc/data/ucf101_full/UCF-101")
OUTPUT = Path("/root/autodl-tmp/tsc/data/manifests/ucf101_repaired_c20_t10.csv")


def main() -> None:
    rows = list(csv.DictReader(SOURCE.open(encoding="utf-8-sig", newline="")))
    output_rows = []
    for row in rows:
        path = VIDEO_ROOT / row["relative_path"]
        if not path.is_file():
            raise FileNotFoundError(path)
        output_rows.append({
            "split": row["split"],
            "label": row["label"],
            "path": str(path),
            "group": row["group"],
            "clip": row["clip"],
            "filename": row["filename"],
            "relative_path": row["relative_path"],
        })
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(output_rows[0]))
        writer.writeheader(); writer.writerows(output_rows)
    print(OUTPUT, len(output_rows))


if __name__ == "__main__":
    main()
