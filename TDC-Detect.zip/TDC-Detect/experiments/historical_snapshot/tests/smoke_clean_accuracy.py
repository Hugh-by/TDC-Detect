from __future__ import annotations

import argparse
import csv
import gc
import sys
from pathlib import Path

import torch
import pytorchvideo.models.hub as hub

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.tsc_action_model import get_action_probs
from TSC_Detect.utils_video import load_frames


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--video-root", required=True, type=Path)
    parser.add_argument("--classes", type=int, default=20)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    rows = list(csv.DictReader(args.manifest.open(encoding="utf-8-sig", newline="")))
    first_by_label = {}
    labels = {}
    for row in rows:
        index = int(row["label_index"])
        labels[index] = row["label"]
        first_by_label.setdefault(index, row)
    selected_indices = [round(i * 399 / max(args.classes - 1, 1)) for i in range(args.classes)]
    selected = [first_by_label[index] for index in selected_indices]
    device = torch.device(args.device)

    for name in ("x3d_m", "mvit_base_16x4", "slowfast_r50", "csn_r101"):
        model = getattr(hub, name)(pretrained=True).eval().to(device)
        model._tdc_action_model_name = name
        correct = 0
        confidence = 0.0
        for row in selected:
            frames = load_frames(args.video_root / row["relative_path"])
            _, pred, conf = get_action_probs(model, frames, device)
            correct += int(pred == int(row["label_index"]))
            confidence += conf
            print(name, row["label"], "->", labels[pred], f"conf={conf:.4f}", flush=True)
        print(
            f"SUMMARY {name} top1={correct}/{len(selected)} ({correct/len(selected):.3f}) "
            f"mean_conf={confidence/len(selected):.4f}",
            flush=True,
        )
        del model
        torch.cuda.empty_cache()
        gc.collect()


if __name__ == "__main__":
    main()
