from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.eval_temporal_shuffle import TS_FEATURES, success_rows
from TSC_Detect.tsc_calibration import matrix_from_rows
from TSC_Detect.utils_metrics import binary_metrics, roc_auc_np


def folds_for_rows(rows: list[dict[str, str]], n_folds: int, seed: int) -> np.ndarray:
    videos = sorted({row["video_path"] for row in rows})
    rng = np.random.default_rng(seed)
    rng.shuffle(videos)
    mapping = {video: index % n_folds for index, video in enumerate(videos)}
    return np.asarray([mapping[row["video_path"]] for row in rows])


def logistic_group5(rows: list[dict[str, str]], folds: np.ndarray, n_folds: int) -> np.ndarray:
    x = matrix_from_rows(rows, TS_FEATURES)
    y = np.asarray([int(row["is_adv"]) for row in rows])
    scores = np.zeros(len(rows), dtype=np.float64)
    for fold in range(n_folds):
        train, test = folds != fold, folds == fold
        model = make_pipeline(
            StandardScaler(),
            LogisticRegression(C=1000.0, max_iter=1000, solver="lbfgs"),
        )
        model.fit(x[train], y[train])
        scores[test] = model.predict_proba(x[test])[:, 1]
    return scores


def evaluate(rows: list[dict[str, str]], setting: str, n_folds: int, n_boot: int, seed: int) -> list[dict[str, object]]:
    y = np.asarray([int(row["is_adv"]) for row in rows])
    folds = folds_for_rows(rows, n_folds, seed)
    scores = {
        "TS shift mean": np.asarray([float(row["ts_prob_shift_mean"]) for row in rows]),
        "TS shift max": np.asarray([float(row["ts_prob_shift_max"]) for row in rows]),
        "TS label change": np.asarray([float(row["ts_label_change"]) for row in rows]),
        "Temporal Shuffle-LR Group-5": logistic_group5(rows, folds, n_folds),
    }
    videos = sorted({row["video_path"] for row in rows})
    indices_by_video = {
        video: np.asarray([idx for idx, row in enumerate(rows) if row["video_path"] == video])
        for video in videos
    }
    rng = np.random.default_rng(seed)
    samples = {name: [] for name in scores}
    for _ in range(n_boot):
        chosen = rng.choice(videos, size=len(videos), replace=True)
        indices = np.concatenate([indices_by_video[video] for video in chosen])
        for name, values in scores.items():
            samples[name].append(roc_auc_np(y[indices], values[indices]))
    output = []
    for name, values in scores.items():
        metric = binary_metrics(y, values)
        boot = np.asarray(samples[name])
        output.append({
            "setting": setting,
            "method": name,
            "roc_auc": metric["roc_auc"],
            "auc_ci_low": np.quantile(boot, 0.025),
            "auc_ci_high": np.quantile(boot, 0.975),
            "pr_auc": metric["pr_auc"],
            "fpr_at_95_tpr": metric["fpr_at_95_tpr"],
            "tpr_at_1_fpr": metric["tpr_at_1_fpr"],
            "n_rows": len(rows),
            "n_videos": len(videos),
            "n_folds": n_folds,
        })
    return output


def write_csv(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    print(f"Saved {path}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output-prefix", required=True, type=Path)
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--n-boot", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    with args.input.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))
    full = evaluate(rows, "full", args.folds, args.n_boot, args.seed)
    success = success_rows(rows)
    success_output = evaluate(success, "success", args.folds, args.n_boot, args.seed)
    write_csv(Path(f"{args.output_prefix}_full_group5.csv"), full)
    write_csv(Path(f"{args.output_prefix}_success_group5.csv"), success_output)


if __name__ == "__main__":
    main()
