from __future__ import annotations

import sys
import unittest
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.tsc_action_model import get_action_probs, process_action_view
from TSC_Detect.tsc_sampling import video_seed


class ActionPreprocessingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.frames = np.random.default_rng(7).integers(0, 256, (41, 180, 320, 3), dtype=np.uint8)

    def test_single_pathway_shapes(self) -> None:
        expected = {
            "csn_r101": (1, 3, 32, 224, 224),
            "x3d_m": (1, 3, 16, 256, 256),
            "mvit_base_16x4": (1, 3, 16, 224, 224),
        }
        for name, shape in expected.items():
            with self.subTest(name=name):
                value = process_action_view(self.frames, name, torch.device("cpu"))
                self.assertEqual(tuple(value.shape), shape)
                self.assertTrue(torch.isfinite(value).all())

    def test_slowfast_pathway_shapes(self) -> None:
        slow, fast = process_action_view(self.frames, "slowfast_r50", torch.device("cpu"))
        self.assertEqual(tuple(slow.shape), (1, 3, 8, 256, 256))
        self.assertEqual(tuple(fast.shape), (1, 3, 32, 256, 256))

    def test_model_sampling_uses_center_clip(self) -> None:
        frames = np.zeros((100, 8, 8, 3), dtype=np.uint8)
        frames[:, :, :, 0] = np.arange(100, dtype=np.uint8)[:, None, None]
        value = process_action_view(frames, "x3d_m", torch.device("cpu"))
        # X3D-M uses 16 frames at rate 5: indices 12, 17, ..., 87.
        expected = ((12 / 255.0) - 0.45) / 0.225
        self.assertAlmostEqual(float(value[0, 0, 0, 0, 0]), expected, places=5)

    def test_video_seed_is_stable_and_video_specific(self) -> None:
        self.assertEqual(video_seed(3, "a.mp4"), video_seed(3, "a.mp4"))
        self.assertNotEqual(video_seed(3, "a.mp4"), video_seed(3, "b.mp4"))

    def test_x3d_probabilities_are_not_softmaxed_twice(self) -> None:
        class ProbabilityModel(torch.nn.Module):
            _tdc_action_model_name = "x3d_m"

            def forward(self, _value):
                return torch.tensor([[0.8, 0.2]])

        probs, pred, confidence = get_action_probs(
            ProbabilityModel(), self.frames, torch.device("cpu")
        )
        np.testing.assert_allclose(probs, [0.8, 0.2], rtol=1e-6)
        self.assertEqual(pred, 0)
        self.assertAlmostEqual(confidence, 0.8, places=6)


if __name__ == "__main__":
    unittest.main()
