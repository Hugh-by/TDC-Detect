from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import pytorchvideo.models.hub as hub
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, prepare_attack_frames, probabilities
from TSC_Detect.utils_video import load_frames


ATTACKS = (
    ("fgsm", 1),
    ("pgd", 5),
    ("ofa", 10),
    ("flick", 10),
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--video-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--clean-correct", type=int, default=5)
    parser.add_argument("--eps", type=float, default=0.03)
    parser.add_argument("--alpha", type=float, default=2 / 255)
    args = parser.parse_args()

    device = torch.device(args.device)
    model = getattr(hub, args.model)(pretrained=True).eval().to(device)
    model._tdc_action_model_name = args.model
    rows = list(csv.DictReader(args.manifest.open(encoding="utf-8-sig", newline="")))
    first_by_label = {}
    for row in rows:
        first_by_label.setdefault(int(row["label_index"]), row)
    candidate_indices = [round(i * 399 / 39) for i in range(40)]

    args.output.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "model", "video_path", "label_index", "label", "attack", "iters",
        "clean_pred", "adv_pred", "clean_conf", "adv_conf", "attack_success",
        "linf", "attacked_frame",
    ]
    accepted = 0
    with args.output.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        for candidate_index in candidate_indices:
            row = first_by_label[candidate_index]
            path = args.video_root / row["relative_path"]
            source = load_frames(path)
            prepared = prepare_attack_frames(source, args.model, device)
            with torch.inference_mode():
                clean_probs = probabilities(model, prepared, args.model)[0]
            if int(clean_probs.argmax()) != candidate_index:
                continue
            accepted += 1
            for attack_index, (attack_name, iters) in enumerate(ATTACKS):
                result = make_attack(
                    model, source, args.model, device, attack_name,
                    eps=args.eps, alpha=args.alpha, iters=iters,
                    seed=accepted * 100 + attack_index,
                )
                writer.writerow({
                    "model": args.model,
                    "video_path": str(path),
                    "label_index": candidate_index,
                    "label": row["label"],
                    "attack": attack_name,
                    "iters": iters,
                    "clean_pred": result.clean_pred,
                    "adv_pred": result.adv_pred,
                    "clean_conf": result.clean_conf,
                    "adv_conf": result.adv_conf,
                    "attack_success": int(result.attack_success),
                    "linf": result.linf,
                    "attacked_frame": "" if result.attacked_frame is None else result.attacked_frame,
                })
                stream.flush()
                print(
                    args.model, f"{accepted}/{args.clean_correct}", attack_name,
                    f"success={result.attack_success}", f"linf={result.linf:.6f}",
                    flush=True,
                )
            if accepted >= args.clean_correct:
                break
    if accepted < args.clean_correct:
        raise SystemExit(f"Only found {accepted} clean-correct candidates")


if __name__ == "__main__":
    main()
