from __future__ import annotations

import csv
import json
import os
import signal
import subprocess
import time
from datetime import datetime
from pathlib import Path


P = "tdc-final-20260714"
ROOT = Path("/root/autodl-tmp/tsc")
PR = ROOT / "final_protocols" / P
OUT = ROOT / "outputs" / P / "E1"
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
ASSIGN = PROJECT / "scripts/run_final_e1_assignment.sh"
EVENTS = PR / "ops/events.log"
SENTINEL = PR / "ops/csn_gpu3_rebalanced.json"
TARGETS = (("k400", "calibration", 10000), ("k400", "test", 10000), ("ucf101", "calibration", 10100), ("ucf101", "test", 5050))


def event(message: str) -> None:
    with EVENTS.open("a", encoding="utf-8") as handle:
        handle.write(f"{datetime.now().astimezone().isoformat(timespec='seconds')} {message}\n")


def rows(path: Path) -> int:
    if not path.exists(): return 0
    with path.open(encoding="utf-8", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def complete(model: str) -> bool:
    return all(rows(OUT / f"{dataset}_{model}_{partition}.csv") == expected for dataset, partition, expected in TARGETS)


def csn_pids() -> list[int]:
    output = subprocess.run(["ps", "-eo", "pid=,cmd="], check=True, capture_output=True, text=True).stdout
    pids = []
    for line in output.splitlines():
        if ("run_final_e1_model_queue.sh csn_r101" in line or "run_final_e1_assignment.sh csn_r101" in line or "--action-model csn_r101" in line) and "tdc_e1_work_stealer" not in line:
            pids.append(int(line.strip().split(maxsplit=1)[0]))
    return sorted(set(pids), reverse=True)


def main() -> None:
    if SENTINEL.exists(): return
    event("WORK_STEALER_WAIT source=x3d_m target=csn_r101")
    while not complete("x3d_m"):
        time.sleep(60)
    if complete("csn_r101"):
        SENTINEL.write_text(json.dumps({"status": "not_needed", "time": datetime.now().astimezone().isoformat()}) + "\n")
        return

    pending = []
    for dataset, partition, expected in TARGETS:
        current = rows(OUT / f"{dataset}_csn_r101_{partition}.csv")
        if current < expected:
            pending.append((expected - current, dataset, partition, current, expected))
    event(f"WORK_STEAL_BEGIN target=csn_r101 pending={pending}")
    SENTINEL.write_text(json.dumps({"status": "preparing", "time": datetime.now().astimezone().isoformat(), "pending": pending}, indent=2) + "\n", encoding="utf-8")
    for pid in csn_pids():
        try: os.kill(pid, signal.SIGTERM)
        except ProcessLookupError: pass
    time.sleep(15)

    bins = {0: {"weight": 0, "tasks": []}, 3: {"weight": 0, "tasks": []}}
    for weight, dataset, partition, current, expected in sorted(pending, reverse=True):
        gpu = min(bins, key=lambda key: bins[key]["weight"])
        bins[gpu]["weight"] += weight
        bins[gpu]["tasks"].append((dataset, partition))
    record = {"status": "launched", "time": datetime.now().astimezone().isoformat(), "assignments": bins}
    SENTINEL.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    for gpu, plan in bins.items():
        if not plan["tasks"]: continue
        plan_path = PR / "ops" / f"csn_gpu{gpu}_plan.txt"
        plan_path.write_text("".join(f"{dataset} {partition}\n" for dataset, partition in plan["tasks"]), encoding="utf-8")
        log = (PR / "logs/E1" / f"csn_r101_gpu{gpu}_rebalanced.log").open("a", encoding="utf-8")
        proc = subprocess.Popen(["bash", str(ASSIGN), "csn_r101", str(gpu), str(plan_path)], cwd=PROJECT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        event(f"WORK_STEAL_LAUNCH target=csn_r101 gpu={gpu} pid={proc.pid} tasks={plan['tasks']} weight={plan['weight']}")


if __name__ == "__main__": main()
