from __future__ import annotations

import csv
import fcntl
import json
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path


PROTOCOL = "tdc-final-20260714"
ROOT = Path("/root/autodl-tmp/tsc")
PROTOCOL_ROOT = ROOT / "final_protocols" / PROTOCOL
OUTPUT_ROOT = ROOT / "outputs" / PROTOCOL
E1_ROOT = OUTPUT_ROOT / "E1"
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
QUEUE_SCRIPT = PROJECT / "scripts/run_final_e1_model_queue.sh"
WORK_STEALER = Path("/root/autodl-tmp/tdc_e1_work_stealer.py")
OPS_ROOT = PROTOCOL_ROOT / "ops"
STATE_PATH = OPS_ROOT / "supervisor_state.json"
EVENT_PATH = OPS_ROOT / "events.log"
LOCK_PATH = OPS_ROOT / "supervisor.lock"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
GPU_BY_MODEL = {model: index for index, model in enumerate(MODELS)}
ATTACKS = {"clean", "fgsm", "pgd", "ofa-style", "flicker-style"}
POLL_SECONDS = 60
STALL_SECONDS = 45 * 60


def now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def event(message: str) -> None:
    OPS_ROOT.mkdir(parents=True, exist_ok=True)
    with EVENT_PATH.open("a", encoding="utf-8") as handle:
        handle.write(f"{now()} {message}\n")
        handle.flush()


def manifest_count(path: Path) -> int:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def targets() -> list[dict[str, object]]:
    result = []
    ucf_manifest = PROTOCOL_ROOT / "manifests/ucf101_group_disjoint.csv"
    with ucf_manifest.open("r", encoding="utf-8", newline="") as handle:
        ucf_counts: dict[str, int] = {}
        for row in csv.DictReader(handle):
            ucf_counts[row["split"]] = ucf_counts.get(row["split"], 0) + 1
    for model in MODELS:
        for partition in ("calibration", "test"):
            manifest = PROTOCOL_ROOT / "manifests" / f"k400_{model}_{partition}_selected.csv"
            result.append({
                "dataset": "k400", "model": model, "partition": partition,
                "videos": manifest_count(manifest),
                "path": E1_ROOT / f"k400_{model}_{partition}.csv",
            })
        for partition in ("calibration", "test"):
            result.append({
                "dataset": "ucf101", "model": model, "partition": partition,
                "videos": ucf_counts[partition],
                "path": E1_ROOT / f"ucf101_{model}_{partition}.csv",
            })
    for item in result:
        item["expected_rows"] = int(item["videos"]) * 5
    return result


def inspect_csv(path: Path, full_validate: bool = False) -> dict[str, object]:
    if not path.exists():
        return {"rows": 0, "mtime_age_seconds": None, "valid": True}
    rows = 0
    valid = True
    keys: set[tuple[str, str]] = set()
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {"protocol_id", "pair_id", "attack", "row_type", "measured_linf"}
        valid = required <= set(reader.fieldnames or ())
        for row in reader:
            rows += 1
            if not full_validate:
                continue
            key = (row.get("pair_id", ""), row.get("attack", ""))
            valid = valid and row.get("protocol_id") == PROTOCOL and key not in keys and key[1] in ATTACKS
            keys.add(key)
    return {"rows": rows, "mtime_age_seconds": max(0, time.time() - path.stat().st_mtime), "valid": valid}


def process_lines() -> list[str]:
    output = subprocess.run(["ps", "-eo", "pid=,cmd="], check=True, capture_output=True, text=True).stdout
    return output.splitlines()


def model_processes(model: str, lines: list[str]) -> list[int]:
    identifiers = (
        f"run_final_e1_model_queue.sh {model}",
        f"run_final_e1_assignment.sh {model}",
        f"--action-model {model}",
    )
    pids = []
    for line in lines:
        if any(value in line for value in identifiers) and "tdc_final_supervisor.py" not in line:
            try:
                pids.append(int(line.strip().split(maxsplit=1)[0]))
            except (ValueError, IndexError):
                pass
    return sorted(set(pids))


def post_e1_processes(lines: list[str]) -> list[int]:
    identifiers = (
        "run_final_post_e1.sh", "run_final_e6_model.sh", "run_final_e7_model.sh",
        "run_final_e8_e10.sh", "run_final_e8_model.sh", "run_final_e9_condition.sh",
        "run_final_e10_model.sh", "run_final_e6_strength", "run_final_e7_sensitivity",
        "run_final_e8_adaptive", "run_final_e9_runtime", "run_final_e10_perceptual",
        "eval_final_e1_e5.py", "eval_final_e6_e7.py", "eval_final_e8_e10.py",
        "build_final_deliverables.py",
    )
    pids = []
    for line in lines:
        if any(value in line for value in identifiers) and "tdc_final_supervisor.py" not in line:
            try:
                pids.append(int(line.strip().split(maxsplit=1)[0]))
            except (ValueError, IndexError):
                pass
    return sorted(set(pids))


def work_stealer_processes(lines: list[str]) -> list[int]:
    pids = []
    for line in lines:
        if "tdc_e1_work_stealer.py" in line and "tdc_final_supervisor.py" not in line:
            try:
                pids.append(int(line.strip().split(maxsplit=1)[0]))
            except (ValueError, IndexError):
                pass
    return sorted(set(pids))


def launch_work_stealer() -> int:
    log_path = PROTOCOL_ROOT / "logs/E1/work_stealer.log"
    stream = log_path.open("a", encoding="utf-8")
    proc = subprocess.Popen(
        [sys.executable, str(WORK_STEALER)], cwd=PROJECT,
        stdout=stream, stderr=subprocess.STDOUT, start_new_session=True,
    )
    event(f"RECOVERY_LAUNCH component=work_stealer pid={proc.pid}")
    return proc.pid


def launch_model(model: str) -> int:
    log_path = PROTOCOL_ROOT / "logs/E1" / f"{model}.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    stream = log_path.open("a", encoding="utf-8")
    proc = subprocess.Popen(
        ["bash", str(QUEUE_SCRIPT), model, str(GPU_BY_MODEL[model])],
        cwd=PROJECT,
        stdout=stream,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    event(f"RECOVERY_LAUNCH model={model} gpu={GPU_BY_MODEL[model]} pid={proc.pid}")
    return proc.pid


def terminate_model(model: str, pids: list[int], reason: str) -> None:
    event(f"RECOVERY_TERMINATE model={model} reason={reason} pids={pids}")
    for pid in reversed(pids):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    time.sleep(10)


def gpu_state() -> list[str]:
    try:
        output = subprocess.run(
            ["nvidia-smi", "--query-gpu=index,utilization.gpu,memory.used,memory.total", "--format=csv,noheader"],
            check=True, capture_output=True, text=True,
        ).stdout
        return output.strip().splitlines()
    except Exception as exc:
        return [f"ERROR: {exc}"]


def write_state(state: dict[str, object]) -> None:
    temporary = STATE_PATH.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    temporary.replace(STATE_PATH)


def campaign_phase(e1_complete: bool) -> str:
    if not e1_complete: return "E1"
    markers = (
        ("FINAL_EXPORT_COMPLETE", "COMPLETE"),
        ("E1_E10_COMPLETE", "FINAL_DELIVERABLES"),
        ("E9_COMPLETE", "FINAL_DELIVERABLES"),
        ("E10_COMPLETE", "E9"),
        ("E8_COMPLETE", "E10"),
        ("E7_COMPLETE", "E8"),
        ("E6_COMPLETE", "E7"),
        ("E1_E5_METRICS_COMPLETE", "E6"),
    )
    for marker, phase in markers:
        if (OUTPUT_ROOT / marker).exists(): return phase
    return "E1_E5_EVALUATION"


def main() -> None:
    OPS_ROOT.mkdir(parents=True, exist_ok=True)
    lock = LOCK_PATH.open("w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit("another supervisor is active")
    all_targets = targets()
    previous_completed: set[str] = set()
    if STATE_PATH.exists():
        try:
            previous = json.loads(STATE_PATH.read_text(encoding="utf-8"))
            previous_completed = {item["file"] for item in previous.get("targets", []) if item.get("complete")}
        except (OSError, json.JSONDecodeError, KeyError):
            pass
    event(f"SUPERVISOR_START protocol={PROTOCOL} poll_seconds={POLL_SECONDS}")

    while True:
        lines = process_lines()
        details = []
        complete_names: set[str] = set()
        total_rows = total_expected = 0
        by_model: dict[str, list[dict[str, object]]] = {model: [] for model in MODELS}
        for target in all_targets:
            name = Path(target["path"]).name
            quick = inspect_csv(Path(target["path"]))
            expected = int(target["expected_rows"])
            complete = quick["rows"] == expected
            if complete:
                checked = inspect_csv(Path(target["path"]), full_validate=True)
                complete = bool(checked["valid"])
                quick["valid"] = checked["valid"]
            target_state = {
                **{key: value for key, value in target.items() if key != "path"},
                "file": name, **quick, "complete": complete,
                "progress": min(float(quick["rows"]) / expected, 1.0) if expected else 0.0,
            }
            details.append(target_state)
            by_model[str(target["model"])].append(target_state)
            total_rows += int(quick["rows"])
            total_expected += expected
            if complete:
                complete_names.add(name)
                if name not in previous_completed:
                    event(f"TARGET_COMPLETE file={name} rows={quick['rows']}")

        for model in MODELS:
            pending = [item for item in by_model[model] if not item["complete"]]
            pids = model_processes(model, lines)
            preparing_rebalance = False
            rebalance_path = OPS_ROOT / "csn_gpu3_rebalanced.json"
            if model == "csn_r101" and rebalance_path.exists():
                try:
                    preparing_rebalance = json.loads(rebalance_path.read_text(encoding="utf-8")).get("status") == "preparing"
                except (OSError, json.JSONDecodeError):
                    pass
            if pending and not pids and not preparing_rebalance:
                launch_model(model)
            elif pending and pids:
                active = next((item for item in pending if item["rows"] > 0), pending[0])
                age = active.get("mtime_age_seconds")
                if age is not None and float(age) > STALL_SECONDS:
                    terminate_model(model, pids, f"output_stalled_{int(float(age))}s")
                    launch_model(model)

        rebalance_path = OPS_ROOT / "csn_gpu3_rebalanced.json"
        if not rebalance_path.exists() and not work_stealer_processes(lines):
            launch_work_stealer()

        previous_completed = complete_names
        state = {
            "protocol_id": PROTOCOL,
            "updated_at": now(),
            "phase": campaign_phase(len(complete_names) == len(all_targets)),
            "overall_rows": total_rows,
            "overall_expected_rows": total_expected,
            "overall_progress": total_rows / total_expected if total_expected else 0.0,
            "completed_targets": len(complete_names),
            "total_targets": len(all_targets),
            "gpus": gpu_state(),
            "targets": details,
        }
        write_state(state)

        if len(complete_names) == len(all_targets):
            marker = OUTPUT_ROOT / "E1_COMPLETE.json"
            if not marker.exists():
                marker.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
                event(f"PHASE_COMPLETE phase=E1 rows={total_rows}")
            post_script = PROJECT / "scripts/run_final_post_e1.sh"
            post_pids = post_e1_processes(lines)
            final_complete = (OUTPUT_ROOT / "FINAL_EXPORT_COMPLETE").exists()
            if post_script.exists() and not final_complete and not post_pids:
                started = OUTPUT_ROOT / "POST_E1_STARTED"
                with started.open("a", encoding="utf-8") as handle:
                    handle.write(now() + "\n")
                log = (PROTOCOL_ROOT / "logs/post_e1.log").open("a", encoding="utf-8")
                proc = subprocess.Popen(["bash", str(post_script)], cwd=PROJECT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                event(f"PHASE_LAUNCH phase=POST_E1 pid={proc.pid} attempt={sum(1 for _ in started.open())}")
            time.sleep(300)
        else:
            time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    if "--status" in sys.argv:
        if not STATE_PATH.exists():
            raise SystemExit("no supervisor state is available")
        print(STATE_PATH.read_text(encoding="utf-8"), end="")
    else:
        main()
