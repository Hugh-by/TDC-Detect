import av,csv,json,hashlib,time
from pathlib import Path
r=Path('/root/autodl-tmp/tdc_r1_revision_20261028')
def digest(p,**kw):
 h=hashlib.sha256();n=0
 with av.open(str(p),**kw) as c:
  for f in c.decode(video=0):h.update(f.to_ndarray(format='rgb24').tobytes());n+=1
 assert n>0
 return {'frames':n,'rgb_sha256':h.hexdigest()}
rows=list(csv.DictReader((r/'data/hmdb51_manifest.csv').open()));out=[]
for i,row in enumerate(rows):
 p=r/'data/videos'/row['relative_path']
 try:d=digest(p);mode='strict';error=None
 except UnicodeDecodeError as e:
  d=digest(p,metadata_errors='replace');assert d==digest(p,metadata_encoding='latin1');mode='metadata_replace';error=str(e)
 out.append({'source_id':row['source_id'],'relative_path':row['relative_path'],'mode':mode,'original_error':error,**d})
 if (i+1)%100==0:print(i+1,flush=True)
report={'passed':True,'clips':len(out),'metadata_fallback_clips':sum(x['mode']!='strict' for x in out),'rows':out,'repair':'Retry av.open only on UnicodeDecodeError with metadata_errors=replace; no video or sample-selection changes. Fallback RGB hashes independently match latin1 metadata decoding.'}
(r/'protocols/DECODE_PREFLIGHT.json').write_text(json.dumps(report,indent=2));print('PASS',len(out),report['metadata_fallback_clips'],flush=True)
