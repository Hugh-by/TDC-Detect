#!/usr/bin/env python3
import argparse,hashlib,json,math,os,sys,time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
RUN=Path('/root/autodl-tmp/tdc_r1_revision_20261028')
OLD=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01')
PROJECT=Path('/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master')
for p in (PROJECT,OLD/'code'):sys.path.insert(0,str(p))
from gpu_full_detector import DetectorState,FullDetector,action_input,action_probs,build_text_features,aggregate_features,FEATURES,_sym_kl
from TSC_Detect.run_tsc_detect import load_real_models,score_frames
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.utils_video import load_frames,read_class_names
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
PROTOCOL='tdc-r1-hmdb51-transfer-20261028-v1';EPS=8/255;ALPHA=2/255
CLASSES=Path('/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv')
MODELS=['csn_r101','mvit_base_16x4','slowfast_r50','x3d_m']
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for c in iter(lambda:f.read(8*1024*1024),b''):h.update(c)
 return h.hexdigest()
def atomic(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(d,indent=2,allow_nan=False));os.replace(tmp,p)
def score(x,s):
 z=(np.asarray(x,np.float64)-np.asarray(s['scaler_mean']))/np.asarray(s['scaler_scale'])
 logit=float(z@np.asarray(s['lr_coef'])+s['lr_intercept'])
 return logit,float(1/(1+np.exp(-np.clip(logit,-700,700))))
def load_states(model):
 paths={'full21':OLD/'protocols/G05_v2_frozen_states'/f'{model}.json'}
 for name in ['discrepancy9_lr','e14_action_shift9_lr','single_discrepancy_lr']:paths[name]=OLD/'models/G03_method_identity_v2'/f'k400_{model}_{name}.json'
 out={}
 for name,p in paths.items():
  target=RUN/'protocols/frozen_states'/f'{model}_{name}.json';target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert target.read_bytes()==p.read_bytes()
  else:target.write_bytes(p.read_bytes())
  out[name]=json.loads(target.read_text());out[name]['state_sha256']=sha(target)
 assert out['full21']['feature_order']==FEATURES
 return out
class Loss:
 def __init__(self,model,name):
  self.model=model;self.name=name;self.pre=None;self.active=False
  if name=='x3d_m':self.hook=model.blocks[-1].activation.register_forward_pre_hook(self.capture)
 def capture(self,module,args):
  if self.active:self.pre=args[0]
 def __call__(self,x,label):
  self.active=True;out=self.model(action_input(x,self.name))[0];self.active=False
  if self.name=='x3d_m':
   v=F.log_softmax(self.pre,dim=1)[0,label].reshape(-1);loss=-(torch.logsumexp(v,0)-math.log(v.numel()));self.pre=None;probs=out
  else:loss=-F.log_softmax(out,dim=0)[label];probs=out.softmax(0)
  return loss,probs

def attack(clean,name,lossfn,label,seed):
 gen=torch.Generator(device=clean.device).manual_seed(seed)
 delta=torch.zeros((len(clean),1,1,3),device=clean.device) if name=='flicker' else torch.zeros_like(clean)
 if name=='pgd':delta.uniform_(-EPS,EPS,generator=gen);delta=((clean+delta).clamp(0,1)-clean).detach()
 steps={'fgsm':1,'pgd':40,'ofa':100,'flicker':100}[name];alpha=EPS if name=='fgsm' else ALPHA
 best=-float('inf');selected=None;beststep=None;frame=None;trajectory=[];beg=time.perf_counter()
 for step in range(1,steps+1):
  delta=delta.detach().requires_grad_(True);candidate=(clean+delta).clamp(0,1)
  loss,_=lossfn(candidate,label);grad=torch.autograd.grad(loss,delta)[0]
  assert torch.isfinite(loss) and torch.isfinite(grad).all()
  if name=='ofa':
   if frame is None:frame=int(grad.abs().flatten(1).mean(1).argmax())
   mask=torch.zeros_like(grad);mask[frame]=1;grad=grad*mask
  delta=(delta.detach()+alpha*grad.sign()).clamp(-EPS,EPS)
  if name=='ofa':delta=delta*mask
  if name!='flicker':delta=((clean+delta).clamp(0,1)-clean).detach()
  candidate=(clean+delta).clamp(0,1)
  with torch.no_grad():value,probs=lossfn(candidate,label)
  v=float(value);norm=float((candidate-clean).abs().max());pred=int(probs.argmax())
  structural=True
  if name=='ofa':structural=bool(torch.count_nonzero((candidate-clean)[torch.arange(len(clean),device=clean.device)!=frame])==0)
  if name=='flicker':structural=delta.shape[1:3]==(1,1)
  assert math.isfinite(v) and norm<=EPS+1e-7 and structural
  trajectory.append({'step':step,'loss':v,'pred':pred,'success':pred!=label,'linf':norm,'structure_passed':structural})
  if v>best:best=v;selected=candidate.detach().clone();beststep=step
 torch.cuda.synchronize()
 return selected,{'attack':name,'seed':seed,'steps':steps,'best_step':beststep,'best_loss':best,'attacked_frame':frame,'seconds':time.perf_counter()-beg,'trajectory':trajectory,'selection':'maximum stable classification loss; no detector score'}

def evaluate(x,detector,states):
 with torch.no_grad():
  ga,gc,la,lc,_,_=detector.responses(x,False);features=aggregate_features(ga,gc,la,lc)
  pa=torch.cat([ga,la]);pc=torch.cat([gc,lc]);D=_sym_kl(pa,pc);shift=_sym_kl(pa[0].expand_as(pa),pa)
 vector=[float(features[k]) for k in FEATURES]
 vectors={'full21':vector,'discrepancy9_lr':D.cpu().tolist(),'e14_action_shift9_lr':shift[1:].cpu().tolist(),'single_discrepancy_lr':D[:1].cpu().tolist()}
 rows={}
 for name,s in states.items():
  v=vectors[name];assert len(v)==len(s['feature_order']);logit,prob=score(v,s)
  rows[name]={'logit':logit,'score':prob,'threshold':s['threshold'],'detected':prob>s['threshold']}
 assert np.isfinite(vector).all()
 return {'features':dict(zip(FEATURES,vector)),'action_probs':pa.cpu().tolist(),'clip_probs':pc.cpu().tolist(),'methods':rows,'pred':int(pa[0].argmax()),'confidence':float(pa[0].max())}

def legacy_check(x,result,models,classes,device,states):
 action,clip,processor=models
 args=SimpleNamespace(protocol_id='tdc-final-20260714',mock_models=False,seed=20260714,num_frames=32,num_random=2,prompt_template=DEFAULT_PROMPT_TEMPLATES[0],prompt_templates=DEFAULT_PROMPT_TEMPLATES,max_clip_frames=8,num_local_windows=4,local_window_frames=None,max_global_views=None,base_views_only=False)
 f=score_frames(x.detach().cpu().numpy(),classes,args,action_model=action,clip_model=clip,clip_processor=processor,device=device,video_id='r1_pilot')
 err=max(abs(float(f[k])-result['features'][k]) for k in FEATURES);_,s=score([f[k] for k in FEATURES],states['full21']);s0=result['methods']['full21']['score'];same=(s>states['full21']['threshold'])==result['methods']['full21']['detected']
 return {'max_feature_error':err,'score_error':abs(s-s0),'decision_match':same,'passed':err<1e-3 and abs(s-s0)<1e-4 and same}

def main():
 p=argparse.ArgumentParser();p.add_argument('--model',choices=MODELS,required=True);p.add_argument('--cohort',choices=['pilot','test'],required=True);p.add_argument('--limit',type=int);a=p.parse_args()
 torch.set_num_threads(4);torch.manual_seed(20261028);np.random.seed(20261028)
 device=torch.device('cuda:0');out=RUN/'results'/a.cohort/a.model;out.mkdir(parents=True,exist_ok=True)
 manifest=RUN/'data/hmdb51_manifest.csv';rows=pd.read_csv(manifest);rows=rows[rows.cohort==a.cohort].sort_values('selection_hash')
 if a.limit:rows=rows.head(a.limit)
 if a.cohort=='test':
  gate=json.loads((RUN/'protocols/PILOT_GATE.json').read_text());assert gate['passed'] and gate['protocol_id']==PROTOCOL
 states=load_states(a.model);state_hashes={k:v['state_sha256'] for k,v in states.items()}
 code_hash=sha(__file__);contract={'protocol_id':PROTOCOL,'model':a.model,'cohort':a.cohort,'code_sha256':code_hash,'manifest_sha256':sha(manifest),'states':state_hashes,'sources':len(rows),'torch':torch.__version__,'gpu':torch.cuda.get_device_name(),'gpu_uuid':os.environ.get('TDC_GPU_UUID')}
 atomic(out/'contract.json',contract)
 action,clip,processor=load_real_models(device,a.model)
 for m in (action,clip):
  m.eval()
  for param in m.parameters():param.requires_grad_(False)
 classes=read_class_names(CLASSES);s=states['full21'];state=DetectorState(FEATURES,*[torch.tensor(s[k],dtype=torch.float64,device=device) for k in ['scaler_mean','scaler_scale','lr_coef','lr_intercept']],float(s['threshold']))
 detector=FullDetector(action,clip,processor,build_text_features(clip,processor,classes,device),a.model,state);lossfn=Loss(action,a.model)
 for rank,row in enumerate(rows.to_dict('records'),1):
  source=row['source_id'];target=out/'sources'/f'{source}.json'
  if target.exists():
   old=json.loads(target.read_text());assert old['code_sha256']==code_hash and old['state_hashes']==state_hashes
   if old['complete']:continue
  video=RUN/'data/videos'/row['relative_path'];assert sha(video)==row['sha256']
  started=time.perf_counter();clean=prepare_attack_frames(load_frames(video),a.model,device).detach()
  clean_result=evaluate(clean,detector,states);label=clean_result['pred']
  with torch.no_grad():l,prob=lossfn(clean,label)
  checkloss=abs(math.exp(-float(l))-float(prob[label]));assert checkloss<1e-6
  checks=[]
  if a.cohort=='pilot':checks.append(legacy_check(clean,clean_result,(action,clip,processor),classes,device,states));assert checks[-1]['passed']
  results={'clean':clean_result};traces={}
  for name in ['fgsm','pgd','ofa','flicker']:
   attackfile=out/'attacks'/f'{source}_{name}.json'
   if attackfile.exists():
    saved=json.loads(attackfile.read_text());assert saved['code_sha256']==code_hash and saved['state_hashes']==state_hashes
    if a.cohort=='pilot':checks.append(saved['legacy_check']);assert checks[-1]['passed']
    results[name]=saved['result'];traces[name]=saved['trace'];continue
   seed=int(hashlib.sha256(f'{PROTOCOL}|{a.model}|{source}|{name}'.encode()).hexdigest()[:8],16)
   selected,trace=attack(clean,name,lossfn,label,seed);result=evaluate(selected,detector,states)
   result['attack_success']=result['pred']!=label;result['linf']=float((selected-clean).abs().max());result['tensor_sha256']=hashlib.sha256(selected.detach().cpu().contiguous().numpy().tobytes()).hexdigest()
   if a.cohort=='pilot':
    check=legacy_check(selected,result,(action,clip,processor),classes,device,states);checks.append(check);assert check['passed']
    tensors=out/'tensors';tensors.mkdir(exist_ok=True);torch.save(selected.detach().cpu(),tensors/f'{source}_{name}.pt')
   saved={'protocol_id':PROTOCOL,'code_sha256':code_hash,'state_hashes':state_hashes,'source_id':source,'result':result,'trace':trace,'legacy_check':check if a.cohort=='pilot' else None};atomic(attackfile,saved);results[name]=result;traces[name]=trace
   print(json.dumps({'rank':rank,'sources':len(rows),'model':a.model,'attack':name,'seconds':trace['seconds']}),flush=True)
  atomic(target,{'protocol_id':PROTOCOL,'code_sha256':code_hash,'state_hashes':state_hashes,'complete':True,'source':row,'results':results,'legacy_checks':checks,'loss_probability_error':checkloss,'seconds':time.perf_counter()-started})
  print(json.dumps({'source_complete':rank,'sources':len(rows),'model':a.model}),flush=True)
 files=list((out/'sources').glob('*.json'));assert len(files)==len(rows)
 atomic(out/'COMPLETE.json',{'protocol_id':PROTOCOL,'passed':True,'sources':len(rows),'contract':contract})
if __name__=='__main__':main()
