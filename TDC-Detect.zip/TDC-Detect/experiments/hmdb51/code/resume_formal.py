#!/usr/bin/env python3
import datetime, fcntl, hashlib, json, os, subprocess, sys
from pathlib import Path
from audit_pilot import RUN, PROTOCOL, MODELS, sha

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(status):
 p=RUN/'results/JOB_STATUS.json';t=p.with_suffix('.tmp');t.write_text(json.dumps(status,indent=2));t.replace(p)
def main():
 lock=(RUN/'results/launch.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 gate=json.loads((RUN/'protocols/PILOT_GATE.json').read_text());assert gate['passed'] and gate['protocol_id']==PROTOCOL
 assert gate['worker_sha256']==sha(RUN/'code/worker.py') and gate['manifest_sha256']==sha(RUN/'data/hmdb51_manifest.csv')
 gpus=subprocess.check_output(['nvidia-smi','--query-gpu=uuid,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True).splitlines()
 assert len(gpus)==4
 for row in gpus:
  uuid,mem,util=[v.strip() for v in row.split(',')];assert int(mem)<1000 and int(util)<10, row
 status={'protocol_id':PROTOCOL,'started_utc':now(),'state':'running','supervisor_pid':os.getpid(),'workers':{}};workers={}
 for model,row in zip(MODELS,gpus):
  uuid=row.split(',')[0].strip();env=os.environ.copy();env.update(CUDA_VISIBLE_DEVICES=uuid,TDC_GPU_UUID=uuid,HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',TOKENIZERS_PARALLELISM='false')
  log=(RUN/f'logs/test_{model}.log').open('a')
  p=subprocess.Popen([sys.executable,'-u',str(RUN/'code/resume_worker.py'),'--model',model,'--cohort','test'],stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,env=env,start_new_session=True)
  workers[model]=p;status['workers'][model]={'pid':p.pid,'gpu_uuid':uuid,'state':'running','log':str(RUN/f'logs/test_{model}.log')}
 save(status);print(json.dumps(status),flush=True)
 for model,p in workers.items():
  code=p.wait();status['workers'][model].update(exit_code=code,state='complete' if code==0 else 'failed',finished_utc=now());save(status)
 if all(p.returncode==0 for p in workers.values()):
  status['state']='summarizing';save(status)
  with (RUN/'logs/summary.log').open('a') as log:code=subprocess.call([sys.executable,'-u',str(RUN/'code/summarize.py')],stdout=log,stderr=subprocess.STDOUT)
  status.update(state='complete' if code==0 else 'summary_failed',summary_exit_code=code)
 else:status['state']='failed'
 status['finished_utc']=now();save(status);print(json.dumps(status),flush=True)
if __name__=='__main__':main()
