"""Metadata-only decoding repair; original worker and strict path unchanged."""
from pathlib import Path
import av,json,runpy,hashlib
r=Path('/root/autodl-tmp/tdc_r1_revision_20261028')
assert json.loads((r/'protocols/DECODE_PREFLIGHT.json').read_text())['passed']
original_open=av.open
def metadata_safe_open(*args,**kwargs):
 try:return original_open(*args,**kwargs)
 except UnicodeDecodeError:
  if 'metadata_errors' in kwargs:raise
  print(json.dumps({'metadata_decode_retry':str(args[0]),'metadata_errors':'replace'}),flush=True)
  return original_open(*args,metadata_errors='replace',**kwargs)
av.open=metadata_safe_open
print(json.dumps({'resume_adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'repair':'metadata-only fallback; original worker, inputs, model states and successful strict decoding unchanged'}),flush=True)
runpy.run_path(str(r/'code/worker.py'),run_name='__main__')
