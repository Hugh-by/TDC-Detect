#!/usr/bin/env python3
"""Summarize a complete frozen HMDB transfer run with source-paired bootstrap."""
import csv, hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score, average_precision_score
from audit_pilot import RUN, PROTOCOL, MODELS, ATTACKS, METHODS, sha, reconstructed

def metrics(clean,adv,threshold):
 if len(adv)==0:return {'auc':None,'ap':None,'fpr':float(np.mean(clean>threshold)) if len(clean) else None,'tpr':None}
 y=np.r_[np.zeros(len(clean)),np.ones(len(adv))];scores=np.r_[clean,adv]
 return {'auc':float(roc_auc_score(y,scores)),'ap':float(average_precision_score(y,scores)),'fpr':float(np.mean(clean>threshold)),'tpr':float(np.mean(adv>threshold))}

def bootstrap(clean,adv,seed,repeats=2000):
 # One draw selects a source's clean clip and ALL of its associated attacks,
 # identically for every method. Clean enters a pooled comparison only once.
 n=len(clean['full21']);k=adv['full21'].shape[1];rng=np.random.default_rng(seed)
 labels=np.r_[np.zeros(n),np.ones(n*k)];scores={m:np.r_[clean[m],adv[m].ravel()] for m in METHODS}
 aucs={m:[] for m in METHODS}
 for _ in range(repeats):
  counts=np.bincount(rng.integers(0,n,n),minlength=n);weights=np.r_[counts,np.repeat(counts,k)]
  for m in METHODS:aucs[m].append(roc_auc_score(labels,scores[m],sample_weight=weights))
 out={'repeats':repeats,'seed':seed,'unit':'source clip; clean and all attacks jointly resampled','auc_95ci':{},'full21_minus_baseline_95ci':{}}
 for m in METHODS:out['auc_95ci'][m]=np.quantile(aucs[m],[.025,.975]).tolist()
 for m in METHODS[1:]:out['full21_minus_baseline_95ci'][m]=np.quantile(np.array(aucs['full21'])-aucs[m],[.025,.975]).tolist()
 return out

def main():
 manifest=list(csv.DictReader((RUN/'data/hmdb51_manifest.csv').open()));expected={r['source_id'] for r in manifest if r['cohort']=='test'}
 assert len(expected)==510
 gate=json.loads((RUN/'protocols/PILOT_GATE.json').read_text());assert gate['passed'] and gate['worker_sha256']==sha(RUN/'code/worker.py')
 report={'protocol_id':PROTOCOL,'complete':False,'scope':'K400-frozen detector to HMDB51 split1; 510 clips; no HMDB fitting','secondary_subset':'attack changes clean top1; clean comparator uses the same successful sources once','models':{}}
 flat=[];paired=[]
 for model in MODELS:
  folder=RUN/'results/test'/model;done=json.loads((folder/'COMPLETE.json').read_text());assert done['passed'] and done['sources']==510
  contract=done['contract'];assert contract['code_sha256']==gate['worker_sha256'] and contract['manifest_sha256']==gate['manifest_sha256']
  files=sorted((folder/'sources').glob('*.json'));assert {p.stem for p in files}==expected
  states={m:json.loads((RUN/'protocols/frozen_states'/f'{model}_{m}.json').read_text()) for m in METHODS}
  sources=[json.loads(p.read_text()) for p in files]
  for s in sources:
   assert s['complete'] and s['code_sha256']==contract['code_sha256'] and s['state_hashes']==contract['states']
   assert set(s['results'])=={'clean',*ATTACKS}
   for r in s['results'].values():reconstructed(r,states)
   for a in ATTACKS:assert s['results'][a]['linf']<=8/255+1e-7
  clean={m:np.array([s['results']['clean']['methods'][m]['score'] for s in sources]) for m in METHODS}
  model_results={}
  for group in [*ATTACKS,'pooled']:
   attacks=ATTACKS if group=='pooled' else [group]
   adv={m:np.array([[s['results'][a]['methods'][m]['score'] for a in attacks] for s in sources]) for m in METHODS}
   success=np.array([[s['results'][a]['attack_success'] for a in attacks] for s in sources],bool);selected_clean=success.any(1)
   comparisons={}
   for m in METHODS:
    for subset in ['all_sources','successful_attacks']:
     c=clean[m] if subset=='all_sources' else clean[m][selected_clean]
     a=adv[m].ravel() if subset=='all_sources' else adv[m][success]
     row={'model':model,'attack':group,'method':m,'subset':subset,'n_clean':len(c),'n_attack':len(a),'attack_success_rate':float(success.mean()),'threshold':states[m]['threshold'],**metrics(c,a,states[m]['threshold'])}
     flat.append(row);comparisons[f'{m}/{subset}']=row
   seed=int(hashlib.sha256(f'{PROTOCOL}|bootstrap|{model}|{group}'.encode()).hexdigest()[:8],16)
   boot=bootstrap(clean,adv,seed)
   for baseline in METHODS[1:]:
    paired.append({'model':model,'attack':group,'comparison':f'full21 - {baseline}','auc_difference':comparisons['full21/all_sources']['auc']-comparisons[f'{baseline}/all_sources']['auc'],'ci_low':boot['full21_minus_baseline_95ci'][baseline][0],'ci_high':boot['full21_minus_baseline_95ci'][baseline][1],'bootstrap_repeats':2000})
   model_results[group]={'metrics':comparisons,'bootstrap':boot}
   print(f'Completed metrics: {model}/{group}',flush=True)
  report['models'][model]=model_results
 out=RUN/'results/summary';out.mkdir(exist_ok=True)
 pd.DataFrame(flat).to_csv(out/'metrics.csv',index=False);pd.DataFrame(paired).to_csv(out/'paired_auc_differences.csv',index=False)
 primary=pd.DataFrame(flat).query("subset == 'all_sources'");macro=primary.groupby(['attack','method'])[['auc','ap','fpr','tpr','attack_success_rate']].mean().reset_index();macro.to_csv(out/'macro_over_models.csv',index=False)
 report['complete']=True;report['macro_definition']='Unweighted mean across the four backbones; no cross-model score pooling'
 (out/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False));print('SUMMARY_COMPLETE',flush=True)
if __name__=='__main__':main()
