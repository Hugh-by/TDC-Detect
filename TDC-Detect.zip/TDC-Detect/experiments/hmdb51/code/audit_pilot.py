#!/usr/bin/env python3
"""Engineering-only launch gate; never selects runs by detection performance."""
import csv, hashlib, json, shutil
from pathlib import Path
import numpy as np
import torch

RUN=Path('/root/autodl-tmp/tdc_r1_revision_20261028')
PROTOCOL='tdc-r1-hmdb51-transfer-20261028-v1'
MODELS=['csn_r101','mvit_base_16x4','slowfast_r50','x3d_m']
ATTACKS=['fgsm','pgd','ofa','flicker']
METHODS=['full21','discrepancy9_lr','e14_action_shift9_lr','single_discrepancy_lr']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def kl(p,q):
 p=np.clip(np.asarray(p,np.float64),1e-8,1);q=np.clip(np.asarray(q,np.float64),1e-8,1)
 p=p/p.sum(-1,keepdims=True);q=q/q.sum(-1,keepdims=True)
 return .5*((p*np.log(p/q)).sum(-1)+(q*np.log(q/p)).sum(-1))
def reconstructed(record,states):
 pa=np.array(record['action_probs']);pc=np.array(record['clip_probs']);assert pa.shape==pc.shape==(9,400)
 assert np.isfinite(pa).all() and np.isfinite(pc).all()
 assert np.allclose(pa.sum(-1),1,atol=1e-5) and np.allclose(pc.sum(-1),1,atol=1e-5)
 d=kl(pa,pc);shift=kl(pa[0],pa)
 vectors={'full21':[record['features'][k] for k in states['full21']['feature_order']],'discrepancy9_lr':d,'e14_action_shift9_lr':shift[1:],'single_discrepancy_lr':d[:1]}
 errors=[]
 for method,s in states.items():
  z=(np.array(vectors[method])-s['scaler_mean'])/s['scaler_scale'];logit=float(z@np.array(s['lr_coef'])+s['lr_intercept'])
  score=float(1/(1+np.exp(-np.clip(logit,-700,700))));error=abs(score-record['methods'][method]['score']);errors.append(error)
  assert error<1e-8 and abs(logit-record['methods'][method]['logit'])<1e-7
  assert (score>s['threshold'])==record['methods'][method]['detected']
 return max(errors)

def main():
 manifest=RUN/'data/hmdb51_manifest.csv';rows=list(csv.DictReader(manifest.open()))
 pilot=sorted([r for r in rows if r['cohort']=='pilot'],key=lambda r:r['selection_hash'])[:2]
 expected={r['source_id'] for r in pilot};test=[r for r in rows if r['cohort']=='test']
 assert len(test)==510 and len({r['class_name'] for r in test})==51
 assert all(sum(r['class_name']==c for r in test)==10 for c in {r['class_name'] for r in test})
 assert not expected & {r['source_id'] for r in test}
 result={'protocol_id':PROTOCOL,'passed':False,'criterion':'engineering correctness only; no performance gate','worker_sha256':sha(RUN/'code/worker.py'),'manifest_sha256':sha(manifest),'models':{}}
 for model in MODELS:
  folder=RUN/'results/pilot'/model;done=json.loads((folder/'COMPLETE.json').read_text());contract=done['contract']
  assert done['passed'] and done['sources']==2 and contract['code_sha256']==result['worker_sha256'] and contract['manifest_sha256']==result['manifest_sha256']
  states={k:json.loads((RUN/'protocols/frozen_states'/f'{model}_{k}.json').read_text()) for k in METHODS}
  assert contract['states']=={k:sha(RUN/'protocols/frozen_states'/f'{model}_{k}.json') for k in METHODS}
  files=list((folder/'sources').glob('*.json'));assert {p.stem for p in files}==expected
  maximum_score_error=0.;feature_errors=[];times=[];attack_times=[]
  for file in files:
   source=json.loads(file.read_text());sid=source['source']['source_id']
   assert source['complete'] and source['code_sha256']==result['worker_sha256'] and source['state_hashes']==contract['states']
   checks=source['legacy_checks'];assert len(checks)==5 and all(c['passed'] and c['decision_match'] for c in checks)
   feature_errors.extend(c['max_feature_error'] for c in checks);times.append(source['seconds'])
   assert source['loss_probability_error']<1e-6
   for condition,r in source['results'].items():
    maximum_score_error=max(maximum_score_error,reconstructed(r,states))
    if condition=='clean':continue
    raw=json.loads((folder/'attacks'/f'{sid}_{condition}.json').read_text());trace=raw['trace'];steps={'fgsm':1,'pgd':40,'ofa':100,'flicker':100}[condition]
    assert trace['steps']==len(trace['trajectory'])==steps and raw['legacy_check']['passed']
    assert trace['seed']==int(hashlib.sha256(f'{PROTOCOL}|{model}|{sid}|{condition}'.encode()).hexdigest()[:8],16)
    assert all(t['structure_passed'] and t['linf']<=8/255+1e-7 and np.isfinite(t['loss']) for t in trace['trajectory'])
    best=max(trace['trajectory'],key=lambda t:t['loss']);assert best['step']==trace['best_step'] and best['loss']==trace['best_loss']
    assert r['pred']==best['pred'] and r['attack_success']==best['success']
    tensor=torch.load(folder/'tensors'/f'{sid}_{condition}.pt',map_location='cpu',weights_only=True)
    assert hashlib.sha256(tensor.contiguous().numpy().tobytes()).hexdigest()==r['tensor_sha256']
    attack_times.append(trace['seconds'])
  result['models'][model]={'passed':True,'pilot_sources':2,'original_forward_checks':10,'max_original_feature_error':max(feature_errors),'max_independent_score_error':maximum_score_error,'mean_source_seconds_with_legacy_checks':float(np.mean(times)),'conservative_full_run_hours':float(np.mean(times)*510/3600),'attack_seconds_total':sum(attack_times)}
 result['free_disk_gib']=shutil.disk_usage(RUN).free/2**30;assert result['free_disk_gib']>2
 result['passed']=True
 (RUN/'protocols/PILOT_GATE.json').write_text(json.dumps(result,indent=2))
 print(json.dumps(result,indent=2))
if __name__=='__main__':main()
