#!/usr/bin/env python3
import json
from pathlib import Path
import numpy as np
import pandas as pd

RUN=Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01"); ROOT=RUN/"results/G03/full_corrected"; shards=sorted((ROOT/"shards").glob("*.csv.gz"))
frames=[pd.read_csv(p,float_precision="round_trip") for p in shards]; raw=pd.concat(frames,ignore_index=True)
raw.to_csv(ROOT/"per_clip_runtime.csv.gz",index=False,compression="gzip")
keys=["dataset","model","method","timing_boundary"]
summary=raw.groupby(keys,sort=True).agg(n_measurements=("seconds","size"),n_sources=("source_id","nunique"),repeats=("repeat","nunique"),mean_seconds=("seconds","mean"),median_seconds=("seconds","median"),p95_seconds=("seconds",lambda x:float(np.quantile(x,.95))),peak_allocated=("peak_allocated","max"),peak_reserved=("peak_reserved","max"),resident_model_allocated=("resident_memory","max"),resident_model_reserved=("resident_reserved","max")).reset_index()
summary.insert(0,"protocol_id","tdc-r3r5-g03-full-corrected-20261025-v2"); summary.to_csv(ROOT/"condition_latency.csv",index=False)
trace_cols=["dataset","model","method","logical_action_view_calls","logical_clip_view_calls","clip_model_loaded","frozen_action_parameters","frozen_clip_parameters","readout_trainable_parameters","method_state_sha256","utility_source","process_isolation"]
trace=raw[trace_cols].drop_duplicates().sort_values(["dataset","model","method"]); trace.to_csv(ROOT/"method_call_and_load_evidence.csv",index=False)
action_only={"action_single","e14_action_shift9_lr","action_stats12_lr"}; action=trace[trace.method.isin(action_only)]
checks={"shards_52":len(shards)==52,"rows_52000":len(raw)==52000,"unique_measurements":not raw.duplicated(["dataset","model","method","source_id","repeat","timing_boundary"]).any(),"two_boundaries":set(raw.timing_boundary)=={"A_predecoded","B_path_to_score"},"action_only_never_loaded_clip":bool((~action.clip_model_loaded.astype(bool)).all()),"action_only_zero_clip_calls":bool((action.logical_clip_view_calls==0).all()),"identity_gate":json.loads((RUN/"protocols/G03_METHOD_IDENTITY_GATE.json").read_text()).get("passed") is True,"finite_seconds":bool(np.isfinite(raw.seconds).all() and (raw.seconds>0).all())}
(ROOT/"final_validation.json").write_text(json.dumps({"protocol_id":"tdc-r3r5-g03-full-corrected-20261025-v2","passed":all(checks.values()),"checks":checks,"shards":len(shards),"rows":len(raw),"summary_rows":len(summary),"call_trace_rows":len(trace)},indent=2,sort_keys=True)+"\n")
if not all(checks.values()): raise SystemExit(checks)
