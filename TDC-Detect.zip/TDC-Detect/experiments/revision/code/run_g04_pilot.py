#!/usr/bin/env python3
"""Bounded G04 convergence pilot for OFA and Flicker structured attacks."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_loss_and_probs, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g04-pilot-20261023-v3"
EPSILON, ALPHA, STEPS = 8 / 255, 2 / 255, 20


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def save_tensor(path: Path, value: torch.Tensor) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(value.detach().cpu().float(), temp)
    os.replace(temp, path)
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("csn_r101", "mvit_base_16x4"), required=True)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results" / "G04" / "pilot" / args.model
    shards = output / "trajectory_shards"
    tensors = output / "checkpoints"
    output.mkdir(parents=True, exist_ok=True)

    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    scores = score_lr(pipeline, calibration, FEATURES)
    threshold = threshold_from_clean(calibration, scores)
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    class_names = read_class_names(CLASSES)
    manifest_path = PROTOCOL / "manifests" / f"k400_{args.model}_calibration_fixed20.csv"
    manifest = pd.read_csv(manifest_path).sort_values("relative_path").head(3)
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters(): parameter.requires_grad_(False)
    for parameter in clip_model.parameters(): parameter.requires_grad_(False)
    text = build_text_features(clip_model, processor, class_names, device)
    detector = FullDetector(action_model, clip_model, processor, text, args.model, state)

    for source_rank, row in enumerate(manifest.itertuples(index=False), 1):
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        with torch.no_grad(): clean_prob = action_probs(action_model, clean, args.model)
        clean_pred = int(clean_prob.argmax())
        for attack in ("ofa", "flicker"):
            trajectory_id = hashlib.sha256(f"{args.model}|{row.relative_path}|{attack}".encode()).hexdigest()[:20]
            shard = shards / f"{trajectory_id}.json"
            if shard.exists() and json.loads(shard.read_text()).get("complete") and json.loads(shard.read_text()).get("protocol_id") == PROTOCOL_ID:
                print(json.dumps({"reused": trajectory_id}), flush=True); continue
            delta = (torch.zeros((len(clean), 1, 1, 3), device=device) if attack == "flicker" else torch.zeros_like(clean))
            attacked_frame = None
            trajectory, checkpoints = [], []
            torch.cuda.reset_peak_memory_stats(device)
            for step in range(1, STEPS + 1):
                delta = delta.detach().requires_grad_(True)
                adv = (clean + delta).clamp(0, 1)
                started = time.perf_counter()
                loss, prob = action_loss_and_probs(action_model, adv, args.model, clean_pred)
                gradient = torch.autograd.grad(loss, delta)[0]
                if attack == "ofa":
                    if attacked_frame is None:
                        attacked_frame = int(gradient.abs().flatten(1).mean(1).argmax())
                    mask = torch.zeros_like(gradient); mask[attacked_frame] = 1
                    gradient = gradient * mask
                delta = (delta.detach() + ALPHA * gradient.sign()).clamp(-EPSILON, EPSILON)
                if attack == "ofa":
                    mask = torch.zeros_like(delta); mask[attacked_frame] = 1
                    delta = delta * mask
                if attack == "flicker":
                    # Retain the spatially broadcast parameterization. Box clipping
                    # happens only when forming the candidate, as in the historical attack.
                    delta = delta.detach()
                else:
                    delta = ((clean + delta).clamp(0, 1) - clean).detach()
                torch.cuda.synchronize(device)
                step_seconds = time.perf_counter() - started
                candidate = (clean + delta).clamp(0, 1)
                with torch.no_grad(): candidate_prob = action_probs(action_model, candidate, args.model)
                entry = {
                    "step": step, "action_loss": float(-candidate_prob[clean_pred].clamp_min(1e-12).log()),
                    "attacked_pred": int(candidate_prob.argmax()), "attack_success": int(candidate_prob.argmax()) != clean_pred,
                    "measured_linf": float((candidate - clean).abs().max()), "seconds": step_seconds,
                    "parameter_spatial_std_max": float(delta.std(dim=(1, 2), unbiased=False).max()),
                }
                if step in (10, 20):
                    score_started = time.perf_counter()
                    with torch.no_grad(): features, logit, score, _, _ = detector.exact_forward(candidate)
                    torch.cuda.synchronize(device)
                    entry.update({"detector_logit": float(logit), "detector_score": float(score),
                                  "detector_evaded": float(score) <= threshold,
                                  "score_seconds": time.perf_counter() - score_started})
                    path = tensors / f"{trajectory_id}_step{step}.pt"
                    checkpoints.append({"step": step, "path": str(path), "sha256": save_tensor(path, candidate)})
                trajectory.append(entry)
                print(json.dumps({"model": args.model, "source": source_rank, "attack": attack, "step": step}), flush=True)
            atomic_json(shard, {
                "protocol_id": PROTOCOL_ID, "complete": True, "trajectory_id": trajectory_id,
                "action_model": args.model, "gpu_uuid": gpu_uuid, "source_rank": source_rank,
                "relative_path": row.relative_path, "partition": "calibration", "attack": attack,
                "epsilon": EPSILON, "alpha": ALPHA, "steps": STEPS, "initialization": "zero",
                "clean_pred": clean_pred, "threshold": threshold, "attacked_frame": attacked_frame,
                "structure": "one fixed temporal frame" if attack == "ofa" else "one spatially constant RGB offset per frame",
                "peak_memory_bytes": torch.cuda.max_memory_allocated(device),
                "trajectory": trajectory, "checkpoints": checkpoints,
            })

    records = [json.loads(path.read_text()) for path in sorted(shards.glob("*.json"))]
    if len(records) != 6: raise RuntimeError(f"incomplete G04 pilot: {len(records)}/6")
    rows, checkpoint_rows = [], []
    for item in records:
        for entry in item["trajectory"]:
            rows.append({key: item[key] for key in ("protocol_id", "trajectory_id", "action_model", "gpu_uuid", "source_rank", "relative_path", "partition", "attack", "epsilon", "alpha", "clean_pred", "threshold", "attacked_frame")} | entry)
        for checkpoint in item["checkpoints"]: checkpoint_rows.append({"trajectory_id": item["trajectory_id"], **checkpoint})
    frame = pd.DataFrame(rows)
    frame.to_csv(output / "trajectory.csv.gz", index=False, compression="gzip")
    pd.DataFrame(checkpoint_rows).to_csv(tensors / "INDEX.csv", index=False)
    checkpoint_frame = frame[frame.step.isin([10, 20])].copy()
    checkpoint_frame.to_csv(output / "checkpoint_scores.csv.gz", index=False, compression="gzip")
    metrics = checkpoint_frame.groupby(["action_model", "attack", "step"], as_index=False).agg(
        n_sources=("trajectory_id", "size"), attack_success_rate=("attack_success", "mean"),
        mean_detector_score=("detector_score", "mean"), mean_linf=("measured_linf", "mean"),
        mean_step_seconds=("seconds", "mean"), mean_score_seconds=("score_seconds", "mean"),
    )
    metrics.to_csv(output / "convergence_metrics.csv", index=False)
    atomic_json(output / "constraint_validation.json", {
        "protocol_id": PROTOCOL_ID, "passed": bool((frame.measured_linf <= EPSILON + 1e-7).all()),
        "trajectory_count": len(records), "row_count": len(frame), "test_touched": False,
        "ofa_fixed_frame_passed": all(item["attacked_frame"] is not None for item in records if item["attack"] == "ofa"),
        "flicker_parameterization": "delta[T,1,1,3] retained throughout and broadcast spatially before [0,1] box clipping",
        "flicker_parameter_spatial_constant_passed": bool((frame.loc[frame.attack == "flicker", "parameter_spatial_std_max"] == 0).all()),
        "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"model": args.model, "G04_pilot_complete": True, "output": str(output)}), flush=True)


if __name__ == "__main__": main()
