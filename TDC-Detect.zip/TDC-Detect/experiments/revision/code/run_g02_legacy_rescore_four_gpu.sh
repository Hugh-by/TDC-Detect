#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"; LOG="$RUN/logs/G02_legacy_rescore_v2"; mkdir -p "$LOG"; pids=()
specs=("0 csn_r101 adaptive" "1 csn_r101 lambda0_control" "2 mvit_base_16x4 adaptive" "3 mvit_base_16x4 lambda0_control")
for spec in "${specs[@]}"; do read -r gpu model mode <<<"$spec"; CUDA_VISIBLE_DEVICES="$gpu" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 python "$RUN/code/run_g02_legacy_rescore_worker.py" --model "$model" --mode "$mode" >"$LOG/${model}_${mode}.log" 2>&1 & pids+=("$!"); done
failed=0; for pid in "${pids[@]}"; do wait "$pid" || failed=1; done; [[ "$failed" == 0 ]]
echo G02_LEGACY_RESCORE_COMPLETE >"$LOG/COMPLETE"
