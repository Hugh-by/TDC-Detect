#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
mkdir -p "$RUN/logs/G05_full"
pids=()
for spec in "0 csn_r101" "1 mvit_base_16x4" "2 slowfast_r50" "3 x3d_m"; do
  read -r gpu model <<<"$spec"
  uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i "$gpu" | tr -d ' ')"
  CUDA_VISIBLE_DEVICES="$gpu" TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 python "$RUN/code/run_g05_full_worker.py" --model "$model" \
    >"$RUN/logs/G05_full/${model}.log" 2>&1 &
  pids+=("$!")
done
failed=0
for pid in "${pids[@]}"; do if ! wait "$pid"; then failed=1; fi; done
[[ "$failed" == 0 ]] || exit 1
echo "$(date -u '+%FT%TZ') G05_FULL_COMPLETE" >"$RUN/logs/G05_full/COMPLETE"
