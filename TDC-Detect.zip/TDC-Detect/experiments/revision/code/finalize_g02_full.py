#!/usr/bin/env python3
"""Consolidate and scientifically validate G02 full option-B outputs."""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROTOCOL_ID = "tdc-r3r5-g02-full-option-b-20261023-v1"
MODELS = ("csn_r101", "mvit_base_16x4")


def metric_values(clean: np.ndarray, selected: pd.DataFrame, threshold: float) -> dict:
    attack = selected.attack_success.astype(bool).to_numpy()
    evaded = selected.detector_evaded.astype(bool).to_numpy()
    adv = selected.detector_score.to_numpy(float)
    return {
        "auc": float(roc_auc_score(np.r_[np.zeros(len(clean)), np.ones(len(adv))], np.r_[clean, adv])),
        "attack_success_rate": float(attack.mean()),
        "joint_success_evasion_rate": float((attack & evaded).mean()),
        "conditional_evasion_rate": float(evaded[attack].mean()) if attack.any() else np.nan,
        "clean_fpr": float((clean > threshold).mean()),
    }


def main() -> None:
    all_candidates, all_selected, all_clean, all_index, metrics = [], [], [], [], []
    rng = np.random.default_rng(20260714)
    validations = {}
    for model in MODELS:
        root = RUN / "results/G02/full" / model
        statuses = [json.loads((root / "worker_status" / f"test_{i}.json").read_text()) for i in range(2)]
        if not all(item.get("complete") and item.get("protocol_id") == PROTOCOL_ID for item in statuses):
            raise RuntimeError(f"{model} test workers incomplete")
        trajectories = []
        for path in sorted((root / "trajectory_shards").glob("*.json")):
            item = json.loads(path.read_text())
            if item.get("protocol_id") == PROTOCOL_ID and item.get("complete"):
                trajectories.append(item)
        if len(trajectories) != 780: raise RuntimeError(f"{model} trajectories {len(trajectories)}/780")
        candidate_rows = []
        for item in trajectories:
            for row in item["checkpoint_rows"]:
                candidate_rows.append({key: item[key] for key in ("protocol_id", "trajectory_id", "action_model", "gpu_uuid", "partition", "mode", "source_rank", "relative_path", "tradeoff_lambda", "restart", "seed", "threshold")} | {key: value for key, value in row.items() if key != "features"} | {f"feature__{key}": value for key, value in row["features"].items()})
        candidates = pd.DataFrame(candidate_rows)
        all_candidates.append(candidates)
        source_records = []
        for path in sorted((root / "source_shards").glob("test_*.json")):
            item = json.loads(path.read_text())
            if item.get("protocol_id") == PROTOCOL_ID and item.get("complete"):
                source_records.append(item)
        if len(source_records) != 200: raise RuntimeError(f"{model} test selections {len(source_records)}/200")
        selected_rows = []
        for item in source_records:
            row = {key: item[key] for key in ("protocol_id", "action_model", "partition", "mode", "source_rank", "relative_path", "tradeoff_lambda", "selected_trajectory_id", "selected_adv_path", "selected_adv_sha256")}
            row.update({key: value for key, value in item["selected_checkpoint"].items() if key != "features"})
            row.update({f"feature__{key}": value for key, value in item["selected_checkpoint"]["features"].items()})
            selected_rows.append(row)
            tensor = Path(item["selected_adv_path"])
            if not tensor.exists() or tensor.stat().st_size == 0: raise RuntimeError(f"missing tensor {tensor}")
            all_index.append({"action_model": model, "mode": item["mode"], "source_rank": item["source_rank"], "relative_path": item["relative_path"], "path": str(tensor), "bytes": tensor.stat().st_size, "sha256": item["selected_adv_sha256"]})
        selected = pd.DataFrame(selected_rows)
        all_selected.append(selected)
        clean_records = []
        for path in sorted((root / "clean_shards").glob("test_*.json")):
            item = json.loads(path.read_text())
            if item.get("protocol_id") == PROTOCOL_ID and item.get("complete"):
                clean_records.append(item)
        if len(clean_records) != 100: raise RuntimeError(f"{model} clean test {len(clean_records)}/100")
        clean = pd.DataFrame([{key: value for key, value in item.items() if key not in ("features", "complete")} | {f"feature__{key}": value for key, value in item["features"].items()} for item in clean_records]).sort_values("source_rank")
        all_clean.append(clean)
        for mode, group in selected.groupby("mode", sort=True):
            group = group.sort_values("source_rank").reset_index(drop=True)
            clean_scores = clean.detector_score.to_numpy(float)
            threshold = float(clean.threshold.iloc[0])
            point = metric_values(clean_scores, group, threshold)
            boot = {key: [] for key in point}
            for _ in range(1000):
                index = rng.integers(0, len(group), len(group))
                value = metric_values(clean_scores[index], group.iloc[index].reset_index(drop=True), threshold)
                for key in boot: boot[key].append(value[key])
            row = {"protocol_id": PROTOCOL_ID, "action_model": model, "mode": mode, "tradeoff_lambda": group.tradeoff_lambda.iloc[0], "n_sources": len(group), **point}
            for key, values in boot.items():
                finite = np.asarray(values, float); finite = finite[np.isfinite(finite)]
                row[f"{key}_ci_low"] = float(np.quantile(finite, .025)) if len(finite) else np.nan
                row[f"{key}_ci_high"] = float(np.quantile(finite, .975)) if len(finite) else np.nan
            metrics.append(row)
        validations[model] = {"trajectories": len(trajectories), "test_source_selections": len(source_records), "clean_test": len(clean_records), "passed": True}

    output = RUN / "results/G02/full"
    pd.concat(all_candidates, ignore_index=True).to_csv(output / "candidates.csv.gz", index=False, compression="gzip")
    pd.concat(all_selected, ignore_index=True).to_csv(output / "selected.csv.gz", index=False, compression="gzip")
    pd.concat(all_clean, ignore_index=True).to_csv(output / "clean_scores.csv.gz", index=False, compression="gzip")
    pd.DataFrame(all_index).to_csv(output / "selected_adv_index.csv", index=False)
    pd.DataFrame(metrics).to_csv(output / "metrics.csv", index=False)
    validation = {"protocol_id": PROTOCOL_ID, "passed": True, "option": "B", "models": validations,
                  "expected_trajectories": 1560, "observed_trajectories": sum(value["trajectories"] for value in validations.values()),
                  "selected_adv": len(all_index), "bootstrap_replicates": 1000, "seed": 20260714}
    (output / "validation.json").write_text(json.dumps(validation, indent=2, sort_keys=True) + "\n")
    print(json.dumps(validation))


if __name__ == "__main__": main()
