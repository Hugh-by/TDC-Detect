#!/usr/bin/env python3
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
MODELS = ("csn_r101", "mvit_base_16x4")


def atomic_json(path: Path, value: object) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def main() -> None:
    # G01 common contract entries.
    g01 = RUN / "results" / "G01"
    forward = pd.concat([pd.read_csv(g01 / model / "forward_equivalence.csv") for model in MODELS], ignore_index=True)
    forward.to_csv(g01 / "forward_equivalence.csv", index=False)
    audits = {model: json.loads((g01 / model / "gradient_audit.json").read_text()) for model in MODELS}
    vjp = {model: json.loads((g01 / model / "vjp_comparison.json").read_text()) for model in MODELS}
    atomic_json(g01 / "gradient_audit.json", {"passed": all(value["passed"] for value in audits.values()), "models": audits})
    atomic_json(g01 / "vjp_comparison.json", {"passed": all(value["passed"] for value in vjp.values()), "models": vjp})
    (g01 / "approximation_list.md").write_text((g01 / MODELS[0] / "approximation_list.md").read_text(), encoding="utf-8")

    # G02 pilot common entries.
    g02 = RUN / "results" / "G02" / "pilot"
    trajectories = pd.concat([pd.read_csv(g02 / model / "trajectory.csv.gz") for model in MODELS], ignore_index=True)
    if set(trajectories.protocol_id) != {"tdc-r3r5-g02-pilot-20261023-v2"} or len(trajectories) != 252:
        raise RuntimeError("G02 protocol/coverage gate failed")
    trajectories.to_csv(g02 / "candidates.csv.gz", index=False, compression="gzip")
    trajectories.to_csv(g02 / "trajectory.csv.gz", index=False, compression="gzip")
    final = trajectories[trajectories.step == 20].copy()
    final.to_csv(g02 / "selected_scores.csv.gz", index=False, compression="gzip")
    tuning = final.groupby(["action_model", "tradeoff_lambda"], as_index=False).agg(
        n_sources=("trajectory_id", "size"), attack_success_rate=("attack_success", "mean"),
        joint_success_evasion_rate=("detector_evaded", lambda s: np.nan), mean_detector_score=("detector_score", "mean"),
    )
    # Joint metric requires both columns from the original rows.
    tuning["joint_success_evasion_rate"] = [
        (group.attack_success.astype(bool) & group.detector_evaded.astype(bool)).mean()
        for _, group in final.groupby(["action_model", "tradeoff_lambda"], sort=True)
    ]
    tuning["pilot_only_no_lambda_selection"] = True
    tuning.to_csv(g02 / "tuning.csv", index=False)
    clean_parts = []
    for model in MODELS:
        source = pd.read_csv(g01 / model / "forward_equivalence.csv")
        source = source[(source.variant == "clean") & (source.feature == "R_model")]
        clean_parts.append(source[["protocol_id", "action_model", "source_rank", "relative_path", "detector_score", "threshold", "decision", "gpu_uuid"]])
    pd.concat(clean_parts, ignore_index=True).to_csv(g02 / "clean_scores.csv.gz", index=False, compression="gzip")
    pd.concat([pd.read_csv(g02 / model / "metrics.csv") for model in MODELS], ignore_index=True).to_csv(g02 / "metrics.csv", index=False)
    index_parts = []
    for model in MODELS:
        part = pd.read_csv(g02 / model / "selected_adv" / "INDEX.csv"); part["action_model"] = model; index_parts.append(part)
    selected_dir = g02 / "selected_adv"; selected_dir.mkdir(exist_ok=True)
    pd.concat(index_parts, ignore_index=True).to_csv(selected_dir / "INDEX.csv", index=False)
    validations = {model: json.loads((g02 / model / "validation.json").read_text()) for model in MODELS}
    atomic_json(g02 / "validation.json", {"passed": all(value["passed"] for value in validations.values()), "models": validations})

    # G04 common entries.
    g04 = RUN / "results" / "G04" / "pilot"
    g04_trajectory = pd.concat([pd.read_csv(g04 / model / "trajectory.csv.gz") for model in MODELS], ignore_index=True)
    if set(g04_trajectory.protocol_id) != {"tdc-r3r5-g04-pilot-20261023-v3"} or len(g04_trajectory) != 240:
        raise RuntimeError("G04 protocol/coverage gate failed")
    g04_trajectory.to_csv(g04 / "trajectory.csv.gz", index=False, compression="gzip")
    pd.concat([pd.read_csv(g04 / model / "checkpoint_scores.csv.gz") for model in MODELS], ignore_index=True).to_csv(g04 / "checkpoint_scores.csv.gz", index=False, compression="gzip")
    pd.concat([pd.read_csv(g04 / model / "convergence_metrics.csv") for model in MODELS], ignore_index=True).to_csv(g04 / "convergence_metrics.csv", index=False)
    g04_checks = {model: json.loads((g04 / model / "constraint_validation.json").read_text()) for model in MODELS}
    atomic_json(g04 / "constraint_validation.json", {"passed": all(value["passed"] for value in g04_checks.values()), "models": g04_checks})
    cohort = g04_trajectory[["protocol_id", "action_model", "source_rank", "relative_path", "partition", "attack", "clean_pred", "threshold"]].drop_duplicates()
    cohort.to_csv(g04 / "cohort_manifest.csv", index=False)
    print(json.dumps({"consolidated": ["G01", "G02", "G04"], "passed": True}))


if __name__ == "__main__": main()
