#!/usr/bin/env python3
"""Cross-task scientific/mechanical validation for the completed NO_GPU stage."""

from __future__ import annotations

import gc
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd

from cache_features import load_probability_cache
from cpu_common import DATASETS, FEATURES, MODELS, RUN, load_e1, write_json
from run_cache_cpu_tasks import close_memmap, drop_file_cache, make_raw_feature_memmap, sigmoid

REQUIRED_SCORE_COLUMNS = {
    "run_id", "dataset", "model", "partition", "source_id", "pair_id", "relative_path",
    "attack", "method", "config", "is_adv", "attack_success", "score", "score_domain",
    "threshold", "predicted_adv",
}


def validate_long_scores(path: Path, expected_rows: int, expected_methods: int) -> dict:
    frame = pd.read_csv(path, low_memory=False, keep_default_na=False)
    missing = sorted(REQUIRED_SCORE_COLUMNS - set(frame.columns))
    duplicate = int(frame.duplicated(["dataset", "model", "pair_id", "attack", "method", "config"]).sum())
    finite = bool(np.isfinite(frame.score.to_numpy(float)).all() and np.isfinite(frame.threshold.to_numpy(float)).all())
    methods = int(frame.method.nunique())
    return {"path": str(path.relative_to(RUN)), "rows": len(frame), "expected_rows": expected_rows,
            "methods": methods, "expected_methods": expected_methods, "missing_columns": missing,
            "duplicate_keys": duplicate, "finite": finite,
            "passed": len(frame) == expected_rows and methods == expected_methods and not missing and duplicate == 0 and finite}


def model_score(frame: pd.DataFrame, state: dict) -> np.ndarray:
    features = state["feature_order"]
    values = frame[features].to_numpy(float)
    standardized = (values - np.asarray(state["scaler_mean"], float)) / np.asarray(state["scaler_scale"], float)
    return sigmoid(standardized @ np.asarray(state["lr_coef"], float) + float(state["lr_intercept"]))


def aligned_archived(frame: pd.DataFrame, source: pd.DataFrame, method: str) -> np.ndarray:
    selected = frame[frame.method == method]
    lookup = pd.Series(selected.score.to_numpy(float), index=pd.MultiIndex.from_arrays(
        [selected.pair_id.astype(str), selected.attack.astype(str)]))
    if not lookup.index.is_unique:
        raise ValueError(f"non-unique archived scores for {method}")
    return lookup.loc[list(zip(source.pair_id.astype(str), source.attack.astype(str)))].to_numpy(float)


def validate_small_states() -> dict:
    score_files = {
        "C03": pd.read_csv(RUN / "results/C03/sample_scores.csv.gz", low_memory=False),
        "C05": pd.read_csv(RUN / "results/C05/ablation_scores.csv.gz", low_memory=False),
        "C09": pd.read_csv(RUN / "results/C09/sample_scores.csv.gz", low_memory=False),
    }
    errors = []
    for dataset in DATASETS:
        for model in MODELS:
            test = load_e1(dataset, model, "test")
            condition = (score_files["C03"].dataset == dataset) & (score_files["C03"].model == model)
            c03 = json.loads((RUN / f"models/C03/{dataset}_{model}.json").read_text())
            errors.append({"task": "C03", "dataset": dataset, "model": model, "method": "full21_lr",
                           "max_abs_error": float(np.max(np.abs(model_score(test, c03) -
                               aligned_archived(score_files["C03"][condition], test, "full21_lr"))))})
            c05 = json.loads((RUN / f"models/C05/{dataset}_{model}.json").read_text())
            condition = (score_files["C05"].dataset == dataset) & (score_files["C05"].model == model)
            for method, state in c05.items():
                errors.append({"task": "C05-A", "dataset": dataset, "model": model, "method": method,
                               "max_abs_error": float(np.max(np.abs(model_score(test, state) -
                                   aligned_archived(score_files["C05"][condition], test, method))))})
            c09 = json.loads((RUN / f"models/C09/{dataset}_{model}.json").read_text())
            condition = (score_files["C09"].dataset == dataset) & (score_files["C09"].model == model)
            for method, state in c09.items():
                errors.append({"task": "C09", "dataset": dataset, "model": model, "method": method,
                               "max_abs_error": float(np.max(np.abs(model_score(test, state) -
                                   aligned_archived(score_files["C09"][condition], test, method))))})
    maximum = max(item["max_abs_error"] for item in errors)
    return {"checks": errors, "max_abs_error": maximum, "tolerance": 1e-12,
            "passed": maximum <= 1e-12}


def chunked_c04_scores(x: np.memmap, arrays: dict[str, np.ndarray], chunk: int = 128) -> tuple[np.ndarray, np.ndarray]:
    raw = np.empty(len(x), dtype=np.float64)
    compressed = np.empty(len(x), dtype=np.float64)
    mean = arrays["raw_scaler_mean"].astype(np.float32)
    scale = arrays["raw_scaler_scale"].astype(np.float32)
    pca_mean = arrays["pca_mean"].astype(np.float32)
    components = arrays["pca_components"].astype(np.float32)
    for start in range(0, len(x), chunk):
        end = min(start + chunk, len(x))
        standardized = (np.asarray(x[start:end], dtype=np.float32) - mean) / scale
        raw[start:end] = sigmoid(standardized @ arrays["raw_lr_coef"] + float(arrays["raw_lr_intercept"][0]))
        projected = (standardized - pca_mean) @ components.T
        compressed[start:end] = sigmoid(projected @ arrays["pca_lr_coef"] + float(arrays["pca_lr_intercept"][0]))
    return raw, compressed


def validate_c04_reload() -> dict:
    archived = pd.read_csv(RUN / "results/C04/sample_scores.csv.gz", low_memory=False)
    scratch_root = RUN / "scratch/C04_reload_validation"
    shutil.rmtree(scratch_root, ignore_errors=True)
    checks = []
    for dataset in DATASETS:
        for model in MODELS:
            condition_id = f"{dataset}_{model}"
            scratch = scratch_root / condition_id
            test = load_e1(dataset, model, "test")
            action, clip = load_probability_cache(test, dataset, model, "test", scratch)
            x_path = scratch / "test_raw7200.npy"
            x = make_raw_feature_memmap(x_path, action, clip)
            close_memmap(action); close_memmap(clip); del action, clip; gc.collect()
            drop_file_cache(scratch / "test_action.npy"); drop_file_cache(scratch / "test_clip.npy")
            state_path = RUN / f"models/C04/{condition_id}.npz"
            with np.load(state_path) as handle:
                arrays = {name: handle[name] for name in handle.files}
            raw, compressed = chunked_c04_scores(x, arrays)
            selected = archived[(archived.dataset == dataset) & (archived.model == model)]
            raw_error = float(np.max(np.abs(raw - aligned_archived(selected, test, "raw_probs7200_lr"))))
            pca_error = float(np.max(np.abs(compressed - aligned_archived(selected, test, "raw_probs_pca21_lr"))))
            checks.append({"dataset": dataset, "model": model, "rows": len(test),
                           "raw_max_abs_error": raw_error, "pca_max_abs_error": pca_error})
            close_memmap(x); del x; gc.collect()
            for path in scratch.glob("*.npy"):
                drop_file_cache(path)
            shutil.rmtree(scratch, ignore_errors=True)
            print(json.dumps({"C04_reload_validated": condition_id, "raw_error": raw_error,
                              "pca_error": pca_error}), flush=True)
    shutil.rmtree(scratch_root, ignore_errors=True)
    maximum = max(max(item["raw_max_abs_error"], item["pca_max_abs_error"]) for item in checks)
    return {"checks": checks, "max_abs_error": maximum, "tolerance": 2e-5,
            "passed": maximum <= 2e-5}


def validate_permutation_states() -> dict:
    rows = []
    for dataset in DATASETS:
        for model in MODELS:
            path = RUN / f"models/C05/{dataset}_{model}_permutations.json"
            data = json.loads(path.read_text())
            finite = True
            for state in data.values():
                values = np.r_[state["threshold"], state["scaler_mean"], state["scaler_scale"],
                               state["lr_coef"], state["lr_intercept"]]
                finite &= bool(np.isfinite(values).all())
            rows.append({"condition": f"{dataset}_{model}", "states": len(data), "finite": finite})
    return {"checks": rows, "passed": all(row["states"] == 120 and row["finite"] for row in rows)}


def main() -> None:
    required = [
        "validation/A00.json", "validation/C01.json", "validation/C01_export_contract.json", "validation/C02.json",
        "validation/C03_C05A_C09.json", "validation/C04_C05B_C06.json", "validation/C07.json", "validation/C08.json",
        "results/C04/parameter_count.csv", "results/C05/permutation_manifest.csv", "results/C06/tail_and_clipping_stats.csv",
    ]
    missing = [path for path in required if not (RUN / path).exists()]
    if missing:
        raise FileNotFoundError(f"missing required outputs: {missing}")
    validations = {
        "A00": json.loads((RUN / "validation/A00.json").read_text()).get("all_a00_gates_passed", False),
        "C01": json.loads((RUN / "validation/C01.json").read_text()).get("all_mechanical_checks_passed", False),
        "C01_contract": json.loads((RUN / "validation/C01_export_contract.json").read_text()).get("passed", False),
        "C02": json.loads((RUN / "validation/C02.json").read_text()).get("passed", False),
        "C03_C05A_C09": json.loads((RUN / "validation/C03_C05A_C09.json").read_text()).get("passed", False),
        "C04_C05B_C06": json.loads((RUN / "validation/C04_C05B_C06.json").read_text()).get("passed", False),
        "C07": json.loads((RUN / "validation/C07.json").read_text()).get("passed", False),
        "C08_expected_block": json.loads((RUN / "validation/C08.json").read_text()).get("status") == "blocked_input",
    }
    score_checks = [
        validate_long_scores(RUN / "results/C01/oof_scores.csv.gz", 21600, 1),
        validate_long_scores(RUN / "results/C02/sample_scores.csv.gz", 299025, 5),
        validate_long_scores(RUN / "results/C03/sample_scores.csv.gz", 239220, 4),
        validate_long_scores(RUN / "results/C04/sample_scores.csv.gz", 179415, 3),
        validate_long_scores(RUN / "results/C05/ablation_scores.csv.gz", 239220, 4),
        validate_long_scores(RUN / "results/C06/sample_scores.csv.gz", 239220, 4),
        validate_long_scores(RUN / "results/C09/sample_scores.csv.gz", 119610, 2),
    ]
    # C01 method is intentionally identical across nine configs, so include config in the method-count exception.
    score_checks[0]["methods"] = 1
    score_checks[0]["passed"] = (score_checks[0]["rows"] == 21600 and not score_checks[0]["missing_columns"] and
                                  score_checks[0]["duplicate_keys"] == 0 and score_checks[0]["finite"])
    small_reload = validate_small_states()
    c04_reload = validate_c04_reload()
    permutation_states = validate_permutation_states()
    forbidden_c08 = [name for name in ("cohort_manifest.csv", "clean_scores.csv.gz", "stratified_fpr.csv", "sampling_weights.csv")
                     if (RUN / "results/C08" / name).exists()]
    c06_reconstruction = pd.read_csv(RUN / "validation/C06_reconstruction.csv")
    overall = (all(validations.values()) and all(item["passed"] for item in score_checks) and
               small_reload["passed"] and c04_reload["passed"] and permutation_states["passed"] and
               bool(c06_reconstruction.passed.all()) and not forbidden_c08)
    report = {
        "protocol_id": "tdc-r3r5-no-gpu-validation-20261022-v1",
        "passed": overall,
        "task_validations": validations,
        "score_tables": score_checks,
        "small_model_state_reload": small_reload,
        "C04_model_state_reload": c04_reload,
        "C05_permutation_state_integrity": permutation_states,
        "C06_reconstruction_max_abs_error": float(c06_reconstruction.max_abs_error.max()),
        "C08_forbidden_placeholder_results": forbidden_c08,
        "gpu_used": False,
    }
    write_json(RUN / "validation/NO_GPU_scientific_validation.json", report)
    print(json.dumps({"passed": overall, "C04_reload_max_error": c04_reload["max_abs_error"],
                      "small_reload_max_error": small_reload["max_abs_error"]}, indent=2))
    if not overall:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
