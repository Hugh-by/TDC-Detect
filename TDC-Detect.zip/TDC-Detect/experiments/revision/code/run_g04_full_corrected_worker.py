#!/usr/bin/env python3
"""Corrected G04 worker: stable-loss selection plus lossless tensor persistence."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
BASE_PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_loss_and_probs, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g04-full-corrected-20261025-v2"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
EPSILON, ALPHA, STEPS = 8 / 255, 2 / 255, 100
CHECKPOINTS = (10, 20, 40, 100)
LOSS_CLIP_FLOOR = 1e-30


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def atomic_tensor(path: Path, tensor: torch.Tensor) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(tensor.detach().cpu().to(torch.float32).contiguous(), temp)
    os.replace(temp, path)
    return sha256(path)


def valid(path: Path, output: Path) -> dict | None:
    try:
        value = json.loads(path.read_text())
        tensor = output / value["selected_tensor"]["relative_path"]
    except Exception:
        return None
    if not value.get("complete") or value.get("protocol_id") != PROTOCOL_ID:
        return None
    if not tensor.is_file() or sha256(tensor) != value["selected_tensor"]["sha256"]:
        return None
    return value


def evaluate(detector, action_model, candidate, model, clean_pred, threshold) -> dict:
    started = time.perf_counter()
    with torch.no_grad():
        features, logit, detector_score, _, _ = detector.exact_forward(candidate)
        stable_loss, probability = action_loss_and_probs(action_model, candidate, model, clean_pred)
    torch.cuda.synchronize(candidate.device)
    clipped_loss = -probability[clean_pred].clamp_min(LOSS_CLIP_FLOOR).log()
    return {
        "optimization_action_loss": float(stable_loss),
        "reported_probability_loss_clipped": float(clipped_loss),
        "probability_loss_saturated": bool(float(probability[clean_pred]) <= LOSS_CLIP_FLOOR),
        "attacked_pred": int(probability.argmax()),
        "attack_success": int(probability.argmax()) != clean_pred,
        "detector_logit": float(logit),
        "detector_score": float(detector_score),
        "detector_evaded": float(detector_score) <= threshold,
        "score_seconds": time.perf_counter() - started,
        "features": {name: float(features[name]) for name in FEATURES},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=MODELS, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--output-name", default="full_corrected")
    parser.add_argument("--limit", type=int, default=100)
    args = parser.parse_args()
    if not 1 <= args.limit <= 100:
        raise ValueError("--limit must be in [1,100]")
    authorization = json.loads((RUN / "protocols/authorization.json").read_text())
    if authorization.get("selected_option") != "B":
        raise RuntimeError("option B not authorized")

    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results/G04" / args.output_name / args.model
    shards, tensors = output / "source_shards", output / "selected_adv"
    output.mkdir(parents=True, exist_ok=True)

    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    threshold = threshold_from_clean(calibration, score_lr(pipeline, calibration, FEATURES))
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    manifest = pd.read_csv(BASE_PROTOCOL / "manifests" / f"k400_{args.model}_test_fixed100.csv").sort_values("relative_path").head(args.limit)
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters():
        parameter.requires_grad_(False)
    for parameter in clip_model.parameters():
        parameter.requires_grad_(False)
    text = build_text_features(clip_model, processor, read_class_names(CLASSES), device)
    detector = FullDetector(action_model, clip_model, processor, text, args.model, state)

    for source_rank, row in enumerate(manifest.itertuples(index=False), 1):
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        with torch.no_grad():
            clean_probability = action_probs(action_model, clean, args.model)
        clean_pred = int(clean_probability.argmax())
        for attack in ("ofa", "flicker"):
            shard = shards / f"{source_rank:03d}_{attack}.json"
            if valid(shard, output) is not None:
                print(json.dumps({"reused": str(shard)}), flush=True)
                continue
            delta = torch.zeros((len(clean), 1, 1, 3), device=device) if attack == "flicker" else torch.zeros_like(clean)
            attacked_frame = None
            trajectory, checkpoint_rows = [], []
            best_optimization_loss = -float("inf")
            best_step, best_action_tensor = None, None
            torch.cuda.reset_peak_memory_stats(device)
            for step in range(1, STEPS + 1):
                delta = delta.detach().requires_grad_(True)
                candidate = (clean + delta).clamp(0, 1)
                started = time.perf_counter()
                objective, _ = action_loss_and_probs(action_model, candidate, args.model, clean_pred)
                gradient = torch.autograd.grad(objective, delta)[0]
                if attack == "ofa":
                    if attacked_frame is None:
                        attacked_frame = int(gradient.abs().flatten(1).mean(1).argmax())
                    gradient_mask = torch.zeros_like(gradient)
                    gradient_mask[attacked_frame] = 1
                    gradient = gradient * gradient_mask
                delta = (delta.detach() + ALPHA * gradient.sign()).clamp(-EPSILON, EPSILON)
                if attack == "ofa":
                    parameter_mask = torch.zeros_like(delta)
                    parameter_mask[attacked_frame] = 1
                    delta = parameter_mask * delta
                    delta = ((clean + delta).clamp(0, 1) - clean).detach()
                else:
                    delta = delta.detach()
                torch.cuda.synchronize(device)
                step_seconds = time.perf_counter() - started
                candidate = (clean + delta).clamp(0, 1)
                with torch.no_grad():
                    stable_loss, probability = action_loss_and_probs(action_model, candidate, args.model, clean_pred)
                stable_value = float(stable_loss)
                clipped_value = float(-probability[clean_pred].clamp_min(LOSS_CLIP_FLOOR).log())
                entry = {
                    "step": step,
                    "optimization_action_loss": stable_value,
                    "reported_probability_loss_clipped": clipped_value,
                    "probability_loss_saturated": bool(float(probability[clean_pred]) <= LOSS_CLIP_FLOOR),
                    "attacked_pred": int(probability.argmax()),
                    "attack_success": int(probability.argmax()) != clean_pred,
                    "measured_linf": float((candidate - clean).abs().max()),
                    "seconds": step_seconds,
                    "parameter_spatial_std_max": float(delta.std(dim=(1, 2), unbiased=False).max()),
                }
                if stable_value > best_optimization_loss:
                    best_optimization_loss = stable_value
                    best_step = step
                    best_action_tensor = candidate.detach().cpu().to(torch.float32).clone()
                if step in CHECKPOINTS:
                    measured = evaluate(detector, action_model, candidate, args.model, clean_pred, threshold)
                    entry.update({key: value for key, value in measured.items() if key != "features"})
                    checkpoint_rows.append({"step": step, **measured, "measured_linf": entry["measured_linf"]})
                trajectory.append(entry)
                if step % 10 == 0:
                    print(json.dumps({"model": args.model, "source": source_rank, "attack": attack, "step": step}), flush=True)

            assert best_action_tensor is not None and best_step is not None
            tensor_path = tensors / f"{source_rank:03d}_{attack}.pt"
            tensor_hash = atomic_tensor(tensor_path, best_action_tensor)
            best_score = evaluate(detector, action_model, best_action_tensor.to(device), args.model, clean_pred, threshold)
            last_score = checkpoint_rows[-1]
            atomic_json(shard, {
                "protocol_id": PROTOCOL_ID,
                "complete": True,
                "action_model": args.model,
                "gpu_uuid": gpu_uuid,
                "source_rank": source_rank,
                "relative_path": row.relative_path,
                "video_path": row.path,
                "partition": "test",
                "attack": attack,
                "epsilon": EPSILON,
                "alpha": ALPHA,
                "steps": STEPS,
                "initialization": "zero",
                "clean_pred": clean_pred,
                "threshold": threshold,
                "attacked_frame": attacked_frame,
                "structure": "one fixed temporal frame" if attack == "ofa" else "delta[T,1,1,3] spatially broadcast",
                "selection_rule": "maximum stable optimization_action_loss over steps 1..100; earliest step wins exact ties; detector score not used",
                "best_step": best_step,
                "trajectory": trajectory,
                "checkpoint_rows": checkpoint_rows,
                "best_action_selected": best_score,
                "last_iterate": last_score,
                "selected_tensor": {
                    "relative_path": str(tensor_path.relative_to(output)),
                    "sha256": tensor_hash,
                    "dtype": str(best_action_tensor.dtype),
                    "shape": list(best_action_tensor.shape),
                    "minimum": float(best_action_tensor.min()),
                    "maximum": float(best_action_tensor.max()),
                    "measured_linf": float((best_action_tensor - clean.cpu()).abs().max()),
                    "best_step": best_step,
                },
                "peak_memory_bytes": int(torch.cuda.max_memory_allocated(device)),
            })

    records = [valid(path, output) for path in sorted(shards.glob("*.json"))]
    records = [item for item in records if item is not None]
    expected = args.limit * 2
    if len(records) != expected:
        raise RuntimeError(f"G04 {args.model}: {len(records)}/{expected} source-attacks")
    trajectory_rows, checkpoint_rows, selected_rows, tensor_rows = [], [], [], []
    for item in records:
        common = {key: item[key] for key in ("protocol_id", "action_model", "gpu_uuid", "source_rank", "relative_path", "partition", "attack", "epsilon", "alpha", "clean_pred", "threshold", "attacked_frame")}
        trajectory_rows.extend(common | row for row in item["trajectory"])
        checkpoint_rows.extend(common | row for row in item["checkpoint_rows"])
        for selection, field in (("best_stable_action_loss", "best_action_selected"), ("last_iterate", "last_iterate")):
            selected_rows.append(common | {"selection": selection, "best_step": item["best_step"]} | item[field])
        tensor_rows.append(common | item["selected_tensor"])
    trajectory_frame = pd.DataFrame(trajectory_rows)
    trajectory_frame.to_csv(output / "trajectory.csv.gz", index=False, compression="gzip")
    pd.DataFrame(checkpoint_rows).to_csv(output / "checkpoint_scores.csv.gz", index=False, compression="gzip")
    pd.DataFrame(selected_rows).to_csv(output / "selected_scores.csv.gz", index=False, compression="gzip")
    pd.DataFrame(tensor_rows).to_csv(output / "selected_adv_index.csv", index=False)
    saturation_rows = trajectory_frame.loc[trajectory_frame.probability_loss_saturated].copy()
    saturation_rows.to_csv(output / "loss_saturation_audit.csv", index=False)
    atomic_json(output / "validation.json", {
        "protocol_id": PROTOCOL_ID,
        "passed": bool(
            len(records) == expected
            and (trajectory_frame.measured_linf <= EPSILON + 1e-7).all()
            and all(item["selected_tensor"]["measured_linf"] <= EPSILON + 1e-7 for item in records)
        ),
        "records": len(records),
        "trajectory_rows": len(trajectory_frame),
        "sources": args.limit,
        "attacks": ["ofa", "flicker"],
        "checkpoints": list(CHECKPOINTS),
        "selected_tensors": len(tensor_rows),
        "tensor_hashes_verified": all(valid(shards / f"{item['source_rank']:03d}_{item['attack']}.json", output) is not None for item in records),
        "saturated_trajectory_rows": int(len(saturation_rows)),
        "ofa_fixed_frame_passed": all(item["attacked_frame"] is not None for item in records if item["attack"] == "ofa"),
        "flicker_spatial_constant_passed": bool((trajectory_frame.loc[trajectory_frame.attack == "flicker", "parameter_spatial_std_max"] == 0).all()),
        "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"G04_corrected_complete": True, "model": args.model, "records": len(records)}), flush=True)


if __name__ == "__main__":
    main()
