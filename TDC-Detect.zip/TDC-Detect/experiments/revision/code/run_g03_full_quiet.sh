#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
LOGS="$RUN/logs/G03_full"
mkdir -p "$LOGS"
uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i 0 | tr -d ' ')"
methods=(action_single e14_action_shift9 action_stats12 discrepancy9 full_g5l4 light_g3l2 single_discrepancy)
models=(csn_r101 mvit_base_16x4 slowfast_r50 x3d_m)
for dataset in k400 ucf101; do
  for model in "${models[@]}"; do
    for method in "${methods[@]}"; do
      if [[ "$dataset" == "ucf101" && "$method" == "light_g3l2" ]]; then continue; fi
      CUDA_VISIBLE_DEVICES=0 TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 python "$RUN/code/run_g03_full_method.py" \
        --dataset "$dataset" --model "$model" --method "$method" \
        >"$LOGS/${dataset}_${model}_${method}.log" 2>&1
    done
  done
done
python "$RUN/code/finalize_g03_full.py" >"$LOGS/finalize.log" 2>&1
echo "$(date -u '+%FT%TZ') G03_FULL_COMPLETE" >"$LOGS/COMPLETE"
