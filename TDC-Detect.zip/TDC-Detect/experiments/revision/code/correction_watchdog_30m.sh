#!/usr/bin/env bash
set -uo pipefail

RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
LOG="$RUN/logs/correction_watchdog_30m.log"
INTERVAL="${WATCHDOG_INTERVAL_SECONDS:-3600}"
LOCK="$RUN/logs/correction_watchdog.lock"
mkdir -p "$RUN/logs"
exec 9>"$LOCK"
flock -n 9 || exit 0

json_passed() {
  python - "$1" <<'PY'
import json, sys
try:
    print("true" if json.load(open(sys.argv[1])).get("passed") is True else "false")
except Exception:
    print("false")
PY
}

while true; do
  now="$(date -u '+%F %T UTC')"
  g04_records="$(find "$RUN/results/G04/full_corrected" -path '*/source_shards/*.json' -type f 2>/dev/null | wc -l)"
  g04_tensors="$(find "$RUN/results/G04/full_corrected" -path '*/selected_adv/*.pt' -type f 2>/dev/null | wc -l)"
  g05_records="$(find "$RUN/results/G05/full_corrected" -path '*/shards/*.json' -type f 2>/dev/null | wc -l)"
  g04_pass="$(json_passed "$RUN/results/G04/full_corrected/csn_r101/validation.json")"
  g05_pass="$(json_passed "$RUN/results/G05/full_corrected/validation.json")"
  g03_gate="$(json_passed "$RUN/protocols/G03_METHOD_IDENTITY_GATE.json")"
  g03_records="$(find "$RUN/results/G03/full_corrected" -type f -name '*.csv.gz' 2>/dev/null | wc -l)"
  g02_rescore="$(find "$RUN/results/G02/legacy_rescore_v2/shards" -type f -name '*.json' 2>/dev/null | wc -l)"
  c04_pass="$(json_passed "$RUN/results/C04_roundtrip_v2/validation.json")"
  disk_kb="$(df -Pk "$RUN" | awk 'NR==2 {print $4}')"
  gpu="$(nvidia-smi --query-gpu=index,utilization.gpu,memory.used --format=csv,noheader 2>/dev/null | tr '\n' ';' || true)"
  active="$(pgrep -fc 'run_g04_full_corrected_worker|run_g05_v2_worker|run_g03.*corrected' || true)"
  echo "$now g04=$g04_records/800 tensors=$g04_tensors/800 g04_sample_validation=$g04_pass g05=$g05_records/1600 g05_validation=$g05_pass g03_gate=$g03_gate g03_files=$g03_records g02_legacy_rescore=$g02_rescore/400 c04_roundtrip=$c04_pass active=$active disk_available_kb=$disk_kb gpu=[$gpu]" >>"$LOG"

  # Corrected G04/G05 runners are resumable and skip already valid atomic shards.
  # Restart only an authorized, gate-passed formal task and only with >=8 GiB free.
  if (( disk_kb >= 8388608 )); then
    if [[ "$g04_records" -lt 800 ]] && ! pgrep -f 'run_g04_full_corrected_worker' >/dev/null; then
      echo "$now action=restart_g04_corrected" >>"$LOG"
      screen -DmS tdc_g04_corrected bash -lc "exec '$RUN/code/run_g04_full_corrected_four_gpu.sh'"
    elif [[ "$g04_records" -eq 800 && "$g05_records" -lt 1600 ]] &&
         [[ "$(json_passed "$RUN/protocols/G05_v2_frozen_states/validation.json")" == "true" ]] &&
         ! pgrep -f 'run_g05_v2_worker' >/dev/null; then
      echo "$now action=restart_g05_corrected" >>"$LOG"
      screen -DmS tdc_g05_corrected bash -lc "exec '$RUN/code/run_g05_v2_four_gpu.sh'"
    fi
  else
    echo "$now warning=low_disk_auto_restart_suppressed" >>"$LOG"
  fi

  # G03 is deliberately not launched until its corrected identity gate is PASS.
  if [[ "$g03_gate" != "true" ]]; then
    echo "$now g03_action=wait_for_method_identity_gate" >>"$LOG"
  elif [[ ! -s "$RUN/logs/G03_full_corrected/COMPLETE" ]] &&
       ! pgrep -f 'run_g03_corrected_chain|run_g03_corrected_pilot_four_gpu|run_g03_corrected_full_serial|run_g03_full_method.py.*output-name.*corrected' >/dev/null; then
    echo "$now action=restart_g03_corrected_chain" >>"$LOG"
    screen -DmS tdc_g03_corrected bash -lc "exec '$RUN/code/run_g03_corrected_chain.sh'"
  fi
  if [[ "$g03_records" -eq 52 && "$g02_rescore" -lt 400 ]] &&
     ! pgrep -f 'run_g02_legacy_rescore_worker|run_g02_legacy_rescore_four_gpu' >/dev/null; then
    echo "$now action=restart_g02_legacy_rescore" >>"$LOG"
    screen -DmS tdc_g02_legacy_rescore bash -lc "exec '$RUN/code/run_g02_legacy_rescore_four_gpu.sh'"
  fi
  if [[ "$c04_pass" != "true" ]] && ! pgrep -f 'repair_c04_roundtrip.py' >/dev/null; then
    echo "$now action=restart_c04_roundtrip" >>"$LOG"
    screen -DmS tdc_c04_roundtrip bash -lc "python '$RUN/code/repair_c04_roundtrip.py' >> '$RUN/logs/C04_roundtrip_repair.log' 2>&1"
  fi
  echo "$now next_check_seconds=$INTERVAL" >>"$LOG"
  sleep "$INTERVAL"
done
