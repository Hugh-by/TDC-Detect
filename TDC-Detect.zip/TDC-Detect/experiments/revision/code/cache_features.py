"""Read validated nine-view probability shards and derive CPU feature variants."""

from __future__ import annotations

import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from safetensors import safe_open

from cpu_common import FEATURES, RUN, SUPP

CACHE = SUPP / "E14/probe_cache"
VIEWS = ("original", "early_crop", "late_crop", "temporal_sparse", "motion_aware",
         "local_0", "local_1", "local_2", "local_3")


def load_probability_cache(source: pd.DataFrame, dataset: str, model: str, split: str,
                           mmap_directory: Path | None = None) -> tuple[np.ndarray, np.ndarray]:
    index = {(str(pair), str(attack)): position for position, (pair, attack) in
             enumerate(zip(source.pair_id, source.attack))}
    if len(index) != len(source):
        raise ValueError("non-unique source pair/attack keys")
    if mmap_directory is None:
        action = np.empty((len(source), 9, 400), dtype=np.float32)
        clip = np.empty((len(source), 9, 400), dtype=np.float32)
    else:
        mmap_directory.mkdir(parents=True, exist_ok=True)
        action = np.lib.format.open_memmap(
            mmap_directory / f"{split}_action.npy", mode="w+", dtype=np.float32,
            shape=(len(source), 9, 400))
        clip = np.lib.format.open_memmap(
            mmap_directory / f"{split}_clip.npy", mode="w+", dtype=np.float32,
            shape=(len(source), 9, 400))
    assigned = np.zeros(len(source), dtype=bool)
    directory = CACHE / f"{dataset}_{model}_{split}"
    for shard in sorted(directory.glob("*.safetensors")):
        with safe_open(str(shard), framework="np") as handle:
            metadata = handle.metadata() or {}
            identities = json.loads(metadata["rows_json"])
            action_part = handle.get_tensor("action_probs")
            clip_part = handle.get_tensor("clip_probs")
        for row_index, item in enumerate(identities):
            position = index[str(item["pair_id"]), str(item["attack"])]
            action[position] = action_part[row_index]
            clip[position] = clip_part[row_index]
            assigned[position] = True
    if not assigned.all() or not np.isfinite(action).all() or not np.isfinite(clip).all():
        raise ValueError(f"incomplete/non-finite cache: {dataset}/{model}/{split}")
    if isinstance(action, np.memmap):
        action.flush(); clip.flush()
    return action, clip


def normalized(values: np.ndarray, eps: float) -> np.ndarray:
    values = np.clip(np.asarray(values, np.float64), eps, 1.0)
    return values / values.sum(axis=-1, keepdims=True)


def pair_distance(p: np.ndarray, q: np.ndarray, metric: str, eps: float) -> np.ndarray:
    p, q = normalized(p, eps), normalized(q, eps)
    if metric == "symmetric_kl":
        return 0.5 * (np.sum(p * np.log(p / q), axis=-1) + np.sum(q * np.log(q / p), axis=-1))
    if metric == "js":
        middle = 0.5 * (p + q)
        return 0.5 * (np.sum(p * np.log(p / middle), axis=-1) +
                      np.sum(q * np.log(q / middle), axis=-1))
    raise ValueError(metric)


def fft_batch(values: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    values = np.asarray(values, np.float64)
    centered = values - values.mean(axis=1, keepdims=True)
    power = np.abs(np.fft.rfft(centered, axis=1)) ** 2
    non_dc = power[:, 1:]
    total = non_dc.sum(axis=1)
    midpoint = max(non_dc.shape[1] // 2, 1)
    high = np.divide(non_dc[:, midpoint:].sum(axis=1), total,
                     out=np.zeros(len(values), dtype=float), where=total > 1e-12)
    probabilities = np.divide(non_dc, total[:, None], out=np.zeros_like(non_dc), where=total[:, None] > 1e-12)
    entropy = -np.sum(probabilities * np.log(probabilities + 1e-12), axis=1) / np.log(non_dc.shape[1])
    invalid = (np.std(values, axis=1) < 1e-12) | (total <= 1e-12)
    high[invalid] = 0.0; entropy[invalid] = 0.0
    return high, entropy


def top2(values: np.ndarray) -> np.ndarray:
    return np.sort(values, axis=1)[:, -2:].mean(axis=1)


def response_sequences(action: np.ndarray, clip: np.ndarray, metric: str = "symmetric_kl",
                       eps: float = 1e-8, chunk: int = 256) -> tuple[np.ndarray, np.ndarray, np.ndarray,
                                                                         np.ndarray, np.ndarray]:
    n = len(action)
    confidence = np.max(action[:, :5], axis=2).astype(np.float64)
    semantic = np.empty((n, 9), dtype=np.float64)
    shift = np.empty((n, 9), dtype=np.float64)
    for start in range(0, n, chunk):
        end = min(start + chunk, n)
        semantic[start:end] = pair_distance(action[start:end], clip[start:end], metric, eps)
        reference = np.repeat(action[start:end, :1], 9, axis=1)
        shift[start:end] = pair_distance(reference, action[start:end], metric, eps)
    return confidence, semantic[:, :5], shift[:, :5], semantic[:, 5:], shift[:, 5:]


def rebuild_distance_features(base: pd.DataFrame, action: np.ndarray, clip: np.ndarray,
                              metric: str, eps: float) -> tuple[pd.DataFrame, dict]:
    values = base[FEATURES].copy()
    confidence, semantic, shift, local_semantic, local_shift = response_sequences(action, clip, metric, eps)
    values["R_uniform_shift"] = shift[:, 1:].mean(axis=1)
    values["vlad_original"] = semantic[:, 0]
    values["R_sem_mean"] = semantic.mean(axis=1)
    values["R_sem_max"] = semantic.max(axis=1)
    values["R_sem_var"] = semantic.var(axis=1)
    conf_high, conf_entropy = fft_batch(confidence)
    sem_high, sem_entropy = fft_batch(semantic)
    shift_high, shift_entropy = fft_batch(shift)
    values["R_fft_conf_high"] = conf_high
    values["R_fft_conf_entropy"] = conf_entropy
    values["R_fft_sem_high"] = sem_high
    values["R_fft_sem_entropy"] = sem_entropy
    values["R_fft_vlad_high"] = shift_high
    values["R_fft_vlad_entropy"] = shift_entropy
    local_conf = np.max(action[:, 5:], axis=2)
    values["R_local_sem_max"] = local_semantic.max(axis=1)
    values["R_local_sem_top2"] = top2(local_semantic)
    values["R_local_shift_max"] = local_shift.max(axis=1)
    values["R_local_shift_top2"] = top2(local_shift)
    values["R_local_conf_max"] = local_conf.max(axis=1)
    values["R_local_conf_top2"] = top2(local_conf)
    stats = {
        "metric": metric, "epsilon": eps,
        "action_values": int(action.size), "clip_values": int(clip.size),
        "action_clipped_fraction": float(np.mean(action < eps)),
        "clip_clipped_fraction": float(np.mean(clip < eps)),
        "action_zero_fraction": float(np.mean(action == 0)),
        "clip_zero_fraction": float(np.mean(clip == 0)),
        "action_min": float(action.min()), "clip_min": float(clip.min()),
        "global_semantic_q50": float(np.quantile(semantic, .5)),
        "global_semantic_q95": float(np.quantile(semantic, .95)),
        "global_semantic_q99": float(np.quantile(semantic, .99)),
        "global_shift_q95": float(np.quantile(shift, .95)),
        "local_semantic_q95": float(np.quantile(local_semantic, .95)),
        "local_shift_q95": float(np.quantile(local_shift, .95)),
    }
    return values, stats


def adjacent_difference_features(base: pd.DataFrame, action: np.ndarray, clip: np.ndarray) -> pd.DataFrame:
    confidence, semantic, shift, _, _ = response_sequences(action, clip)
    return adjacent_difference_from_sequences(base, confidence, semantic, shift)


def adjacent_difference_from_sequences(base: pd.DataFrame, confidence: np.ndarray,
                                       semantic: np.ndarray, shift: np.ndarray) -> pd.DataFrame:
    values = base[FEATURES].copy()
    for sequence, high_name, entropy_name in (
        (confidence, "R_fft_conf_high", "R_fft_conf_entropy"),
        (semantic, "R_fft_sem_high", "R_fft_sem_entropy"),
        (shift, "R_fft_vlad_high", "R_fft_vlad_entropy"),
    ):
        difference = np.diff(sequence, axis=1)
        values[high_name] = np.mean(np.abs(difference), axis=1)
        values[entropy_name] = np.mean(difference ** 2, axis=1)
    return values


def permutation_features(base: pd.DataFrame, action: np.ndarray, clip: np.ndarray,
                         permutation: tuple[int, ...]) -> pd.DataFrame:
    confidence, semantic, shift, _, _ = response_sequences(action, clip)
    return permutation_from_sequences(base, confidence, semantic, shift, permutation)


def permutation_from_sequences(base: pd.DataFrame, confidence: np.ndarray, semantic: np.ndarray,
                               shift: np.ndarray, permutation: tuple[int, ...]) -> pd.DataFrame:
    values = base[FEATURES].copy()
    for sequence, high_name, entropy_name in (
        (confidence[:, permutation], "R_fft_conf_high", "R_fft_conf_entropy"),
        (semantic[:, permutation], "R_fft_sem_high", "R_fft_sem_entropy"),
        (shift[:, permutation], "R_fft_vlad_high", "R_fft_vlad_entropy"),
    ):
        high, entropy = fft_batch(sequence)
        values[high_name] = high; values[entropy_name] = entropy
    return values


def permutation_manifest() -> pd.DataFrame:
    rows = []
    for index, permutation in enumerate(itertools.permutations(range(5))):
        rotations = []
        values = tuple(permutation)
        reverse = tuple(reversed(values))
        for candidate in (values, reverse):
            rotations.extend(candidate[offset:] + candidate[:offset] for offset in range(5))
        canonical = min(rotations)
        rows.append({
            "permutation_id": f"perm_{index:03d}", "permutation": ";".join(map(str, permutation)),
            "original_view_position": permutation.index(0),
            "dihedral_power_equivalence_class": ";".join(map(str, canonical)),
            "is_original_order": permutation == (0, 1, 2, 3, 4),
        })
    return pd.DataFrame(rows)
