#!/usr/bin/env python3
"""Build the NO_GPU stage status, reviewer evidence matrix, reports, and figures."""

from __future__ import annotations

import json
import platform
from datetime import datetime, timezone
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from cpu_common import RUN, write_csv, write_json

PROTOCOL = "tdc-r3r5-d01-20261022-v1"
HANDOFF = RUN / "handoff"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_macro(task: str, left: str, right: str, filename: str = "paired_differences.csv") -> pd.Series:
    frame = pd.read_csv(RUN / "results" / task / filename)
    selected = frame[(frame.method_a == left) & (frame.method_b == right) &
                     (frame.condition_scope.astype(str).isin(["macro", "macro_summary"]))]
    if len(selected) != 1:
        raise ValueError(f"Expected one macro row for {task}: {left} - {right}; got {len(selected)}")
    return selected.iloc[0]


def pooled_macro(task: str, method: str, metric_file: str = "condition_metrics.csv") -> float:
    frame = pd.read_csv(RUN / "results" / task / metric_file)
    selected = frame[(frame.method == method) & (frame.attack == "pooled") & (frame.setting == "full")]
    if len(selected) != 8:
        raise ValueError(f"Expected eight pooled/full rows for {task}/{method}; got {len(selected)}")
    return float(selected.roc_auc.mean())


def result_line(row: pd.Series) -> str:
    return (f"ΔAUC={float(row.point_difference):+.4f}; bootstrap mean={float(row.bootstrap_mean):+.4f}; "
            f"95% CI [{float(row.ci_low):+.4f}, {float(row.ci_high):+.4f}]")


def build_results_at_a_glance() -> pd.DataFrame:
    e7 = pd.read_csv(RUN / "results/C01/paired_differences.csv")
    e7 = e7[(e7.comparison == "g3_l2 - g5_l4") & (e7.scope == "macro_summary")].iloc[0]
    rows = [{
        "task_id": "C01", "reviewer_issue": "R3.2/R3.5", "scope": "K400 E7; 4 models × 2 attacks; source-grouped 5-fold OOF",
        "comparison": "g3_l2 - g5_l4", "key_result": f"ΔAUC={e7.point_macro_difference:+.4f}; 95% CI [{e7.ci_low:+.4f}, {e7.ci_high:+.4f}]",
        "old_paper_consistency": "conflicts with the unrecovered historical GroupKFold claim; this is the validated replacement",
        "recommended_change": "Replace the three E7 AUCs and describe fixed GroupKFold/per-configuration refitting; do not claim g3_l2 superiority over g5_l4.",
        "evidence_limit": "Fixed-OOF bootstrap excludes fold/refit uncertainty; historical score_seconds only.",
    }]
    specs = [
        ("C02", "R3.2/R5.6", "TDC-v2", "Nine-view action-shift-LR", "E1 independent test; 8 dataset-model conditions", "Same-budget action-response comparison"),
        ("C03", "R3.1/R5.1", "full21_lr", "mean_abs_z", "E1 independent test; pooled/full macro", "Learned LR versus same-21 fixed score"),
        ("C03", "R3.1/R5.1", "full21_lr", "max_abs_z", "E1 independent test; pooled/full macro", "Learned LR versus same-21 fixed score"),
        ("C04", "R3.1/R5.4", "raw_probs7200_lr", "full21_lr", "E1 independent test; pooled/full macro", "Raw 7200D learned readout versus engineered 21D"),
        ("C04", "R3.1/R5.4", "raw_probs_pca21_lr", "full21_lr", "E1 independent test; pooled/full macro", "PCA21 raw-response readout versus engineered 21D"),
        ("C05", "R3.3/R5.10", "full21_lr", "noFFT15_lr", "E1 independent test; pooled/full macro", "All six FFT descriptors"),
        ("C05", "R3.3/R5.10", "full21_lr", "adjacent_difference_stats21_lr", "E1 independent test; pooled/full macro", "FFT versus ordinary adjacent-difference statistics", "ordinary_difference_paired_differences.csv"),
        ("C06", "R3.5/R5.5", "symmetric_kl_eps1e-8", "js_eps1e-8", "E1 independent test; pooled/full macro", "Symmetric KL versus bounded JS"),
        ("C09", "R3.1/R5.9", "full21_lr", "without_local_confidence19_lr", "E1 independent test; pooled/full macro", "Marginal value of two local-confidence columns"),
    ]
    for spec in specs:
        task, issue, left, right, scope, comparison, *optional = spec
        row = read_macro(task, left, right, optional[0] if optional else "paired_differences.csv")
        rows.append({
            "task_id": task, "reviewer_issue": issue, "scope": scope,
            "comparison": comparison, "key_result": result_line(row),
            "old_paper_consistency": "new reviewer-requested control; does not overwrite historical E1–E10",
            "recommended_change": "Report the prespecified comparison, including unfavorable or non-significant results, and limit mechanism claims to the observed protocol.",
            "evidence_limit": "Fixed fitted-score source bootstrap; old test set has prior research use and is not a new confirmatory holdout.",
        })
    rows.extend([
        {"task_id": "C07", "reviewer_issue": "R5.6/R5.7/R5.10/R5.12", "scope": "E1 calibration correlations; reused E16 1000-fit coefficient bootstrap; E3/E4/E15 transfer",
         "comparison": "conditional weights, collinearity, and deployment regimes", "key_result": "Correlation/stability/deployment tables completed; coefficients are explicitly non-causal.",
         "old_paper_consistency": "narrows prior interpretive language", "recommended_change": "Separate mathematical definitions, empirical motivations, and deployment evidence; disclose source-attack dependence.",
         "evidence_limit": "Historical selection path lacks Git metadata; source-disjoint splits do not prove no repeated test inspection."},
        {"task_id": "C08", "reviewer_issue": "R5.7/R5.9", "scope": "unfiltered K400 clean", "comparison": "original-correct versus original-wrong FPR",
         "key_result": "blocked_input: prediction/correctness tables exist, but zero of 21 detector feature columns are available.",
         "old_paper_consistency": "confirms the clean-population coverage gap", "recommended_change": "State that current K400 FPR applies to original-correct clips only; do not report population FPR.",
         "evidence_limit": "Requires G05 clean-only forward extraction after explicit GPU authorization."},
    ])
    return pd.DataFrame(rows)


def evidence_rows() -> list[dict]:
    def row(reviewer: str, sub: str, concern: str, tasks: str, status: str, paths: str,
            key: str, section: str, change: str, allowed: str, gap: str) -> dict:
        return {"reviewer_id": reviewer, "subissue_id": sub, "concern": concern, "task_ids": tasks,
                "evidence_status": status, "result_paths": paths, "key_result": key,
                "manuscript_section": section, "proposed_change": change, "allowed_claim": allowed,
                "remaining_gap": gap}

    return [
        row("R3", "R3.1", "Clarify contribution and compare learned versus fixed readouts", "C03;C04;C09", "completed_cpu", "results/C03;results/C04;results/C09", "Same-feature and raw-response controls with paired CIs", "Abstract;Introduction;§4.2", "Frame TDC as a calibrated response representation and report readout dependence.", "LR improves over the two prespecified fixed same-21 scores under E1.", "Not an exhaustive upper bound over all handcrafted or nonlinear rules."),
        row("R3", "R3.2", "Fair efficiency and probe-budget claims", "C01;C02;C04;G03", "partial_gpu_pending", "results/C01;results/C02;results/C04", "CPU representation/readout evidence complete; old timing provenance separated", "§3;§4 efficiency", "Separate backbone queries, representation dimension, readout parameters, and historical timing.", "PCA/raw controls do not reduce nine-view forward cost.", "New same-batch per-clip timing is G03."),
        row("R3", "R3.3", "DFT on a non-temporal heterogeneous probe axis", "C05", "completed_cpu", "results/C05", "Subset, ordinary-difference, and all-120-permutation analyses", "§3 feature definition;§4 ablation", "Call these order descriptors, not physical temporal frequency.", "Empirical utility/order sensitivity can be reported.", "Old test reuse makes configuration selection exploratory."),
        row("R3", "R3.4", "Adaptive attack must differentiate through the full detector", "G01;G02", "blocked_resource", "STATUS.json;reports/UNRESOLVED_ITEMS.md", "Historical E8 is confirmed as a partial action proxy", "Threat model;adaptive evaluation", "Relabel historical E8 accurately and reserve full-branch claims for G01/G02.", "Historical E8 evaluates a partial action-response proxy with final detector scoring.", "Full forward/gradient audit and attack need explicit GPU mode."),
        row("R3", "R3.5", "Reproducibility, code/version, KL implementation", "A00;C06;D01", "completed_cpu_gpu_gap_disclosed", "validation/A00.json;results/C06;provenance", "28,041 cache shards and 140,205 rows fully reconstructed", "Method;reproducibility", "Publish exact 21D order, clip-renormalize KL, hashes, protocols, and limitations.", "The executed July code/results are byte-linked by path/hash evidence.", "No historical Git commit/reflog; GPU corrections remain new versions."),
        row("R5", "R5.1", "Novelty and benefit of learned fusion", "C03;C04", "completed_cpu", "results/C03;results/C04", "Learned/fixed/raw controls complete", "Introduction;§4.2", "Constrain novelty to compact auditable multi-response representation and calibrated fusion.", "Prespecified full21 LR outperforms the tested fixed scores.", "No claim of universally optimal learned fusion."),
        row("R5", "R5.2", "Role and limits of CLIP", "C02;C06;C07;G07", "partial_optional_gpu", "results/C02;results/C06;results/C07", "Semantic-group transfer evidence and distance controls available", "§3.4;limitations", "Describe CLIP as an independent reproducible image-language response source.", "CLIP-related features provide condition-dependent complementary evidence.", "No direct comparison to motion-aware video-language models; G07 optional."),
        row("R5", "R5.3", "Adaptive robustness", "G01;G02", "blocked_resource", "STATUS.json", "No new GPU attack was authorized", "Threat model;§4 adaptive", "Do not call the historical proxy a full white-box attack.", "Only the exact historical proxy protocol and its limits may be stated.", "G01 must pass before G02 pilot."),
        row("R5", "R5.4", "Raw probabilities versus engineered features and matched probe controls", "C04;G07", "partial_optional_gpu", "results/C04", "raw7200 and standardized-PCA21 learned controls complete", "§4.2;efficiency", "Report representation/readout comparison separately from query count.", "The fixed raw/PCA controls test the existing nine-view response cache.", "New equal-count random/uniform probes require GPU and a defined G07 scope."),
        row("R5", "R5.5", "Symmetric KL unboundedness, epsilon, and JS", "C06", "completed_cpu", "results/C06;validation/C06_reconstruction.csv", "Four consistent distance variants with tails and paired CIs", "§3.4;§4 ablation", "Define clip-to-epsilon then renormalize; acknowledge tail sensitivity.", "Performance sensitivity under eps 1e-6/1e-8/1e-10 and JS can be reported.", "No optimality claim beyond these fixed variants."),
        row("R5", "R5.6", "Per-condition fitting and new-architecture deployment", "C02;C07", "completed_cpu", "results/C02/transfer_threshold_metrics.csv;results/C07/deployment_table.csv", "E3/E4/E15 AUC and frozen-threshold FPR/TPR audited", "Deployment discussion", "Add four deployment regimes and distinguish source attacks from attack-free operation.", "LOMO/cross-domain transfer provides bounded source-supervised evidence.", "Completely attack-free training is unsupported."),
        row("R5", "R5.7a", "False positives on original-wrong clean clips", "C08;G05", "blocked_input", "results/C08/availability_report.md", "Unfiltered prediction rows exist but detector features/scores do not", "§4.1 data;limitations", "Limit K400 clean-FPR claims to original-correct filtering.", "The coverage gap is confirmed and quantified at input-availability level.", "G05 clean forward extraction requires GPU authorization."),
        row("R5", "R5.7b", "Feature rationale", "C07", "completed_cpu", "results/C07/feature_rationale.csv", "All 21 features classified by rationale and limitation", "Method;limitations", "Separate mathematical definition from empirical attack specificity.", "Features measure defined response properties.", "Definitions do not prove attack-specific causality."),
        row("R5", "R5.7c", "Repeated experimentation and selection bias", "A00;C07", "completed_audit_limitation", "results/C07/selection_history.md", "Historical Git metadata is absent; test-use limits disclosed", "Experimental protocol;limitations", "Do not claim historical preregistration or that source separation removes researcher degrees of freedom.", "New controls were frozen by this handoff before execution.", "A new untouched source holdout is needed for confirmatory selection claims."),
        row("R5", "R5.8", "Endpoint retention, CLIP frame cap, and cross-probe consistency", "C07;G07", "documented_gpu_optional", "results/C07/feature_rationale.csv;reports/manuscript_change_map.md", "Existing deterministic rules documented; no specific ablation in cache", "Sampling subsection", "State the exact rule and computational motivation without optimality language.", "Sampling is deterministic within each view.", "Endpoint/no-endpoint and 4/8/16 cap need new forward passes (optional G07)."),
        row("R5", "R5.9", "Ambiguous clean, local confidence, and full-clip reference", "C08;C09", "partial_blocked_clean", "results/C09;results/C08/availability_report.md", "Two-column local-confidence ablation complete; unfiltered clean FPR blocked", "§3.5;§4 ablation;limitations", "Treat local coordinates as empirical; explain full clip as deployable common reference.", "The two local-confidence columns have a measurable conditional association under E1.", "Matching-support new probes and original-wrong scoring are unavailable."),
        row("R5", "R5.10a", "DFT versus ordinary statistics", "C05", "completed_cpu", "results/C05", "Prespecified ordinary adjacent differences and permutations complete", "Feature design;ablation", "Replace mechanistic spectral language with order-descriptor language.", "Only comparative predictive results under the fixed protocol may be claimed.", "No exhaustive order-statistic search."),
        row("R5", "R5.10b", "Correlated coefficients and interpretation", "C07", "completed_cpu", "results/C07/correlation.csv;results/C07/coefficient_stability.csv", "Calibration correlations and reused E16 source-bootstrap stability", "Interpretability section", "Call coefficients conditional fitted weights, not causes or independent importance.", "Sign/rank stability describes the fitted models.", "Collinearity prevents causal attribution."),
        row("R5", "R5.10c", "Use without deployment adversarial examples", "C02;C07", "completed_limit", "results/C07/deployment_scenarios.csv", "Four regimes explicitly separated", "Deployment/limitations", "State that current supervised LR needs labeled attacks somewhere.", "Source-trained transfer is possible under evaluated settings.", "Clean-only detection is a different future method."),
        row("R5", "R5.11", "OFA/Flicker 10-step convergence", "G04", "blocked_resource", "STATUS.json;reports/UNRESOLVED_ITEMS.md", "Historical objective/budgets documented; convergence not established", "Attack protocol;limitations", "Describe 10 steps as historical reproducibility budget, not proven saturation.", "Historical step count/objective can be reported exactly.", "10/20/40/100 checkpoint test requires GPU pilot/full budget."),
        row("R5", "R5.12", "Semantic transfer and correlated-feature caveat", "C02;C07", "completed_cpu", "results/C02/transfer_summary.json;results/C07", "E15 semantic-group gain and correlation limits reported together", "Transfer and interpretation", "Distinguish label mapping, semantic-feature gain, and causal interpretation.", "Semantic response features add condition-dependent transfer signal.", "Does not establish semantic causality or universal CLIP benefit."),
    ]


def status_document() -> dict:
    tasks = {
        "A00": ("completed", 16, 16, ["provenance/input_manifest.csv", "provenance/cache_inventory.csv"], ["validation/A00.json", "validation/reconstruction_check.json"]),
        "C01": ("completed", 180, 180, ["results/C01/oof_scores.csv.gz", "results/C01/paired_differences.csv"], ["validation/C01.json", "validation/C01_export_contract.json"]),
        "C02": ("completed", 8, 8, ["results/C02/sample_scores.csv.gz", "results/C02/paired_differences.csv"], ["validation/C02.json"]),
        "C03": ("completed", 8, 8, ["results/C03/sample_scores.csv.gz", "results/C03/paired_differences.csv"], ["validation/C03_C05A_C09.json"]),
        "C04": ("completed", 8, 8, ["results/C04/sample_scores.csv.gz", "results/C04/paired_differences.csv"], ["validation/C04_C05B_C06.json"]),
        "C05": ("completed", 8, 8, ["results/C05/ablation_scores.csv.gz", "results/C05/permutation_metrics.csv"], ["validation/C03_C05A_C09.json", "validation/C04_C05B_C06.json"]),
        "C06": ("completed", 8, 8, ["results/C06/sample_scores.csv.gz", "results/C06/paired_differences.csv"], ["validation/C04_C05B_C06.json", "validation/C06_reconstruction.csv"]),
        "C07": ("completed", 8, 8, ["results/C07/correlation.csv", "results/C07/deployment_table.csv"], ["validation/C07.json"]),
        "C08": ("blocked_input", 0, 4, ["results/C08/availability_report.md", "results/C08/availability_inventory.csv"], ["validation/C08.json"]),
        "C09": ("completed", 8, 8, ["results/C09/sample_scores.csv.gz", "results/C09/paired_differences.csv"], ["validation/C03_C05A_C09.json"]),
        "D01": ("completed", 1, 1, ["reports/STAGE_REPORT.md", "reports/reviewer_evidence_matrix.csv"], ["validation/NO_GPU_scientific_validation.json"]),
        "G01": ("blocked_resource", 0, 1, [], []),
        "G02": ("blocked_resource", 0, 12, [], []),
        "G03": ("blocked_resource", 0, 1, [], []),
        "G04": ("blocked_resource", 0, 1, [], []),
        "G05": ("blocked_resource", 0, 1, ["results/C08/availability_report.md"], ["validation/C08.json"]),
        "G06": ("deferred_optional", 0, 0, ["provenance/cache_inventory.csv"], ["validation/A00.json"]),
        "G07": ("deferred_optional", 0, 0, [], []),
    }
    reasons = {
        "C08": "Unfiltered K400 correctness tables lack all 21 detector features/scores; requires G05 clean forward extraction.",
        "G01": "NO_GPU mode; user has not authorized GPU mode.",
        "G02": "NO_GPU mode and depends on a passing G01 full-forward/gradient audit.",
        "G03": "NO_GPU mode; controlled GPU timing not authorized.",
        "G04": "NO_GPU mode; structured-attack convergence pilot not authorized.",
        "G05": "NO_GPU mode; C08 confirmed missing unfiltered clean detector features.",
        "G06": "A00 validated all 28,041 formal response-cache shards, so cache regeneration is not needed.",
        "G07": "Optional design extensions require a defined scope and budget.",
    }
    registry = json.loads((HANDOFF / "TASK_REGISTRY.json").read_text(encoding="utf-8-sig"))
    registry_tasks = registry["tasks"] if isinstance(registry, dict) else registry
    registry_by_id = {item["task_id"]: item for item in registry_tasks}
    output = []
    for task_id in registry_by_id:
        status, done, expected, paths, validations = tasks[task_id]
        output.append({
            "task_id": task_id, "status": status,
            "protocol_id": PROTOCOL if task_id == "D01" else "see protocols/ and validation/",
            "input_hash_manifest": "provenance/input_manifest.csv",
            "completed_units": done, "expected_units": expected,
            "reason": reasons.get(task_id, "Completed under the declared NO_GPU protocol and validated in the listed report."),
            "result_paths": paths, "validation_paths": validations,
            "next_command": ("none" if status == "completed" else
                             "await explicit GPU-mode authorization; then follow GPU_TASKS.md" if task_id.startswith("G") else
                             "run G05 after explicit GPU-mode authorization"),
        })
    return {
        "format_version": 1, "run_id": RUN.name, "generated_at": now(), "mode": "NO_GPU",
        "stage_scope_tasks": ["A00", "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "D01"],
        "scope_complete": False,
        "scope_note": "All currently computable required CPU analyses are complete; C08 remains blocked_input, and GPU tasks were not authorized.",
        "tasks": output,
    }


def write_reports() -> None:
    reports = RUN / "reports"; reports.mkdir(parents=True, exist_ok=True)
    figures = RUN / "figures"; figures.mkdir(parents=True, exist_ok=True)
    glance = build_results_at_a_glance()
    write_csv(reports / "RESULTS_AT_A_GLANCE.csv", glance)
    matrix = pd.DataFrame(evidence_rows())
    write_csv(reports / "reviewer_evidence_matrix.csv", matrix)

    resources = []
    for path in sorted((RUN / "validation").glob("*.json")):
        data = json.loads(path.read_text())
        resources.append({"task_or_report": path.stem, "elapsed_seconds": data.get("elapsed_seconds", np.nan),
                          "max_rss_kib": data.get("max_rss_kib", np.nan), "gpu_used": data.get("gpu_used", False),
                          "source": str(path.relative_to(RUN))})
    for path in sorted((RUN / "logs/cache_task_conditions").glob("*.json")):
        data = json.loads(path.read_text())
        resources.append({"task_or_report": f"cache_condition:{data['condition']}", "elapsed_seconds": data["elapsed_seconds"],
                          "max_rss_kib": data["max_rss_kib"], "gpu_used": False, "source": str(path.relative_to(RUN))})
    write_csv(reports / "RESOURCE_USAGE.csv", pd.DataFrame(resources))

    # Figure source data and compact reviewer-facing plots.
    plot_rows = []
    for task, left, right, filename in [
        ("C03", "full21_lr", "mean_abs_z", "paired_differences.csv"),
        ("C03", "full21_lr", "max_abs_z", "paired_differences.csv"),
        ("C05", "full21_lr", "noFFT15_lr", "paired_differences.csv"),
        ("C05", "full21_lr", "adjacent_difference_stats21_lr", "ordinary_difference_paired_differences.csv"),
        ("C06", "symmetric_kl_eps1e-8", "js_eps1e-8", "paired_differences.csv"),
        ("C09", "full21_lr", "without_local_confidence19_lr", "paired_differences.csv"),
    ]:
        value = read_macro(task, left, right, filename)
        plot_rows.append({"task": task, "contrast": f"{left} − {right}", "difference": value.point_difference,
                          "ci_low": value.ci_low, "ci_high": value.ci_high})
    plot_data = pd.DataFrame(plot_rows)
    write_csv(figures / "paired_auc_differences_source_data.csv", plot_data)
    fig, ax = plt.subplots(figsize=(9, 4.8))
    y = np.arange(len(plot_data))
    ax.errorbar(plot_data.difference, y,
                xerr=np.vstack([plot_data.difference - plot_data.ci_low,
                                plot_data.ci_high - plot_data.difference]), fmt="o", capsize=3)
    ax.axvline(0, color="black", linewidth=.8)
    ax.set_yticks(y, plot_data.task + ": " + plot_data.contrast)
    ax.set_xlabel("Macro ROC-AUC difference (paired 95% CI)")
    ax.invert_yaxis(); fig.tight_layout()
    fig.savefig(figures / "paired_auc_differences.png", dpi=180)
    fig.savefig(figures / "paired_auc_differences.pdf")
    plt.close(fig)

    c04 = pd.read_csv(RUN / "results/C04/condition_metrics.csv")
    c04 = c04[(c04.attack == "pooled") & (c04.setting == "full")].copy()
    c04["condition"] = c04.dataset.astype(str) + "/" + c04.model.astype(str)
    write_csv(figures / "C04_readout_auc_source_data.csv", c04)
    pivot = c04.pivot(index="condition", columns="method", values="roc_auc")
    fig, ax = plt.subplots(figsize=(10, 4.8))
    pivot.plot(kind="bar", ax=ax)
    ax.set_ylabel("ROC-AUC"); ax.set_ylim(0, 1); ax.set_xlabel("")
    ax.legend(fontsize=8); fig.tight_layout()
    fig.savefig(figures / "C04_readout_auc.png", dpi=180)
    fig.savefig(figures / "C04_readout_auc.pdf")
    plt.close(fig)

    unresolved = """# Unresolved items after the NO_GPU stage

1. **C08 / G05 — unfiltered clean false positives.** Four K400 prediction/correctness tables exist, but they contain no 21D detector features or frozen detector score. A clean-only GPU forward extraction is required; no attacks are needed.
2. **G01–G02 — full-detector adaptive attack.** Historical E8 is a partial action-response proxy. Full forward equivalence and gradient audit must pass before the bounded attack pilot.
3. **G03 — controlled efficiency.** Historical E9/E14 timings differ in batch/boundary. A quiet same-GPU pilot is required for publication-grade ratios.
4. **G04 — OFA/Flicker optimization sufficiency.** The historical 10-step budget is reproducible but not a convergence demonstration.
5. **G07 — optional endpoint/frame-cap/equal-count/new-VLM controls.** These are not authorized or necessary to complete the current NO_GPU scope; define scope and budget before running.

No GPU inference or attack was started in this run. G06 is not needed because A00 validated all formal probability-cache shards.
"""
    (reports / "UNRESOLVED_ITEMS.md").write_text(unresolved, encoding="utf-8")

    change_map = """# Proposed manuscript change map

These are proposed edits; this run does not overwrite the manuscript and does not invent page/line numbers.

- **Abstract and Introduction:** narrow the contribution to a compact, auditable multi-response representation with supervised calibration; avoid universal novelty, optimality, or physical-frequency claims.
- **Method / feature order:** publish the exact historical evaluator’s 21D order. Explain that CSV physical order differs but the evaluator explicitly selects the canonical list.
- **Sampling subsection:** document endpoints, motion selection, local supports, and the up-to-eight-frame CLIP rule as deterministic budget choices, not proven optima.
- **Semantic/KL subsection:** define natural-log symmetric KL as clip-to-epsilon followed by renormalization; state epsilon=1e-8, unboundedness, tail sensitivity, and that CLIP scores are relative text compatibilities.
- **Local-feature subsection:** call local confidence and full-clip-reference differences empirical coordinates; do not assert that high confidence or discrepancy uniquely indicates attack.
- **Data and clean evaluation:** explicitly state that K400 main cohorts were original-correct filtered. Do not generalize their FPR to all natural clean clips until G05.
- **Main comparison:** add C03 fixed same-21 controls and C04 raw/PCA learned controls. Separate readout benefit from nine-view forward cost.
- **Transfer/deployment:** report E3/E4/E15 frozen-threshold FPR/TPR, the four deployment regimes, and the need for labeled attacks somewhere in the current supervised method.
- **DFT/order ablation:** report C05 subset, ordinary-difference, and permutation analyses; replace physical temporal-frequency language with order-descriptor language.
- **Distance ablation:** report C06 KL epsilon and JS results with tail/clipping statistics; do not select a new main distance from the old test without labeling it exploratory.
- **Probe sensitivity:** replace inconsistent historical E7 numbers with validated C01 OOF results; the g3/l2 versus g5/l4 CI includes zero.
- **Adaptive evaluation:** relabel historical E8 as a partial action-response proxy. Reserve full-white-box conclusions for G01/G02.
- **Efficiency:** separate old timing boundaries, forward-query counts, representation/readout parameters, and new G03 timing.
- **Interpretability and limitations:** coefficient signs/ranks are conditional fitted weights under collinearity, not independent or causal importance; disclose missing Git history and repeated-test-selection limits.
"""
    (reports / "manuscript_change_map.md").write_text(change_map, encoding="utf-8")

    stage_report = f"""# NO_GPU stage report

Run: `{RUN.name}`  
Protocol: `{PROTOCOL}`  
Generated: `{now()}`

## Outcome

A00 and all input-available required CPU analyses (C01–C07 and C09) completed under independent calibration/test or the declared E7 OOF protocol. C08 is correctly blocked because unfiltered clean predictions lack detector features. No GPU task was authorized or started, and the historical E1–E10 outputs were not modified.

## Main results

{chr(10).join('- ' + str(value) for value in build_results_at_a_glance().key_result.head(10))}

The raw 7200D/PCA21 controls, distance variants, and permutation results must be interpreted as prespecified comparisons on an already-used historical test set, not as a new confirmatory model-selection holdout. See `RESULTS_AT_A_GLANCE.csv` for scopes and limitations.

## Reuse and provenance

- C01 reuses the independently completed `tdc-e7-cpu-correction-20261021-v1` only after copying it into this new root and rerunning its validator; 180 fit states and 21,600 OOF rows passed.
- E14/E15/E16 saved scores/summaries are reused where the task asks for recomputation or evidence synthesis; their provenance remains `tdc-supplement-20260817`.
- A00 fully hashed and reconstructed 28,041 formal cache shards / 140,205 rows; the maximum 21D reconstruction error was below the predeclared 2e-5 tolerance.
- All new outputs are under this run root; original E1–E10 and supplement directories are read-only dependencies.

## Claims that must be narrowed

Do not claim physical DFT frequency, causal coefficient importance, population-wide K400 clean FPR, attack-free training, full-white-box robustness from historical E8, or newly controlled efficiency from historical timing. The evidence matrix lists the precise allowed claim and remaining gap for every R3/R5 subissue.

## Remaining work and next command

The concrete remaining items are C08/G05, G01/G02, G03, G04, and optional G07. They require explicit GPU-mode authorization. The next authorized command in the current mode is only export/verification; do not start `GPU_TASKS.md` until the user switches modes.
"""
    (reports / "STAGE_REPORT.md").write_text(stage_report, encoding="utf-8")


def main() -> None:
    cache_validation = json.loads((RUN / "validation/C04_C05B_C06.json").read_text())
    if not cache_validation.get("passed"):
        raise RuntimeError("Cannot build D01 before C04/C05-B/C06 validation passes")
    write_json(RUN / "protocols/D01.json", {"protocol_id": PROTOCOL, "task_id": "D01", "mode": "NO_GPU",
        "manuscript_modified": False, "gpu_used": False, "scope": "evidence synthesis, change proposals, status, and export preparation"})
    write_reports()
    write_json(RUN / "STATUS.json", status_document())
    write_csv(RUN / "logs/errors.csv", pd.DataFrame([
        {"task": "C04/C05-B/C06 smoke", "attempt": 1, "exit_code": 137, "error": "in-memory raw7200 construction exceeded 2 GiB cgroup", "resolution": "bounded float32 memmap and sequential train/test materialization", "scientific_output_used": False},
        {"task": "C04/C05-B/C06 smoke", "attempt": 2, "exit_code": 130, "error": "diagnostic interruption before likely memory exhaustion", "resolution": "closed/evicted probability maps and materialized only one 7200D split at a time", "scientific_output_used": False},
    ]))
    commands = [
        {"task": "A00", "command": "python3 code/a00_audit.py", "mode": "NO_GPU"},
        {"task": "A00 gate rebuild", "command": "python3 code/a00_audit.py --reuse-validated-cache-audit", "mode": "NO_GPU"},
        {"task": "C01", "command": "python3 artifacts/C01_reused_source/scripts/validate_e7_cpu.py --output-root artifacts/C01_reused_source", "mode": "NO_GPU"},
        {"task": "C02", "command": "python3 code/run_c02.py", "mode": "NO_GPU"},
        {"task": "C03/C05-A/C09", "command": "python3 code/run_c03_c05a_c09.py", "mode": "NO_GPU"},
        {"task": "C07/C08", "command": "python3 code/run_c07_c08.py", "mode": "NO_GPU"},
        {"task": "C04/C05-B/C06 smoke", "command": "python3 code/run_cache_cpu_tasks.py --mode smoke", "mode": "NO_GPU"},
        {"task": "C04/C05-B/C06 full", "command": "python3 code/run_cache_cpu_tasks.py --mode full", "mode": "NO_GPU"},
        {"task": "D01", "command": "python3 code/build_d01_reports.py", "mode": "NO_GPU"},
    ]
    history = RUN / "logs/command_history.jsonl"
    history.write_text("".join(json.dumps(item, ensure_ascii=False) + "\n" for item in commands), encoding="utf-8")
    readme = f"""# TDC R3+R5 revision — NO_GPU stage

This directory contains the independently versioned run `{RUN.name}`. Start with `reports/STAGE_REPORT.md`, `reports/RESULTS_AT_A_GLANCE.csv`, `reports/reviewer_evidence_matrix.csv`, and `STATUS.json`.

All computable required CPU analyses are complete. C08 is blocked by absent unfiltered-clean detector features. G01–G05 were not run because this stage had no GPU authorization; G06 is unnecessary after full cache validation; G07 is optional and unscoped.

The original E1–E10 and E11–E16 directories were not modified. Large response-cache dependencies are indexed by provenance and will be supplied as separate reproducibility volumes.
"""
    (RUN / "README.md").write_text(readme, encoding="utf-8")
    print(json.dumps({"protocol_id": PROTOCOL, "status": "reports_complete", "python": platform.python_version()}, indent=2))


if __name__ == "__main__":
    main()
