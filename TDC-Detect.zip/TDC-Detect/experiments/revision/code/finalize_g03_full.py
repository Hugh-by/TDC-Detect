#!/usr/bin/env python3
"""Validate and summarize all G03 full isolated timing shards."""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROTOCOL_ID = "tdc-r3r5-g03-full-option-b-20261023-v1"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
METHODS = ("action_single", "e14_action_shift9", "action_stats12", "discrepancy9", "full_g5l4", "light_g3l2", "single_discrepancy")


def main() -> None:
    output = RUN / "results/G03/full"
    availability = []
    frames = []
    for dataset in ("k400", "ucf101"):
        for model in MODELS:
            for method in METHODS:
                available = not (dataset == "ucf101" and method == "light_g3l2")
                path = output / "shards" / f"{dataset}_{model}_{method}.csv.gz"
                availability.append({"dataset": dataset, "model": model, "method": method, "available": available,
                                     "reason": "no independent UCF101 light calibration adapter" if not available else "implemented",
                                     "path": str(path) if available else ""})
                if available:
                    frame = pd.read_csv(path)
                    if len(frame) != 1000 or not frame.protocol_id.eq(PROTOCOL_ID).all(): raise RuntimeError(f"invalid {path}")
                    frames.append(frame)
    all_rows = pd.concat(frames, ignore_index=True)
    all_rows.to_csv(output / "per_clip_runtime.csv.gz", index=False, compression="gzip")
    pd.DataFrame(availability).to_csv(output / "method_availability.csv", index=False)
    rng = np.random.default_rng(20260714)
    summaries = []
    for keys, group in all_rows.groupby(["dataset", "model", "method", "timing_boundary"], sort=True):
        by_source = group.groupby("source_id").seconds.mean().to_numpy()
        boots = np.asarray([rng.choice(by_source, len(by_source), replace=True).mean() for _ in range(1000)])
        summaries.append({"dataset": keys[0], "model": keys[1], "method": keys[2], "timing_boundary": keys[3],
                          "n_sources": group.source_id.nunique(), "repeats": group.repeat.nunique(),
                          "mean_seconds": group.seconds.mean(), "median_seconds": group.seconds.median(),
                          "p95_seconds": group.seconds.quantile(.95), "source_cluster_ci_low": np.quantile(boots, .025),
                          "source_cluster_ci_high": np.quantile(boots, .975), "peak_allocated": group.peak_allocated.max(),
                          "peak_reserved": group.peak_reserved.max()})
    latency = pd.DataFrame(summaries)
    latency.to_csv(output / "condition_latency.csv", index=False)
    pivot = latency.pivot_table(index=["dataset", "model", "timing_boundary"], columns="method", values="mean_seconds").reset_index()
    for baseline in ("action_single", "e14_action_shift9", "single_discrepancy"):
        pivot[f"full_over_{baseline}"] = pivot.full_g5l4 / pivot[baseline]
    pivot.to_csv(output / "ratio_table.csv", index=False)
    parameters = all_rows.groupby(["dataset", "model", "method"], as_index=False).agg(
        frozen_action_parameters=("frozen_action_parameters", "max"), frozen_clip_parameters=("frozen_clip_parameters", "max"),
        readout_trainable_parameters=("readout_trainable_parameters", "max"), logical_action_view_calls=("logical_action_view_calls", "max"),
        logical_clip_view_calls=("logical_clip_view_calls", "max"))
    parameters.to_csv(output / "parameter_table.csv", index=False)
    validation = {"protocol_id": PROTOCOL_ID, "passed": bool(len(frames) == 52 and len(all_rows) == 52000 and np.isfinite(all_rows.seconds).all()),
                  "shards": len(frames), "rows": len(all_rows), "available_conditions": 52, "unavailable_conditions": 4,
                  "quiet_window": True, "gpu": 0, "warmups": 10, "repeats": 5}
    (output / "validation.json").write_text(json.dumps(validation, indent=2, sort_keys=True) + "\n")
    print(json.dumps(validation))


if __name__ == "__main__": main()
