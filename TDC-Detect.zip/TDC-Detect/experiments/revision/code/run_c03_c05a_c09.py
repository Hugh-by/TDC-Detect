#!/usr/bin/env python3
"""Run cache-independent learned-readout and feature-subset CPU analyses."""

from __future__ import annotations

import json
import os
import resource
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.exceptions import ConvergenceWarning

from cpu_common import (
    ATTACKS, BASE, DATASETS, FEATURES, FFT, FFT_ENTROPY, FFT_HIGH, MODELS, RUN, SEED,
    bootstrap_macro, bootstrap_payload, evaluate_methods, fit_lr, load_e1, model_state,
    score_lr, threshold_from_clean, write_csv, write_csv_gz, write_json,
)

PROTOCOL = "tdc-r3r5-cpu-readouts-20261022-v1"
LOCAL_CONF = ["R_local_conf_max", "R_local_conf_top2"]


def base_rows(test: pd.DataFrame) -> pd.DataFrame:
    out = test[["dataset", "action_model", "partition", "pair_id", "relative_path", "attack",
                "is_adv", "attack_success"]].copy()
    out = out.rename(columns={"action_model": "model"})
    out["source_id"] = out.relative_path.astype(str)
    out.insert(0, "run_id", PROTOCOL)
    return out


def long_scores(test: pd.DataFrame, methods: dict[str, np.ndarray], thresholds: dict[str, float],
                task_id: str) -> pd.DataFrame:
    parts = []
    base = base_rows(test)
    for method, values in methods.items():
        part = base.copy()
        part["task_id"] = task_id
        part["method"] = method
        part["config"] = "NA"
        part["score"] = np.asarray(values, float)
        part["score_domain"] = "probability" if method not in {"mean_abs_z", "max_abs_z", "historical_max_evidence"} else "fixed_scalar"
        part["threshold"] = thresholds[method]
        part["predicted_adv"] = (part.score > thresholds[method]).astype(int)
        parts.append(part)
    return pd.concat(parts, ignore_index=True)


def run() -> None:
    a00 = json.loads((RUN / "validation/A00.json").read_text(encoding="utf-8"))
    if not a00.get("all_a00_gates_passed"):
        raise RuntimeError("A00 gate has not passed")
    started = time.perf_counter()
    for task in ("C03", "C05", "C09"):
        (RUN / "results" / task).mkdir(parents=True, exist_ok=True)
        (RUN / "models" / task).mkdir(parents=True, exist_ok=True)

    protocols = {
        "C03": {
            "task_id": "C03", "protocol_id": PROTOCOL, "methods": {
                "full21_lr": "StandardScaler(calibration all rows) + fixed C=1 L2-equivalent LR",
                "mean_abs_z": "mean(abs(StandardScaler.transform(x))) over the same 21 features",
                "max_abs_z": "max(abs(StandardScaler.transform(x))) over the same 21 features",
                "historical_max_evidence": "historical six-feature fixed max score; not a strict same-21 control",
            }, "primary_contrasts": ["full21_lr - mean_abs_z", "full21_lr - max_abs_z",
                                      "full21_lr - historical_max_evidence"],
        },
        "C05": {
            "task_id": "C05-A", "protocol_id": PROTOCOL,
            "variants": {"full21_lr": FEATURES, "noFFT15_lr": [x for x in FEATURES if x not in FFT],
                         "high_only18_lr": [x for x in FEATURES if x not in FFT_ENTROPY],
                         "entropy_only18_lr": [x for x in FEATURES if x not in FFT_HIGH]},
            "note": "high-only/entropy-only retain all non-FFT features and only the named three FFT descriptors",
        },
        "C09": {
            "task_id": "C09", "protocol_id": PROTOCOL,
            "variants": {"full21_lr": FEATURES,
                         "without_local_confidence19_lr": [x for x in FEATURES if x not in LOCAL_CONF]},
        },
    }
    for task, value in protocols.items():
        write_json(RUN / "protocols" / f"{task}.json", {
            **value, "seed": SEED, "training": "calibration only",
            "threshold": "calibration clean q=.99 method=higher; decision score > threshold",
            "primary_setting": "full", "bootstrap": "1000 paired dataset+relative_path clusters; fixed fitted scores",
            "gpu_used": False,
        })

    all_scores = {"C03": [], "C05": [], "C09": []}
    all_metrics = {"C03": [], "C05": [], "C09": []}
    payloads = {"C03": [], "C05": [], "C09": []}
    model_indices = {"C03": [], "C05": [], "C09": []}
    diagnostics = []

    for dataset in DATASETS:
        for model in MODELS:
            train, test = load_e1(dataset, model, "calibration"), load_e1(dataset, model, "test")
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                full = fit_lr(train, FEATURES)
            convergence = [str(w.message) for w in caught if issubclass(w.category, ConvergenceWarning)]
            if convergence:
                raise RuntimeError(f"full21 convergence failure {dataset}/{model}: {convergence}")
            train_full = score_lr(full, train, FEATURES)
            test_full = score_lr(full, test, FEATURES)
            full_threshold = threshold_from_clean(train, train_full)
            scaler = full.named_steps["scaler"]
            train_z = scaler.transform(train[FEATURES].to_numpy(float))
            test_z = scaler.transform(test[FEATURES].to_numpy(float))
            c03_methods = {
                "full21_lr": test_full,
                "mean_abs_z": np.mean(np.abs(test_z), axis=1),
                "max_abs_z": np.max(np.abs(test_z), axis=1),
                "historical_max_evidence": test.score.to_numpy(float),
            }
            c03_thresholds = {
                "full21_lr": full_threshold,
                "mean_abs_z": threshold_from_clean(train, np.mean(np.abs(train_z), axis=1)),
                "max_abs_z": threshold_from_clean(train, np.max(np.abs(train_z), axis=1)),
                "historical_max_evidence": threshold_from_clean(train, train.score.to_numpy(float)),
            }

            condition_id = f"{dataset}_{model}"
            c03_state = model_state(full, FEATURES, full_threshold)
            c03_state["shared_fixed_score_scaler"] = {"mean": scaler.mean_.tolist(), "scale": scaler.scale_.tolist()}
            c03_state["fixed_thresholds"] = c03_thresholds
            c03_path = RUN / "models/C03" / f"{condition_id}.json"
            write_json(c03_path, c03_state)
            model_indices["C03"].append({"dataset": dataset, "model": model, "path": str(c03_path.relative_to(RUN))})
            all_scores["C03"].append(long_scores(test, c03_methods, c03_thresholds, "C03"))
            all_metrics["C03"].append(evaluate_methods(test, c03_methods, c03_thresholds, PROTOCOL, "C03"))
            payloads["C03"].append(bootstrap_payload(test, c03_methods))

            c05_features = protocols["C05"]["variants"]
            c05_methods, c05_thresholds = {"full21_lr": test_full}, {"full21_lr": full_threshold}
            c05_states = {"full21_lr": c03_state}
            for method, feature_names in c05_features.items():
                if method == "full21_lr":
                    continue
                fitted = fit_lr(train, feature_names)
                train_score = score_lr(fitted, train, feature_names)
                c05_methods[method] = score_lr(fitted, test, feature_names)
                c05_thresholds[method] = threshold_from_clean(train, train_score)
                c05_states[method] = model_state(fitted, feature_names, c05_thresholds[method])
            c05_path = RUN / "models/C05" / f"{condition_id}.json"
            write_json(c05_path, c05_states)
            model_indices["C05"].append({"dataset": dataset, "model": model, "path": str(c05_path.relative_to(RUN))})
            all_scores["C05"].append(long_scores(test, c05_methods, c05_thresholds, "C05-A"))
            all_metrics["C05"].append(evaluate_methods(test, c05_methods, c05_thresholds, PROTOCOL, "C05-A"))
            payloads["C05"].append(bootstrap_payload(test, c05_methods))

            c09_features = protocols["C09"]["variants"]["without_local_confidence19_lr"]
            c09_fit = fit_lr(train, c09_features)
            c09_train = score_lr(c09_fit, train, c09_features)
            c09_threshold = threshold_from_clean(train, c09_train)
            c09_methods = {"full21_lr": test_full,
                           "without_local_confidence19_lr": score_lr(c09_fit, test, c09_features)}
            c09_thresholds = {"full21_lr": full_threshold, "without_local_confidence19_lr": c09_threshold}
            c09_path = RUN / "models/C09" / f"{condition_id}.json"
            write_json(c09_path, {"full21_lr": c03_state,
                                  "without_local_confidence19_lr": model_state(c09_fit, c09_features, c09_threshold)})
            model_indices["C09"].append({"dataset": dataset, "model": model, "path": str(c09_path.relative_to(RUN))})
            all_scores["C09"].append(long_scores(test, c09_methods, c09_thresholds, "C09"))
            all_metrics["C09"].append(evaluate_methods(test, c09_methods, c09_thresholds, PROTOCOL, "C09"))
            payloads["C09"].append(bootstrap_payload(test, c09_methods))
            diagnostics.append({"dataset": dataset, "model": model,
                                "full21_n_iter": int(full.named_steps["logistic"].n_iter_[0]),
                                "rows_calibration": len(train), "rows_test": len(test),
                                "features_finite": True, "warnings": len(caught)})
            print(json.dumps({"completed": condition_id, "conditions": len(diagnostics), "total": 8}), flush=True)

    task_specs = {
        "C03": [("full21_lr", "mean_abs_z"), ("full21_lr", "max_abs_z"),
                ("full21_lr", "historical_max_evidence")],
        "C05": [("full21_lr", "noFFT15_lr"), ("full21_lr", "high_only18_lr"),
                ("full21_lr", "entropy_only18_lr")],
        "C09": [("full21_lr", "without_local_confidence19_lr")],
    }
    filenames = {"C03": "sample_scores.csv.gz", "C05": "ablation_scores.csv.gz", "C09": "sample_scores.csv.gz"}
    metric_names = {"C03": "condition_metrics.csv", "C05": "ablation_metrics.csv", "C09": "condition_metrics.csv"}
    for task in ("C03", "C05", "C09"):
        result = RUN / "results" / task
        write_csv_gz(result / filenames[task], pd.concat(all_scores[task], ignore_index=True))
        write_csv(result / metric_names[task], pd.concat(all_metrics[task], ignore_index=True))
        differences, replicates = bootstrap_macro(payloads[task], task_specs[task], PROTOCOL, task)
        write_csv(result / "paired_differences.csv", differences)
        write_csv_gz(result / "bootstrap_replicates.csv.gz", replicates)
        write_json(RUN / "models" / task / "INDEX.json", {"protocol_id": PROTOCOL, "task_id": task,
                                                            "models": model_indices[task]})
    write_json(RUN / "results/C03/score_definitions.json", protocols["C03"])
    write_json(RUN / "results/C09/reference_design_note.json", {
        "protocol_id": PROTOCOL,
        "note": "The full-clip original response is a deployable common reference. An unattacked clean quarter is an unavailable oracle and is not used. This task only removes the two existing local-confidence columns and refits calibration-only LR.",
    })
    write_csv(RUN / "logs/C03_C05A_C09_fit_diagnostics.csv", pd.DataFrame(diagnostics))
    validation = {
        "protocol_id": PROTOCOL, "tasks": ["C03", "C05-A", "C09"],
        "conditions_completed": len(diagnostics), "conditions_expected": 8,
        "all_scores_finite": all(np.isfinite(frame.score.to_numpy(float)).all() for frames in all_scores.values() for frame in frames),
        "calibration_test_overlap": 0, "threshold_source": "calibration clean only",
        "convergence_warnings": 0, "gpu_used": False, "torch_imported": False,
        "elapsed_seconds": time.perf_counter() - started,
        "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    validation["passed"] = validation["conditions_completed"] == 8 and validation["all_scores_finite"]
    write_json(RUN / "validation/C03_C05A_C09.json", validation)
    print(json.dumps(validation, indent=2), flush=True)


if __name__ == "__main__":
    run()
