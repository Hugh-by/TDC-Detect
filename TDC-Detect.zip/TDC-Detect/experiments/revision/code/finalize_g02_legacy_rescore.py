#!/usr/bin/env python3
import hashlib, json
from pathlib import Path
import numpy as np
import pandas as pd

RUN=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01'); ROOT=RUN/'results/G02/legacy_rescore_v2'; PROTOCOL='tdc-r3r5-g02-legacy-rescore-20261026-v1'
records=[json.loads(p.read_text()) for p in sorted((ROOT/'shards').glob('*.json'))]; rows=[]; errors=[]
for r in records:
 base={k:r[k] for k in ('protocol_id','action_model','mode','source_rank','relative_path','tensor_path','tensor_sha256_expected','tensor_sha256_actual','tensor_shape','tensor_dtype','tensor_min','tensor_max','measured_linf','epsilon','constraint_passed','clean_pred_saved','adv_pred_legacy','adv_pred_saved','attack_success_legacy','attack_success_saved','legacy_score','saved_score','score_error','threshold','legacy_decision','saved_decision','frozen_detector_state','frozen_detector_state_sha256','max_abs_feature_error')}
 base['tensor_shape']=json.dumps(base['tensor_shape']); rows.append(base)
 for name in r['feature_order']:
  errors.append({**{k:r[k] for k in ('action_model','mode','source_rank','relative_path')},'feature':name,'legacy_value':r['legacy_features'][name],'saved_value':r['saved_features'][name],'signed_error':r['feature_errors'][name],'absolute_error':abs(r['feature_errors'][name])})
samples=pd.DataFrame(rows); feature=pd.DataFrame(errors); samples.to_csv(ROOT/'legacy_rescore_per_sample.csv.gz',index=False,compression='gzip'); feature.to_csv(ROOT/'legacy_rescore_feature_errors.csv.gz',index=False,compression='gzip')
weights={'csn_r101':Path('/root/.cache/torch/hub/checkpoints/CSN_32x2_R101.pyth'),'mvit_base_16x4':Path('/root/.cache/torch/hub/checkpoints/MVIT_B_16x4.pyth')}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
state_rows=[]
for model in weights:
 state=RUN/'protocols/G05_v2_frozen_states'/f'{model}.json'; state_rows.append({'protocol_id':PROTOCOL,'action_model':model,'detector_state_path':str(state),'detector_state_sha256':sha(state),'action_checkpoint_path':str(weights[model]),'action_checkpoint_sha256':sha(weights[model]),'preprocessing':'prepare_attack_frames CUDA + historical score_frames frozen views; float32 tensor retained; CLIP image path applies historical uint8 quantization','clip_templates':'a video of a person {};a video of {};an action of {}','feature_order':'\x1f'.join(json.loads(state.read_text())['feature_order'])})
pd.DataFrame(state_rows).to_csv(ROOT/'frozen_detector_state_index.csv',index=False)
checks={'records_400':len(samples)==400,'tensor_hashes_match':bool((samples.tensor_sha256_actual==samples.tensor_sha256_expected).all()),'constraints_pass':bool(samples.constraint_passed.all()),'decision_identity':bool((samples.legacy_decision==samples.saved_decision).all()),'adv_prediction_identity':bool((samples.adv_pred_legacy==samples.adv_pred_saved).all()),'attack_success_identity':bool((samples.attack_success_legacy==samples.attack_success_saved).all()),'finite_features':bool(np.isfinite(feature[['legacy_value','saved_value','signed_error']]).all().all())}
summary={'protocol_id':PROTOCOL,'passed':all(checks.values()),'checks':checks,'records':len(samples),'maximum_linf':float(samples.measured_linf.max()),'linf_tolerance':1e-7,'maximum_abs_feature_error':float(feature.absolute_error.max()),'maximum_abs_score_error':float(samples.score_error.abs().max()),'decision_mismatches':int((samples.legacy_decision!=samples.saved_decision).sum()),'prediction_mismatches':int((samples.adv_pred_legacy!=samples.adv_pred_saved).sum()),'preprocessing_note':'GPU clean reconstruction is required; CPU interpolation smoke produced 3e-6 to 9e-6 artificial L-infinity excess and was rejected.'}
(ROOT/'constraint_validation.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
if not summary['passed']: raise SystemExit(summary)
