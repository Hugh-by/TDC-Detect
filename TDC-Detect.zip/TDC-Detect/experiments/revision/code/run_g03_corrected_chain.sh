#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
[[ "$(python -c "import json; print(json.load(open('$RUN/protocols/G03_METHOD_IDENTITY_GATE.json')).get('passed'))")" == True ]]
if [[ ! -s "$RUN/logs/G03_corrected_pilot/COMPLETE" ]]; then "$RUN/code/run_g03_corrected_pilot_four_gpu.sh"; fi
if [[ ! -s "$RUN/logs/G03_full_corrected/COMPLETE" ]]; then "$RUN/code/run_g03_corrected_full_serial.sh"; fi
