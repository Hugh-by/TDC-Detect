#!/usr/bin/env python3
"""Resumable G02 GPU_FULL worker for one model and one source shard."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path(os.environ.get("TDC_PROJECT_ROOT", "/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master"))
BASE_PROTOCOL = Path(os.environ.get("TDC_PROTOCOL_ROOT", "/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714"))
CLASSES = Path(os.environ.get("TDC_CLASS_MANIFEST", "/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv"))
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_loss_and_probs, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g02-full-option-b-20261023-v1"
EPSILON = 8 / 255
CHECKPOINTS = (0, 10, 20, 40, 60, 80, 100)
CALIBRATION_LAMBDAS = (0.1, 1.0, 10.0)
RESTARTS = 3


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def save_tensor(path: Path, value: torch.Tensor) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(value.detach().cpu().to(torch.float32), temp)
    os.replace(temp, path)
    return sha256(path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def stable_seed(model: str, partition: str, mode: str, relative_path: str, tradeoff: float, restart: int) -> int:
    value = f"{PROTOCOL_ID}|{model}|{partition}|{mode}|{relative_path}|{tradeoff:g}|{restart}"
    return int.from_bytes(hashlib.sha256(value.encode()).digest()[:4], "little")


def trajectory_id(model: str, partition: str, mode: str, relative_path: str, tradeoff: float, restart: int) -> str:
    value = f"{PROTOCOL_ID}|{model}|{partition}|{mode}|{relative_path}|{tradeoff:g}|{restart}"
    return hashlib.sha256(value.encode()).hexdigest()[:24]


def candidate_key(row: dict) -> tuple[int, float]:
    return (0 if row["attack_success"] else 1, float(row["detector_score"]))


def lambda_tag(value: float) -> str:
    return f"{value:g}".replace(".", "p")


def complete_record(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        value = json.loads(path.read_text())
    except Exception:
        return None
    if value.get("complete") and value.get("protocol_id") == PROTOCOL_ID:
        return value
    return None


def run_trajectory(
    *, detector: FullDetector, action_model, clean: torch.Tensor, clean_pred: int,
    model: str, partition: str, mode: str, relative_path: str, source_rank: int,
    tradeoff: float, restart: int, threshold: float, z_threshold: float,
    gpu_uuid: str, shard_path: Path, temporary_tensor: Path | None,
) -> dict:
    existing = complete_record(shard_path)
    if existing is not None and (temporary_tensor is None or temporary_tensor.exists()):
        return existing

    device = clean.device
    seed = stable_seed(model, partition, mode, relative_path, tradeoff, restart)
    generator = torch.Generator(device=device).manual_seed(seed)
    delta = torch.empty_like(clean).uniform_(-EPSILON, EPSILON, generator=generator)
    delta = ((clean + delta).clamp(0, 1) - clean).detach()
    checkpoint_rows: list[dict] = []
    gradient_seconds: list[float] = []
    best_tensor = None
    best_row = None
    torch.cuda.reset_peak_memory_stats(device)

    def score_candidate(step: int, candidate: torch.Tensor, step_seconds: float) -> None:
        nonlocal best_tensor, best_row
        started = time.perf_counter()
        with torch.no_grad():
            features, logit, score, _, _ = detector.exact_forward(candidate)
            probability = action_probs(action_model, candidate, model)
        torch.cuda.synchronize(device)
        row = {
            "step": step,
            "classification_loss": float(-probability[clean_pred].clamp_min(1e-30).log()),
            "detector_logit": float(logit),
            "detector_score": float(score),
            "attacked_pred": int(probability.argmax()),
            "attack_success": int(probability.argmax()) != clean_pred,
            "detector_evaded": float(score) <= threshold,
            "joint_success_evasion": int(probability.argmax()) != clean_pred and float(score) <= threshold,
            "measured_linf": float((candidate - clean).abs().max()),
            "gradient_seconds": step_seconds,
            "score_seconds": time.perf_counter() - started,
            "features": {name: float(features[name]) for name in FEATURES},
        }
        checkpoint_rows.append(row)
        if best_row is None or candidate_key(row) < candidate_key(best_row):
            best_row = row
            best_tensor = candidate.detach().cpu().to(torch.float32).clone()

    score_candidate(0, (clean + delta).clamp(0, 1), 0.0)
    for step in range(1, 101):
        adv = (clean + delta).clamp(0, 1).detach().requires_grad_(True)
        started = time.perf_counter()
        classification_loss, _ = action_loss_and_probs(action_model, adv, model, clean_pred)
        classification_gradient = torch.autograd.grad(classification_loss, adv)[0]
        if tradeoff > 0:
            _, detector_z, _, detector_gradient, _ = detector.logit_and_vjp_gradient(adv)
            gradient = classification_gradient - tradeoff * torch.sigmoid(detector_z - z_threshold) * detector_gradient
        else:
            gradient = classification_gradient
        torch.cuda.synchronize(device)
        elapsed = time.perf_counter() - started
        gradient_seconds.append(elapsed)
        alpha = 2 / 255 if step <= 40 else 1 / 255
        delta = (delta + alpha * gradient.sign()).clamp(-EPSILON, EPSILON)
        delta = ((clean + delta).clamp(0, 1) - clean).detach()
        if step in CHECKPOINTS:
            score_candidate(step, (clean + delta).clamp(0, 1), elapsed)
        if step % 10 == 0:
            print(json.dumps({"model": model, "partition": partition, "mode": mode, "source": source_rank,
                              "lambda": tradeoff, "restart": restart, "step": step}), flush=True)

    tensor_hash = None
    if temporary_tensor is not None:
        assert best_tensor is not None
        tensor_hash = save_tensor(temporary_tensor, best_tensor)
    record = {
        "protocol_id": PROTOCOL_ID, "complete": True,
        "trajectory_id": trajectory_id(model, partition, mode, relative_path, tradeoff, restart),
        "action_model": model, "gpu_uuid": gpu_uuid, "partition": partition, "mode": mode,
        "source_rank": source_rank, "relative_path": relative_path, "tradeoff_lambda": tradeoff,
        "restart": restart, "seed": seed, "epsilon": EPSILON, "steps": 100,
        "alpha_schedule": {"1-40": 2 / 255, "41-100": 1 / 255},
        "checkpoints": list(CHECKPOINTS), "clean_pred": clean_pred, "threshold": threshold,
        "z_threshold": z_threshold, "checkpoint_rows": checkpoint_rows,
        "best_checkpoint": best_row, "temporary_best_tensor": str(temporary_tensor) if temporary_tensor else None,
        "temporary_best_tensor_sha256": tensor_hash,
        "gradient_seconds": gradient_seconds,
        "gradient_seconds_median": float(np.median(gradient_seconds)),
        "gradient_seconds_p95": float(np.quantile(gradient_seconds, .95)),
        "peak_memory_bytes": int(torch.cuda.max_memory_allocated(device)),
    }
    atomic_json(shard_path, record)
    return record


def finalize_source(output: Path, model: str, partition: str, mode: str, source_rank: int,
                    relative_path: str, tradeoff: float, records: list[dict]) -> None:
    qualified_mode = f"{mode}_l{lambda_tag(tradeoff)}" if partition == "calibration" else mode
    summary_path = output / "source_shards" / f"{partition}_{qualified_mode}_{source_rank:03d}.json"
    selected_dir = output / "selected_adv" / mode
    if complete_record(summary_path) is not None:
        return
    chosen = min(records, key=lambda item: candidate_key(item["best_checkpoint"]))
    selected_path = None
    selected_hash = None
    if partition == "test":
        source_tensor = Path(chosen["temporary_best_tensor"])
        if not source_tensor.exists():
            raise RuntimeError(f"missing temporary tensor {source_tensor}")
        selected_path = selected_dir / f"{source_rank:03d}_{hashlib.sha256(relative_path.encode()).hexdigest()[:16]}.pt"
        selected_path.parent.mkdir(parents=True, exist_ok=True)
        temp = selected_path.with_suffix(".pt.tmp")
        shutil.copy2(source_tensor, temp)
        os.replace(temp, selected_path)
        selected_hash = sha256(selected_path)
    atomic_json(summary_path, {
        "protocol_id": PROTOCOL_ID, "complete": True, "action_model": model,
        "partition": partition, "mode": mode, "source_rank": source_rank,
        "relative_path": relative_path, "tradeoff_lambda": tradeoff,
        "selection_rule": "attack_success first, then lowest exact full-detector score over restart/checkpoint union",
        "selected_trajectory_id": chosen["trajectory_id"],
        "selected_checkpoint": chosen["best_checkpoint"],
        "selected_adv_path": str(selected_path) if selected_path else None,
        "selected_adv_sha256": selected_hash,
        "restart_trajectory_ids": [item["trajectory_id"] for item in records],
    })
    for item in records:
        value = item.get("temporary_best_tensor")
        if value:
            Path(value).unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("csn_r101", "mvit_base_16x4"), required=True)
    parser.add_argument("--stage", choices=("calibration", "test"), required=True)
    parser.add_argument("--worker-index", type=int, required=True)
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if not 0 <= args.worker_index < args.workers:
        raise ValueError("invalid worker shard")
    authorization = json.loads((RUN / "protocols/authorization.json").read_text())
    if authorization.get("selected_option") != "B" or authorization.get("mode") != "GPU_FULL":
        raise RuntimeError("GPU_FULL option B is not authorized")
    gate = RUN / "results/G01" / args.model / "gradient_audit.json"
    if not gate.exists() or not json.loads(gate.read_text()).get("passed"):
        raise RuntimeError(f"G01 gate not passed: {gate}")

    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results/G02/full" / args.model
    output.mkdir(parents=True, exist_ok=True)
    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    threshold = threshold_from_clean(calibration, score_lr(pipeline, calibration, FEATURES))
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    z_threshold = math.log(threshold / (1 - threshold))
    manifest_path = BASE_PROTOCOL / "manifests" / f"k400_{args.model}_{args.stage}_fixed{20 if args.stage == 'calibration' else 100}.csv"
    manifest = pd.read_csv(manifest_path).sort_values("relative_path").reset_index(drop=True)
    manifest = manifest.iloc[:20 if args.stage == "calibration" else 100]
    assigned = [(index + 1, row) for index, row in manifest.iterrows() if index % args.workers == args.worker_index]

    torch.manual_seed(20260714)
    torch.cuda.manual_seed_all(20260714)
    torch.backends.cudnn.benchmark = False
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters(): parameter.requires_grad_(False)
    for parameter in clip_model.parameters(): parameter.requires_grad_(False)
    text = build_text_features(clip_model, processor, read_class_names(CLASSES), device)
    detector = FullDetector(action_model, clip_model, processor, text, args.model, state)

    if args.stage == "test":
        selection = json.loads((output / "lambda_selection.json").read_text())
        modes = (("adaptive", float(selection["selected_lambda"])), ("lambda0_control", 0.0))
    else:
        modes = tuple(("tuning", value) for value in CALIBRATION_LAMBDAS)

    for source_rank, row in assigned:
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        with torch.no_grad(): clean_probability = action_probs(action_model, clean, args.model)
        clean_pred = int(clean_probability.argmax())
        clean_shard = output / "clean_shards" / f"{args.stage}_{source_rank:03d}.json"
        if complete_record(clean_shard) is None:
            clean_started = time.perf_counter()
            with torch.no_grad():
                clean_features, clean_logit, clean_score, _, _ = detector.exact_forward(clean)
            torch.cuda.synchronize(device)
            atomic_json(clean_shard, {
                "protocol_id": PROTOCOL_ID, "complete": True, "action_model": args.model,
                "gpu_uuid": gpu_uuid, "partition": args.stage, "source_rank": source_rank,
                "relative_path": row.relative_path, "clean_pred": clean_pred,
                "clean_conf": float(clean_probability.max()), "detector_logit": float(clean_logit),
                "detector_score": float(clean_score), "threshold": threshold,
                "false_positive": float(clean_score) > threshold,
                "score_seconds": time.perf_counter() - clean_started,
                "features": {name: float(clean_features[name]) for name in FEATURES},
            })
        for mode, tradeoff in modes:
            qualified_mode = f"{mode}_l{lambda_tag(tradeoff)}" if args.stage == "calibration" else mode
            summary = output / "source_shards" / f"{args.stage}_{qualified_mode}_{source_rank:03d}.json"
            if complete_record(summary) is not None:
                print(json.dumps({"reused_source": source_rank, "mode": mode}), flush=True)
                continue
            records = []
            for restart in range(RESTARTS):
                tid = trajectory_id(args.model, args.stage, mode, row.relative_path, tradeoff, restart)
                shard = output / "trajectory_shards" / f"{tid}.json"
                temporary = output / "temporary_best" / f"{tid}.pt" if args.stage == "test" else None
                records.append(run_trajectory(
                    detector=detector, action_model=action_model, clean=clean, clean_pred=clean_pred,
                    model=args.model, partition=args.stage, mode=mode, relative_path=row.relative_path,
                    source_rank=source_rank, tradeoff=tradeoff, restart=restart, threshold=threshold,
                    z_threshold=z_threshold, gpu_uuid=gpu_uuid, shard_path=shard, temporary_tensor=temporary,
                ))
            finalize_source(output, args.model, args.stage, mode, source_rank, row.relative_path, tradeoff, records)
        atomic_json(output / "worker_status" / f"{args.stage}_{args.worker_index}.json", {
            "protocol_id": PROTOCOL_ID, "complete": False, "stage": args.stage,
            "model": args.model, "worker_index": args.worker_index, "workers": args.workers,
            "last_completed_source": source_rank, "assigned_sources": len(assigned), "gpu_uuid": gpu_uuid,
        })

    atomic_json(output / "worker_status" / f"{args.stage}_{args.worker_index}.json", {
        "protocol_id": PROTOCOL_ID, "complete": True, "stage": args.stage,
        "model": args.model, "worker_index": args.worker_index, "workers": args.workers,
        "completed_sources": len(assigned), "assigned_sources": len(assigned), "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"G02_full_worker_complete": True, "model": args.model, "stage": args.stage,
                      "worker": args.worker_index, "sources": len(assigned)}), flush=True)


if __name__ == "__main__":
    main()
