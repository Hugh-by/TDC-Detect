#!/usr/bin/env python3
"""Bounded G02 pilot: three calibration sources, lambda 1/0, 20 steps."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path(os.environ.get("TDC_PROJECT_ROOT", "/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master"))
PROTOCOL = Path(os.environ.get("TDC_PROTOCOL_ROOT", "/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714"))
CLASSES = Path(os.environ.get("TDC_CLASS_MANIFEST", "/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv"))
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_loss_and_probs, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g02-pilot-20261023-v2"
EPSILON = 8 / 255
ALPHA = 2 / 255
STEPS = 20


def stable_seed(model: str, relative: str, tradeoff: float) -> int:
    text = f"{PROTOCOL_ID}|{model}|{relative}|{tradeoff:g}|0"
    return int.from_bytes(hashlib.sha256(text.encode()).digest()[:4], "little")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def save_tensor(path: Path, tensor: torch.Tensor) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    torch.save(tensor.detach().cpu().to(torch.float32), temp)
    os.replace(temp, path)
    return sha256(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("csn_r101", "mvit_base_16x4"), required=True)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    gate = RUN / "results" / "G01" / args.model / "gradient_audit.json"
    if not gate.exists() or not json.loads(gate.read_text())["passed"]:
        raise RuntimeError(f"G01 gate not passed: {gate}")

    output = RUN / "results" / "G02" / "pilot" / args.model
    shards = output / "trajectory_shards"
    tensors = output / "selected_adv"
    output.mkdir(parents=True, exist_ok=True)
    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    calibration_scores = score_lr(pipeline, calibration, FEATURES)
    threshold = threshold_from_clean(calibration, calibration_scores)
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    z_threshold = math.log(threshold / (1 - threshold))
    class_names = read_class_names(CLASSES)
    manifest_path = PROTOCOL / "manifests" / f"k400_{args.model}_calibration_fixed20.csv"
    manifest = pd.read_csv(manifest_path).sort_values("relative_path").head(3)

    torch.manual_seed(20260714)
    torch.cuda.manual_seed_all(20260714)
    torch.backends.cudnn.benchmark = False
    load_started = time.perf_counter()
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters():
        parameter.requires_grad_(False)
    for parameter in clip_model.parameters():
        parameter.requires_grad_(False)
    text = build_text_features(clip_model, processor, class_names, device)
    detector = FullDetector(action_model, clip_model, processor, text, args.model, state)
    torch.cuda.synchronize(device)
    load_seconds = time.perf_counter() - load_started

    for source_rank, row in enumerate(manifest.itertuples(index=False), 1):
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        with torch.no_grad():
            clean_prob = action_probs(action_model, clean, args.model)
        clean_pred = int(clean_prob.argmax())
        for tradeoff in (1.0, 0.0):
            trajectory_id = hashlib.sha256(f"{args.model}|{row.relative_path}|{tradeoff:g}|0".encode()).hexdigest()[:20]
            shard_path = shards / f"{trajectory_id}.json"
            final_path = tensors / f"{trajectory_id}_step20.pt"
            if shard_path.exists() and final_path.exists():
                record = json.loads(shard_path.read_text())
                if record.get("complete") and record.get("protocol_id") == PROTOCOL_ID:
                    print(json.dumps({"reused": trajectory_id}), flush=True)
                    continue
            seed = stable_seed(args.model, row.relative_path, tradeoff)
            generator = torch.Generator(device=device).manual_seed(seed)
            delta = torch.empty_like(clean).uniform_(-EPSILON, EPSILON, generator=generator)
            delta = ((clean + delta).clamp(0, 1) - clean).detach()
            rows = []
            checkpoint_files = []

            torch.cuda.reset_peak_memory_stats(device)
            with torch.no_grad():
                initial = (clean + delta).clamp(0, 1)
                initial_features, initial_logit, initial_score, _, _ = detector.exact_forward(initial)
                initial_prob = action_probs(action_model, initial, args.model)
            rows.append({
                "step": 0, "classification_loss": float(-initial_prob[clean_pred].clamp_min(1e-12).log()),
                "detector_logit": float(initial_logit), "detector_score": float(initial_score),
                "attacked_pred": int(initial_prob.argmax()), "attack_success": int(initial_prob.argmax()) != clean_pred,
                "detector_evaded": float(initial_score) <= threshold,
                "measured_linf": float(delta.abs().max()), "gradient_seconds": 0.0, "score_seconds": 0.0,
            })
            for step in range(1, STEPS + 1):
                adv = (clean + delta).clamp(0, 1).detach().requires_grad_(True)
                gradient_started = time.perf_counter()
                classification_loss, p = action_loss_and_probs(action_model, adv, args.model, clean_pred)
                classification_gradient = torch.autograd.grad(classification_loss, adv)[0]
                if tradeoff:
                    _, detector_z, _, detector_gradient, _ = detector.logit_and_vjp_gradient(adv)
                    penalty_scale = torch.sigmoid(detector_z - z_threshold)
                    gradient = classification_gradient - tradeoff * penalty_scale * detector_gradient
                else:
                    gradient = classification_gradient
                torch.cuda.synchronize(device)
                gradient_seconds = time.perf_counter() - gradient_started
                delta = (delta + ALPHA * gradient.sign()).clamp(-EPSILON, EPSILON)
                delta = ((clean + delta).clamp(0, 1) - clean).detach()
                candidate = (clean + delta).clamp(0, 1)
                score_started = time.perf_counter()
                with torch.no_grad():
                    _, candidate_logit, candidate_score, _, _ = detector.exact_forward(candidate)
                    candidate_prob = action_probs(action_model, candidate, args.model)
                torch.cuda.synchronize(device)
                score_seconds = time.perf_counter() - score_started
                rows.append({
                    "step": step, "classification_loss": float(-candidate_prob[clean_pred].clamp_min(1e-12).log()),
                    "detector_logit": float(candidate_logit), "detector_score": float(candidate_score),
                    "attacked_pred": int(candidate_prob.argmax()), "attack_success": int(candidate_prob.argmax()) != clean_pred,
                    "detector_evaded": float(candidate_score) <= threshold,
                    "measured_linf": float(delta.abs().max()),
                    "gradient_seconds": gradient_seconds, "score_seconds": score_seconds,
                })
                if step in (10, 20):
                    checkpoint = tensors / f"{trajectory_id}_step{step}.pt"
                    checkpoint_files.append({"step": step, "path": str(checkpoint), "sha256": save_tensor(checkpoint, candidate)})
                print(json.dumps({"model": args.model, "source": source_rank, "lambda": tradeoff, "step": step, "score": float(candidate_score)}), flush=True)

            record = {
                "protocol_id": PROTOCOL_ID, "complete": True, "trajectory_id": trajectory_id,
                "action_model": args.model, "gpu_uuid": gpu_uuid, "source_rank": source_rank,
                "relative_path": row.relative_path, "video_path": row.path,
                "partition": "calibration", "tradeoff_lambda": tradeoff, "restart": 0,
                "seed": seed, "epsilon": EPSILON, "alpha": ALPHA, "steps": STEPS,
                "clean_pred": clean_pred, "clean_conf": float(clean_prob.max()),
                "threshold": threshold, "z_threshold": z_threshold,
                "peak_memory_bytes": torch.cuda.max_memory_allocated(device),
                "checkpoints": checkpoint_files, "trajectory": rows,
            }
            atomic_json(shard_path, record)

    records = [json.loads(path.read_text()) for path in sorted(shards.glob("*.json"))]
    if len(records) != 6 or any(not item.get("complete") for item in records):
        raise RuntimeError(f"incomplete pilot trajectories: {len(records)}/6")
    trajectory_rows = []
    tensor_rows = []
    for item in records:
        for row in item["trajectory"]:
            trajectory_rows.append({key: item[key] for key in (
                "protocol_id", "trajectory_id", "action_model", "gpu_uuid", "source_rank", "relative_path",
                "partition", "tradeoff_lambda", "restart", "seed", "epsilon", "alpha", "clean_pred", "threshold",
            )} | row)
        for checkpoint in item["checkpoints"]:
            tensor_rows.append({"trajectory_id": item["trajectory_id"], **checkpoint})
    trajectory_frame = pd.DataFrame(trajectory_rows)
    temp = output / "trajectory.csv.gz.tmp"
    trajectory_frame.to_csv(temp, index=False, compression="gzip")
    os.replace(temp, output / "trajectory.csv.gz")
    pd.DataFrame(tensor_rows).to_csv(output / "selected_adv" / "INDEX.csv", index=False)
    metrics = []
    final = trajectory_frame[trajectory_frame.step == STEPS]
    for tradeoff, group in final.groupby("tradeoff_lambda"):
        metrics.append({
            "protocol_id": PROTOCOL_ID, "action_model": args.model, "tradeoff_lambda": tradeoff,
            "n_sources": len(group), "attack_success_rate": group.attack_success.mean(),
            "joint_success_evasion_rate": (group.attack_success.astype(bool) & group.detector_evaded.astype(bool)).mean(),
            "mean_detector_score": group.detector_score.mean(),
            "median_gradient_seconds_per_step": trajectory_frame[(trajectory_frame.step > 0) & (trajectory_frame.tradeoff_lambda == tradeoff)].gradient_seconds.median(),
            "median_score_seconds_per_step": trajectory_frame[(trajectory_frame.step > 0) & (trajectory_frame.tradeoff_lambda == tradeoff)].score_seconds.median(),
            "max_peak_memory_bytes": max(item["peak_memory_bytes"] for item in records if item["tradeoff_lambda"] == tradeoff),
        })
    pd.DataFrame(metrics).to_csv(output / "metrics.csv", index=False)
    atomic_json(output / "validation.json", {
        "protocol_id": PROTOCOL_ID, "passed": True, "expected_trajectories": 6,
        "observed_trajectories": len(records), "expected_rows": 126,
        "observed_rows": len(trajectory_frame), "unique_keys": not trajectory_frame.duplicated(["trajectory_id", "step"]).any(),
        "finite": bool(np.isfinite(trajectory_frame[["classification_loss", "detector_logit", "detector_score", "measured_linf"]]).all().all()),
        "linf_passed": bool((trajectory_frame.measured_linf <= EPSILON + 1e-7).all()),
        "partition": "calibration only", "test_touched": False,
        "model_load_seconds": load_seconds, "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"model": args.model, "G02_pilot_complete": True, "output": str(output)}), flush=True)


if __name__ == "__main__":
    main()
