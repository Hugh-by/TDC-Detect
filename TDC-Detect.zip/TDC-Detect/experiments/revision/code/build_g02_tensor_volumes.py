#!/usr/bin/env python3
"""Create independently extractable <=2 GiB lossless G02 tensor ZIP volumes."""
import csv, hashlib, io, json, os, zipfile
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

RUN=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01'); OUT=RUN/'exports/g02_tensor_volumes'; OUT.mkdir(parents=True,exist_ok=True)
MAX_RAW=1750*1024*1024
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
index=pd.read_csv(RUN/'results/G02/full/selected_adv_index.csv').sort_values(['action_model','mode','source_rank'])
items=[]
for r in index.itertuples(index=False):
 p=Path(r.path)
 if not p.is_file() or p.stat().st_size!=int(r.bytes) or sha(p)!=r.sha256: raise SystemExit(f'tensor gate failed: {p}')
 items.append({'action_model':r.action_model,'mode':r.mode,'source_rank':int(r.source_rank),'relative_path':r.relative_path,'source_path':p,'bytes':p.stat().st_size,'sha256':r.sha256})
groups=[]; current=[]; size=0
for item in items:
 if current and size+item['bytes']>MAX_RAW: groups.append(current); current=[]; size=0
 current.append(item); size+=item['bytes']
if current: groups.append(current)
volume_rows=[]
for number,group in enumerate(groups,1):
 name=f'G02_SELECTED_ADV_VOLUME_{number:02d}.zip'; target=OUT/name; temp=target.with_suffix('.zip.tmp')
 buffer=io.StringIO(); writer=csv.DictWriter(buffer,fieldnames=['action_model','mode','source_rank','relative_path','member','bytes','sha256']); writer.writeheader()
 with zipfile.ZipFile(temp,'w',compression=zipfile.ZIP_STORED,allowZip64=True) as z:
  for item in group:
   member=f"selected_adv/{item['action_model']}/{item['mode']}/{item['source_path'].name}"
   z.write(item['source_path'],member)
   writer.writerow({**{k:item[k] for k in ('action_model','mode','source_rank','relative_path','bytes','sha256')},'member':member})
  z.writestr('VOLUME_INDEX.csv',buffer.getvalue())
 os.replace(temp,target)
 with zipfile.ZipFile(target) as z:
  bad=z.testzip()
  if bad is not None: raise SystemExit(f'zip CRC failure: {target}: {bad}')
 if target.stat().st_size>2*1024**3: raise SystemExit(f'volume exceeds 2 GiB: {target}')
 volume_rows.append({'volume':name,'path':str(target),'bytes':target.stat().st_size,'sha256':sha(target),'tensor_count':len(group),'raw_tensor_bytes':sum(x['bytes'] for x in group),'maximum_bytes':2*1024**3,'independently_extractable':True})
pd.DataFrame(volume_rows).to_csv(OUT/'VOLUME_INDEX.csv',index=False)
manifest={'protocol_id':'tdc-r3r5-g02-tensor-volumes-20261026-v1','generated_at':datetime.now(timezone.utc).isoformat(),'passed':sum(x['tensor_count'] for x in volume_rows)==400 and all(x['bytes']<=2*1024**3 for x in volume_rows),'tensor_count':400,'volume_count':len(volume_rows),'source_index':'results/G02/full/selected_adv_index.csv','volumes':volume_rows}
(OUT/'validation.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
if not manifest['passed']: raise SystemExit(manifest)
