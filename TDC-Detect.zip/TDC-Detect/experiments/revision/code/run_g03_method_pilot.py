#!/usr/bin/env python3
"""One isolated G03 timing worker (one model, one method, boundaries A/B)."""

from __future__ import annotations

import argparse
import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path: sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.tsc_action_model import get_action_probs
from TSC_Detect.tsc_features import compute_tsc_features, local_window_features, symmetric_kl
from TSC_Detect.tsc_sampling import build_frozen_global_views, build_frozen_local_views
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES, get_vlm_context_probs
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g03-pilot-20261023-v1"
METHODS = ("action_single", "e14_action_shift9", "action_stats12", "discrepancy9", "full_g5l4", "light_g3l2", "single_discrepancy")
ACTION_FEATURES = FEATURES[:12]


def state_score(features: dict[str, float], state: dict) -> float:
    order = state["feature_order"]
    vector = np.asarray([features[name] for name in order], dtype=np.float64)
    z = np.sum((vector - np.asarray(state["scaler_mean"])) / np.asarray(state["scaler_scale"]) * np.asarray(state["lr_coef"])) + float(state["lr_intercept"])
    return float(1 / (1 + np.exp(-np.clip(z, -700, 700))))


def pipeline_state(pipeline, order: list[str]) -> dict:
    scaler, lr = pipeline.named_steps["scaler"], pipeline.named_steps["logistic"]
    return {"feature_order": order, "scaler_mean": scaler.mean_.tolist(), "scaler_scale": scaler.scale_.tolist(), "lr_coef": lr.coef_[0].tolist(), "lr_intercept": float(lr.intercept_[0])}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("csn_r101", "mvit_base_16x4"), required=True)
    parser.add_argument("--method", choices=METHODS, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--videos", type=int, default=20)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--warmups", type=int, default=10)
    args = parser.parse_args()
    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results" / "G03" / "pilot" / "shards" / f"{args.model}_{args.method}.csv.gz"
    output.parent.mkdir(parents=True, exist_ok=True)
    expected = args.videos * args.repeats * 2
    if output.exists():
        old = pd.read_csv(output)
        if len(old) == expected and not old.duplicated(["source_id", "repeat", "timing_boundary"]).any():
            print(json.dumps({"reused": str(output)})); return

    classes = read_class_names(CLASSES)
    manifest = pd.read_csv(PROTOCOL / "manifests" / f"k400_{args.model}_test_fixed100.csv").sort_values("relative_path").head(args.videos)
    calibration = load_e1("k400", args.model, "calibration")
    full_state = pipeline_state(fit_lr(calibration, FEATURES), FEATURES)
    action_state = pipeline_state(fit_lr(calibration, ACTION_FEATURES), ACTION_FEATURES)
    light_path = RUN / "models" / "C01" / args.model / "g3_l2" / "fold_0.json"
    light_raw = json.loads(light_path.read_text())
    light_state = {
        "feature_order": light_raw["feature_order"],
        "scaler_mean": light_raw["scaler"]["mean"],
        "scaler_scale": light_raw["scaler"]["scale"],
        "lr_coef": light_raw["logistic"]["coef"],
        "lr_intercept": light_raw["logistic"]["intercept"],
    }
    action_model, clip_model, processor = load_real_models(device, args.model)
    action_parameter_count = sum(parameter.numel() for parameter in action_model.parameters())
    clip_parameter_count = sum(parameter.numel() for parameter in clip_model.parameters())
    class Parameters:
        pass
    prepared = []
    for row in manifest.itertuples(index=False):
        rgb = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach().cpu().numpy().astype(np.float32)
        prepared.append((row.relative_path, row.path, rgb))

    def infer(rgb: np.ndarray) -> tuple[float, int, int]:
        global_views = build_frozen_global_views(rgb)
        local_views = build_frozen_local_views(rgb)
        all_views = {**global_views, **local_views}
        if args.method == "action_single":
            pa, _, confidence = get_action_probs(action_model, global_views["original"], device)
            return confidence, 1, 0
        if args.method == "single_discrepancy":
            view = global_views["original"]
            pa, _, _ = get_action_probs(action_model, view, device)
            pc = get_vlm_context_probs(clip_model, processor, view, classes, device, prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8)
            return symmetric_kl(pa, pc), 1, 1

        selected_global = list(global_views.items()) if args.method != "light_g3l2" else list(global_views.items())[:3]
        selected_local = list(local_views.items()) if args.method != "light_g3l2" else list(local_views.items())[:2]
        selected = dict(selected_global + selected_local)
        need_clip = args.method in ("discrepancy9", "full_g5l4", "light_g3_l2", "light_g3l2")
        action, clip = {}, {}
        for name, view in selected.items():
            pa, _, _ = get_action_probs(action_model, view, device); action[name] = pa
            if need_clip:
                clip[name] = get_vlm_context_probs(clip_model, processor, view, classes, device, prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8)
        if args.method == "e14_action_shift9":
            score = float(np.mean([symmetric_kl(action["original"], value) for value in action.values()]))
            return score, len(selected), 0
        if args.method == "discrepancy9":
            score = float(np.mean([symmetric_kl(action[name], clip[name]) for name in selected]))
            return score, len(selected), len(selected)
        global_action = {name: action[name] for name, _ in selected_global}
        local_action = {name: action[name] for name, _ in selected_local}
        if args.method == "action_stats12":
            # Clip values are immaterial for the first 12 action-only fields.
            dummy_global = {name: value for name, value in global_action.items()}
            dummy_local = {name: value for name, value in local_action.items()}
            features = compute_tsc_features(global_action, dummy_global, primary_view="original")
            features.update(local_window_features(local_action, dummy_local, reference_action_probs=global_action["original"]))
            return state_score(features, action_state), len(selected), 0
        global_clip = {name: clip[name] for name, _ in selected_global}
        local_clip = {name: clip[name] for name, _ in selected_local}
        features = compute_tsc_features(global_action, global_clip, primary_view="original")
        features.update(local_window_features(local_action, local_clip, reference_action_probs=global_action["original"]))
        state = full_state if args.method == "full_g5l4" else light_state
        return state_score(features, state), len(selected), len(selected)

    for index in range(args.warmups): infer(prepared[index % len(prepared)][2])
    torch.cuda.synchronize(device)
    rows = []
    for repeat in range(args.repeats):
        boundaries = ("A_predecoded", "B_path_to_score") if repeat % 2 == 0 else ("B_path_to_score", "A_predecoded")
        for source_index, (relative_path, path, rgb) in enumerate(prepared):
            for boundary in boundaries:
                torch.cuda.reset_peak_memory_stats(device); torch.cuda.synchronize(device)
                started = time.perf_counter()
                current = rgb
                if boundary == "B_path_to_score":
                    current = prepare_attack_frames(load_frames(Path(path)), args.model, device).detach().cpu().numpy().astype(np.float32)
                score, action_calls, clip_calls = infer(current)
                torch.cuda.synchronize(device)
                rows.append({
                    "protocol_id": PROTOCOL_ID, "dataset": "k400", "model": args.model, "method": args.method,
                    "source_id": relative_path, "repeat": repeat, "timing_boundary": boundary,
                    "seconds": time.perf_counter() - started, "score": score,
                    "peak_allocated": torch.cuda.max_memory_allocated(device), "peak_reserved": torch.cuda.max_memory_reserved(device),
                    "resident_memory": torch.cuda.memory_allocated(device), "gpu_uuid": gpu_uuid,
                    "warmups": args.warmups, "logical_action_view_calls": action_calls,
                    "logical_clip_view_calls": clip_calls, "process_isolation": "one model-method worker",
                    "frozen_action_parameters": action_parameter_count,
                    "frozen_clip_parameters": clip_parameter_count if clip_calls else 0,
                    "readout_trainable_parameters": 13 if args.method == "action_stats12" else (22 if args.method in ("full_g5l4", "light_g3l2") else 0),
                })
        print(json.dumps({"model": args.model, "method": args.method, "repeat": repeat + 1}), flush=True)
    frame = pd.DataFrame(rows)
    if len(frame) != expected or frame.duplicated(["source_id", "repeat", "timing_boundary"]).any(): raise RuntimeError("G03 row gate failed")
    temp = output.with_suffix(output.suffix + ".tmp")
    frame.to_csv(temp, index=False, compression="gzip"); os.replace(temp, output)
    definition = {
        "action_single": "original action inference only; computational reference, no detector AUC point",
        "e14_action_shift9": "five global plus four local action responses; fixed mean symmetric-KL shift",
        "action_stats12": "same nine action responses; 12 historical action features plus independently fitted LR",
        "discrepancy9": "nine action and nine CLIP responses; fixed mean paired semantic discrepancy",
        "full_g5l4": "five global plus four local action/CLIP responses; full 21-D reconstructed LR",
        "light_g3l2": "first three frozen globals plus first two frozen locals; C01 independently fitted g3_l2 fold-0 LR used only as timing adapter",
        "single_discrepancy": "one original action and one original CLIP response; fixed symmetric KL",
    }
    (output.parent / f"{args.model}_{args.method}.definition.json").write_text(json.dumps({"method": args.method, "definition": definition[args.method], "gpu_uuid": gpu_uuid}, indent=2) + "\n")
    print(json.dumps({"complete": str(output)}), flush=True)


if __name__ == "__main__": main()
