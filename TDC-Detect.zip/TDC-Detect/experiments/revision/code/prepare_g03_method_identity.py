#!/usr/bin/env python3
"""Freeze E14 timing-adapter identities and verify scores from saved probe responses."""
import hashlib, json, os
from pathlib import Path
import numpy as np
import pandas as pd
from safetensors import safe_open

RUN=Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01")
E14=Path("/root/autodl-tmp/results_supp_20260817/E14")
PROTOCOL="tdc-r3r5-g03-method-identity-20261025-v2"
MAP={
 "single_discrepancy_lr":"Single-view discrepancy-LR",
 "discrepancy9_lr":"Nine-view discrepancy-LR",
 "e14_action_shift9_lr":"Nine-view action-shift-LR",
}
def write_json(path,value):
 path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+".tmp"); tmp.write_text(json.dumps(value,indent=2,sort_keys=True)+"\n"); os.replace(tmp,path)
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def score(x,state):
 z=np.sum((np.asarray(x,float)-np.asarray(state["scaler_mean"]))/np.asarray(state["scaler_scale"])*np.asarray(state["lr_coef"]))+float(state["lr_intercept"])
 return float(1/(1+np.exp(-np.clip(z,-700,700))))

parameters=json.loads((E14/"fitted_detector_parameters.json").read_text())
saved=pd.read_csv(E14/"matched_budget_scores.csv",float_precision="round_trip")
state_dir=RUN/"models/G03_method_identity_v2"; state_dir.mkdir(parents=True,exist_ok=True)
state_rows=[]; check_rows=[]
for condition, methods in sorted(parameters.items()):
 dataset,model=condition.split("/")
 condition_scores=saved[(saved.dataset==dataset)&(saved.model==model)]
 for method_id,e14_name in MAP.items():
  raw=methods[e14_name]
  thresholds=condition_scores[f"threshold__{e14_name}"].drop_duplicates().to_numpy(float)
  if len(thresholds)!=1: raise RuntimeError(f"threshold identity failed: {condition}/{e14_name}")
  state={"protocol_id":PROTOCOL,"method_id":method_id,"source_method":e14_name,"dataset":dataset,"model":model,"feature_order":raw["features"],"scaler_mean":raw["scaler_mean"],"scaler_scale":raw["scaler_scale"],"lr_coef":raw["coefficients"],"lr_intercept":raw["intercept"],"threshold":float(thresholds[0]),"fit_source":str(E14/"fitted_detector_parameters.json"),"utility_source":str(E14/"matched_budget_scores.csv")}
  path=state_dir/f"{dataset}_{model}_{method_id}.json"; write_json(path,state)
  state_rows.append({"protocol_id":PROTOCOL,"dataset":dataset,"model":model,"method_id":method_id,"source_method":e14_name,"feature_order":";".join(raw["features"]),"state_path":str(path),"state_sha256":digest(path),"threshold":float(thresholds[0])})
 cache=E14/"probe_cache"/f"{dataset}_{model}_test"
 for tensor_path in sorted(cache.glob("*.safetensors"))[:5]:
  with safe_open(str(tensor_path),framework="np") as handle:
   meta=json.loads(handle.metadata()["rows_json"]); discrepancy=handle.get_tensor("action_semantic_D"); shift=handle.get_tensor("action_shift")
  for i,row in enumerate(meta):
   key=(condition_scores.pair_id.astype(str)==str(row["pair_id"]))&(condition_scores.attack.astype(str)==str(row["attack"]))
   matched=condition_scores.loc[key]
   if len(matched)!=1: raise RuntimeError(f"score lookup failed: {condition}/{row}")
   vectors={"single_discrepancy_lr":discrepancy[i,:1],"discrepancy9_lr":discrepancy[i,:9],"e14_action_shift9_lr":shift[i,1:9]}
   for method_id,e14_name in MAP.items():
    state=json.loads((state_dir/f"{dataset}_{model}_{method_id}.json").read_text()); actual=score(vectors[method_id],state); expected=float(matched.iloc[0][e14_name]); error=abs(actual-expected)
    check_rows.append({"protocol_id":PROTOCOL,"dataset":dataset,"model":model,"pair_id":row["pair_id"],"attack":row["attack"],"method_id":method_id,"expected_e14_score":expected,"adapter_score":actual,"absolute_error":error,"tolerance":1e-7,"passed":error<=1e-7,"cache_path":str(tensor_path)})
states=pd.DataFrame(state_rows); checks=pd.DataFrame(check_rows)
states.to_csv(RUN/"results/G03/method_identity_states.csv",index=False); checks.to_csv(RUN/"results/G03/method_identity_check.csv",index=False)
write_json(RUN/"results/G03/method_identity_check.json",{"protocol_id":PROTOCOL,"passed":bool(checks.passed.all()),"rows":len(checks),"conditions":8,"methods":list(MAP),"tolerance":1e-7,"maximum_absolute_error":float(checks.absolute_error.max()),"state_count":len(states),"source_parameter_sha256":digest(E14/"fitted_detector_parameters.json"),"source_score_sha256":digest(E14/"matched_budget_scores.csv")})
write_json(RUN/"protocols/G03_METHOD_IDENTITY_GATE.json",{"protocol_id":PROTOCOL,"passed":bool(checks.passed.all()),"identity_check":"results/G03/method_identity_check.json","state_index":"results/G03/method_identity_states.csv","gpu_launch_authorized_by_gate":bool(checks.passed.all()),"note":"This gate covers the three previously misidentified E14 LR adapters; full timing code must load these states and preserve separate fixed-score IDs if retained."})
