#!/usr/bin/env python3
"""Freeze and validate the four K400 detector states used by corrected G05."""
import hashlib, json, sys
from pathlib import Path
import numpy as np

RUN = Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01")
sys.path.insert(0, str(RUN / "code"))
from cpu_common import BASE, FEATURES, MODELS, fit_lr, load_e1, model_state, score_lr, threshold_from_clean, write_json

out = RUN / "protocols/G05_v2_frozen_states"
out.mkdir(parents=True, exist_ok=True)
rows = []
for model in MODELS:
    source = BASE / "E1" / f"k400_{model}_calibration.csv"
    frame = load_e1("k400", model, "calibration")
    pipeline = fit_lr(frame, FEATURES)
    scores = score_lr(pipeline, frame, FEATURES)
    threshold = threshold_from_clean(frame, scores)
    state = model_state(pipeline, FEATURES, threshold)
    state.update({
        "protocol_id": "tdc-r3r5-g05-corrected-20261025-v2",
        "dataset": "k400", "action_model": model,
        "fit_source": str(source), "fit_source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "fit_rows": len(frame), "fit_partition": "calibration",
    })
    path = out / f"{model}.json"
    write_json(path, state)
    loaded = json.loads(path.read_text())
    x = frame[FEATURES].to_numpy(float)
    z = (x - np.asarray(loaded["scaler_mean"])) / np.asarray(loaded["scaler_scale"])
    logits = z @ np.asarray(loaded["lr_coef"]) + float(loaded["lr_intercept"])
    restored = 1.0 / (1.0 + np.exp(-logits))
    rows.append({
        "model": model, "state_path": str(path),
        "state_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "calibration_sha256": state["fit_source_sha256"],
        "max_score_roundtrip_error": float(np.max(np.abs(restored - scores))),
        "threshold": threshold, "passed": bool(np.max(np.abs(restored - scores)) <= 1e-12),
    })
write_json(out / "validation.json", {
    "protocol_id": "tdc-r3r5-g05-corrected-20261025-v2",
    "passed": all(row["passed"] for row in rows), "tolerance": 1e-12, "states": rows,
})
