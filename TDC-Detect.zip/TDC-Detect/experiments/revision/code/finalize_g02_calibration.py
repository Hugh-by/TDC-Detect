#!/usr/bin/env python3
"""Freeze G02 lambda from completed calibration shards without touching test."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROTOCOL_ID = "tdc-r3r5-g02-full-option-b-20261023-v1"


def atomic_json(path: Path, value: object) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("csn_r101", "mvit_base_16x4"), required=True)
    args = parser.parse_args()
    output = RUN / "results/G02/full" / args.model
    statuses = [json.loads((output / "worker_status" / f"calibration_{i}.json").read_text()) for i in range(2)]
    if not all(item.get("complete") and item.get("protocol_id") == PROTOCOL_ID for item in statuses):
        raise RuntimeError("calibration workers are not complete")
    records = []
    for path in sorted((output / "trajectory_shards").glob("*.json")):
        item = json.loads(path.read_text())
        if item.get("protocol_id") == PROTOCOL_ID and item.get("partition") == "calibration":
            records.append(item)
    expected = 20 * 3 * 3
    if len(records) != expected:
        raise RuntimeError(f"calibration trajectories {len(records)}/{expected}")
    rows = []
    for item in records:
        for row in item["checkpoint_rows"]:
            rows.append({key: item[key] for key in ("trajectory_id", "action_model", "partition", "mode", "source_rank", "relative_path", "tradeoff_lambda", "restart", "seed", "threshold")} | {key: value for key, value in row.items() if key != "features"})
    frame = pd.DataFrame(rows)
    frame.to_csv(output / "tuning_candidates.csv.gz", index=False, compression="gzip")
    selected = frame.sort_values(["attack_success", "detector_score"], ascending=[False, True]).groupby(["tradeoff_lambda", "source_rank"], as_index=False).first()
    selected.to_csv(output / "tuning_selected_by_source.csv", index=False)
    metrics = selected.groupby("tradeoff_lambda", as_index=False).agg(
        joint_success_evasion_rate=("joint_success_evasion", "mean"),
        attack_success_rate=("attack_success", "mean"),
        successful_mean_detector_score=("detector_score", lambda x: float(np.mean(x[selected.loc[x.index, "attack_success"].astype(bool)])) if selected.loc[x.index, "attack_success"].any() else float("inf")),
        mean_detector_score=("detector_score", "mean"),
    )
    metrics = metrics.sort_values(["joint_success_evasion_rate", "attack_success_rate", "successful_mean_detector_score", "tradeoff_lambda"], ascending=[False, False, True, True])
    chosen = float(metrics.iloc[0].tradeoff_lambda)
    metrics.to_csv(output / "lambda_metrics.csv", index=False)
    atomic_json(output / "lambda_selection.json", {
        "protocol_id": PROTOCOL_ID, "complete": True, "action_model": args.model,
        "selected_lambda": chosen,
        "selection_rule": "joint success/evasion desc, ASR desc, successful mean detector score asc, lambda asc",
        "calibration_sources": 20, "restarts": 3, "test_touched": False,
        "ranked_metrics": metrics.replace([np.inf, -np.inf], None).to_dict(orient="records"),
    })
    print(json.dumps({"model": args.model, "selected_lambda": chosen, "calibration_trajectories": len(records)}))


if __name__ == "__main__":
    main()
