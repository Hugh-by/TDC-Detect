#!/usr/bin/env python3
"""C04, C05-B, and C06 CPU analyses sharing one response-cache read per condition."""

from __future__ import annotations

import argparse
import gc
import json
import os
import resource
import shutil
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.exceptions import ConvergenceWarning
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from cache_features import (
    adjacent_difference_from_sequences, load_probability_cache, permutation_from_sequences,
    permutation_manifest, rebuild_distance_features, response_sequences,
)
from cpu_common import (
    ATTACKS, DATASETS, FEATURES, MODELS, RUN, SEED, bootstrap_macro, bootstrap_payload,
    condition, evaluate_methods, fit_lr, load_e1, metric, model_state, score_lr,
    threshold_from_clean, write_csv, write_csv_gz, write_json,
)

PROTOCOL = "tdc-r3r5-cache-cpu-20261022-v1"
DISTANCES = (
    ("symmetric_kl_eps1e-8", "symmetric_kl", 1e-8),
    ("symmetric_kl_eps1e-6", "symmetric_kl", 1e-6),
    ("symmetric_kl_eps1e-10", "symmetric_kl", 1e-10),
    ("js_eps1e-8", "js", 1e-8),
)


def sigmoid(logits: np.ndarray) -> np.ndarray:
    out = np.empty_like(logits, dtype=np.float64)
    positive = logits >= 0
    out[positive] = 1 / (1 + np.exp(-logits[positive]))
    exp = np.exp(logits[~positive]); out[~positive] = exp / (1 + exp)
    return out


def lr_array(x_train: np.ndarray, y_train: np.ndarray, x_test: np.ndarray,
             scale: bool = True) -> tuple[np.ndarray, np.ndarray, dict, object, object]:
    scaler = StandardScaler() if scale else None
    if scaler is not None:
        transformed_train = scaler.fit_transform(x_train)
        transformed_test = scaler.transform(x_test)
    else:
        transformed_train, transformed_test = x_train, x_test
    lr = LogisticRegression(C=1.0, l1_ratio=0.0, class_weight="balanced", max_iter=5000,
                            solver="lbfgs", random_state=SEED)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always"); lr.fit(transformed_train, y_train)
    convergence = [str(w.message) for w in caught if issubclass(w.category, ConvergenceWarning)]
    if convergence or int(lr.n_iter_[0]) >= 5000:
        raise RuntimeError(f"LR convergence failure: {convergence}, n_iter={lr.n_iter_[0]}")
    train_score = lr.predict_proba(transformed_train)[:, 1]
    test_score = lr.predict_proba(transformed_test)[:, 1]
    info = {"n_iter": int(lr.n_iter_[0]), "warnings": [str(w.message) for w in caught],
            "train_shape": list(x_train.shape), "test_shape": list(x_test.shape)}
    return train_score, test_score, info, scaler, lr


def make_raw_feature_memmap(path: Path, action: np.ndarray, clip: np.ndarray,
                            chunk: int = 128) -> np.memmap:
    """Materialize action-then-CLIP 7200D rows without an in-memory concatenate."""
    values = np.lib.format.open_memmap(path, mode="w+", dtype=np.float32,
                                       shape=(len(action), 7200))
    for start in range(0, len(action), chunk):
        end = min(start + chunk, len(action))
        values[start:end, :3600] = action[start:end].reshape(end - start, 3600)
        values[start:end, 3600:] = clip[start:end].reshape(end - start, 3600)
    values.flush()
    return values


def standardize_memmap(values: np.memmap, scaler: StandardScaler, chunk: int = 128) -> None:
    """Apply a fitted scaler in bounded-memory chunks and retain float32 storage."""
    mean = scaler.mean_.astype(np.float32)
    scale = scaler.scale_.astype(np.float32)
    for start in range(0, len(values), chunk):
        end = min(start + chunk, len(values))
        block = np.asarray(values[start:end])
        np.subtract(block, mean, out=block)
        np.divide(block, scale, out=block)
    values.flush()


def close_memmap(values: np.ndarray) -> None:
    if isinstance(values, np.memmap):
        values.flush()
        values._mmap.close()


def drop_file_cache(path: Path) -> None:
    """Ask Linux to evict clean scratch pages; critical under the 2 GiB cgroup."""
    if hasattr(os, "posix_fadvise") and hasattr(os, "POSIX_FADV_DONTNEED"):
        with path.open("rb") as handle:
            os.posix_fadvise(handle.fileno(), 0, 0, os.POSIX_FADV_DONTNEED)


def stage(condition_id: str, name: str, started: float) -> None:
    print(json.dumps({"condition": condition_id, "stage": name,
                      "elapsed_seconds": time.perf_counter() - started,
                      "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}), flush=True)


def output_base(test: pd.DataFrame) -> pd.DataFrame:
    frame = test[["dataset", "action_model", "partition", "pair_id", "relative_path", "attack",
                  "is_adv", "attack_success"]].copy().rename(columns={"action_model": "model"})
    frame.insert(0, "run_id", PROTOCOL)
    frame["source_id"] = frame.relative_path.astype(str)
    return frame


def long_scores(test: pd.DataFrame, methods: dict[str, np.ndarray], thresholds: dict[str, float],
                task_id: str) -> pd.DataFrame:
    parts = []
    for method, values in methods.items():
        frame = output_base(test)
        frame["task_id"] = task_id; frame["method"] = method; frame["config"] = "NA"
        frame["score"] = np.asarray(values, float); frame["score_domain"] = "probability"
        frame["threshold"] = thresholds[method]
        frame["predicted_adv"] = (frame.score > thresholds[method]).astype(int)
        parts.append(frame)
    return pd.concat(parts, ignore_index=True)


def calculate_metrics(test: pd.DataFrame, values: np.ndarray, threshold: float,
                      method: str, task: str, settings: tuple[str, ...] = ("full",)) -> list[dict]:
    lookup = pd.Series(values, index=pd.MultiIndex.from_arrays([test.pair_id.astype(str), test.attack.astype(str)]))
    rows = []
    for attack in (*ATTACKS, "pooled"):
        for setting in settings:
            selected = condition(test, attack, setting)
            scores = lookup.loc[list(zip(selected.pair_id.astype(str), selected.attack.astype(str)))].to_numpy(float)
            stats = metric(selected.is_adv.to_numpy(int), scores, threshold)
            stats["n_sources"] = int(selected.relative_path.nunique())
            rows.append({"protocol_id": PROTOCOL, "task_id": task, "evaluation_protocol": "independent_calibration_test",
                         "dataset": str(test.dataset.iloc[0]), "model": str(test.action_model.iloc[0]),
                         "method": method, "config": "NA", "attack": attack, "setting": setting,
                         "threshold": threshold, **stats})
    return rows


def save_c04_state(condition_id: str, raw_scaler, raw_lr, pca_scaler, pca, pca_lr,
                   thresholds: dict, full_state: dict) -> tuple[dict, float]:
    directory = RUN / "models/C04"; directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{condition_id}.npz"
    temp = directory / f".{condition_id}.tmp.npz"
    np.savez_compressed(
        temp,
        raw_scaler_mean=raw_scaler.mean_, raw_scaler_scale=raw_scaler.scale_, raw_lr_coef=raw_lr.coef_[0],
        raw_lr_intercept=raw_lr.intercept_, pca_scaler_mean=pca_scaler.mean_, pca_scaler_scale=pca_scaler.scale_,
        pca_mean=pca.mean_, pca_components=pca.components_, pca_explained_variance=pca.explained_variance_,
        pca_explained_variance_ratio=pca.explained_variance_ratio_, pca_lr_coef=pca_lr.coef_[0],
        pca_lr_intercept=pca_lr.intercept_, thresholds=np.asarray([thresholds["raw_probs7200_lr"],
        thresholds["raw_probs_pca21_lr"], thresholds["full21_lr"]]),
    )
    os.replace(temp, path)
    metadata = {
        "protocol_id": PROTOCOL, "task_id": "C04", "condition": condition_id,
        "feature_layout": "action_probs views 0..8/classes 0..399 then clip_probs views 0..8/classes 0..399",
        "raw_dtype": "float32", "fit_dtype_observed": str(raw_scaler.mean_.dtype),
        "raw_lr": {"n_iter": int(raw_lr.n_iter_[0]), "C": 1.0, "l1_ratio": 0.0, "solver": "lbfgs"},
        "pca": {"n_components": 21, "svd_solver": "randomized", "random_state": SEED,
                "iterated_power": 4, "whiten": False, "post_pca_scaler": False,
                "explained_variance_ratio_sum": float(pca.explained_variance_ratio_.sum())},
        "pca_lr": {"n_iter": int(pca_lr.n_iter_[0]), "C": 1.0, "l1_ratio": 0.0, "solver": "lbfgs"},
        "thresholds": thresholds, "full21_state": full_state, "array_state": str(path.relative_to(RUN)),
    }
    write_json(directory / f"{condition_id}.json", metadata)
    return metadata, path.stat().st_size


def process_condition(dataset: str, model: str) -> dict:
    condition_id = f"{dataset}_{model}"
    marker = RUN / "logs/cache_task_conditions" / f"{condition_id}.json"
    if marker.exists():
        prior = json.loads(marker.read_text())
        if prior.get("status") == "complete" and all((RUN / path).exists() for path in prior["result_shards"]):
            print(json.dumps({"reused_condition": condition_id}), flush=True)
            return prior
    marker.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    scratch = RUN / "scratch/cache_cpu" / condition_id
    if scratch.exists():
        shutil.rmtree(scratch)
    scratch.mkdir(parents=True, exist_ok=True)
    train, test = load_e1(dataset, model, "calibration"), load_e1(dataset, model, "test")
    action_train, clip_train = load_probability_cache(train, dataset, model, "calibration", scratch)
    action_test, clip_test = load_probability_cache(test, dataset, model, "test", scratch)
    stage(condition_id, "probability_cache_loaded", started)
    y_train = train.is_adv.to_numpy(int)

    full_fit = fit_lr(train, FEATURES)
    full_train = score_lr(full_fit, train, FEATURES); full_test = score_lr(full_fit, test, FEATURES)
    full_threshold = threshold_from_clean(train, full_train)
    full_state = model_state(full_fit, FEATURES, full_threshold)

    # C04: fixed raw 7200 probabilities and PCA21 readouts.
    x_train = make_raw_feature_memmap(scratch / "calibration_raw7200.npy", action_train, clip_train)
    probability_paths = [scratch / f"{split}_{branch}.npy"
                         for split in ("calibration", "test") for branch in ("action", "clip")]
    for values in (action_train, clip_train, action_test, clip_test):
        close_memmap(values)
    del action_train, clip_train, action_test, clip_test
    gc.collect()
    for path in probability_paths:
        drop_file_cache(path)
    stage(condition_id, "probability_maps_parked", started)
    raw_scaler = StandardScaler(copy=False).fit(x_train)
    standardize_memmap(x_train, raw_scaler)
    stage(condition_id, "raw7200_train_standardized", started)
    raw_train, _, raw_info, _, raw_lr = lr_array(x_train, y_train, x_train, scale=False)
    raw_threshold = threshold_from_clean(train, raw_train)
    stage(condition_id, "raw7200_lr_fitted", started)
    # Independently fitting the PCA-path StandardScaler would produce the same
    # deterministic state on the same calibration rows. Reuse that state and its
    # standardized memmap to stay below the 2 GiB container limit.
    pca_scaler = raw_scaler
    pca = PCA(n_components=21, svd_solver="randomized", random_state=SEED, iterated_power=4,
              whiten=False, copy=False)
    pca_train = pca.fit_transform(x_train)
    stage(condition_id, "pca21_train_projected", started)
    pca_train_score, _, pca_info, _, pca_lr = lr_array(pca_train, y_train, pca_train, scale=False)
    pca_threshold = threshold_from_clean(train, pca_train_score)
    close_memmap(x_train)
    del x_train, pca_train
    gc.collect()
    train_raw_path = scratch / "calibration_raw7200.npy"
    drop_file_cache(train_raw_path); train_raw_path.unlink(missing_ok=True)

    # Materialize and score test only after training objects are fixed, so at most
    # one 7200D matrix is resident at a time.
    action_test_for_raw = np.load(scratch / "test_action.npy", mmap_mode="r")
    clip_test_for_raw = np.load(scratch / "test_clip.npy", mmap_mode="r")
    x_test = make_raw_feature_memmap(scratch / "test_raw7200.npy", action_test_for_raw, clip_test_for_raw)
    close_memmap(action_test_for_raw); close_memmap(clip_test_for_raw)
    del action_test_for_raw, clip_test_for_raw
    drop_file_cache(scratch / "test_action.npy"); drop_file_cache(scratch / "test_clip.npy")
    standardize_memmap(x_test, raw_scaler)
    raw_test = raw_lr.predict_proba(x_test)[:, 1]
    pca_test = pca.transform(x_test)
    pca_test_score = pca_lr.predict_proba(pca_test)[:, 1]
    stage(condition_id, "raw7200_and_pca21_test_scored", started)
    c04_methods = {"raw_probs7200_lr": raw_test, "raw_probs_pca21_lr": pca_test_score, "full21_lr": full_test}
    c04_thresholds = {"raw_probs7200_lr": raw_threshold, "raw_probs_pca21_lr": pca_threshold,
                      "full21_lr": full_threshold}
    c04_dir = RUN / "results/C04/shards"; c04_dir.mkdir(parents=True, exist_ok=True)
    c04_score_path = c04_dir / f"{condition_id}_scores.csv.gz"
    c04_metric_path = c04_dir / f"{condition_id}_metrics.csv"
    write_csv_gz(c04_score_path, long_scores(test, c04_methods, c04_thresholds, "C04"))
    write_csv(c04_metric_path, evaluate_methods(test, c04_methods, c04_thresholds, PROTOCOL, "C04"))
    c04_state, c04_state_bytes = save_c04_state(condition_id, raw_scaler, raw_lr, pca_scaler, pca, pca_lr,
                                                c04_thresholds, full_state)
    close_memmap(x_test)
    del x_test, pca_test
    gc.collect()
    for raw_path in (scratch / "test_raw7200.npy",):
        drop_file_cache(raw_path)
        raw_path.unlink(missing_ok=True)
    stage(condition_id, "C04_complete", started)

    action_train = np.load(scratch / "calibration_action.npy", mmap_mode="r")
    clip_train = np.load(scratch / "calibration_clip.npy", mmap_mode="r")
    action_test = np.load(scratch / "test_action.npy", mmap_mode="r")
    clip_test = np.load(scratch / "test_clip.npy", mmap_mode="r")

    # Shared five-global sequences for C05-B.
    conf_train, sem_train, shift_train, _, _ = response_sequences(action_train, clip_train)
    conf_test, sem_test, shift_test, _, _ = response_sequences(action_test, clip_test)
    ordinary_train = adjacent_difference_from_sequences(train, conf_train, sem_train, shift_train)
    ordinary_test = adjacent_difference_from_sequences(test, conf_test, sem_test, shift_test)
    ordinary_fit = fit_lr(ordinary_train.assign(partition="calibration", is_adv=train.is_adv.to_numpy(int)), FEATURES)
    ordinary_train_score = score_lr(ordinary_fit, ordinary_train, FEATURES)
    ordinary_test_score = score_lr(ordinary_fit, ordinary_test, FEATURES)
    ordinary_threshold = threshold_from_clean(train, ordinary_train_score)
    c05_methods = {"full21_lr": full_test, "adjacent_difference_stats21_lr": ordinary_test_score}
    c05_thresholds = {"full21_lr": full_threshold, "adjacent_difference_stats21_lr": ordinary_threshold}
    c05_dir = RUN / "results/C05/shards"; c05_dir.mkdir(parents=True, exist_ok=True)
    c05_score_path = c05_dir / f"{condition_id}_ordinary_scores.csv.gz"
    c05_metric_path = c05_dir / f"{condition_id}_ordinary_metrics.csv"
    write_csv_gz(c05_score_path, long_scores(test, c05_methods, c05_thresholds, "C05-B"))
    write_csv(c05_metric_path, evaluate_methods(test, c05_methods, c05_thresholds, PROTOCOL, "C05-B"))
    write_json(RUN / "models/C05" / f"{condition_id}_ordinary.json",
               model_state(ordinary_fit, FEATURES, ordinary_threshold))

    manifest = permutation_manifest()
    score_identity = output_base(test)
    refit_score_columns: dict[str, np.ndarray] = {}
    fixed_score_columns: dict[str, np.ndarray] = {}
    permutation_metric_rows, fixed_metric_rows, permutation_states = [], [], {}
    for permutation_index, row in enumerate(manifest.itertuples(index=False), 1):
        permutation = tuple(int(value) for value in row.permutation.split(";"))
        perm_train = permutation_from_sequences(train, conf_train, sem_train, shift_train, permutation)
        perm_test = permutation_from_sequences(test, conf_test, sem_test, shift_test, permutation)
        fitted = fit_lr(perm_train.assign(partition="calibration", is_adv=train.is_adv.to_numpy(int)), FEATURES)
        train_score = score_lr(fitted, perm_train, FEATURES)
        test_score = score_lr(fitted, perm_test, FEATURES)
        threshold = threshold_from_clean(train, train_score)
        refit_score_columns[row.permutation_id] = test_score
        fixed_score = full_fit.predict_proba(perm_test[FEATURES].to_numpy(float))[:, 1]
        fixed_score_columns[row.permutation_id] = fixed_score
        permutation_metric_rows.extend(calculate_metrics(test, test_score, threshold, row.permutation_id,
                                                         "C05-B-permutation"))
        fixed_metric_rows.extend(calculate_metrics(test, fixed_score, full_threshold, row.permutation_id,
                                                   "C05-B-fixed-model"))
        permutation_states[row.permutation_id] = {
            "permutation": row.permutation, "threshold": threshold,
            "n_iter": int(fitted.named_steps["logistic"].n_iter_[0]),
            "scaler_mean": fitted.named_steps["scaler"].mean_.tolist(),
            "scaler_scale": fitted.named_steps["scaler"].scale_.tolist(),
            "lr_coef": fitted.named_steps["logistic"].coef_[0].tolist(),
            "lr_intercept": float(fitted.named_steps["logistic"].intercept_[0]),
        }
        if permutation_index % 30 == 0:
            stage(condition_id, f"permutations_{permutation_index}_of_120", started)
    refit_scores = pd.concat([score_identity, pd.DataFrame(refit_score_columns)], axis=1)
    fixed_scores = pd.concat([score_identity, pd.DataFrame(fixed_score_columns)], axis=1)
    perm_dir = RUN / "results/C05/permutation_scores"; perm_dir.mkdir(parents=True, exist_ok=True)
    refit_perm_path = perm_dir / f"{condition_id}_refit.csv.gz"
    fixed_perm_path = perm_dir / f"{condition_id}_fixed_model.csv.gz"
    perm_metric_path = c05_dir / f"{condition_id}_permutation_metrics.csv"
    fixed_metric_path = c05_dir / f"{condition_id}_fixed_metrics.csv"
    write_csv_gz(refit_perm_path, refit_scores); write_csv_gz(fixed_perm_path, fixed_scores)
    write_csv(perm_metric_path, pd.DataFrame(permutation_metric_rows))
    write_csv(fixed_metric_path, pd.DataFrame(fixed_metric_rows))
    write_json(RUN / "models/C05" / f"{condition_id}_permutations.json", permutation_states)

    # C06: consistent replacement of every KL-derived feature.
    c06_methods, c06_thresholds, tail_rows, reconstruction_rows, c06_states = {}, {}, [], [], {}
    for method_name, distance_name, epsilon in DISTANCES:
        train_features, train_stats = rebuild_distance_features(train, action_train, clip_train, distance_name, epsilon)
        test_features, test_stats = rebuild_distance_features(test, action_test, clip_test, distance_name, epsilon)
        for split, stats in (("calibration", train_stats), ("test", test_stats)):
            tail_rows.append({"protocol_id": PROTOCOL, "dataset": dataset, "model": model,
                              "partition": split, "method": method_name, **stats})
        if method_name == "symmetric_kl_eps1e-8":
            for split, original, rebuilt in (("calibration", train, train_features), ("test", test, test_features)):
                errors = np.abs(original[FEATURES].to_numpy(float) - rebuilt[FEATURES].to_numpy(float))
                reconstruction_rows.append({"protocol_id": PROTOCOL, "dataset": dataset, "model": model,
                                            "partition": split, "rows": len(original),
                                            "max_abs_error": float(errors.max()),
                                            "mean_abs_error": float(errors.mean()), "tolerance": 2e-5,
                                            "passed": bool(errors.max() <= 2e-5)})
        fit_train = train_features.assign(partition="calibration", is_adv=train.is_adv.to_numpy(int))
        fitted = fit_lr(fit_train, FEATURES)
        train_score = score_lr(fitted, train_features, FEATURES)
        test_score = score_lr(fitted, test_features, FEATURES)
        threshold = threshold_from_clean(train, train_score)
        c06_methods[method_name] = test_score; c06_thresholds[method_name] = threshold
        c06_states[method_name] = model_state(fitted, FEATURES, threshold)
    c06_dir = RUN / "results/C06/shards"; c06_dir.mkdir(parents=True, exist_ok=True)
    c06_score_path = c06_dir / f"{condition_id}_scores.csv.gz"
    c06_metric_path = c06_dir / f"{condition_id}_metrics.csv"
    c06_tail_path = c06_dir / f"{condition_id}_tail.csv"
    c06_recon_path = c06_dir / f"{condition_id}_reconstruction.csv"
    write_csv_gz(c06_score_path, long_scores(test, c06_methods, c06_thresholds, "C06"))
    write_csv(c06_metric_path, evaluate_methods(test, c06_methods, c06_thresholds, PROTOCOL, "C06"))
    write_csv(c06_tail_path, pd.DataFrame(tail_rows)); write_csv(c06_recon_path, pd.DataFrame(reconstruction_rows))
    write_json(RUN / "models/C06" / f"{condition_id}.json", c06_states)

    state_paths = (
        RUN / "models/C04" / f"{condition_id}.json",
        RUN / "models/C04" / f"{condition_id}.npz",
        RUN / "models/C05" / f"{condition_id}_ordinary.json",
        RUN / "models/C05" / f"{condition_id}_permutations.json",
        RUN / "models/C06" / f"{condition_id}.json",
    )
    result_shards = [str(path.relative_to(RUN)) for path in (
        c04_score_path, c04_metric_path, c05_score_path, c05_metric_path, refit_perm_path, fixed_perm_path,
        perm_metric_path, fixed_metric_path, c06_score_path, c06_metric_path, c06_tail_path, c06_recon_path,
        *state_paths)]
    complete = {
        "protocol_id": PROTOCOL, "condition": condition_id, "status": "complete",
        "calibration_rows": len(train), "test_rows": len(test), "raw_feature_dimension": 7200,
        "pca_explained_variance_ratio_sum": c04_state["pca"]["explained_variance_ratio_sum"],
        "raw_lr_n_iter": raw_info["n_iter"], "pca_lr_n_iter": pca_info["n_iter"],
        "permutations": len(manifest), "distance_variants": len(DISTANCES),
        "elapsed_seconds": time.perf_counter() - started,
        "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        "result_shards": result_shards,
    }
    write_json(marker, complete)
    del action_train, clip_train, action_test, clip_test
    gc.collect()
    shutil.rmtree(scratch, ignore_errors=True)
    print(json.dumps(complete), flush=True)
    return complete


def finalize() -> None:
    # C04
    c04_scores = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C04/shards").glob("*_scores.csv.gz"))], ignore_index=True)
    c04_metrics = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C04/shards").glob("*_metrics.csv"))], ignore_index=True)
    write_csv_gz(RUN / "results/C04/sample_scores.csv.gz", c04_scores)
    write_csv(RUN / "results/C04/condition_metrics.csv", c04_metrics)
    payloads = []
    for (dataset, model), part in c04_scores.groupby(["dataset", "model"]):
        wide = part.pivot(index=["dataset", "model", "partition", "pair_id", "relative_path", "attack", "is_adv", "attack_success"],
                          columns="method", values="score").reset_index()
        wide["action_model"] = model
        payloads.append(bootstrap_payload(wide, {name: wide[name].to_numpy(float) for name in
            ("raw_probs7200_lr", "raw_probs_pca21_lr", "full21_lr")}))
    diffs, reps = bootstrap_macro(payloads, [("raw_probs7200_lr", "full21_lr"),
                                              ("raw_probs_pca21_lr", "full21_lr")], PROTOCOL, "C04")
    write_csv(RUN / "results/C04/paired_differences.csv", diffs)
    write_csv_gz(RUN / "results/C04/bootstrap_replicates.csv.gz", reps)
    state_files = sorted(path for path in (RUN / "models/C04").glob("*.json") if path.name != "INDEX.json")
    write_json(RUN / "models/C04/INDEX.json", {"protocol_id": PROTOCOL,
        "conditions": [{"metadata": str(path.relative_to(RUN)), "arrays": str(path.with_suffix('.npz').relative_to(RUN))} for path in state_files]})
    parameter_rows = []
    for path in state_files:
        metadata = json.loads(path.read_text())
        parameter_rows.extend([
            {"condition": metadata["condition"], "method": "raw_probs7200_lr", "input_dimensions": 7200,
             "learned_readout_parameters": 7201, "preprocessing_fitted_values": 14400},
            {"condition": metadata["condition"], "method": "raw_probs_pca21_lr", "input_dimensions": 7200,
             "learned_readout_parameters": 22, "preprocessing_fitted_values": 14400 + 21 * 7200 + 7200},
            {"condition": metadata["condition"], "method": "full21_lr", "input_dimensions": 21,
             "learned_readout_parameters": 22, "preprocessing_fitted_values": 42},
        ])
    write_csv(RUN / "results/C04/parameter_count.csv", pd.DataFrame(parameter_rows))

    # C05-B plus combined task index.
    c05_scores = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C05/shards").glob("*_ordinary_scores.csv.gz"))], ignore_index=True)
    c05_metrics = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C05/shards").glob("*_ordinary_metrics.csv"))], ignore_index=True)
    write_csv_gz(RUN / "results/C05/ordinary_difference_scores.csv.gz", c05_scores)
    write_csv(RUN / "results/C05/ordinary_difference_metrics.csv", c05_metrics)
    payloads = []
    for (dataset, model), part in c05_scores.groupby(["dataset", "model"]):
        wide = part.pivot(index=["dataset", "model", "partition", "pair_id", "relative_path", "attack", "is_adv", "attack_success"],
                          columns="method", values="score").reset_index(); wide["action_model"] = model
        payloads.append(bootstrap_payload(wide, {name: wide[name].to_numpy(float) for name in
            ("full21_lr", "adjacent_difference_stats21_lr")}))
    diffs, reps = bootstrap_macro(payloads, [("full21_lr", "adjacent_difference_stats21_lr")], PROTOCOL, "C05-B")
    write_csv(RUN / "results/C05/ordinary_difference_paired_differences.csv", diffs)
    write_csv_gz(RUN / "results/C05/ordinary_difference_bootstrap.csv.gz", reps)
    c05a_differences = RUN / "results/C05/paired_differences.csv"
    if c05a_differences.exists():
        existing_differences = pd.read_csv(c05a_differences)
        if "task_id" in existing_differences:
            existing_differences = existing_differences[existing_differences.task_id != "C05-B"]
        combined_differences = pd.concat([existing_differences, diffs], ignore_index=True, sort=False)
        write_csv(c05a_differences, combined_differences)
    permutation_metrics = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C05/shards").glob("*_permutation_metrics.csv"))], ignore_index=True)
    fixed_metrics = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C05/shards").glob("*_fixed_metrics.csv"))], ignore_index=True)
    write_csv(RUN / "results/C05/permutation_metrics.csv", permutation_metrics)
    write_csv(RUN / "results/C05/fixed_model_perturbation_metrics.csv", fixed_metrics)
    manifest = permutation_manifest(); write_csv(RUN / "results/C05/permutation_manifest.csv", manifest)
    score_files = sorted((RUN / "results/C05/permutation_scores").glob("*.csv.gz"))
    write_json(RUN / "results/C05/permutation_scores/INDEX.json", {
        "protocol_id": PROTOCOL, "files": [{"path": str(path.relative_to(RUN)), "bytes": path.stat().st_size} for path in score_files],
        "note": "wide score shards keyed by immutable sample columns; 120 permutation columns each"})
    write_json(RUN / "models/C05/INDEX.json", {"protocol_id": PROTOCOL,
        "ablation_models": [str(path.relative_to(RUN)) for path in sorted((RUN / "models/C05").glob("*.json"))
                            if path.name != "INDEX.json" and not path.name.endswith("_ordinary.json")
                            and not path.name.endswith("_permutations.json")],
        "ordinary_models": [str(path.relative_to(RUN)) for path in sorted((RUN / "models/C05").glob("*_ordinary.json"))],
        "permutation_models": [str(path.relative_to(RUN)) for path in sorted((RUN / "models/C05").glob("*_permutations.json"))]})

    # C06
    c06_scores = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C06/shards").glob("*_scores.csv.gz"))], ignore_index=True)
    c06_metrics = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C06/shards").glob("*_metrics.csv"))], ignore_index=True)
    write_csv_gz(RUN / "results/C06/sample_scores.csv.gz", c06_scores)
    write_csv(RUN / "results/C06/condition_metrics.csv", c06_metrics)
    write_csv(RUN / "results/C06/tail_and_clipping_stats.csv", pd.concat([
        pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C06/shards").glob("*_tail.csv"))], ignore_index=True))
    reconstruction = pd.concat([pd.read_csv(path, keep_default_na=False) for path in sorted((RUN / "results/C06/shards").glob("*_reconstruction.csv"))], ignore_index=True)
    write_csv(RUN / "validation/C06_reconstruction.csv", reconstruction)
    payloads = []
    methods = [item[0] for item in DISTANCES]
    for (dataset, model), part in c06_scores.groupby(["dataset", "model"]):
        wide = part.pivot(index=["dataset", "model", "partition", "pair_id", "relative_path", "attack", "is_adv", "attack_success"],
                          columns="method", values="score").reset_index(); wide["action_model"] = model
        payloads.append(bootstrap_payload(wide, {name: wide[name].to_numpy(float) for name in methods}))
    diffs, reps = bootstrap_macro(payloads, [("symmetric_kl_eps1e-8", name) for name in methods[1:]], PROTOCOL, "C06")
    write_csv(RUN / "results/C06/paired_differences.csv", diffs)
    write_csv_gz(RUN / "results/C06/bootstrap_replicates.csv.gz", reps)
    write_json(RUN / "models/C06/INDEX.json", {"protocol_id": PROTOCOL,
        "models": [str(path.relative_to(RUN)) for path in sorted((RUN / "models/C06").glob("*.json"))
                   if path.name != "INDEX.json"]})

    all_scores_finite = bool(np.isfinite(c04_scores.score).all() and
                             np.isfinite(c05_scores.score).all() and np.isfinite(c06_scores.score).all())
    write_json(RUN / "validation/C04_C05B_C06.json", {
        "protocol_id": PROTOCOL, "conditions": 8, "C04_score_rows": len(c04_scores),
        "C05_ordinary_score_rows": len(c05_scores), "C05_permutation_metric_rows": len(permutation_metrics),
        "C06_score_rows": len(c06_scores), "C06_reconstruction_max_abs_error": float(reconstruction.max_abs_error.max()),
        "probability_cache_gate": "A00 passed", "all_scores_finite": all_scores_finite,
        "C04_model_states": len(state_files), "C05_permutation_model_sets": len(list((RUN / "models/C05").glob("*_permutations.json"))),
        "C06_model_states": len(list((RUN / "models/C06").glob("*.json"))) - 1,
        "gpu_used": False, "torch_imported": False,
        "passed": bool(reconstruction.passed.all() and all_scores_finite and len(state_files) == 8),
    })


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=("smoke", "full"), required=True)
    args = parser.parse_args()
    a00 = json.loads((RUN / "validation/A00.json").read_text())
    if not a00.get("all_a00_gates_passed"):
        raise RuntimeError("A00 gate has not passed")
    for task in ("C04", "C05", "C06"):
        (RUN / "results" / task).mkdir(parents=True, exist_ok=True)
        (RUN / "models" / task).mkdir(parents=True, exist_ok=True)
    write_json(RUN / "protocols/C04.json", {"protocol_id": PROTOCOL, "task_id": "C04",
        "raw_layout": "9x400 action probabilities followed by 9x400 CLIP probabilities; not logits",
        "methods": ["raw_probs7200_lr", "raw_probs_pca21_lr", "full21_lr"],
        "pca": {"components": 21, "solver": "randomized", "seed": SEED, "iterated_power": 4,
                "whiten": False, "post_pca_scale": False},
        "memory_strategy": "float32 disk memmap; identical calibration-fitted StandardScaler state reused for raw and PCA paths; train and test 7200D matrices materialized sequentially",
        "memory_strategy_semantics": "equivalent to independently fitting deterministic StandardScaler on the same calibration rows; no test statistics used",
        "gpu_used": False})
    write_json(RUN / "results/C04/feature_layout.json", {"protocol_id": PROTOCOL,
        "action": {"offset": 0, "shape": [9, 400]}, "clip": {"offset": 3600, "shape": [9, 400]},
        "view_order": ["original", "early_crop", "late_crop", "temporal_sparse", "motion_aware",
                       "local_0", "local_1", "local_2", "local_3"], "total_dimensions": 7200})
    write_json(RUN / "protocols/C05-B.json", {"protocol_id": PROTOCOL, "task_id": "C05-B",
        "ordinary_statistics": "for each of confidence/action-shift/action-semantic sequences: mean(abs(adjacent difference)) and mean(squared adjacent difference)",
        "permutations": 120, "same_permutation_for_three_sequences": True,
        "original_identity_anchor_unchanged": True, "calibration_and_test_permutation_matched": True,
        "fixed_model_diagnostic": "original full21 model; test FFT columns perturbed only", "gpu_used": False})
    write_json(RUN / "protocols/C06.json", {"protocol_id": PROTOCOL, "task_id": "C06",
        "variants": [{"name": n, "distance": d, "epsilon": e} for n, d, e in DISTANCES],
        "normalization": "natural log; clip to epsilon then renormalize",
        "replacement_scope": "all global/local action-shift and action-semantic distances plus their FFT descriptors",
        "gpu_used": False})
    write_json(RUN / "results/C06/distance_definitions.json", json.loads((RUN / "protocols/C06.json").read_text()))
    if args.mode == "smoke":
        value = process_condition("k400", "csn_r101")
        write_json(RUN / "validation/cache_cpu_smoke.json", {"protocol_id": PROTOCOL, "passed": True,
            "scope": "one complete dataset/model condition", **value})
        return
    completed = []
    for dataset in DATASETS:
        for model in MODELS:
            completed.append(process_condition(dataset, model))
    finalize()
    write_json(RUN / "logs/cache_cpu_run_summary.json", {"protocol_id": PROTOCOL,
        "conditions": len(completed), "status": "complete", "gpu_used": False,
        "elapsed_seconds_sum": float(sum(item["elapsed_seconds"] for item in completed))})


if __name__ == "__main__":
    main()
