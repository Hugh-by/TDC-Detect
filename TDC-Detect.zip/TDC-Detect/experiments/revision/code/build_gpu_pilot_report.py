#!/usr/bin/env python3
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
REPORTS = RUN / "reports"
REPORTS.mkdir(exist_ok=True)


def q(values, value): return float(np.quantile(np.asarray(values, float), value))


def main() -> None:
    g01 = json.loads((RUN / "results/G01/gradient_audit.json").read_text())
    g02 = pd.read_csv(RUN / "results/G02/pilot/candidates.csv.gz")
    g03 = pd.read_csv(RUN / "results/G03/pilot/condition_latency.csv")
    g04 = pd.read_csv(RUN / "results/G04/pilot/trajectory.csv.gz")
    g05 = pd.read_csv(RUN / "results/G05/pilot/clean_scores.csv.gz")

    estimates = []
    g02_core_total = 0.0
    g02_core_upper = 0.0
    g02_model_hours = {}
    for model in ("csn_r101", "mvit_base_16x4"):
        adaptive = g02[(g02.action_model == model) & (g02.tradeoff_lambda == 1) & (g02.step > 0)]
        gradient_p50, gradient_p95 = q(adaptive.gradient_seconds, .5), q(adaptive.gradient_seconds, .95)
        score_p50, score_p95 = q(adaptive.score_seconds, .5), q(adaptive.score_seconds, .95)
        seconds = (480 * 100 * gradient_p50 + 480 * 7 * score_p50) * 1.10
        upper = (480 * 100 * gradient_p95 + 480 * 7 * score_p95) * 1.20
        g02_model_hours[model] = seconds / 3600
        g02_core_total += seconds / 3600; g02_core_upper += upper / 3600
        estimates.append({"option": "task", "scope": f"G02_full_core_{model}", "gpu_hours_mid": seconds / 3600,
                          "gpu_hours_conservative": upper / 3600, "basis": "480 trajectories x 100 full-gradient steps + 7 real scores; pilot p50/p95; 10/20% overhead",
                          "authorization": "pending_GPU_FULL"})

    control_total, control_upper = 0.0, 0.0
    for model in ("csn_r101", "mvit_base_16x4"):
        control = g02[(g02.action_model == model) & (g02.tradeoff_lambda == 0) & (g02.step > 0)]
        all_model = g02[(g02.action_model == model) & (g02.step > 0)]
        seconds = (300 * 100 * q(control.gradient_seconds, .5) + 300 * 7 * q(all_model.score_seconds, .5)) * 1.10
        upper = (300 * 100 * q(control.gradient_seconds, .95) + 300 * 7 * q(all_model.score_seconds, .95)) * 1.20
        control_total += seconds / 3600; control_upper += upper / 3600
    estimates.append({"option": "task", "scope": "G02_formal_lambda0_test_control_both_models", "gpu_hours_mid": control_total,
                      "gpu_hours_conservative": control_upper, "basis": "600 trajectories total x 100 classification-gradient steps + checkpoint scoring",
                      "authorization": "optional_pending_GPU_FULL"})

    pilot_g03_hours = float(
        g03.groupby(["model", "method", "timing_boundary"])["mean_seconds"].sum().sum()
    ) * 20 * 3 / 3600
    # 8 full dataset/model conditions versus 2 pilot conditions, and 100x5 versus 20x3 repetitions.
    g03_mid = pilot_g03_hours * 4 * (100 * 5) / (20 * 3)
    g03_upper = g03_mid * 1.35
    estimates.append({"option": "task", "scope": "G03_full_8_conditions_7_methods_A_B", "gpu_hours_mid": g03_mid,
                      "gpu_hours_conservative": g03_upper, "basis": "pilot aggregate scaled from 2 to 8 conditions and 20x3 to 100x5; 35% cross-model/dataset margin",
                      "authorization": "pending_GPU_FULL"})

    structured_step = g04.groupby("action_model").seconds.median().to_dict()
    score_by_model = g05.groupby("action_model").seconds.median().to_dict()
    rates = {
        "csn_r101": structured_step["csn_r101"], "mvit_base_16x4": structured_step["mvit_base_16x4"],
        "slowfast_r50": structured_step["csn_r101"] * 1.17, "x3d_m": structured_step["csn_r101"] * 0.54,
    }
    g04_seconds = sum(100 * 2 * 100 * rates[m] + 100 * 2 * 4 * score_by_model[m] for m in rates)
    g04_mid, g04_upper = g04_seconds * 1.10 / 3600, g04_seconds * 1.40 / 3600
    estimates.append({"option": "task", "scope": "G04_full_4_models_100_sources_2_attacks_100_steps", "gpu_hours_mid": g04_mid,
                      "gpu_hours_conservative": g04_upper, "basis": "measured CSN/MViT action steps; historical ratios for SlowFast/X3D; four score checkpoints; 10/40% overhead",
                      "authorization": "pending_GPU_FULL"})

    g05_mid = sum(400 * score_by_model[m] for m in score_by_model) * 1.10 / 3600
    g05_upper = g05_mid * 1.35
    estimates.append({"option": "task", "scope": "G05_full_up_to_400_unfiltered_clean_per_model", "gpu_hours_mid": g05_mid,
                      "gpu_hours_conservative": g05_upper, "basis": "12-source pilot score time scaled to 1600 clips; 10/35% overhead",
                      "authorization": "pending_GPU_FULL"})

    tasks = pd.DataFrame(estimates)
    core_scope = tasks.scope.str.startswith(("G03", "G04", "G05"))
    core_other_mid = float(tasks.loc[core_scope, "gpu_hours_mid"].sum())
    core_other_upper = float(tasks.loc[core_scope, "gpu_hours_conservative"].sum())
    bundles = pd.DataFrame([
        {"option": "A", "scope": "G02 core + G03 full + G04 full + G05 full", "gpu_hours_mid": g02_core_total + core_other_mid,
         "gpu_hours_conservative": g02_core_upper + core_other_upper, "basis": "required full scopes after pilot", "authorization": "pending_user_selection"},
        {"option": "B", "scope": "A + formal lambda0 test control", "gpu_hours_mid": g02_core_total + core_other_mid + control_total,
         "gpu_hours_conservative": g02_core_upper + core_other_upper + control_upper, "basis": "adds 600 classification-only test trajectories", "authorization": "pending_user_selection"},
        {"option": "C", "scope": "B + G07 optional design studies", "gpu_hours_mid": np.nan,
         "gpu_hours_conservative": np.nan, "basis": "G07 requires a separately frozen protocol and cannot be honestly priced from current pilots", "authorization": "deferred_budget"},
    ])
    budget = pd.concat([tasks, bundles], ignore_index=True)
    budget.to_csv(REPORTS / "BUDGET_OPTIONS.csv", index=False)

    g01_lines = []
    for model, audit in g01["models"].items():
        times = [row["seconds"] for row in audit["actual_vjp_samples"]]
        memories = [row["peak_memory_bytes"] for row in audit["actual_vjp_samples"]]
        g01_lines.append(f"- {model}: pass; full-gradient median {np.median(times):.3f} s, p95 {np.quantile(times,.95):.3f} s; peak {max(memories)/2**30:.2f} GiB; max forward feature error {audit['forward_max_absolute_error']:.3g}.")
    g02_summary = pd.read_csv(RUN / "results/G02/pilot/metrics.csv")
    report = f"""# GPU_PILOT report

Generated: {datetime.now(timezone.utc).isoformat()}  
Run: `{RUN}`  
Budget state: **GPU_PILOT completed; GPU_FULL not authorized.**

## Gate and completed scope

G01 passed for both CSN and MViT over three calibration sources and clean/random/small-adversarial candidates. All 21 exact-forward features, scores/decisions, response-branch connectivity, VJP equivalence, and continuous-subgraph finite differences passed.

{chr(10).join(g01_lines)}

G02 completed 12 bounded calibration-only trajectories (3 sources x 2 models x lambda 1/0), 20 steps, one restart. G03 completed 1,680 isolated timing rows (2 models x 7 methods x 20 clips x 3 repeats x boundaries A/B). G04 completed 12 structured trajectories with fixed-frame OFA and spatially broadcast Flicker constraints. G05 completed 12 prediction-unfiltered clean forwards across four models. No test100 adaptive trajectory was run.

## Pilot observations

G02 endpoint summary is in `{RUN / 'results/G02/pilot/metrics.csv'}`. These six-source-per-setting values are execution diagnostics, not formal AUC evidence. The detector-aware trajectories are non-monotone, so the full stage must retain the prescribed checkpoint union and best-so-far selection rather than use only the last iterate.

G03 timing uses one isolated process per model/method, warmup=10, batch=1, FP32, and reports both predecoded-to-score (A) and path-to-score (B). GPU0 was used only after the other project GPU workers stopped. `light_g3l2` uses the independently fitted C01 g3_l2 fold-0 readout strictly as a timing adapter; its effect evidence remains C01 OOF and is not mixed with timing scores.

G05 selection used the lowest SHA256 paths after excluding model-specific calibration sources; prediction/correctness was not used. The pilot is only an availability/timing validation and is not an FPR estimate.

## Budget gate

The machine-readable task and bundle estimates are in `{REPORTS / 'BUDGET_OPTIONS.csv'}`. G02 core alone is approximately {g02_core_total:.1f} GPU-hours at pilot medians ({g02_core_upper:.1f} conservative). With CSN and MViT on separate GPUs, its two-worker critical path is approximately {max(g02_model_hours.values()):.1f} hours before queue/verification overhead; four-card wall time is not reported as total GPU-hours divided by four.

Select an option/scope before `authorization.json` is created and any GPU_FULL worker starts. Until then, full tasks remain `deferred_budget`.

## Validation and artifacts

- G01: `{RUN / 'results/G01'}`
- G02: `{RUN / 'results/G02/pilot'}`
- G03: `{RUN / 'results/G03/pilot'}`
- G04: `{RUN / 'results/G04/pilot'}`
- G05: `{RUN / 'results/G05/pilot'}`
- NO_GPU packages: `{RUN / 'exports'}`
"""
    (REPORTS / "PILOT_REPORT.md").write_text(report, encoding="utf-8")
    print(json.dumps({"pilot_report": str(REPORTS / "PILOT_REPORT.md"), "budget": str(REPORTS / "BUDGET_OPTIONS.csv")}))


if __name__ == "__main__": main()
