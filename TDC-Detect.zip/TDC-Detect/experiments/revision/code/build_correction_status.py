#!/usr/bin/env python3
import json
from datetime import datetime, timezone
from pathlib import Path
RUN=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01')
tasks=[
 {'task_id':'G02_LEGACY_RESCORE','status':'completed','protocol_id':'tdc-r3r5-g02-legacy-rescore-20261026-v1','result_paths':['results/G02/legacy_rescore_v2/legacy_rescore_per_sample.csv.gz','results/G02/legacy_rescore_v2/legacy_rescore_feature_errors.csv.gz','results/G02/legacy_rescore_v2/frozen_detector_state_index.csv'],'validation_paths':['results/G02/legacy_rescore_v2/constraint_validation.json']},
 {'task_id':'G02_SUPPLEMENTAL','status':'completed','protocol_id':'tdc-r3r5-g02-supplemental-20261026-v1','result_paths':['results/G02/supplemental_v2/success_only_metrics.csv','results/G02/supplemental_v2/checkpoint_union_convergence.csv','results/G02/supplemental_v2/rate_intervals.csv'],'validation_paths':['results/G02/supplemental_v2/validation.json']},
 {'task_id':'G03_CORRECTED','status':'completed','protocol_id':'tdc-r3r5-g03-full-corrected-20261025-v2','result_paths':['results/G03/full_corrected/per_clip_runtime.csv.gz','results/G03/full_corrected/condition_latency.csv','results/G03/full_corrected/method_call_and_load_evidence.csv'],'validation_paths':['protocols/G03_METHOD_IDENTITY_GATE.json','results/G03/full_corrected/final_validation.json']},
 {'task_id':'G04_CORRECTED','status':'completed','protocol_id':'tdc-r3r5-g04-full-corrected-20261025-v2','result_paths':['results/G04/summary_corrected/metrics_and_convergence.csv','results/G04/summary_corrected/loss_saturation_impact.csv'],'validation_paths':['results/G04/summary_corrected/validation.json']},
 {'task_id':'G05_C08_CORRECTED','status':'completed','protocol_id':'tdc-r3r5-g05-corrected-20261025-v2','result_paths':['results/G05/full_corrected/clean_features_all.csv.gz','results/G05/full_corrected/stratified_fpr.csv'],'validation_paths':['results/G05/full_corrected/validation.json']},
 {'task_id':'C04_ROUNDTRIP','status':'completed','protocol_id':'tdc-r3r5-c04-roundtrip-repair-20261026-v1','result_paths':['results/C04_roundtrip_v2/sample_scores.csv.gz','results/C04_roundtrip_v2/condition_metrics.csv','results/C04_roundtrip_v2/paired_differences.csv','results/C04_roundtrip_v2/before_after_comparison.csv'],'validation_paths':['results/C04_roundtrip_v2/validation.json']},
 {'task_id':'FINAL_REPORT_METADATA','status':'running','protocol_id':'server-correction-checklist-20261025','result_paths':['reports/CORRECTION_STATUS_20261026.md'],'validation_paths':[],'reason':'reviewer-number mapping, artifact delivery inventory, and final narrative audit in progress'},
 {'task_id':'G02_TENSOR_VOLUMES','status':'completed','protocol_id':'tdc-r3r5-g02-tensor-volumes-20261026-v1','result_paths':['exports/g02_tensor_volumes/VOLUME_INDEX.csv','exports/g02_tensor_volumes/G02_SELECTED_ADV_VOLUME_01.zip','exports/g02_tensor_volumes/G02_SELECTED_ADV_VOLUME_02.zip','exports/g02_tensor_volumes/G02_SELECTED_ADV_VOLUME_03.zip','exports/g02_tensor_volumes/G02_SELECTED_ADV_VOLUME_04.zip'],'validation_paths':['exports/g02_tensor_volumes/validation.json']},
 {'task_id':'FINAL_EXPORT','status':'not_started','protocol_id':'server-correction-checklist-20261025','result_paths':[],'validation_paths':[],'reason':'depends on final metadata and tensor-volume indexes'},
]
for task in tasks:
 for p in task.get('validation_paths',[]):
  if not (RUN/p).is_file(): raise SystemExit(f'missing validation: {p}')
status={'format_version':2,'run_id':RUN.name,'generated_at':datetime.now(timezone.utc).isoformat(),'mode':'GPU_FULL_OPTION_B_PLUS_CORRECTIONS','scope_complete':False,'overall_revision_complete':False,'stage_scope_tasks':[x['task_id'] for x in tasks],'tasks':tasks,'completed_scientific_tasks':6,'completed_tasks_total':7,'remaining_delivery_tasks':2,'note':'Completion of numerical tasks does not imply final delivery completion.'}
(RUN/'STATUS_CORRECTED.json').write_text(json.dumps(status,indent=2,sort_keys=True)+'\n')
lines=['# Correction status — 2026-10-26','','Numerical corrections and the G02 tensor-volume delivery are complete and validated; final metadata and export remain.','', '| Task | Status | Validation |','|---|---|---|']
for t in tasks: lines.append(f"| {t['task_id']} | {t['status']} | {'; '.join(t.get('validation_paths',[])) or 'pending'} |")
lines += ['','## Scope statement','','`scope_complete=false` and `overall_revision_complete=false` until the final manifest, external-artifact inventory, tensor volumes, and export validator all pass.']
(RUN/'reports/CORRECTION_STATUS_20261026.md').write_text('\n'.join(lines)+'\n')
