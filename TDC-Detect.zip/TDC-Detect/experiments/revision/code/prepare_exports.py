#!/usr/bin/env python3
"""Create validated review/reproduction archives and cache data volumes."""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import matplotlib
import numpy
import pandas
import safetensors
import sklearn

from cpu_common import BASE, DATASETS, MODELS, RUN, SUPP, write_csv, write_json

EXPORTS = RUN / "exports"
CACHE = SUPP / "E14/probe_cache"
REGISTRY = RUN / "handoff/TASK_REGISTRY.json"
VALIDATOR = RUN / "handoff/tools/validate_export.py"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def add_tree(archive: zipfile.ZipFile, root: Path, prefix: str, include=None) -> int:
    count = 0
    for path in sorted(root.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        relative = path.relative_to(root).as_posix()
        if include is not None and not include(path, relative):
            continue
        archive.write(path, f"{prefix}/{relative}" if prefix else relative)
        count += 1
    return count


def create_cache_volumes() -> list[dict]:
    volume_dir = EXPORTS / "data_volumes"
    volume_dir.mkdir(parents=True, exist_ok=True)
    artifacts = []
    for dataset in DATASETS:
        for model in MODELS:
            for split in ("calibration", "test"):
                condition = f"{dataset}_{model}_{split}"
                source = CACHE / condition
                archive_path = volume_dir / f"REPRO_CACHE_{condition}.zip"
                if not archive_path.exists():
                    temp = archive_path.with_suffix(".zip.tmp")
                    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
                        add_tree(archive, source, f"dependencies/probe_cache/{condition}")
                        shard_manifest = RUN / f"manifests/cache_shards/{condition}.csv"
                        archive.write(shard_manifest, f"provenance/cache_shards/{condition}.csv")
                        model_manifest = CACHE / f"{model}_manifest.json"
                        if model_manifest.exists():
                            archive.write(model_manifest, f"dependencies/probe_cache/{model}_manifest.json")
                    os.replace(temp, archive_path)
                artifacts.append({
                    "artifact_id": f"response_cache_{condition}", "task_id": "C04;C05;C06",
                    "role": "validated nine-view action/CLIP probability cache",
                    "required_for_recompute": True, "placement": "separate_archive",
                    "archive_name": archive_path.name,
                    "member_path": f"dependencies/probe_cache/{condition}",
                    "sha256": sha256(archive_path), "bytes": archive_path.stat().st_size,
                    "availability": "included_as_separate_volume",
                    "regeneration_command_or_external_dependency": "source cache validated by A00; regeneration would be G06 and is not needed",
                })
                print(json.dumps({"cache_volume": archive_path.name, "bytes": archive_path.stat().st_size}), flush=True)
    return artifacts


def create_source_hashes() -> pd.DataFrame:
    rows = []
    e1 = pd.read_csv(RUN / "provenance/input_manifest.csv")
    for item in e1.itertuples(index=False):
        rows.append({"artifact_id": item.artifact_id, "logical_role": item.logical_role,
                     "original_path": item.original_path, "portable_path": item.portable_path,
                     "bytes": item.bytes, "sha256": item.sha256, "protocol": item.protocol,
                     "partition": item.partition, "source_count": item.source_count, "provenance": item.provenance})
    for manifest in sorted((RUN / "manifests/cache_shards").glob("*.csv")):
        frame = pd.read_csv(manifest)
        for item in frame.itertuples(index=False):
            rows.append({"artifact_id": f"cache/{item.relative_member}", "logical_role": "nine_view_probability_shard",
                         "original_path": str(CACHE / item.relative_member),
                         "portable_path": f"dependencies/probe_cache/{item.relative_member}",
                         "bytes": item.bytes, "sha256": item.sha256, "protocol": "tdc-supplement-20260817",
                         "partition": item.condition.rsplit("_", 1)[-1], "source_count": 1,
                         "provenance": "A00 full-shard hash and reconstruction audit"})
    selected_dependencies = []
    selected_dependencies.extend((path, "E7_features", f"dependencies/E7/{path.name}")
                                 for path in sorted((BASE / "E7").glob("*.csv")))
    selected_dependencies.extend((path, "E14_saved", f"dependencies/E14/{path.name}")
                                 for path in sorted((SUPP / "E14").iterdir())
                                 if path.is_file() and path.suffix in {".csv", ".json", ".md", ".py"})
    selected_dependencies.extend((path, "E15_saved", f"dependencies/E15/{path.name}")
                                 for path in sorted((SUPP / "E15").iterdir())
                                 if path.is_file() and path.suffix in {".csv", ".json", ".md", ".py"})
    e16_names = {"coefficient_bootstrap.csv", "coefficient_bootstrap_summary.csv", "coefficient_rank_correlations.csv",
                 "detector_coefficients.csv", "case_feature_contributions.csv", "case_probe_responses.csv",
                 "case_selection.csv", "feature_selection_rule.json", "cpu_manifest.json"}
    selected_dependencies.extend((path, "E16_saved", f"dependencies/E16/{path.name}")
                                 for path in sorted((SUPP / "E16").iterdir()) if path.name in e16_names)
    e11_names = {"probe_validity_summary.csv", "sensitivity_metrics.csv", "table_probe_validity.csv"}
    selected_dependencies.extend((path, "E11_saved", f"dependencies/E11/{path.name}")
                                 for path in sorted((SUPP / "E11").iterdir()) if path.name in e11_names)
    selected_dependencies.extend((path, "E12_saved", f"dependencies/E12/{path.name}")
                                 for path in sorted((SUPP / "E12").iterdir())
                                 if path.is_file() and path.suffix in {".csv", ".json", ".md", ".py"})
    for path in sorted(Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct").glob("*_all.csv")):
        selected_dependencies.append((path, "unfiltered_predictions", f"dependencies/repaired_clean_correct/{path.name}"))
    for path, role, portable in selected_dependencies:
        rows.append({"artifact_id": f"{role}/{path.name}", "logical_role": role,
                     "original_path": str(path), "portable_path": portable, "bytes": path.stat().st_size,
                     "sha256": sha256(path), "protocol": "historical_dependency", "partition": "NA",
                     "source_count": "NA", "provenance": "selected read-only reproduction dependency"})
    frame = pd.DataFrame(rows)
    write_csv(RUN / "SOURCE_HASHES.csv", frame)
    return frame


def create_data_artifacts(cache_artifacts: list[dict]) -> pd.DataFrame:
    rows = list(cache_artifacts)
    dependency_specs = [
        ("E1_features", "A00;C02;C03;C05;C06;C07;C09", "21D calibration/test features", BASE / "E1", "dependencies/E1", True),
        ("E7_features", "C01", "E7 nine-configuration features", BASE / "E7", "dependencies/E7", True),
        ("E14_saved", "C02", "matched-budget scores/metrics/runtime and fitted states", SUPP / "E14", "dependencies/E14", True),
        ("E15_saved", "C02;C07", "transfer ablation scores and metrics", SUPP / "E15", "dependencies/E15", True),
        ("E16_saved", "C07", "coefficient bootstrap and interpretation evidence", SUPP / "E16", "dependencies/E16", True),
        ("E11_saved", "C07;C09", "probe-validity and sensitivity summaries", SUPP / "E11", "dependencies/E11", False),
        ("E12_saved", "C07;C09", "historical local-feature ablation evidence", SUPP / "E12", "dependencies/E12", False),
        ("unfiltered_predictions", "C08", "K400 clean labels/predictions/correctness without detector features", Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct"), "dependencies/repaired_clean_correct", False),
    ]
    for artifact_id, task, role, original, member, required in dependency_specs:
        rows.append({"artifact_id": artifact_id, "task_id": task, "role": role,
                     "required_for_recompute": required, "placement": "REPRO_PACKAGE_CORE.zip",
                     "archive_name": "REPRO_PACKAGE_CORE.zip", "member_path": member,
                     "sha256": "see SOURCE_HASHES.csv or per-file archive manifest", "bytes": "NA",
                     "availability": "included_selected_files",
                     "regeneration_command_or_external_dependency": str(original)})
    frame = pd.DataFrame(rows)
    write_csv(RUN / "DATA_ARTIFACTS.csv", frame)
    return frame


def required_result_paths() -> dict[str, list[str]]:
    return {
        "A00": ["provenance/input_manifest.csv", "provenance/cache_inventory.csv", "provenance/missing_inputs.csv", "validation/reconstruction_check.json"],
        "C01": ["results/C01/oof_scores.csv.gz", "results/C01/fold_manifest.csv", "results/C01/condition_metrics.csv", "results/C01/paired_differences.csv", "results/C01/old_new_paper_comparison.csv", "models/C01/INDEX.json"],
        "C02": ["results/C02/sample_scores.csv.gz", "results/C02/condition_metrics.csv", "results/C02/paired_differences.csv", "results/C02/estimate_definitions.csv", "results/C02/historical_cost.csv", "results/C02/transfer_threshold_metrics.csv"],
        "C03": ["results/C03/sample_scores.csv.gz", "results/C03/condition_metrics.csv", "results/C03/paired_differences.csv", "results/C03/score_definitions.json", "models/C03/INDEX.json"],
        "C04": ["results/C04/sample_scores.csv.gz", "results/C04/condition_metrics.csv", "results/C04/paired_differences.csv", "results/C04/feature_layout.json", "results/C04/parameter_count.csv", "models/C04/INDEX.json"],
        "C05": ["results/C05/ablation_scores.csv.gz", "results/C05/ablation_metrics.csv", "results/C05/paired_differences.csv", "results/C05/permutation_manifest.csv", "results/C05/permutation_metrics.csv", "results/C05/fixed_model_perturbation_metrics.csv", "results/C05/permutation_scores/INDEX.json"],
        "C06": ["results/C06/sample_scores.csv.gz", "results/C06/condition_metrics.csv", "results/C06/paired_differences.csv", "results/C06/distance_definitions.json", "results/C06/tail_and_clipping_stats.csv", "validation/C06_reconstruction.csv"],
        "C07": ["results/C07/correlation.csv", "results/C07/coefficient_stability.csv", "results/C07/deployment_table.csv", "results/C07/selection_history.md", "results/C07/feature_rationale.csv"],
        "C09": ["results/C09/sample_scores.csv.gz", "results/C09/condition_metrics.csv", "results/C09/paired_differences.csv", "results/C09/reference_design_note.md"],
        "D01": ["reports/reviewer_evidence_matrix.csv", "reports/manuscript_change_map.md", "reports/STAGE_REPORT.md", "reports/UNRESOLVED_ITEMS.md"],
    }


def copy_review_tree(stage: Path) -> None:
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True)
    for name in ("code", "environment", "figures", "logs", "manifests", "models", "protocols",
                 "provenance", "reports", "results", "validation"):
        shutil.copytree(RUN / name, stage / name, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    for name in ("README.md", "STATUS.json", "DATA_ARTIFACTS.csv", "SOURCE_HASHES.csv"):
        shutil.copy2(RUN / name, stage / name)
    shutil.copy2(REGISTRY, stage / "TASK_REGISTRY.json")
    (stage / "handoff").mkdir()
    for name in ("START_HERE.md", "MASTER_HANDOFF.md", "NO_GPU_TASKS.md", "EXPORT_REQUIREMENTS.md", "GPU_TASKS.md"):
        shutil.copy2(RUN / "handoff" / name, stage / "handoff" / name)


def write_export_manifest(stage: Path) -> dict:
    files = []
    for path in sorted(stage.rglob("*")):
        if path.is_file() and path.name != "export_manifest.json":
            relative = path.relative_to(stage).as_posix()
            if not relative.isascii():
                raise ValueError(f"non-ASCII member: {relative}")
            files.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path)})
    status = json.loads((stage / "STATUS.json").read_text())
    manifest = {"format_version": 1, "run_id": RUN.name, "stage": "NO_GPU",
                "scope_complete": False, "generated_at": now(), "files": files,
                "required_result_paths": required_result_paths(),
                "stage_scope_tasks": status["stage_scope_tasks"]}
    write_json(stage / "export_manifest.json", manifest)
    return manifest


def create_review_package() -> Path:
    stage = EXPORTS / "review_stage"
    copy_review_tree(stage)
    manifest = write_export_manifest(stage)
    command = ["python3", str(VALIDATOR), str(stage), "--registry", str(stage / "TASK_REGISTRY.json")]
    completed = subprocess.run(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False)
    report = json.loads(completed.stdout)
    write_json(RUN / "validation/REVIEW_PACKAGE_export_validation.json", report)
    (EXPORTS / "REVIEW_PACKAGE.validation.txt").write_text(completed.stdout, encoding="utf-8")
    if completed.returncode != 0 or not report.get("passed"):
        raise RuntimeError(f"review export validation failed: {completed.stdout}")
    archive_path = EXPORTS / "REVIEW_PACKAGE.zip"
    temp = archive_path.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
        add_tree(archive, stage, "")
    os.replace(temp, archive_path)
    return archive_path


def create_repro_core() -> Path:
    archive_path = EXPORTS / "REPRO_PACKAGE_CORE.zip"
    temp = archive_path.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
        for name in ("code", "environment", "figures", "logs", "manifests", "models", "protocols",
                     "provenance", "reports", "results", "validation"):
            add_tree(archive, RUN / name, name)
        for name in ("README.md", "STATUS.json", "DATA_ARTIFACTS.csv", "SOURCE_HASHES.csv"):
            archive.write(RUN / name, name)
        add_tree(archive, BASE / "E1", "dependencies/E1")
        add_tree(archive, BASE / "E7", "dependencies/E7")
        add_tree(archive, SUPP / "E14", "dependencies/E14",
                 include=lambda path, rel: "probe_cache" not in path.parts and path.suffix in {".csv", ".json", ".md", ".py"})
        add_tree(archive, SUPP / "E15", "dependencies/E15",
                 include=lambda path, rel: path.suffix in {".csv", ".json", ".md", ".py"})
        e16_names = {"coefficient_bootstrap.csv", "coefficient_bootstrap_summary.csv", "coefficient_rank_correlations.csv",
                     "detector_coefficients.csv", "case_feature_contributions.csv", "case_probe_responses.csv",
                     "case_selection.csv", "feature_selection_rule.json", "cpu_manifest.json"}
        add_tree(archive, SUPP / "E16", "dependencies/E16", include=lambda path, rel: path.name in e16_names)
        e11_names = {"probe_validity_summary.csv", "sensitivity_metrics.csv", "table_probe_validity.csv"}
        add_tree(archive, SUPP / "E11", "dependencies/E11", include=lambda path, rel: path.name in e11_names)
        add_tree(archive, SUPP / "E12", "dependencies/E12", include=lambda path, rel: path.suffix in {".csv", ".json", ".md", ".py"})
        add_tree(archive, Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct"),
                 "dependencies/repaired_clean_correct", include=lambda path, rel: path.name.endswith("_all.csv"))
    os.replace(temp, archive_path)
    return archive_path


def create_release_candidate() -> Path:
    stage = EXPORTS / "release_candidate_stage"
    shutil.rmtree(stage, ignore_errors=True)
    stage.mkdir(parents=True)
    for name in ("code", "protocols", "manifests"):
        shutil.copytree(RUN / name, stage / name, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    shutil.copy2(RUN / "SOURCE_HASHES.csv", stage / "SOURCE_HASHES.csv")
    shutil.copy2(RUN / "DATA_ARTIFACTS.csv", stage / "DATA_ARTIFACTS.csv")
    shutil.copy2(REGISTRY, stage / "TASK_REGISTRY.json")
    requirements = "\n".join([
        f"numpy=={numpy.__version__}", f"pandas=={pandas.__version__}",
        f"scikit-learn=={sklearn.__version__}", f"safetensors=={safetensors.__version__}",
        f"matplotlib=={matplotlib.__version__}", "",
    ])
    (stage / "requirements.txt").write_text(requirements, encoding="utf-8")
    runner = """#!/usr/bin/env bash
set -euo pipefail
: "${TDC_RUN_ROOT:?set TDC_RUN_ROOT to a new writable run directory}"
: "${TDC_BASE_ROOT:?set TDC_BASE_ROOT to the unpacked historical base containing E1/E7/metrics}"
: "${TDC_SUPPLEMENT_ROOT:?set TDC_SUPPLEMENT_ROOT to the unpacked supplement containing E14/E15/E16}"
: "${TDC_UNFILTERED_PREDICTION_ROOT:?set TDC_UNFILTERED_PREDICTION_ROOT to the unpacked *_all.csv directory}"
export CUDA_VISIBLE_DEVICES=""
export OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
python3 code/run_c02.py
python3 code/run_c03_c05a_c09.py
python3 code/run_c07_c08.py
python3 code/run_cache_cpu_tasks.py --mode smoke
python3 code/run_cache_cpu_tasks.py --mode full
"""
    (stage / "run_no_gpu.sh").write_text(runner, encoding="utf-8")
    (stage / "README.md").write_text("""# TDC revision release candidate

This is a non-published analysis release candidate for the validated NO_GPU revision tasks. It does not include licensed raw videos, checkpoints, or the large probability cache; obtain the dependencies listed in `DATA_ARTIFACTS.csv` and verify them against `SOURCE_HASHES.csv`.

Set `TDC_RUN_ROOT`, `TDC_BASE_ROOT`, `TDC_SUPPLEMENT_ROOT`, and `TDC_UNFILTERED_PREDICTION_ROOT`; install `requirements.txt`, then run `bash run_no_gpu.sh`. A00 provenance validation and the separately validated C01 reuse must be supplied before the downstream scripts. GPU tasks are intentionally excluded and remain unauthorized in this stage.

Do not treat this candidate as a submitted or public release. Model/data licensing and the unresolved GPU experiments must be reviewed first.
""", encoding="utf-8")
    files = []
    for path in sorted(stage.rglob("*")):
        if path.is_file() and path.name != "release_manifest.json":
            relative = path.relative_to(stage).as_posix()
            files.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path)})
    write_json(stage / "release_manifest.json", {"format_version": 1, "generated_at": now(),
        "status": "candidate_not_published", "gpu_scope_included": False, "files": files})
    archive_path = EXPORTS / "RELEASE_CANDIDATE.zip"
    temp = archive_path.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temp, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
        add_tree(archive, stage, "")
    os.replace(temp, archive_path)
    return archive_path


def main() -> None:
    scientific = json.loads((RUN / "validation/NO_GPU_scientific_validation.json").read_text())
    if not scientific.get("passed"):
        raise RuntimeError("Scientific validation must pass before export")
    EXPORTS.mkdir(parents=True, exist_ok=True)
    create_source_hashes()
    cache_artifacts = create_cache_volumes()
    create_data_artifacts(cache_artifacts)
    repro = create_repro_core()
    release = create_release_candidate()
    review = create_review_package()
    packages = [review, repro, release, *sorted((EXPORTS / "data_volumes").glob("*.zip"))]
    rows = [{"archive": path.name if path.parent == EXPORTS else f"data_volumes/{path.name}",
             "absolute_path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in packages]
    write_csv(EXPORTS / "PACKAGE_INDEX.csv", pd.DataFrame(rows))
    write_json(RUN / "validation/export_summary.json", {"passed": True, "archives": len(rows),
        "review_package": str(review), "repro_core": str(repro), "cache_volumes": len(cache_artifacts),
        "total_bytes": int(sum(row["bytes"] for row in rows))})
    print(json.dumps(json.loads((RUN / "validation/export_summary.json").read_text()), indent=2))


if __name__ == "__main__":
    main()
