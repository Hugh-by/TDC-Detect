#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"; LOG="$RUN/logs/G05_full_corrected"; mkdir -p "$LOG"; pids=()
for spec in "0 csn_r101" "1 mvit_base_16x4" "2 slowfast_r50" "3 x3d_m"; do read -r gpu model <<<"$spec"; uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i "$gpu"|tr -d ' ')"; CUDA_VISIBLE_DEVICES="$gpu" TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 python "$RUN/code/run_g05_v2_worker.py" --model "$model" >"$LOG/$model.log" 2>&1 & pids+=("$!"); done
failed=0; for pid in "${pids[@]}"; do wait "$pid" || failed=1; done; [[ "$failed" == 0 ]]
python "$RUN/code/finalize_g05_v2.py" >"$LOG/finalize.log" 2>&1
grep -q '"passed": true' "$RUN/results/G05/full_corrected/validation.json"
echo G05_FULL_CORRECTED_COMPLETE >"$LOG/COMPLETE"
