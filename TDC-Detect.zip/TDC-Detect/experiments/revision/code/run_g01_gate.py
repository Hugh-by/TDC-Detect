#!/usr/bin/env python3
"""Run the G01 exact-forward and gradient gate for one action model."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path(os.environ.get("TDC_PROJECT_ROOT", "/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master"))
BASE = Path(os.environ.get("TDC_BASE_ROOT", "/root/autodl-tmp/tsc/outputs/tdc-final-20260714"))
PROTOCOL = Path(os.environ.get("TDC_PROTOCOL_ROOT", "/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714"))
CLASSES = Path(os.environ.get("TDC_CLASS_MANIFEST", "/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv"))
if str(PROJECT) not in sys.path:
    sys.path.insert(0, str(PROJECT))
if str(RUN / "code") not in sys.path:
    sys.path.insert(0, str(RUN / "code"))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import (
    DetectorState, FullDetector, aggregate_features, build_text_features, detector_logit,
)
from TSC_Detect.attack_rgb import prepare_attack_frames, probabilities
from TSC_Detect.run_tsc_detect import load_real_models, score_frames
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g01-20261023-v1"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def args_for_score(model: str):
    return argparse.Namespace(
        seed=20260714, protocol_id="tdc-final-20260714",
        num_frames=ACTION_MODEL_PROFILES[model].num_frames, num_random=0,
        max_global_views=None, base_views_only=False, num_local_windows=4,
        local_window_frames=None, mock_models=False,
        prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
        prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8,
    )


def variants(clean: torch.Tensor, action_model, model: str, seed: int):
    generator = torch.Generator(device=clean.device).manual_seed(seed)
    noise = torch.empty_like(clean).uniform_(-1 / 255, 1 / 255, generator=generator)
    random_value = (clean + noise).clamp(0, 1).detach()
    adv = clean.detach().clone().requires_grad_(True)
    p = probabilities(action_model, adv, model)[0]
    label = int(p.detach().argmax())
    loss = -p[label].clamp_min(1e-12).log()
    grad = torch.autograd.grad(loss, adv)[0]
    small_adv = (clean + grad.sign() / 255).clamp(0, 1).detach()
    return {"clean": clean, "random_1_255": random_value, "small_adv_1_255": small_adv}


def toy_vjp_check(state: DetectorState, device: torch.device) -> dict:
    torch.manual_seed(731)
    x = torch.randn(37, device=device, dtype=torch.float64, requires_grad=True)
    shapes = ((5, 400), (5, 400), (4, 400), (4, 400))
    matrices = [torch.randn((n * c, len(x)), device=device, dtype=torch.float64) / 20 for n, c in shapes]

    def responses(value):
        return [(matrix @ value).reshape(shape).softmax(-1) for matrix, shape in zip(matrices, shapes)]

    direct_responses = responses(x)
    direct = detector_logit(aggregate_features(*direct_responses), state)
    direct_grad = torch.autograd.grad(direct, x)[0]
    detached = [r.detach().requires_grad_(True) for r in direct_responses]
    small = detector_logit(aggregate_features(*detached), state)
    adjoints = torch.autograd.grad(small, detached)
    recomputed = responses(x)
    vjp = sum((r * a).sum() for r, a in zip(recomputed, adjoints))
    vjp_grad = torch.autograd.grad(vjp, x)[0]
    absolute = float((direct_grad - vjp_grad).abs().max())
    relative = absolute / max(float(direct_grad.abs().max()), 1e-30)
    return {
        "graph": "toy full 21-D aggregator with four differentiable response tensors",
        "max_absolute_gradient_error": absolute,
        "max_relative_gradient_error": relative,
        "cosine_similarity": float(torch.nn.functional.cosine_similarity(direct_grad, vjp_grad, dim=0)),
        "passed": bool(absolute <= 1e-9 and relative <= 1e-8),
    }


def aggregator_gradient_audit(state: DetectorState, device: torch.device) -> dict:
    torch.manual_seed(991)
    raw = [torch.rand(shape, device=device, dtype=torch.float64) for shape in ((5, 400), (5, 400), (4, 400), (4, 400))]
    response = [(x / x.sum(-1, keepdim=True)).requires_grad_(True) for x in raw]
    features = aggregate_features(*response)
    groups = {
        "action": ["R_model", "R_label_change", "R_conf_var", "R_uniform_shift"],
        "clip": ["R_vlm"],
        "semantic": ["vlad_original", "R_sem_mean", "R_sem_max", "R_sem_var"],
        "fft": [name for name in FEATURES if name.startswith("R_fft_")],
        "local": [name for name in FEATURES if name.startswith("R_local_")],
    }
    result = {}
    for group, names in groups.items():
        scalar = sum(features[name] for name in names)
        grads = torch.autograd.grad(scalar, response, retain_graph=True, allow_unused=True)
        norms = [0.0 if value is None else float(value.norm()) for value in grads]
        result[group] = {"response_gradient_norms": norms, "finite": all(np.isfinite(norms)), "connected": any(x > 0 for x in norms)}
    direction = [torch.randn_like(x) for x in response]

    def continuous_logit(values):
        current = aggregate_features(*values)
        vector = torch.stack([current[name].to(torch.float64) for name in state.feature_order])
        contribution = ((vector - state.scaler_mean) / state.scaler_scale) * state.coef
        # Restrict numerical differentiation to globally smooth response terms.
        # Hard labels and max/top-k confidence features are audited for graph
        # connectivity but are intentionally excluded from finite differences.
        smooth = {
            "R_model", "R_uniform_shift", "R_fft_vlad_high", "R_fft_vlad_entropy",
            "R_vlm", "vlad_original", "R_sem_mean", "R_sem_var",
            "R_fft_sem_high", "R_fft_sem_entropy",
        }
        contribution = torch.stack([
            value if name in smooth else value * 0.0
            for name, value in zip(state.feature_order, contribution)
        ])
        return contribution.sum() + state.intercept

    # Account for the normalization in the finite-difference path by applying it in autograd too.
    base = [x.detach().clone().requires_grad_(True) for x in response]
    normalized = [x / x.sum(-1, keepdim=True) for x in base]
    normalized_logit = continuous_logit(normalized)
    normalized_grad = torch.autograd.grad(normalized_logit, base)
    analytic = sum((g * d).sum() for g, d in zip(normalized_grad, direction))
    sweep = []
    for eps in (1e-6, 3e-7, 1e-7, 3e-8, 1e-8, 3e-9, 1e-9):
        plus = [((x.detach() + eps * d).clamp_min(1e-10)) for x, d in zip(response, direction)]
        minus = [((x.detach() - eps * d).clamp_min(1e-10)) for x, d in zip(response, direction)]
        plus = [x / x.sum(-1, keepdim=True) for x in plus]
        minus = [x / x.sum(-1, keepdim=True) for x in minus]
        finite = (continuous_logit(plus) - continuous_logit(minus)) / (2 * eps)
        relative = float(abs(analytic - finite) / max(abs(float(finite)), 1e-12))
        sweep.append({"epsilon": eps, "finite_difference": float(finite), "relative_error": relative})
    selected = min(sweep, key=lambda row: row["relative_error"])
    finite = torch.as_tensor(selected["finite_difference"], device=device, dtype=torch.float64)
    result["continuous_finite_difference"] = {
        "included_smooth_terms": [
            "R_model", "R_uniform_shift", "R_fft_vlad_high", "R_fft_vlad_entropy",
            "R_vlm", "vlad_original", "R_sem_mean", "R_sem_var",
            "R_fft_sem_high", "R_fft_sem_entropy",
        ],
        "excluded_from_finite_difference": "hard-label and max/top-k-derived terms; separately checked for connectivity",
        "analytic_directional_derivative": float(analytic),
        "finite_difference": float(finite),
        "absolute_error": float(abs(analytic - finite)),
        "relative_error": float(abs(analytic - finite) / max(abs(float(finite)), 1e-12)),
        "central_difference_sweep": sweep,
        "selection_rule": "minimum relative error over a fixed predeclared central-difference step sweep",
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=("csn_r101", "mvit_base_16x4"), required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--max-sources", type=int, default=3)
    args = parser.parse_args()
    device = torch.device(args.device)
    output = RUN / "results" / "G01" / args.model
    output.mkdir(parents=True, exist_ok=True)
    log = RUN / "logs" / f"G01_{args.model}.json"
    started = time.time()
    physical_uuid = os.environ.get("TDC_GPU_UUID", "unknown")

    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    scores = score_lr(pipeline, calibration, FEATURES)
    threshold = threshold_from_clean(calibration, scores)
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    class_names = read_class_names(CLASSES)
    manifest_path = PROTOCOL / "manifests" / f"k400_{args.model}_calibration_fixed20.csv"
    manifest = pd.read_csv(manifest_path).sort_values("relative_path").head(args.max_sources)

    torch.manual_seed(20260714)
    torch.cuda.manual_seed_all(20260714)
    torch.backends.cudnn.benchmark = False
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters():
        parameter.requires_grad_(False)
    for parameter in clip_model.parameters():
        parameter.requires_grad_(False)
    text = build_text_features(clip_model, processor, class_names, device)
    detector = FullDetector(action_model, clip_model, processor, text, args.model, state)
    score_args = args_for_score(args.model)

    records = []
    gradient_samples = []
    for source_rank, row in enumerate(manifest.itertuples(index=False), 1):
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        for variant_name, value in variants(clean, action_model, args.model, 20260714 + source_rank).items():
            torch.cuda.reset_peak_memory_stats(device)
            old_started = time.perf_counter()
            old = score_frames(value.detach().cpu().numpy(), class_names, score_args, action_model, clip_model, processor, device, str(row.path))
            torch.cuda.synchronize(device)
            old_seconds = time.perf_counter() - old_started
            new_started = time.perf_counter()
            new, logit, score, _, _ = detector.exact_forward(value)
            torch.cuda.synchronize(device)
            new_seconds = time.perf_counter() - new_started
            new_values = {name: float(new[name]) for name in FEATURES}
            max_error = max(abs(float(old[name]) - new_values[name]) for name in FEATURES)
            for name in FEATURES:
                old_value, new_value = float(old[name]), new_values[name]
                records.append({
                    "protocol_id": PROTOCOL_ID, "action_model": args.model,
                    "source_rank": source_rank, "relative_path": row.relative_path,
                    "variant": variant_name, "feature": name,
                    "legacy_value": old_value, "new_value": new_value,
                    "absolute_error": abs(old_value - new_value),
                    "relative_error": abs(old_value - new_value) / max(abs(old_value), 1e-30),
                    "detector_logit": float(logit), "detector_score": float(score),
                    "threshold": threshold, "decision": int(float(score) > threshold),
                    "legacy_seconds": old_seconds, "new_seconds": new_seconds,
                    "peak_memory_bytes": torch.cuda.max_memory_allocated(device),
                    "gpu_uuid": physical_uuid,
                })
            print(json.dumps({"model": args.model, "source": source_rank, "variant": variant_name, "max_feature_error": max_error}), flush=True)

        grad_input = clean.detach().clone().requires_grad_(True)
        torch.cuda.reset_peak_memory_stats(device)
        grad_started = time.perf_counter()
        features, logit, score, gradient, adjoints = detector.logit_and_vjp_gradient(grad_input)
        torch.cuda.synchronize(device)
        elapsed = time.perf_counter() - grad_started
        gradient_samples.append({
            "source_rank": source_rank, "relative_path": row.relative_path,
            "detector_logit": float(logit), "detector_score": float(score),
            "input_gradient_norm": float(gradient.norm()),
            "input_gradient_max_abs": float(gradient.abs().max()),
            "input_gradient_finite": bool(torch.isfinite(gradient).all()),
            "seconds": elapsed, "peak_memory_bytes": torch.cuda.max_memory_allocated(device),
            "motion_indices": [int(x) for x in __import__("gpu_full_detector").view_indices(clean)["motion_aware"].cpu()],
            **adjoints,
        })
        print(json.dumps({"model": args.model, "source": source_rank, "gradient_seconds": elapsed, "gradient_norm": float(gradient.norm())}), flush=True)

    frame = pd.DataFrame(records)
    temp = output / "forward_equivalence.csv.tmp"
    frame.to_csv(temp, index=False)
    os.replace(temp, output / "forward_equivalence.csv")
    tolerance = 1e-5 + 1e-4 * frame.legacy_value.abs()
    forward_pass = bool((frame.absolute_error <= tolerance).all())
    branch = aggregator_gradient_audit(state, device)
    vjp = toy_vjp_check(state, device)
    finite_ok = all(x["input_gradient_finite"] and x["input_gradient_norm"] > 0 for x in gradient_samples)
    connected_ok = all(item["connected"] and item["finite"] for key, item in branch.items() if key != "continuous_finite_difference")
    finite_difference_ok = branch["continuous_finite_difference"]["relative_error"] <= 5e-4
    audit = {
        "protocol_id": PROTOCOL_ID, "model": args.model, "gpu_uuid": physical_uuid,
        "forward_equivalence_passed": forward_pass,
        "forward_max_absolute_error": float(frame.absolute_error.max()),
        "forward_rows": len(frame), "source_count": len(manifest),
        "variants": sorted(frame.variant.unique()),
        "response_branch_audit": branch, "actual_vjp_samples": gradient_samples,
        "actual_input_gradients_passed": finite_ok,
        "response_branches_connected": connected_ok,
        "continuous_finite_difference_passed": finite_difference_ok,
        "vjp_comparison_passed": vjp["passed"],
        "passed": bool(forward_pass and finite_ok and connected_ok and finite_difference_ok and vjp["passed"]),
    }
    atomic_json(output / "gradient_audit.json", audit)
    atomic_json(output / "vjp_comparison.json", vjp)
    (output / "approximation_list.md").write_text(
        "# G01 BPDA approximation list\n\n"
        "- CLIP uint8 quantization: exact quantized forward with differentiable resize/normalize surrogate backward.\n"
        "- Motion-aware indices: recomputed from every current candidate for the exact forward; current indices are fixed locally in backward.\n"
        "- Hard label-change: exact hard-count forward with temperature-0.05 soft-count backward.\n"
        "- max/top-k: native PyTorch subgradient; ties are not randomized.\n"
        "- No random transforms are used; this implementation is not described as EOT.\n",
        encoding="utf-8",
    )
    atomic_json(log, {
        "status": "complete" if audit["passed"] else "failed", "protocol_id": PROTOCOL_ID,
        "model": args.model, "gpu_uuid": physical_uuid, "device": str(device),
        "torch": torch.__version__, "python": platform.python_version(),
        "manifest": str(manifest_path), "manifest_sha256": sha256(manifest_path),
        "e1_calibration_sha256": sha256(BASE / "E1" / f"k400_{args.model}_calibration.csv"),
        "elapsed_seconds": time.time() - started, "result": str(output),
    })
    print(json.dumps({"model": args.model, "G01_passed": audit["passed"], "output": str(output)}), flush=True)
    if not audit["passed"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
