#!/usr/bin/env python3
"""C02 reuse-based matched-budget, cost, and transfer metric verification."""

from __future__ import annotations

import json
import resource
import time

import numpy as np
import pandas as pd

from cpu_common import (
    ATTACKS, BASE, MODELS, RUN, SEED, SUPP, bootstrap_macro, condition, metric,
    write_csv, write_csv_gz, write_json,
)

PROTOCOL = "tdc-r3r5-c02-20261022-v1"
METHODS = ["Single-view discrepancy-LR", "Nine-view discrepancy-LR", "Nine-view action-shift-LR",
           "Nine-view semantic-shift-LR", "TDC-v2"]
CONTRASTS = [("TDC-v2", "Nine-view discrepancy-LR"), ("TDC-v2", "Nine-view action-shift-LR")]


def score_lookup(full: pd.DataFrame, column: str, selected: pd.DataFrame) -> np.ndarray:
    lookup = pd.Series(full[column].to_numpy(float), index=pd.MultiIndex.from_arrays(
        [full.pair_id.astype(str), full.attack.astype(str)]))
    return lookup.loc[list(zip(selected.pair_id.astype(str), selected.attack.astype(str)))].to_numpy(float)


def run() -> None:
    if not json.loads((RUN / "validation/A00.json").read_text()).get("all_a00_gates_passed"):
        raise RuntimeError("A00 gate has not passed")
    started = time.perf_counter()
    result = RUN / "results/C02"
    result.mkdir(parents=True, exist_ok=True)
    write_json(RUN / "protocols/C02.json", {
        "protocol_id": PROTOCOL, "task_id": "C02", "mode": "NO_GPU", "seed": SEED,
        "source_protocols": ["tdc-final-20260714", "tdc-supplement-20260817"],
        "new_model_fits": False, "metrics_recomputed_from_saved_scores": True,
        "primary_contrasts": [f"{a} - {b}" for a, b in CONTRASTS],
        "bootstrap": "1000 paired dataset+relative_path clusters shared across models/methods; fixed saved scores",
        "runtime_policy": "historical E9/E14 measurements remain separate by provenance and are not a new controlled timing experiment",
        "gpu_used": False,
    })

    source = pd.read_csv(SUPP / "E14/matched_budget_scores.csv", low_memory=False)
    score_parts, metric_rows, payloads = [], [], []
    for (dataset, model), test in source.groupby(["dataset", "model"], sort=True):
        test = test.copy()
        test["action_model"] = model
        test["dataset"] = dataset
        thresholds = {method: float(test[f"threshold__{method}"].iloc[0]) for method in METHODS}
        for method in METHODS:
            part = test[["dataset", "model", "partition", "pair_id", "relative_path", "attack",
                         "is_adv", "attack_success"]].copy()
            part.insert(0, "run_id", PROTOCOL)
            part["task_id"] = "C02"
            part["source_id"] = part.relative_path.astype(str)
            part["method"] = method
            part["config"] = "matched_budget_historical"
            part["score"] = test[method].to_numpy(float)
            part["score_domain"] = "probability"
            part["threshold"] = thresholds[method]
            part["predicted_adv"] = (part.score > thresholds[method]).astype(int)
            score_parts.append(part)
        for attack in (*ATTACKS, "pooled"):
            for setting in ("full", "success-only"):
                selected = condition(test, attack, setting)
                for method in METHODS:
                    stats = metric(selected.is_adv.to_numpy(int), score_lookup(test, method, selected), thresholds[method])
                    stats["n_sources"] = int(selected.relative_path.nunique())
                    metric_rows.append({
                        "run_id": PROTOCOL, "task_id": "C02", "evaluation_protocol": "independent_calibration_test",
                        "dataset": dataset, "model": model, "method": method, "config": "matched_budget_historical",
                        "attack": attack, "setting": setting, "threshold": thresholds[method], **stats,
                    })
        selected = condition(test, "pooled", "full")
        payloads.append({
            "dataset": dataset, "model": model, "attack": "pooled", "setting": "full",
            "clusters": [f"{dataset}|{path}" for path in selected.relative_path.astype(str)],
            "labels": selected.is_adv.to_numpy(int),
            "scores": {method: score_lookup(test, method, selected) for method in METHODS},
        })

    scores = pd.concat(score_parts, ignore_index=True)
    metrics = pd.DataFrame(metric_rows)
    write_csv_gz(result / "sample_scores.csv.gz", scores)
    write_csv(result / "condition_metrics.csv", metrics)
    differences, replicates = bootstrap_macro(payloads, CONTRASTS, PROTOCOL, "C02")
    write_csv(result / "paired_differences.csv", differences)
    write_csv_gz(result / "bootstrap_replicates.csv.gz", replicates)

    old_boot = pd.read_csv(SUPP / "E14/matched_budget_bootstrap_summary.csv")
    old_metrics = pd.read_csv(SUPP / "E14/matched_budget_metrics.csv")
    definitions = []
    for right, label in [("Nine-view action-shift-LR", "action_shift"),
                         ("Nine-view discrepancy-LR", "discrepancy")]:
        selected_metrics = old_metrics[(old_metrics.attack == "pooled") & (old_metrics.setting == "full")]
        pivot = selected_metrics.pivot_table(index=["dataset", "model"], columns="method", values="roc_auc")
        point = float((pivot["TDC-v2"] - pivot[right]).mean())
        comparison = f"TDC-v2 - {right}"
        selected_boot = old_boot[(old_boot.attack == "pooled") & (old_boot.setting == "full") &
                                 (old_boot.comparison == comparison)]
        historical_boot_mean = float(selected_boot.auc_difference_mean.mean())
        new_macro = differences[(differences.condition_scope == "macro") &
                                (differences.method_b == right)].iloc[0]
        definitions.extend([
            {"estimate_id": f"{label}_point_macro", "contrast": comparison,
             "definition": "mean of eight dataset-model pooled/full point AUC differences",
             "value": point, "round4": round(point, 4), "source": "recomputed E14 saved sample scores"},
            {"estimate_id": f"{label}_historical_condition_bootstrap_mean_macro", "contrast": comparison,
             "definition": "mean of eight historical per-condition paired-bootstrap mean differences",
             "value": historical_boot_mean, "round4": round(historical_boot_mean, 4),
             "source": "E14 matched_budget_bootstrap_summary.csv"},
            {"estimate_id": f"{label}_new_shared_cluster_macro_bootstrap_mean", "contrast": comparison,
             "definition": "new joint macro bootstrap; same dataset/path weight shared across models",
             "value": float(new_macro.bootstrap_mean), "round4": round(float(new_macro.bootstrap_mean), 4),
             "source": "C02 bootstrap_replicates.csv.gz"},
        ])
    write_csv(result / "estimate_definitions.csv", pd.DataFrame(definitions))

    e9 = pd.read_csv(BASE / "metrics/E9_runtime_memory.csv")
    e9["source_table"] = "tdc-final-20260714/E9_runtime_memory.csv"
    e9["measurement_batch"] = "historical_E9"
    e9["timing_boundary_note"] = "predecoded feature-scoring path; excludes video decode and final LR predict_proba"
    e14 = pd.read_csv(SUPP / "E14/runtime_memory.csv")
    e14["source_table"] = "tdc-supplement-20260817/E14/runtime_memory.csv"
    e14["measurement_batch"] = e14.runtime_provenance
    e14["timing_boundary_note"] = "isolated serial-view GPU feature path; mixed new and reused E9 rows; not a new same-batch comparison"
    common_columns = sorted(set(e9.columns) | set(e14.columns))
    historical_cost = pd.concat([e9.reindex(columns=common_columns), e14.reindex(columns=common_columns)], ignore_index=True)
    write_csv(result / "historical_cost.csv", historical_cost)

    transfer_parts = []
    e3 = pd.read_csv(BASE / "metrics/E3_leave_one_model_out.csv")
    e3 = e3[e3.method == "TDC-v2"].copy(); e3["source_experiment"] = "E3_leave_one_model_out"
    e3["model"] = e3.held_model; e3["train_dataset"] = "mixed_other_models"; e3["test_dataset"] = e3.dataset
    transfer_parts.append(e3)
    e4 = pd.read_csv(BASE / "metrics/E4_cross_dataset_transfer.csv")
    e4 = e4[e4.method == "TDC-v2"].copy(); e4["source_experiment"] = "E4_cross_dataset_transfer"
    transfer_parts.append(e4)
    e15 = pd.read_csv(SUPP / "E15/cross_domain_branch_ablation.csv")
    e15["source_experiment"] = "E15_cross_domain_branch_ablation"
    transfer_parts.append(e15)
    transfer = pd.concat(transfer_parts, ignore_index=True, sort=False)
    transfer["deployment_note"] = "threshold frozen from stated source calibration; test FPR is observed, not forced to 1%"
    write_csv(result / "transfer_threshold_metrics.csv", transfer)

    e15_boot = pd.read_csv(SUPP / "E15/branch_ablation_bootstrap_summary.csv")
    e15_metric = pd.read_csv(SUPP / "E15/cross_domain_branch_ablation.csv")
    e15_full = e15_metric[e15_metric.setting == "full"].pivot_table(index="model", columns="method", values="roc_auc")
    transfer_summary = {
        "point_mean_full_minus_without_semantic": float((e15_full["TDC-v2"] - e15_full["TDC-v2 without semantic"]).mean()),
        "historical_bootstrap_mean_full_minus_without_semantic": float(e15_boot[
            (e15_boot.protocol == "k400_to_ucf101") & (e15_boot.setting == "full") &
            (e15_boot.right_method == "TDC-v2 without semantic")].auc_difference_mean.mean()),
        "models": int(len(e15_full)),
    }
    write_json(result / "transfer_summary.json", transfer_summary)

    source_metrics = pd.read_csv(SUPP / "E14/matched_budget_metrics.csv")
    key = ["dataset", "model", "attack", "setting", "method"]
    merged = metrics.merge(source_metrics, on=key, suffixes=("_new", "_historical"), validate="one_to_one")
    errors = {}
    for column in ("roc_auc", "pr_auc", "threshold_fpr", "threshold_tpr"):
        errors[column] = float(np.max(np.abs(merged[f"{column}_new"] - merged[f"{column}_historical"])))
    validation = {
        "protocol_id": PROTOCOL, "task_id": "C02", "sample_score_rows": len(scores),
        "condition_metric_rows": len(metrics), "historical_metric_reproduction_max_abs_error": errors,
        "all_scores_finite": bool(np.isfinite(scores.score.to_numpy(float)).all()),
        "paired_bootstrap_replicates": 1000, "gpu_used": False, "new_model_fits": False,
        "elapsed_seconds": time.perf_counter() - started,
        "max_rss_kib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    }
    validation["passed"] = max(errors.values()) <= 1e-12 and validation["all_scores_finite"]
    write_json(RUN / "validation/C02.json", validation)
    print(json.dumps(validation, indent=2), flush=True)


if __name__ == "__main__":
    run()
