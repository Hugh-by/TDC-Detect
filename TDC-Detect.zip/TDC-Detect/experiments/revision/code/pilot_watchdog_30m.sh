#!/usr/bin/env bash
set -uo pipefail

RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
LOGS="$RUN/logs"
INTERVAL_SECONDS="${WATCHDOG_INTERVAL_SECONDS:-1800}"
LOCK="$LOGS/pilot_watchdog.lock"

mkdir -p "$LOGS"
exec 9>"$LOCK"
if ! flock -n 9; then
  echo "$(date -u '+%F %T UTC') watchdog_already_running"
  exit 0
fi

check_validation() {
  python - "$RUN/results/G03/pilot/validation.json" <<'PY'
import json, sys
from pathlib import Path
p = Path(sys.argv[1])
try:
    d = json.loads(p.read_text())
    print("pass" if d.get("passed") is True and d.get("rows") == 1680 else "fail")
except Exception:
    print("missing")
PY
}

while true; do
  now="$(date -u '+%F %T UTC')"
  shards="$(find "$RUN/results/G03/pilot/shards" -name '*.csv.gz' 2>/dev/null | wc -l)"
  validation="$(check_validation)"
  queue="stopped"
  if pgrep -f "$RUN/code/run_g03_pilot_queue.sh" >/dev/null 2>&1; then
    queue="running"
  fi
  echo "$now stage=GPU_PILOT g03_shards=$shards/14 validation=$validation queue=$queue"

  # Resume only the already-authorized pilot queue. The queue skips completed shards.
  if [[ "$validation" != "pass" && "$queue" == "stopped" ]]; then
    echo "$now action=resume_G03_pilot"
    nohup "$RUN/code/run_g03_pilot_queue.sh" >>"$LOGS/G03_watchdog_resume.log" 2>&1 </dev/null &
  fi

  # Rebuild CPU-only reports/packages if pilot evidence is complete but an artifact is absent.
  if [[ "$validation" == "pass" ]]; then
    if [[ ! -s "$RUN/reports/PILOT_REPORT.md" || ! -s "$RUN/reports/BUDGET_OPTIONS.csv" ]]; then
      echo "$now action=rebuild_pilot_report"
      python "$RUN/code/consolidate_gpu_pilots.py" >>"$LOGS/consolidate_gpu_pilots_watchdog.log" 2>&1 &&
        python "$RUN/code/build_gpu_pilot_report.py" >>"$LOGS/build_gpu_pilot_report_watchdog.log" 2>&1
    fi
    if [[ ! -s "$RUN/exports/GPU_PILOT_PACKAGE_INDEX.json" ||
          ! -s "$RUN/exports/GPU_PILOT_REVIEW_PACKAGE.zip" ||
          ! -s "$RUN/exports/GPU_PILOT_REPRO_PACKAGE.zip" ]]; then
      echo "$now action=rebuild_pilot_exports"
      python "$RUN/code/prepare_gpu_pilot_export.py" >>"$LOGS/prepare_gpu_pilot_export_watchdog.log" 2>&1
    fi
  fi

  # GPU_FULL remains deliberately gated on explicit user scope selection.
  echo "$now gpu_full=deferred_budget next_check_seconds=$INTERVAL_SECONDS"
  sleep "$INTERVAL_SECONDS"
done
