#!/usr/bin/env python3
"""Build a review ZIP containing only tasks completed through G02 GPU_FULL."""

from __future__ import annotations

import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
EXPORTS = RUN / "exports"
NAME = "COMPLETED_TASKS_REVIEW_20261025.zip"

COMPLETED = [
    "A00", "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C09", "D01",
    "G01", "G02_PILOT", "G03_PILOT", "G04_PILOT", "G05_PILOT", "G02_FULL_OPTION_B",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def include_roots() -> list[Path]:
    roots = [RUN / name for name in ("reports", "protocols", "validation", "provenance", "manifests", "models", "figures", "code", "environment")]
    roots += [RUN / "results" / task for task in ("A00", "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C09", "D01", "G01")]
    roots += [RUN / "results/G02/pilot", RUN / "results/G02/full", RUN / "results/G03/pilot", RUN / "results/G04/pilot", RUN / "results/G05/pilot"]
    return roots


def included_files() -> list[Path]:
    files: set[Path] = set()
    for root in include_roots():
        if not root.exists():
            continue
        if root.is_file():
            files.add(root)
            continue
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            relative = path.relative_to(RUN)
            if path.suffix == ".pt" or "temporary_best" in relative.parts:
                continue
            if "__pycache__" in relative.parts or path.suffix in (".pyc", ".tmp", ".lock"):
                continue
            files.add(path)
    for name in ("README.md", "DATA_ARTIFACTS.csv", "SOURCE_HASHES.csv"):
        path = RUN / name
        if path.exists(): files.add(path)
    return sorted(files, key=lambda path: path.relative_to(RUN).as_posix())


def main() -> None:
    g02_validation = json.loads((RUN / "results/G02/full/validation.json").read_text())
    if not (g02_validation.get("passed") and g02_validation.get("observed_trajectories") == 1560 and g02_validation.get("selected_adv") == 400):
        raise RuntimeError("G02 full validation gate is not satisfied")
    if not json.loads((RUN / "validation/NO_GPU_scientific_validation.json").read_text()).get("passed"):
        raise RuntimeError("NO_GPU validation gate is not satisfied")

    files = included_files()
    manifest_files = [{"path": path.relative_to(RUN).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in files]
    generated = datetime.now(timezone.utc).isoformat()
    status = {
        "format_version": 1,
        "run_id": RUN.name,
        "stage": "INTERIM_COMPLETED_TASKS_THROUGH_G02_FULL",
        "scope_complete": True,
        "overall_revision_complete": False,
        "generated_at": generated,
        "completed_tasks": COMPLETED,
        "running_tasks": {"G04_FULL": "running; excluded from this archive"},
        "pending_tasks": {"G05_FULL": "not_started", "C08": "blocked_until_G05", "G03_FULL": "not_started", "FINAL_EXPORT": "not_started"},
        "deferred_tasks": {"G06": "deferred_optional_cache_complete", "G07": "not_authorized"},
    }
    manifest = {**status, "files": manifest_files}
    external = {
        "review_package_omissions": [
            {
                "logical_role": "G02_FULL selected adversarial lossless tensors",
                "reason": "400 tensors total approximately 5.4 GiB; retained server-side for final <=2 GiB reproducibility volumes",
                "server_roots": [str(RUN / "results/G02/full/csn_r101/selected_adv"), str(RUN / "results/G02/full/mvit_base_16x4/selected_adv")],
                "index_in_archive": "results/G02/full/selected_adv_index.csv",
                "count": 400,
            }
        ]
    }
    readme = """# Interim completed-tasks review package

This archive contains only tasks validated as complete through G02 GPU_FULL option B. G04 full is currently running and is deliberately excluded; G05 full, C08 completion, and G03 full are pending. The archive is a review package, not the final complete reproduction package.

The 400 lossless G02 selected adversarial tensors remain on the server because they total about 5.4 GiB. Their per-file paths, sizes, and SHA256 values are included in `results/G02/full/selected_adv_index.csv`; final delivery will place them in documented volumes no larger than 2 GiB.
"""

    EXPORTS.mkdir(parents=True, exist_ok=True)
    target = EXPORTS / NAME
    temporary = target.with_suffix(target.suffix + ".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for source in files:
            archive.write(source, source.relative_to(RUN).as_posix())
        archive.writestr("STATUS.json", json.dumps(status, indent=2, sort_keys=True) + "\n")
        archive.writestr("export_manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")
        archive.writestr("EXTERNAL_ARTIFACTS.json", json.dumps(external, indent=2, sort_keys=True) + "\n")
        archive.writestr("README_EXPORT.md", readme)
    os.replace(temporary, target)
    index = {
        "generated_at": generated,
        "package": str(target),
        "bytes": target.stat().st_size,
        "sha256": sha256(target),
        "contained_files": len(files) + 4,
        "completed_tasks": COMPLETED,
        "excluded_running_task": "G04_FULL",
    }
    index_path = EXPORTS / "COMPLETED_TASKS_REVIEW_20261025.index.json"
    index_path.write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(index, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
