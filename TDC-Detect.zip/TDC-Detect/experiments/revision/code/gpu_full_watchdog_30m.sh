#!/usr/bin/env bash
set -uo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
LOGS="$RUN/logs"
INTERVAL="${WATCHDOG_INTERVAL_SECONDS:-1800}"
exec 9>"$LOGS/gpu_full_watchdog.lock"
flock -n 9 || exit 0

while true; do
  now="$(date -u '+%F %T UTC')"
  g02="$(find "$RUN/results/G02/full" -path '*/trajectory_shards/*.json' 2>/dev/null | wc -l)"
  g04="$(find "$RUN/results/G04/full" -path '*/source_shards/*.json' 2>/dev/null | wc -l)"
  g05="$(find "$RUN/results/G05/full" -path '*/shards/*.json' 2>/dev/null | wc -l)"
  g03="$(find "$RUN/results/G03/full/shards" -name '*.csv.gz' 2>/dev/null | wc -l)"
  active="$(pgrep -fc 'run_g0[2345]_full|run_gpu_full_b' || true)"
  echo "$now g02_trajectories=$g02/1560 g04_source_attacks=$g04/800 g05_clean=$g05/1600 g03_timing_shards=$g03/52 active_processes=$active"
  if [[ ! -s "$RUN/protocols/GPU_FULL_HOLD.json" ]] &&
     [[ ! -s "$LOGS/GPU_FULL_B_COMPLETE" ]] &&
     ! screen -list 2>/dev/null | grep -q '[.]tdc_gpu_full_b' &&
     ! screen -list 2>/dev/null | grep -q '[.]tdc_gpu_full_followup'; then
    echo "$now action=restart_followup"
    screen -DmS tdc_gpu_full_followup bash -lc "exec '$RUN/code/run_gpu_full_b_followup.sh'"
  fi
  df -h "$RUN" | tail -n 1 | awk -v now="$now" '{print now " disk_used=" $5 " disk_available=" $4}'
  echo "$now next_check_seconds=$INTERVAL"
  sleep "$INTERVAL"
done
