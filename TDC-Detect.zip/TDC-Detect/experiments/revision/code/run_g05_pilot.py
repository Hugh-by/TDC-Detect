#!/usr/bin/env python3
"""G05 pilot on a hash-fixed, prediction-unfiltered clean cohort."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
PREDICTIONS = Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct")
VALIDATION_ROOT = Path("/root/autodl-tmp/tsc/data/k400_full_fiftyone/fiftyone/kinetics-400/validation")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path: sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g05-pilot-20261023-v1"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")


def atomic_json(path: Path, value: object) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def relative(path: str) -> str:
    return str(Path(path).resolve().relative_to(VALIDATION_ROOT.resolve()))


def main() -> None:
    device = torch.device("cuda:0")
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results" / "G05" / "pilot"
    shards = output / "shards"
    output.mkdir(parents=True, exist_ok=True); shards.mkdir(parents=True, exist_ok=True)
    classes = read_class_names(CLASSES)
    cohort_rows = []
    for model in MODELS:
        frame = pd.read_csv(PREDICTIONS / f"{model}_all.csv")
        frame["relative_path"] = frame.path.map(relative)
        calibration = pd.read_csv(PROTOCOL / "manifests" / f"k400_{model}_calibration_fixed20.csv")
        excluded = set(calibration.relative_path.astype(str))
        frame = frame[~frame.relative_path.isin(excluded)].copy()
        frame["selection_hash"] = frame.relative_path.map(lambda x: hashlib.sha256(f"{PROTOCOL_ID}|{model}|{x}".encode()).hexdigest())
        selected = frame.sort_values(["selection_hash", "relative_path"]).head(3)
        for rank, row in enumerate(selected.itertuples(index=False), 1):
            cohort_rows.append({
                "protocol_id": PROTOCOL_ID, "action_model": model, "source_rank": rank,
                "relative_path": row.relative_path, "path": row.path, "selection_hash": row.selection_hash,
                "ground_truth": int(row.label_index), "ground_truth_name": row.label,
                "historical_clean_pred": int(row.pred_action), "historical_clean_correct": int(row.clean_correct),
                "sampling_rule": "lowest SHA256 after model-specific calibration exclusion; prediction/correctness not used",
            })
    cohort = pd.DataFrame(cohort_rows)
    cohort.to_csv(output / "cohort_manifest.csv", index=False)

    for model in MODELS:
        model_rows = cohort[cohort.action_model == model]
        calibration = load_e1("k400", model, "calibration")
        pipeline = fit_lr(calibration, FEATURES)
        threshold = threshold_from_clean(calibration, score_lr(pipeline, calibration, FEATURES))
        state = DetectorState.from_pipeline(pipeline, threshold, device)
        load_started = time.perf_counter()
        action_model, clip_model, processor = load_real_models(device, model)
        for parameter in action_model.parameters(): parameter.requires_grad_(False)
        for parameter in clip_model.parameters(): parameter.requires_grad_(False)
        text = build_text_features(clip_model, processor, classes, device)
        detector = FullDetector(action_model, clip_model, processor, text, model, state)
        torch.cuda.synchronize(device)
        load_seconds = time.perf_counter() - load_started
        for row in model_rows.itertuples(index=False):
            shard = shards / f"{model}_{row.source_rank}.json"
            if shard.exists() and json.loads(shard.read_text()).get("complete"):
                print(json.dumps({"reused": str(shard)}), flush=True); continue
            clean = prepare_attack_frames(load_frames(Path(row.path)), model, device).detach()
            torch.cuda.reset_peak_memory_stats(device)
            started = time.perf_counter()
            with torch.no_grad():
                features, logit, score, _, _ = detector.exact_forward(clean)
                prob = action_probs(action_model, clean, model)
            torch.cuda.synchronize(device)
            record = {
                "protocol_id": PROTOCOL_ID, "complete": True, "action_model": model,
                "gpu_uuid": gpu_uuid, "source_rank": int(row.source_rank), "relative_path": row.relative_path,
                "path": row.path, "ground_truth": int(row.ground_truth), "ground_truth_name": row.ground_truth_name,
                "historical_clean_pred": int(row.historical_clean_pred), "historical_clean_correct": int(row.historical_clean_correct),
                "clean_pred": int(prob.argmax()), "clean_conf": float(prob.max()),
                "correct_flag": int(prob.argmax()) == int(row.ground_truth),
                "detector_logit": float(logit), "score": float(score), "threshold": threshold,
                "false_positive": float(score) > threshold, "seconds": time.perf_counter() - started,
                "peak_memory_bytes": torch.cuda.max_memory_allocated(device), "model_load_seconds": load_seconds,
                "features": {name: float(features[name]) for name in FEATURES},
            }
            atomic_json(shard, record)
            print(json.dumps({"model": model, "source": row.source_rank, "score": float(score)}), flush=True)
        del detector, action_model, clip_model, processor, text
        torch.cuda.empty_cache()

    records = [json.loads(path.read_text()) for path in sorted(shards.glob("*.json"))]
    if len(records) != 12: raise RuntimeError(f"incomplete G05 pilot: {len(records)}/12")
    rows = [{key: item[key] for key in item if key not in ("features", "complete")} | item["features"] for item in records]
    clean = pd.DataFrame(rows)
    clean.to_csv(output / "clean_features.csv.gz", index=False, compression="gzip")
    clean[["protocol_id", "action_model", "source_rank", "relative_path", "ground_truth", "clean_pred", "correct_flag", "score", "threshold", "false_positive", "seconds", "gpu_uuid"]].to_csv(output / "clean_scores.csv.gz", index=False, compression="gzip")
    atomic_json(output / "validation.json", {
        "protocol_id": PROTOCOL_ID, "passed": bool(len(clean) == 12 and np.isfinite(clean[FEATURES + ["score"]]).all().all()),
        "rows": len(clean), "models": sorted(clean.action_model.unique()), "sources_per_model": 3,
        "calibration_overlap": 0, "prediction_used_for_selection": False,
        "historical_prediction_match": bool((clean.historical_clean_pred == clean.clean_pred).all()),
        "test_touched": False, "purpose": "timing and forward validation only; not an FPR estimate",
        "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"G05_pilot_complete": True, "output": str(output)}), flush=True)


if __name__ == "__main__": main()
