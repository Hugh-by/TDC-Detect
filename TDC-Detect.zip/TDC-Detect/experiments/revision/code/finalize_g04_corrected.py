#!/usr/bin/env python3
import json, math, sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

RUN=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01'); BASE=Path('/root/autodl-tmp/tsc/outputs/tdc-final-20260714/E1'); ROOT=RUN/'results/G04/full_corrected'; OUT=RUN/'results/G04/summary_corrected'; OUT.mkdir(parents=True,exist_ok=True); sys.path.insert(0,str(RUN/'code'))
from cpu_common import FEATURES
PROTOCOL='tdc-r3r5-g04-summary-corrected-20261026-v1'; models=('csn_r101','mvit_base_16x4','slowfast_r50','x3d_m')
def score(frame,state):
 x=frame[FEATURES].to_numpy(float); z=((x-np.asarray(state['scaler_mean']))/np.asarray(state['scaler_scale'])*np.asarray(state['lr_coef'])).sum(1)+float(state['lr_intercept']); return 1/(1+np.exp(-np.clip(z,-700,700)))
def wilson(k,n,z=1.959963984540054):
 if n==0:return np.nan,np.nan
 p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return c-h,c+h
rows=[]; selected_all=[]; checkpoints_all=[]; trajectory_all=[]; saturation=[]
for model in models:
 state=json.loads((RUN/'protocols/G05_v2_frozen_states'/f'{model}.json').read_text()); threshold=float(state['threshold'])
 e1=pd.read_csv(BASE/f'k400_{model}_test.csv',float_precision='round_trip'); clean=e1[e1.attack=='clean'].drop_duplicates('relative_path').copy(); clean['detector_score']=score(clean,state); clean=clean.set_index('relative_path')
 sel=pd.read_csv(ROOT/model/'selected_scores.csv.gz',float_precision='round_trip'); cp=pd.read_csv(ROOT/model/'checkpoint_scores.csv.gz',float_precision='round_trip'); tr=pd.read_csv(ROOT/model/'trajectory.csv.gz',float_precision='round_trip'); selected_all.append(sel); checkpoints_all.append(cp); trajectory_all.append(tr)
 for (attack,selection),adv in sel.groupby(['attack','selection'],sort=True):
  c=clean.loc[adv.relative_path]; labels=np.r_[np.zeros(len(adv)),np.ones(len(adv))]; values=np.r_[c.detector_score.to_numpy(float),adv.detector_score.to_numpy(float)]; success=adv.attack_success.astype(bool).to_numpy(); detected=adv.detector_score.to_numpy(float)>threshold
  for scope,mask in [('full',np.ones(len(adv),bool)),('success-only',success)]:
   if not mask.any(): continue
   v=np.r_[c.detector_score.to_numpy(float)[mask],adv.detector_score.to_numpy(float)[mask]]; y=np.r_[np.zeros(mask.sum()),np.ones(mask.sum())]; n=int(mask.sum()); asr=int(success[mask].sum()); det=int(detected[mask].sum()); alo,ahi=wilson(asr,n); dlo,dhi=wilson(det,n)
   rows.append({'protocol_id':PROTOCOL,'action_model':model,'attack':attack,'selection':selection,'checkpoint':'selected','scope':scope,'n_sources':n,'auc':float(roc_auc_score(y,v)),'attack_success_rate':asr/n,'attack_success_ci_low':alo,'attack_success_ci_high':ahi,'fixed_threshold_tpr':det/n,'fixed_threshold_tpr_ci_low':dlo,'fixed_threshold_tpr_ci_high':dhi,'threshold':threshold})
 for (attack,step),adv in cp.groupby(['attack','step'],sort=True):
  c=clean.loc[adv.relative_path]; success=adv.attack_success.astype(bool).to_numpy(); detected=adv.detector_score.to_numpy(float)>threshold
  for scope,mask in [('full',np.ones(len(adv),bool)),('success-only',success)]:
   if not mask.any():continue
   y=np.r_[np.zeros(mask.sum()),np.ones(mask.sum())]; v=np.r_[c.detector_score.to_numpy(float)[mask],adv.detector_score.to_numpy(float)[mask]]; n=int(mask.sum()); asr=int(success[mask].sum()); det=int(detected[mask].sum()); alo,ahi=wilson(asr,n); dlo,dhi=wilson(det,n)
   rows.append({'protocol_id':PROTOCOL,'action_model':model,'attack':attack,'selection':'iterate','checkpoint':int(step),'scope':scope,'n_sources':n,'auc':float(roc_auc_score(y,v)),'attack_success_rate':asr/n,'attack_success_ci_low':alo,'attack_success_ci_high':ahi,'fixed_threshold_tpr':det/n,'fixed_threshold_tpr_ci_low':dlo,'fixed_threshold_tpr_ci_high':dhi,'threshold':threshold})
 for (attack,rank),g in tr.groupby(['attack','source_rank'],sort=True):
  stable_step=int(g.loc[g.optimization_action_loss.idxmax(),'step']); clipped_max=g.reported_probability_loss_clipped.max(); clipped_first=int(g.loc[g.reported_probability_loss_clipped==clipped_max,'step'].min()); sat=int(g.probability_loss_saturated.sum()); saturation.append({'protocol_id':PROTOCOL,'action_model':model,'attack':attack,'source_rank':int(rank),'stable_best_step':stable_step,'clipped_first_max_step':clipped_first,'selection_changed_under_clipped_rule':stable_step!=clipped_first,'saturated_steps':sat,'any_saturation':sat>0})
pd.DataFrame(rows).to_csv(OUT/'metrics_and_convergence.csv',index=False); pd.concat(selected_all).to_csv(OUT/'selected_scores_all.csv.gz',index=False,compression='gzip'); pd.concat(checkpoints_all).to_csv(OUT/'checkpoint_scores_all.csv.gz',index=False,compression='gzip'); sat=pd.DataFrame(saturation); sat.to_csv(OUT/'loss_saturation_impact.csv',index=False)
valid={'protocol_id':PROTOCOL,'passed':bool(len(sat)==800 and len(pd.DataFrame(rows))>0),'source_attacks':len(sat),'saturated_source_attacks':int(sat.any_saturation.sum()),'selection_changed_if_clipped_rule_used':int(sat.selection_changed_under_clipped_rule.sum()),'metric_rows':len(rows),'models':4,'attacks':2}
(OUT/'validation.json').write_text(json.dumps(valid,indent=2,sort_keys=True)+'\n')
