#!/usr/bin/env python3
"""G05 full prediction-unfiltered clean audit for one action model."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
BASE_PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
PREDICTIONS = Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct")
VALIDATION_ROOT = Path("/root/autodl-tmp/tsc/data/k400_full_fiftyone/fiftyone/kinetics-400/validation")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path: sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g05-full-option-b-20261023-v1"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def valid(path: Path) -> dict | None:
    try: value = json.loads(path.read_text())
    except Exception: return None
    return value if value.get("complete") and value.get("protocol_id") == PROTOCOL_ID else None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=MODELS, required=True)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    authorization = json.loads((RUN / "protocols/authorization.json").read_text())
    if authorization.get("selected_option") != "B": raise RuntimeError("option B not authorized")
    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results/G05/full" / args.model
    shards = output / "shards"
    output.mkdir(parents=True, exist_ok=True)

    pool = pd.read_csv(PREDICTIONS / f"{args.model}_all.csv")
    pool["relative_path"] = pool.path.map(lambda value: str(Path(value).resolve().relative_to(VALIDATION_ROOT.resolve())))
    calibration_manifest = pd.read_csv(BASE_PROTOCOL / "manifests" / f"k400_{args.model}_calibration_fixed20.csv")
    excluded = set(calibration_manifest.relative_path.astype(str))
    pool = pool[~pool.relative_path.isin(excluded)].copy()
    pool["selection_hash"] = pool.relative_path.map(lambda value: hashlib.sha256(f"{PROTOCOL_ID}|{args.model}|{value}".encode()).hexdigest())
    cohort = pool.sort_values(["selection_hash", "relative_path"]).head(400).reset_index(drop=True)
    cohort.insert(0, "source_rank", np.arange(1, len(cohort) + 1))
    cohort["protocol_id"] = PROTOCOL_ID
    cohort["sampling_rule"] = "lowest SHA256 after model-specific calibration exclusion; prediction/correctness not used"
    cohort.to_csv(output / "cohort_manifest.csv", index=False)

    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    threshold = threshold_from_clean(calibration, score_lr(pipeline, calibration, FEATURES))
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    load_started = time.perf_counter()
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters(): parameter.requires_grad_(False)
    for parameter in clip_model.parameters(): parameter.requires_grad_(False)
    detector = FullDetector(action_model, clip_model, processor, build_text_features(clip_model, processor, read_class_names(CLASSES), device), args.model, state)
    torch.cuda.synchronize(device)
    model_load_seconds = time.perf_counter() - load_started

    for row in cohort.itertuples(index=False):
        shard = shards / f"{int(row.source_rank):03d}.json"
        if valid(shard) is not None:
            print(json.dumps({"reused": str(shard)}), flush=True); continue
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        torch.cuda.reset_peak_memory_stats(device)
        started = time.perf_counter()
        with torch.no_grad():
            features, logit, detector_score, _, _ = detector.exact_forward(clean)
            probability = action_probs(action_model, clean, args.model)
        torch.cuda.synchronize(device)
        atomic_json(shard, {
            "protocol_id": PROTOCOL_ID, "complete": True, "action_model": args.model,
            "gpu_uuid": gpu_uuid, "source_rank": int(row.source_rank), "relative_path": row.relative_path,
            "path": row.path, "selection_hash": row.selection_hash,
            "ground_truth": int(row.label_index), "ground_truth_name": row.label,
            "historical_clean_pred": int(row.pred_action), "historical_clean_correct": int(row.clean_correct),
            "clean_pred": int(probability.argmax()), "clean_conf": float(probability.max()),
            "correct_flag": int(probability.argmax()) == int(row.label_index),
            "detector_logit": float(logit), "score": float(detector_score), "threshold": threshold,
            "false_positive": float(detector_score) > threshold, "seconds": time.perf_counter() - started,
            "peak_memory_bytes": int(torch.cuda.max_memory_allocated(device)), "model_load_seconds": model_load_seconds,
            "features": {name: float(features[name]) for name in FEATURES},
        })
        print(json.dumps({"model": args.model, "source": int(row.source_rank), "score": float(detector_score)}), flush=True)

    records = [valid(path) for path in sorted(shards.glob("*.json"))]
    records = [item for item in records if item is not None]
    if len(records) != len(cohort): raise RuntimeError(f"G05 {args.model}: {len(records)}/{len(cohort)}")
    rows = [{key: value for key, value in item.items() if key not in ("features", "complete")} | item["features"] for item in records]
    clean = pd.DataFrame(rows)
    clean.to_csv(output / "clean_features.csv.gz", index=False, compression="gzip")
    score_columns = ["protocol_id", "action_model", "gpu_uuid", "source_rank", "relative_path", "ground_truth", "clean_pred", "correct_flag", "score", "threshold", "false_positive", "seconds"]
    clean[score_columns].to_csv(output / "clean_scores.csv.gz", index=False, compression="gzip")
    atomic_json(output / "validation.json", {
        "protocol_id": PROTOCOL_ID, "passed": bool(len(clean) == len(cohort) and np.isfinite(clean[FEATURES + ["score"]]).all().all()),
        "rows": len(clean), "maximum_requested": 400, "calibration_overlap": 0,
        "prediction_used_for_selection": False,
        "historical_prediction_match": bool((clean.historical_clean_pred == clean.clean_pred).all()),
        "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"G05_full_complete": True, "model": args.model, "rows": len(clean)}), flush=True)


if __name__ == "__main__":
    main()
