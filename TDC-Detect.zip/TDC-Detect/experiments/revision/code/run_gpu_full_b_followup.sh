#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
LOG="$RUN/logs/GPU_FULL_B_followup.log"
HOLD="$RUN/protocols/GPU_FULL_HOLD.json"

if [[ -s "$HOLD" ]]; then
  echo "$(date -u '+%FT%TZ') followup_held hold=$HOLD" >>"$LOG"
  exit 75
fi

echo "$(date -u '+%FT%TZ') followup_started" >>"$LOG"
while screen -list 2>/dev/null | grep -q '[.]tdc_gpu_full_b'; do sleep 300; done

if [[ ! -s "$RUN/logs/G02_full/COMPLETE" ]]; then
  echo "$(date -u '+%FT%TZ') action=resume_G02" >>"$LOG"
  "$RUN/code/run_g02_full_option_b.sh" >>"$LOG" 2>&1
fi
if [[ ! -s "$RUN/results/G02/full/validation.json" ]]; then
  echo "$(date -u '+%FT%TZ') action=finalize_G02" >>"$LOG"
  python "$RUN/code/finalize_g02_full.py" >>"$LOG" 2>&1
fi

if [[ ! -s "$RUN/logs/G04_full/COMPLETE" ]]; then
  echo "$(date -u '+%FT%TZ') action=run_G04" >>"$LOG"
  "$RUN/code/run_g04_full_four_gpu.sh" >>"$LOG" 2>&1
fi

if [[ ! -s "$RUN/logs/G05_full/COMPLETE" ]]; then
  echo "$(date -u '+%FT%TZ') action=run_G05" >>"$LOG"
  "$RUN/code/run_g05_full_four_gpu.sh" >>"$LOG" 2>&1
fi

# Formal G03 timing is deliberately last and serial, after all other project GPU workers stop.
if [[ ! -s "$RUN/logs/G03_full/COMPLETE" ]]; then
  echo "$(date -u '+%FT%TZ') action=run_G03_quiet" >>"$LOG"
  "$RUN/code/run_g03_full_quiet.sh" >>"$LOG" 2>&1
fi

echo "$(date -u '+%FT%TZ') GPU_FULL_OPTION_B_COMPLETE" >"$RUN/logs/GPU_FULL_B_COMPLETE"
echo "$(date -u '+%FT%TZ') followup_complete" >>"$LOG"
