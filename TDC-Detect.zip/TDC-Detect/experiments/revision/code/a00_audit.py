#!/usr/bin/env python3
"""A00 read-only input, cache, provenance, and reconstruction audit."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import platform
import argparse
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "1")
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import numpy as np
import pandas as pd
import sklearn
from safetensors import safe_open
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


RUN = Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01")
HANDOFF = RUN / "handoff"
BASE = Path("/root/autodl-tmp/tsc/outputs/tdc-final-20260714")
VALIDATED = Path("/root/autodl-tmp/TDC_Detect_Validated_Export_20260717")
SUPP = Path("/root/autodl-tmp/results_supp_20260817")
CACHE = SUPP / "E14/probe_cache"
C01 = Path("/root/autodl-tmp/tdc-e7-cpu-correction-20261021-v1")
PROTOCOL_ID = "tdc-r3r5-a00-20261022-v1"
SEED = 20260714
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
DATASETS = ("k400", "ucf101")
SPLITS = ("calibration", "test")
ATTACKS = ("clean", "fgsm", "pgd", "ofa-style", "flicker-style")
VIEWS = ("original", "early_crop", "late_crop", "temporal_sparse", "motion_aware",
         "local_0", "local_1", "local_2", "local_3")
FEATURES = [
    "R_model", "R_label_change", "R_conf_var", "R_uniform_shift",
    "R_fft_conf_high", "R_fft_conf_entropy", "R_fft_vlad_high", "R_fft_vlad_entropy",
    "R_local_conf_max", "R_local_conf_top2", "R_local_shift_max", "R_local_shift_top2",
    "R_vlm", "vlad_original", "R_sem_mean", "R_sem_max", "R_sem_var",
    "R_fft_sem_high", "R_fft_sem_entropy", "R_local_sem_max", "R_local_sem_top2",
]


def load_feature_module():
    path = HANDOFF / "evidence/historical_code/TSC_Detect/tsc_features.py"
    spec = importlib.util.spec_from_file_location("historical_tsc_features", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    return module


FEATURE_MODULE = load_feature_module()


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def command(args: list[str]) -> str:
    try:
        return subprocess.run(args, check=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                              text=True, timeout=30).stdout.strip()
    except Exception as exc:
        return f"unavailable: {type(exc).__name__}: {exc}"


def package_audit() -> dict:
    manifest = json.loads((HANDOFF / "PACKAGE_MANIFEST.json").read_text(encoding="utf-8"))
    mismatches = []
    for item in manifest["files"]:
        path = HANDOFF / item["path"]
        actual_size = path.stat().st_size if path.exists() else None
        actual_hash = sha256(path) if path.exists() else None
        if actual_size != item["bytes"] or actual_hash != item["sha256"]:
            mismatches.append({"path": item["path"], "size": actual_size, "sha256": actual_hash})
    return {"package_id": manifest["package_id"], "files_checked": len(manifest["files"]),
            "mismatches": mismatches, "passed": not mismatches}


def load_e1() -> tuple[dict[tuple[str, str, str], pd.DataFrame], list[dict]]:
    frames = {}
    manifest_rows = []
    for dataset in DATASETS:
        for model in MODELS:
            for split in SPLITS:
                path = BASE / "E1" / f"{dataset}_{model}_{split}.csv"
                frame = pd.read_csv(path, low_memory=False)
                frames[dataset, model, split] = frame
                counts = frame.groupby("attack").size().to_dict()
                source_order = [column for column in frame.columns if column in FEATURES]
                values = frame[FEATURES].to_numpy(float)
                manifest_rows.append({
                    "artifact_id": f"E1_{dataset}_{model}_{split}", "logical_role": "E1_21d_features",
                    "original_path": str(path), "portable_path": f"external/E1/{path.name}",
                    "bytes": path.stat().st_size, "sha256": sha256(path), "protocol": "tdc-final-20260714",
                    "partition": split, "dataset": dataset, "model": model, "rows": len(frame),
                    "source_count": frame.relative_path.nunique(), "attack_counts_json": json.dumps(counts, sort_keys=True),
                    # The CSV's physical column order follows the extractor layout, while the
                    # historical evaluator explicitly selects TDC_V2 in FEATURES order.  Record
                    # both facts instead of incorrectly requiring the physical CSV layout to
                    # equal the evaluator layout.
                    "source_feature_order_json": json.dumps(source_order),
                    "evaluation_feature_order_json": json.dumps(FEATURES),
                    "feature_set_exact": set(source_order) == set(FEATURES) and len(source_order) == len(FEATURES),
                    "feature_order_exact": list(frame[FEATURES].columns) == FEATURES,
                    "source_column_order_matches_evaluation": source_order == FEATURES,
                    "features_finite": bool(np.isfinite(values).all()),
                    "duplicate_pair_attack": int(frame.duplicated(["pair_id", "attack"]).sum()),
                    "provenance": "executed-server final E1 CSV; read-only",
                })
    pd.DataFrame(manifest_rows).to_csv(RUN / "provenance/input_manifest.csv", index=False)
    return frames, manifest_rows


def reconstruct(action: np.ndarray, clip: np.ndarray) -> dict[str, float]:
    global_action = {name: action[index] for index, name in enumerate(VIEWS[:5])}
    global_clip = {name: clip[index] for index, name in enumerate(VIEWS[:5])}
    local_action = {name: action[index] for index, name in enumerate(VIEWS) if name.startswith("local_")}
    local_clip = {name: clip[index] for index, name in enumerate(VIEWS) if name.startswith("local_")}
    result = FEATURE_MODULE.compute_tsc_features(global_action, global_clip, primary_view="original")
    result.update(FEATURE_MODULE.local_window_features(
        local_action, local_clip, reference_action_probs=global_action["original"]))
    return {feature: float(result[feature]) for feature in FEATURES}


def cache_audit(frames: dict[tuple[str, str, str], pd.DataFrame]) -> tuple[list[dict], dict]:
    inventory = []
    global_max_by_feature = {feature: 0.0 for feature in FEATURES}
    global_probability_sum_error = 0.0
    total_corrupt = 0
    total_missing = 0
    total_shards = 0
    started_all = time.perf_counter()
    shard_dir = RUN / "manifests/cache_shards"
    shard_dir.mkdir(parents=True, exist_ok=True)
    progress_path = RUN / "logs/a00_cache_progress.jsonl"
    with progress_path.open("w", encoding="utf-8") as progress:
        for dataset in DATASETS:
            for model in MODELS:
                for split in SPLITS:
                    condition = f"{dataset}_{model}_{split}"
                    source = frames[dataset, model, split]
                    source_index = source.set_index(["pair_id", "attack"])
                    if not source_index.index.is_unique:
                        raise ValueError(f"non-unique source keys: {condition}")
                    expected_ids = set(source.pair_id.astype(str))
                    directory = CACHE / condition
                    shards = sorted(directory.glob("*.safetensors"))
                    actual_ids = {path.stem for path in shards}
                    missing = sorted(expected_ids - actual_ids)
                    unexpected = sorted(actual_ids - expected_ids)
                    total_missing += len(missing)
                    condition_corrupt = 0
                    max_probability_error = 0.0
                    max_feature_error = {feature: 0.0 for feature in FEATURES}
                    hash_rows = []
                    attacks_seen = set()
                    rows_checked = 0
                    for shard_index, path in enumerate(shards, 1):
                        error_text = ""
                        file_hash = sha256(path)
                        try:
                            with safe_open(str(path), framework="np") as handle:
                                metadata = handle.metadata() or {}
                                keys = set(handle.keys())
                                required = {"action_probs", "clip_probs", "support_indices", "aggregate_max_abs_error",
                                            "attack_success", "is_adv", "measured_linf"}
                                if not required <= keys:
                                    raise ValueError(f"missing keys {sorted(required - keys)}")
                                if metadata.get("protocol_id") != "tdc-supplement-20260817" or metadata.get("base_protocol") != "tdc-final-20260714":
                                    raise ValueError("protocol metadata mismatch")
                                if (metadata.get("dataset"), metadata.get("model"), metadata.get("split")) != (dataset, model, split):
                                    raise ValueError("condition metadata mismatch")
                                if json.loads(metadata.get("view_names", "[]")) != list(VIEWS):
                                    raise ValueError("view order mismatch")
                                identity = json.loads(metadata["rows_json"])
                                action = handle.get_tensor("action_probs")
                                clip = handle.get_tensor("clip_probs")
                                support = handle.get_tensor("support_indices")
                                recorded_errors = handle.get_tensor("aggregate_max_abs_error")
                            if action.shape != (5, 9, 400) or clip.shape != (5, 9, 400) or support.shape[0:2] != (5, 9):
                                raise ValueError(f"tensor shape mismatch {action.shape}/{clip.shape}/{support.shape}")
                            if len(identity) != 5 or {str(row["attack"]) for row in identity} != set(ATTACKS):
                                raise ValueError("row identity/attack coverage mismatch")
                            if not np.isfinite(action).all() or not np.isfinite(clip).all():
                                raise ValueError("non-finite probabilities")
                            probability_error = max(float(np.max(np.abs(action.sum(axis=2) - 1.0))),
                                                    float(np.max(np.abs(clip.sum(axis=2) - 1.0))))
                            max_probability_error = max(max_probability_error, probability_error)
                            if probability_error > 2e-5:
                                raise ValueError(f"probability closure error {probability_error}")
                            if not np.isfinite(recorded_errors).all() or float(np.max(recorded_errors)) > 2e-5:
                                raise ValueError("recorded aggregate error gate failure")
                            for row_index, item in enumerate(identity):
                                pair_id = str(item["pair_id"])
                                attack_name = str(item["attack"])
                                attacks_seen.add(attack_name)
                                if pair_id != path.stem:
                                    raise ValueError("pair_id/filename mismatch")
                                raw = source_index.loc[(pair_id, attack_name)]
                                if str(raw.relative_path) != str(item["relative_path"]):
                                    raise ValueError("relative_path mismatch")
                                rebuilt = reconstruct(action[row_index].astype(np.float64), clip[row_index].astype(np.float64))
                                for feature in FEATURES:
                                    difference = abs(float(raw[feature]) - rebuilt[feature])
                                    max_feature_error[feature] = max(max_feature_error[feature], difference)
                                    if difference > 2e-5:
                                        raise ValueError(f"feature reconstruction {feature} error {difference}")
                                rows_checked += 1
                        except Exception as exc:
                            condition_corrupt += 1
                            error_text = f"{type(exc).__name__}: {exc}"
                        hash_rows.append({
                            "condition": condition, "relative_member": str(path.relative_to(CACHE)),
                            "bytes": path.stat().st_size, "sha256": file_hash, "status": "corrupt" if error_text else "valid",
                            "error": error_text,
                        })
                    pd.DataFrame(hash_rows).to_csv(shard_dir / f"{condition}.csv", index=False)
                    total_corrupt += condition_corrupt
                    total_shards += len(shards)
                    for feature in FEATURES:
                        global_max_by_feature[feature] = max(global_max_by_feature[feature], max_feature_error[feature])
                    global_probability_sum_error = max(global_probability_sum_error, max_probability_error)
                    item = {
                        "protocol_id": PROTOCOL_ID, "condition": condition, "dataset": dataset, "model": model,
                        "partition": split, "expected_sources": len(expected_ids), "actual_shards": len(shards),
                        "rows_checked": rows_checked, "attack_coverage": ";".join(sorted(attacks_seen)),
                        "tensor_schema": "action_probs[5,9,400] float32; clip_probs[5,9,400] float32; support_indices[5,9,16|32] int16",
                        "metadata_protocol": "tdc-supplement-20260817 / tdc-final-20260714",
                        "shard_hash_manifest": str(shard_dir / f"{condition}.csv"),
                        "missing_count": len(missing), "unexpected_count": len(unexpected), "corrupt_count": condition_corrupt,
                        "max_probability_sum_abs_error": max_probability_error,
                        "max_21d_reconstruction_abs_error": max(max_feature_error.values()),
                        "supports_tasks": "C04;C05-B;C06;C07",
                        "status": "valid" if not missing and not unexpected and not condition_corrupt and rows_checked == 5 * len(expected_ids) else "invalid",
                    }
                    inventory.append(item)
                    event = {"completed_condition": condition, "conditions_completed": len(inventory), "conditions_total": 16,
                             "elapsed_seconds": time.perf_counter() - started_all, "status": item["status"]}
                    progress.write(json.dumps(event) + "\n"); progress.flush()
                    print(json.dumps(event), flush=True)
    pd.DataFrame(inventory).to_csv(RUN / "provenance/cache_inventory.csv", index=False)
    reconstruction = {
        "protocol_id": PROTOCOL_ID, "conditions": len(inventory), "formal_shards": total_shards,
        "rows_reconstructed": int(sum(item["rows_checked"] for item in inventory)),
        "missing_shards": total_missing, "corrupt_shards": total_corrupt,
        "max_probability_sum_abs_error": global_probability_sum_error,
        "max_abs_error_by_feature": global_max_by_feature,
        "max_21d_reconstruction_abs_error": max(global_max_by_feature.values()),
        "tolerance": 2e-5,
        "passed": len(inventory) == 16 and all(item["status"] == "valid" for item in inventory),
    }
    return inventory, reconstruction


def lr_reconstruction(frames: dict[tuple[str, str, str], pd.DataFrame]) -> dict:
    scores = pd.read_csv(SUPP / "E14/matched_budget_scores.csv", low_memory=False)
    saved = json.loads((SUPP / "E14/fitted_detector_parameters.json").read_text(encoding="utf-8"))
    conditions = []
    max_score_error = 0.0
    max_threshold_error = 0.0
    max_parameter_error = 0.0
    for dataset in DATASETS:
        for model in MODELS:
            train = frames[dataset, model, "calibration"]
            test = frames[dataset, model, "test"]
            pipeline = Pipeline([
                ("scaler", StandardScaler()),
                ("logistic", LogisticRegression(C=1.0, l1_ratio=0.0, class_weight="balanced",
                                                  max_iter=5000, solver="lbfgs", random_state=SEED)),
            ]).fit(train[FEATURES].to_numpy(float), train.is_adv.to_numpy(int))
            predicted = pipeline.predict_proba(test[FEATURES].to_numpy(float))[:, 1]
            threshold = float(np.quantile(
                pipeline.predict_proba(train[FEATURES].to_numpy(float))[train.is_adv.to_numpy(int) == 0, 1],
                0.99, method="higher"))
            old = scores[(scores.dataset == dataset) & (scores.model == model)]
            old_index = old.set_index(["pair_id", "attack"])
            if not old_index.index.is_unique:
                raise ValueError(f"non-unique historical score keys: {dataset}/{model}")
            aligned = old_index.loc[list(zip(test.pair_id, test.attack))]
            score_error = float(np.max(np.abs(predicted - aligned["TDC-v2"].to_numpy(float))))
            threshold_error = float(np.max(np.abs(threshold - aligned["threshold__TDC-v2"].to_numpy(float))))
            state = saved[f"{dataset}/{model}"]["TDC-v2"]
            parameter_error = max(
                float(np.max(np.abs(pipeline.named_steps["scaler"].mean_ - np.asarray(state["scaler_mean"], float)))),
                float(np.max(np.abs(pipeline.named_steps["scaler"].scale_ - np.asarray(state["scaler_scale"], float)))),
                float(np.max(np.abs(pipeline.named_steps["logistic"].coef_[0] - np.asarray(state["coefficients"], float)))),
                abs(float(pipeline.named_steps["logistic"].intercept_[0]) - float(state["intercept"])),
            )
            max_score_error = max(max_score_error, score_error)
            max_threshold_error = max(max_threshold_error, threshold_error)
            max_parameter_error = max(max_parameter_error, parameter_error)
            conditions.append({"dataset": dataset, "model": model, "test_rows": len(test),
                               "max_score_abs_error": score_error, "threshold_abs_error": threshold_error,
                               "max_parameter_abs_error": parameter_error,
                               "n_iter": int(pipeline.named_steps["logistic"].n_iter_[0])})
    return {"conditions": conditions, "max_score_abs_error": max_score_error,
            "max_threshold_abs_error": max_threshold_error, "max_parameter_abs_error": max_parameter_error,
            "tolerance": 1e-12,
            "passed": max(max_score_error, max_threshold_error, max_parameter_error) <= 1e-12}


def split_and_input_checks(frames: dict[tuple[str, str, str], pd.DataFrame], manifest_rows: list[dict]) -> dict:
    overlaps = []
    failures = []
    for dataset in DATASETS:
        for model in MODELS:
            cal = frames[dataset, model, "calibration"]
            test = frames[dataset, model, "test"]
            path_overlap = len(set(cal.relative_path.astype(str)) & set(test.relative_path.astype(str)))
            overlaps.append({"dataset": dataset, "model": model, "calibration_test_path_overlap": path_overlap})
    for item in manifest_rows:
        if (not item["feature_set_exact"] or not item["feature_order_exact"]
                or not item["features_finite"] or item["duplicate_pair_attack"]):
            failures.append(item["artifact_id"])
        if json.loads(item["attack_counts_json"]).keys() != set(ATTACKS):
            failures.append(item["artifact_id"] + ":attacks")
    return {"conditions": len(manifest_rows), "split_overlaps": overlaps,
            "failed_inputs": failures, "passed": not failures and all(row["calibration_test_path_overlap"] == 0 for row in overlaps)}


def historical_code_checks() -> list[dict]:
    rows = []
    mappings = [
        ("TSC_Detect/attack_rgb.py", "TSC_Detect/attack_rgb.py"),
        ("TSC_Detect/run_final_extract.py", "TSC_Detect/run_final_extract.py"),
        ("TSC_Detect/tsc_features.py", "TSC_Detect/tsc_features.py"),
        ("TSC_Detect/tsc_sampling.py", "TSC_Detect/tsc_sampling.py"),
        ("TSC_Detect/tsc_vlm.py", "TSC_Detect/tsc_vlm.py"),
        ("scripts/eval_final_e1_e5.py", "scripts/eval_final_e1_e5.py"),
    ]
    executed_root = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
    for packaged_rel, executed_rel in mappings:
        packaged = HANDOFF / "evidence/historical_code" / packaged_rel
        executed = executed_root / executed_rel
        rows.append({"artifact": packaged_rel, "packaged_sha256": sha256(packaged),
                     "executed_sha256": sha256(executed), "match": sha256(packaged) == sha256(executed),
                     "executed_path": str(executed)})
    return rows


def reuse_and_missing(reconstruction: dict, lr_check: dict) -> None:
    c01_validation = json.loads((C01 / "validation.json").read_text(encoding="utf-8"))
    reused = [
        {"task_id": "C01", "artifact": str(C01), "protocol_id": "tdc-e7-cpu-correction-20261021-v1",
         "reuse_status": "candidate_validated", "validation": str(C01 / "validation.json"),
         "reason": f"mechanical checks={c01_validation.get('all_mechanical_checks_passed')}"},
    ]
    for exp in ("E11", "E12", "E13", "E14", "E15", "E16"):
        reused.append({"task_id": "A00/C02/C07", "artifact": str(SUPP / exp),
                       "protocol_id": "tdc-supplement-20260817", "reuse_status": "available_historical_evidence",
                       "validation": str(SUPP / "logs/final_validation_evidence.json"),
                       "reason": "historical supplement reports COMPLETE; new task must preserve measurement scope"})
    pd.DataFrame(reused).to_csv(RUN / "provenance/reused_results.csv", index=False)

    prediction_only = Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct")
    missing = [{
        "task_id": "C08", "required_input": "unfiltered K400 clean full21 features including original-wrong",
        "status": "blocked_input", "searched_location": str(prediction_only),
        "available_instead": "*_all.csv has labels/predictions/correctness but no 21-dimensional detector features",
        "impact": "cannot estimate detector false-positive rate for original-wrong or population overall",
        "next_task": "G05 after explicit GPU mode and budget",
    }]
    if not reconstruction["passed"]:
        missing.append({"task_id": "C04/C05-B/C06", "required_input": "validated nine-view response cache",
                        "status": "blocked_input", "searched_location": str(CACHE),
                        "available_instead": "cache failed A00 integrity/reconstruction", "impact": "dependent analyses blocked",
                        "next_task": "G06 after explicit GPU mode and budget"})
    if not lr_check["passed"]:
        missing.append({"task_id": "G01/G02", "required_input": "reconstructed historical full21 classifier equivalence",
                        "status": "blocked_input", "searched_location": str(SUPP / "E14"),
                        "available_instead": "reconstruction mismatch", "impact": "new classifier cannot be used for attack",
                        "next_task": "diagnose before GPU pilot"})
    pd.DataFrame(missing).to_csv(RUN / "provenance/missing_inputs.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reuse-validated-cache-audit", action="store_true",
                        help="Reuse this run's prior full cache scan while rebuilding the A00 gate report")
    args = parser.parse_args()
    started = time.perf_counter()
    for directory in (RUN / "provenance", RUN / "validation", RUN / "logs", RUN / "environment", RUN / "protocols"):
        directory.mkdir(parents=True, exist_ok=True)
    protocol = {
        "protocol_id": PROTOCOL_ID, "task_id": "A00", "mode": "NO_GPU", "read_only_inputs": True,
        "cache_gate": {"conditions": 16, "expected_shards": 28041, "probability_tolerance": 2e-5,
                       "feature_reconstruction_tolerance": 2e-5, "full_scan": True},
        "classifier_reconstruction_tolerance": 1e-12, "seed": SEED,
        "features": FEATURES, "views": VIEWS,
    }
    write_json(RUN / "protocols/A00.json", protocol)
    environment = {
        "generated_utc": now(), "platform": platform.platform(), "python": sys.version,
        "numpy": np.__version__, "pandas": pd.__version__, "sklearn": sklearn.__version__,
        "safetensors": __import__("safetensors").__version__, "cpu_count_visible": os.cpu_count(),
        "thread_environment": {name: os.environ.get(name, "") for name in
                               ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS")},
        "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES", ""),
        "nvidia_smi": command(["nvidia-smi", "--query-gpu=index,name,memory.total", "--format=csv,noheader"]),
        "disk": command(["df", "-h", "/root/autodl-tmp"]), "memory": command(["free", "-h"]),
        "gpu_or_model_inference_run": False, "torch_imported_by_this_script": False,
    }
    write_json(RUN / "environment/environment.json", environment)
    (RUN / "environment/environment.txt").write_text(
        "\n".join(f"{key}: {value}" for key, value in environment.items()) + "\n", encoding="utf-8")

    package = package_audit()
    frames, manifest_rows = load_e1()
    inputs = split_and_input_checks(frames, manifest_rows)
    code_checks = historical_code_checks()
    pd.DataFrame(code_checks).to_csv(RUN / "provenance/historical_code_hashes.csv", index=False)
    prior_validation_path = RUN / "validation/A00.json"
    if args.reuse_validated_cache_audit:
        if not prior_validation_path.exists() or not (RUN / "provenance/cache_inventory.csv").exists():
            raise FileNotFoundError("A prior complete A00 cache audit is required for --reuse-validated-cache-audit")
        prior_validation = json.loads(prior_validation_path.read_text(encoding="utf-8"))
        reconstruction = prior_validation["response_cache_integrity_and_21d_reconstruction"]
        if not reconstruction.get("passed"):
            raise ValueError("The prior cache audit did not pass and cannot be reused")
        inventory = pd.read_csv(RUN / "provenance/cache_inventory.csv").to_dict("records")
        lr_check = prior_validation["historical_classifier_reconstruction"]
        if not lr_check.get("passed"):
            raise ValueError("The prior historical classifier reconstruction did not pass")
    else:
        inventory, reconstruction = cache_audit(frames)
        lr_check = lr_reconstruction(frames)
    reuse_and_missing(reconstruction, lr_check)

    validation = {
        "protocol_id": PROTOCOL_ID, "task_id": "A00", "generated_utc": now(),
        "package_integrity": package,
        "e1_input_integrity_and_split_isolation": inputs,
        "historical_code_identity": {"rows": code_checks, "passed": all(row["match"] for row in code_checks)},
        "response_cache_integrity_and_21d_reconstruction": reconstruction,
        "historical_classifier_reconstruction": lr_check,
        "historical_supplement_validation": {
            "path": str(SUPP / "logs/final_validation_evidence.json"),
            "reported_status": json.loads((SUPP / "logs/final_validation_evidence.json").read_text())["status"],
            "note": "reported historical validation is reused as evidence; cache was independently rescanned above",
        },
        "gpu_used": False, "model_inference_run": False, "torch_imported": False,
    }
    validation["all_a00_gates_passed"] = all([
        package["passed"], inputs["passed"], validation["historical_code_identity"]["passed"],
        reconstruction["passed"], lr_check["passed"],
    ])
    validation["elapsed_seconds"] = time.perf_counter() - started
    write_json(RUN / "validation/A00.json", validation)
    write_json(RUN / "validation/reconstruction_check.json", reconstruction)
    write_json(RUN / "logs/A00_run_summary.json", {
        "protocol_id": PROTOCOL_ID, "elapsed_seconds": validation["elapsed_seconds"],
        "conditions": len(inventory), "formal_cache_shards": reconstruction["formal_shards"],
        "cache_rows_reconstructed": reconstruction["rows_reconstructed"],
        "all_a00_gates_passed": validation["all_a00_gates_passed"], "gpu_used": False,
    })
    print(json.dumps(json.loads((RUN / "logs/A00_run_summary.json").read_text()), indent=2), flush=True)
    if not validation["all_a00_gates_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
