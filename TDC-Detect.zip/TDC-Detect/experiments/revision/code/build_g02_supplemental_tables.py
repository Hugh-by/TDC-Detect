#!/usr/bin/env python3
"""CPU-only G02 success-only, checkpoint-union, and rate-interval tables."""
import math
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score

RUN=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01'); SRC=RUN/'results/G02/full'; OUT=RUN/'results/G02/supplemental_v2'; OUT.mkdir(parents=True,exist_ok=True)
PROTOCOL='tdc-r3r5-g02-supplemental-20261026-v1'; rng=np.random.default_rng(20260714)
selected=pd.read_csv(SRC/'selected.csv.gz',float_precision='round_trip'); clean=pd.read_csv(SRC/'clean_scores.csv.gz',float_precision='round_trip'); candidates=pd.read_csv(SRC/'candidates.csv.gz',float_precision='round_trip')
def wilson(k,n,z=1.959963984540054):
 if n==0:return np.nan,np.nan
 p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return c-h,c+h
def metrics(model,mode,adv,clean_rows,scope,step='selected'):
 adv=adv.sort_values('source_rank'); clean_rows=clean_rows.set_index('source_rank').loc[adv.source_rank].reset_index(); labels=np.r_[np.zeros(len(adv)),np.ones(len(adv))]; scores=np.r_[clean_rows.detector_score.to_numpy(float),adv.detector_score.to_numpy(float)]
 auc=float(roc_auc_score(labels,scores)); attack=adv.attack_success.astype(bool).to_numpy(); evade=adv.detector_evaded.astype(bool).to_numpy(); joint=attack&evade; row={'protocol_id':PROTOCOL,'action_model':model,'mode':mode,'scope':scope,'checkpoint_union_through_step':step,'n_sources':len(adv),'auc':auc,'attack_success_rate':float(attack.mean()),'detector_evasion_rate':float(evade.mean()),'joint_success_evasion_rate':float(joint.mean())}
 for name,values in [('attack_success',attack),('detector_evasion',evade),('joint_success_evasion',joint)]:
  lo,hi=wilson(int(values.sum()),len(values)); row[f'{name}_count']=int(values.sum()); row[f'{name}_ci_low']=lo; row[f'{name}_ci_high']=hi
 boots=[]
 for _ in range(1000):
  ix=rng.integers(0,len(adv),len(adv)); boots.append(roc_auc_score(np.r_[np.zeros(len(ix)),np.ones(len(ix))],np.r_[clean_rows.detector_score.to_numpy(float)[ix],adv.detector_score.to_numpy(float)[ix]]))
 row['auc_ci_low'],row['auc_ci_high']=map(float,np.quantile(boots,[.025,.975])); return row
rows=[]
for (model,mode),adv in selected.groupby(['action_model','mode'],sort=True):
 c=clean[clean.action_model==model]
 rows.append(metrics(model,mode,adv,c,'full'))
 success=adv[adv.attack_success.astype(bool)]
 rows.append(metrics(model,mode,success,c,'success-only'))
pd.DataFrame(rows).to_csv(OUT/'success_only_metrics.csv',index=False)

# For each source and step budget, select from the union of all restarts/checkpoints <= budget
# by the original rule: attack success first, then minimum detector score.
conv=[]
test=candidates[candidates.partition=='test'].copy()
for (model,mode),group in test.groupby(['action_model','mode'],sort=True):
 c=clean[clean.action_model==model]
 for budget in (0,10,20,40,60,80,100):
  pool=group[group.step<=budget].copy(); pool['_failure']=(~pool.attack_success.astype(bool)).astype(int)
  chosen=pool.sort_values(['source_rank','_failure','detector_score','step','restart']).groupby('source_rank',as_index=False).first()
  conv.append(metrics(model,mode,chosen,c,'full',budget))
pd.DataFrame(conv).to_csv(OUT/'checkpoint_union_convergence.csv',index=False)

interval=[]
for _,r in pd.DataFrame(rows).iterrows():
 for rate in ('attack_success','detector_evasion','joint_success_evasion'):
  interval.append({'protocol_id':PROTOCOL,'action_model':r.action_model,'mode':r['mode'],'scope':r.scope,'rate':rate,'count':int(r[f'{rate}_count']),'n':int(r.n_sources),'proportion':float(r[f'{rate}_rate']),'ci_low':float(r[f'{rate}_ci_low']),'ci_high':float(r[f'{rate}_ci_high']),'ci_method':'Wilson 95%'})
pd.DataFrame(interval).to_csv(OUT/'rate_intervals.csv',index=False)
(OUT/'validation.json').write_text(pd.Series({'protocol_id':PROTOCOL,'passed':True,'success_metric_rows':len(rows),'convergence_rows':len(conv),'bootstrap_replicates':1000,'rate_ci_method':'Wilson 95%'}).to_json(indent=2)+'\n')
