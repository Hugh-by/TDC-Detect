#!/usr/bin/env python3
"""Corrected prediction-unfiltered clean FPR audit for one action model."""
import argparse, hashlib, json, os, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
BASE_PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
PREDICTIONS = Path("/root/autodl-tmp/tsc/outputs/repaired_clean_correct")
VALIDATION_ROOT = Path("/root/autodl-tmp/tsc/data/k400_full_fiftyone/fiftyone/kinetics-400/validation")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path: sys.path.insert(0, str(path))
from cpu_common import FEATURES
from gpu_full_detector import DetectorState, FullDetector, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g05-corrected-20261025-v2"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def atomic_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True); tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n"); os.replace(tmp, path)
def valid(path):
    try: value=json.loads(path.read_text())
    except Exception: return None
    return value if value.get("complete") and value.get("protocol_id") == PROTOCOL_ID else None
def load_state(model, device):
    path = RUN / "protocols/G05_v2_frozen_states" / f"{model}.json"; value=json.loads(path.read_text())
    state=DetectorState(list(value["feature_order"]), torch.tensor(value["scaler_mean"],dtype=torch.float64,device=device), torch.tensor(value["scaler_scale"],dtype=torch.float64,device=device), torch.tensor(value["lr_coef"],dtype=torch.float64,device=device), torch.tensor(value["lr_intercept"],dtype=torch.float64,device=device), float(value["threshold"]))
    return state, path, sha(path)

def main():
    p=argparse.ArgumentParser(); p.add_argument("--model",choices=MODELS,required=True); p.add_argument("--device",default="cuda:0"); p.add_argument("--output-name",default="full_corrected"); p.add_argument("--limit",type=int,default=400); a=p.parse_args()
    auth=json.loads((RUN/"protocols/authorization.json").read_text())
    if auth.get("selected_option") != "B": raise RuntimeError("option B not authorized")
    device=torch.device(a.device); gpu_uuid=os.environ.get("TDC_GPU_UUID","unknown")
    output=RUN/"results/G05"/a.output_name/a.model; shards=output/"shards"; output.mkdir(parents=True,exist_ok=True)
    pool_path=PREDICTIONS/f"{a.model}_all.csv"; pool=pd.read_csv(pool_path)
    pool["relative_path"]=pool.path.map(lambda x:str(Path(x).resolve().relative_to(VALIDATION_ROOT.resolve())))
    cal_path=BASE_PROTOCOL/"manifests"/f"k400_{a.model}_calibration_fixed20.csv"; cal=pd.read_csv(cal_path); excluded=set(cal.relative_path.astype(str))
    pool=pool[~pool.relative_path.isin(excluded)].copy(); pool["selection_hash"]=pool.relative_path.map(lambda x:hashlib.sha256(f"{PROTOCOL_ID}|{a.model}|{x}".encode()).hexdigest())
    cohort=pool.sort_values(["selection_hash","relative_path"]).head(a.limit).reset_index(drop=True); cohort.insert(0,"source_rank",np.arange(1,len(cohort)+1)); cohort["protocol_id"]=PROTOCOL_ID; cohort["sampling_rule"]="lowest SHA256 after calibration exclusion; prediction/correctness not used"
    cohort.to_csv(output/"cohort_manifest.csv",index=False)
    if len(cohort)!=a.limit or cohort.relative_path.duplicated().any() or set(cohort.relative_path)&excluded: raise RuntimeError("cohort gate failed")
    state,state_path,state_hash=load_state(a.model,device); threshold=state.threshold
    action_model,clip_model,processor=load_real_models(device,a.model)
    for x in action_model.parameters(): x.requires_grad_(False)
    for x in clip_model.parameters(): x.requires_grad_(False)
    detector=FullDetector(action_model,clip_model,processor,build_text_features(clip_model,processor,read_class_names(CLASSES),device),a.model,state)
    for row in cohort.itertuples(index=False):
        shard=shards/f"{int(row.source_rank):03d}.json"
        if valid(shard): continue
        clean=prepare_attack_frames(load_frames(Path(row.path)),a.model,device).detach(); started=time.perf_counter()
        with torch.no_grad():
            features,logit,score,_,_=detector.exact_forward(clean); probability=action_probs(action_model,clean,a.model)
        torch.cuda.synchronize(device); pred=int(probability.argmax())
        feature_values={name:float(features[name]) for name in FEATURES}
        vector=np.asarray([feature_values[n] for n in FEATURES]); z=(vector-state.scaler_mean.cpu().numpy())/state.scaler_scale.cpu().numpy(); reconstructed=float(1/(1+np.exp(-(z@state.coef.cpu().numpy()+float(state.intercept)))))
        atomic_json(shard,{"protocol_id":PROTOCOL_ID,"complete":True,"action_model":a.model,"gpu_uuid":gpu_uuid,"source_rank":int(row.source_rank),"relative_path":row.relative_path,"path":row.path,"selection_hash":row.selection_hash,"ground_truth":int(row.label_index),"ground_truth_name":row.label,"historical_clean_pred":int(row.pred_action),"historical_clean_correct":int(row.clean_correct),"clean_pred":pred,"correct_flag":pred==int(row.label_index),"historical_prediction_match":pred==int(row.pred_action),"clean_conf":float(probability.max()),"detector_logit":float(logit),"score":float(score),"reconstructed_score":reconstructed,"score_roundtrip_error":abs(reconstructed-float(score)),"threshold":threshold,"false_positive":float(score)>threshold,"seconds":time.perf_counter()-started,"frozen_state_path":str(state_path),"frozen_state_sha256":state_hash,"features":feature_values})
        print(json.dumps({"model":a.model,"source":int(row.source_rank)}),flush=True)
    records=[valid(x) for x in sorted(shards.glob("*.json"))]; records=[x for x in records if x]
    if len(records)!=a.limit: raise RuntimeError(f"{len(records)}/{a.limit}")
    rows=[{k:v for k,v in x.items() if k not in ("features","complete")}|x["features"] for x in records]; frame=pd.DataFrame(rows); frame.to_csv(output/"clean_features.csv.gz",index=False,compression="gzip")
    atomic_json(output/"validation.json",{"protocol_id":PROTOCOL_ID,"passed":bool(len(frame)==a.limit and np.isfinite(frame[FEATURES+["score"]]).all().all() and frame.score_roundtrip_error.max()<=1e-12),"rows":len(frame),"calibration_overlap":0,"prediction_used_for_selection":False,"cohort_unique":bool(not frame.relative_path.duplicated().any()),"max_score_roundtrip_error":float(frame.score_roundtrip_error.max()),"frozen_state_sha256":state_hash})

if __name__=="__main__": main()
