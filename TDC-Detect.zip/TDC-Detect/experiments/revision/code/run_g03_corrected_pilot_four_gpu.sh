#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"; LOG="$RUN/logs/G03_corrected_pilot"; mkdir -p "$LOG"
methods=(action_single e14_action_shift9_lr action_stats12_lr discrepancy9_lr full_g5l4_lr light_g3l2_adapter single_discrepancy_lr)
models=(csn_r101 mvit_base_16x4 slowfast_r50 x3d_m); pids=()
for i in 0 1 2 3; do
  model="${models[$i]}"; uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i "$i"|tr -d ' ')"
  (
    for method in "${methods[@]}"; do
      CUDA_VISIBLE_DEVICES="$i" TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
        python "$RUN/code/run_g03_full_method.py" --dataset k400 --model "$model" --method "$method" \
        --videos 3 --repeats 1 --warmups 2 --output-name pilot_corrected \
        >"$LOG/${model}_${method}.log" 2>&1
    done
  ) & pids+=("$!")
done
failed=0; for pid in "${pids[@]}"; do wait "$pid" || failed=1; done; [[ "$failed" == 0 ]]
python - "$RUN" <<'PY'
import json, sys
from pathlib import Path
import pandas as pd
run=Path(sys.argv[1]); root=run/'results/G03/pilot_corrected/shards'; files=list(root.glob('*.csv.gz'))
passed=len(files)==28 and all(len(pd.read_csv(p))==6 for p in files)
value={'protocol_id':'tdc-r3r5-g03-full-corrected-20261025-v2','passed':passed,'shards':len(files),'expected_shards':28,'rows':sum(len(pd.read_csv(p)) for p in files)}
(run/'results/G03/pilot_corrected/validation.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
if not passed: raise SystemExit(value)
PY
echo G03_CORRECTED_PILOT_COMPLETE >"$LOG/COMPLETE"
