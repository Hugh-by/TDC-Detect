#!/usr/bin/env python3
"""Build and validate the final correction review archive without embedding large tensor volumes."""
from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

RUN = Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01")
STAGE = RUN / "exports/final_correction_stage"
TARGET = Path("/root/TDC_R3R5_FINAL_CORRECTION_REVIEW_20261027.zip")
INDEX = Path("/root/TDC_R3R5_FINAL_CORRECTION_REVIEW_20261027.index.json")
VALIDATION = Path("/root/TDC_R3R5_FINAL_CORRECTION_REVIEW_20261027.validation.json")
G02_VOLUMES = RUN / "exports/g02_tensor_volumes"
G04_VOLUMES = Path("/root/tdc_r3r5_revision_20261022_01_g04_tensor_volumes")
GENERATED = datetime.now(timezone.utc).isoformat()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def place(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        destination.unlink()
    try:
        os.link(source, destination)
    except OSError:
        shutil.copy2(source, destination)


def write_text(relative: str, content: str) -> None:
    destination = STAGE / relative
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        destination.unlink()
    destination.write_text(content, encoding="utf-8")


def copy_scoped_files() -> None:
    if STAGE.exists():
        shutil.rmtree(STAGE)
    STAGE.mkdir(parents=True)
    roots = [
        "code", "reports", "protocols", "validation", "provenance", "manifests",
        "models", "figures", "environment", "results", "logs",
    ]
    for root_name in roots:
        root = RUN / root_name
        if not root.exists():
            continue
        for source in root.rglob("*"):
            if not source.is_file():
                continue
            relative = source.relative_to(RUN)
            if source.suffix == ".pt" or "__pycache__" in relative.parts:
                continue
            if source.suffix in {".pyc", ".tmp", ".lock"}:
                continue
            place(source, STAGE / relative)
    for name in ("SOURCE_HASHES.csv",):
        place(RUN / name, STAGE / name)
    place(RUN / "handoff/TASK_REGISTRY.json", STAGE / "TASK_REGISTRY.json")
    place(RUN / "handoff/tools/validate_export.py", STAGE / "tools/validate_export.py")
    place(Path("/root/服务器补正清单.md"), STAGE / "handoff/SERVER_CORRECTION_CHECKLIST_20261025.md")
    place(G02_VOLUMES / "VOLUME_INDEX.csv", STAGE / "external_indexes/G02_VOLUME_INDEX.csv")
    place(G02_VOLUMES / "validation.json", STAGE / "external_indexes/G02_VOLUME_VALIDATION.json")
    place(G04_VOLUMES / "VOLUME_INDEX.csv", STAGE / "external_indexes/G04_VOLUME_INDEX.csv")
    place(G04_VOLUMES / "validation.json", STAGE / "external_indexes/G04_VOLUME_VALIDATION.json")


def build_data_artifacts() -> None:
    source = RUN / "DATA_ARTIFACTS.csv"
    with source.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        fieldnames = list(reader.fieldnames or [])
        rows = list(reader)
    for task, directory, validation_name in (
        ("G02", G02_VOLUMES, "G02_VOLUME_VALIDATION.json"),
        ("G04", G04_VOLUMES, "G04_VOLUME_VALIDATION.json"),
    ):
        volume_index = list(csv.DictReader((directory / "VOLUME_INDEX.csv").open(newline="", encoding="utf-8")))
        for volume in volume_index:
            rows.append({
                "artifact_id": volume["volume"].removesuffix(".zip").lower(),
                "task_id": task,
                "role": "lossless selected adversarial tensors",
                "required_for_recompute": "True",
                "placement": "separate_archive",
                "archive_name": volume["volume"],
                "member_path": "selected_adv/ (see per-volume VOLUME_INDEX.csv)",
                "sha256": volume["sha256"],
                "bytes": volume["bytes"],
                "availability": "included_as_separate_volume",
                "regeneration_command_or_external_dependency": f"delivered beside review package; validation index external_indexes/{validation_name}",
            })
    destination = STAGE / "DATA_ARTIFACTS.csv"
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def corrected_reviewer_matrix() -> None:
    path = STAGE / "reports/reviewer_evidence_matrix.csv"
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        fields = list(reader.fieldnames or [])
        rows = list(reader)
    updates = {
        "R3.4": {
            "concern": "Complete adaptive attack through the full detector",
            "task_ids": "G01;G02",
            "evidence_status": "completed_gpu_negative_result_preserved",
            "result_paths": "results/G01;results/G02/full;results/G02/legacy_rescore_v2;results/G02/supplemental_v2",
            "key_result": "Legacy rescoring passed; CSN AUC 0.7978 with 94/100 joint evasions, while MViT AUC is 0 with 100/100 joint evasions.",
            "manuscript_section": "Threat model; adaptive evaluation; limitations",
            "proposed_change": "Report the full-detector adaptive protocol and retain the adverse MViT result without score-direction flipping.",
            "allowed_claim": "The evaluated detector is not uniformly robust to the tested full adaptive attacks.",
            "remaining_gap": "Results cover the declared digital model-space attacks, not physical-world video attacks.",
        },
        "R5.2": {
            "concern": "Make each claimed contribution empirically testable",
            "task_ids": "C01;C02;C03;C04;C05;C06;C07;C08;C09;G01;G02;G03;G04;G05",
            "evidence_status": "completed_with_claim_limits",
            "result_paths": "reports/RESULTS_AT_A_GLANCE.csv;reports/manuscript_change_map.md",
            "key_result": "Each retained contribution is linked to a protocol, result, validation record, and stated limitation.",
            "manuscript_section": "Abstract; Introduction; contributions; limitations",
            "proposed_change": "Replace broad contribution language with the testable statements in manuscript_change_map.md.",
            "allowed_claim": "The reported contributions are supported within the exported protocols and conditions.",
            "remaining_gap": "Claims must not be generalized beyond the evaluated datasets, models, attacks, or digital setting.",
        },
        "R5.3": {
            "concern": "Position against adversarial-detection literature and separate digital model-space from physical video attacks",
            "task_ids": "D01;G01;G02;G04",
            "evidence_status": "mapping_corrected_narrative_scope",
            "result_paths": "reports/manuscript_change_map.md;handoff/SERVER_CORRECTION_CHECKLIST_20261025.md",
            "key_result": "The evidence supports only the declared digital, model-space protocols; it does not establish physical-world robustness.",
            "manuscript_section": "Related work; threat model; limitations",
            "proposed_change": "Add adversarial-detection positioning and explicitly state the physical-video boundary.",
            "allowed_claim": "Performance is reported for the declared digital attacks and detector implementation.",
            "remaining_gap": "Final bibliography wording and exact reviewer quotation must be checked against the manuscript-side reviewer-response source.",
        },
    }
    seen = set()
    for row in rows:
        key = row.get("subissue_id")
        if key in updates:
            row.update(updates[key])
            seen.add(key)
    for key, values in updates.items():
        if key not in seen:
            reviewer_id = key.split(".", 1)[0]
            rows.append({"reviewer_id": reviewer_id, "subissue_id": key, **values})
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def make_status() -> tuple[dict, dict[str, list[str]]]:
    old = json.loads((RUN / "exports/review_stage/STATUS.json").read_text(encoding="utf-8"))
    by_id = {task["task_id"]: task for task in old["tasks"]}
    updates = {
        "C04": (8, 8, "tdc-r3r5-c04-roundtrip-repair-20261026-v1", ["results/C04_roundtrip_v2/sample_scores.csv.gz", "results/C04_roundtrip_v2/condition_metrics.csv", "results/C04_roundtrip_v2/paired_differences.csv"], ["results/C04_roundtrip_v2/validation.json"]),
        "C08": (1600, 1600, "tdc-r3r5-g05-corrected-20261025-v2", ["results/G05/full_corrected/clean_features_all.csv.gz", "results/G05/full_corrected/stratified_fpr.csv"], ["results/G05/full_corrected/validation.json"]),
        "D01": (1, 1, "server-correction-checklist-20261025", ["reports/STAGE_REPORT.md", "reports/reviewer_evidence_matrix.csv", "reports/manuscript_change_map.md"], ["validation/NO_GPU_scientific_validation.json"]),
        "G01": (2, 2, "tdc-r3r5-g01-full-forward-gradient-audit", ["results/G01/forward_equivalence.csv", "results/G01/gradient_audit.json", "results/G01/vjp_comparison.json"], ["results/G01/gradient_audit.json"]),
        "G02": (400, 400, "tdc-r3r5-g02-legacy-rescore-20261026-v1", ["results/G02/legacy_rescore_v2/legacy_rescore_per_sample.csv.gz", "results/G02/legacy_rescore_v2/legacy_rescore_feature_errors.csv.gz", "results/G02/supplemental_v2/success_only_metrics.csv", "external_indexes/G02_VOLUME_INDEX.csv"], ["results/G02/legacy_rescore_v2/constraint_validation.json", "results/G02/supplemental_v2/validation.json", "external_indexes/G02_VOLUME_VALIDATION.json"]),
        "G03": (52000, 52000, "tdc-r3r5-g03-full-corrected-20261025-v2", ["results/G03/full_corrected/per_clip_runtime.csv.gz", "results/G03/full_corrected/condition_latency.csv", "results/G03/full_corrected/method_call_and_load_evidence.csv"], ["protocols/G03_METHOD_IDENTITY_GATE.json", "results/G03/full_corrected/final_validation.json"]),
        "G04": (800, 800, "tdc-r3r5-g04-full-corrected-20261025-v2", ["results/G04/summary_corrected/metrics_and_convergence.csv", "results/G04/summary_corrected/loss_saturation_impact.csv", "external_indexes/G04_VOLUME_INDEX.csv"], ["results/G04/summary_corrected/validation.json", "external_indexes/G04_VOLUME_VALIDATION.json"]),
        "G05": (1600, 1600, "tdc-r3r5-g05-corrected-20261025-v2", ["results/G05/full_corrected/clean_features_all.csv.gz", "results/G05/full_corrected/stratified_fpr.csv"], ["results/G05/full_corrected/validation.json"]),
    }
    for task_id, (done, expected, protocol, results, validations) in updates.items():
        task = by_id[task_id]
        task.update({
            "completed_units": done,
            "expected_units": expected,
            "protocol_id": protocol,
            "result_paths": results,
            "validation_paths": validations,
            "status": "completed",
            "reason": "Completed and validated under the listed correction protocol.",
            "next_command": "none",
        })
    for task in old["tasks"]:
        if task["status"] == "completed":
            task["next_command"] = "none"
    status = {
        "format_version": 2,
        "run_id": RUN.name,
        "generated_at": GENERATED,
        "mode": "GPU_FULL_OPTION_B_PLUS_CORRECTIONS_FINAL_EXPORT",
        "scope_complete": True,
        "overall_revision_complete": False,
        "scope_note": "Server-side experiment and correction-delivery scope is complete. Manuscript editing and exact reviewer-quotation verification remain manuscript-side work.",
        "stage_scope_tasks": [task["task_id"] for task in old["tasks"]],
        "tasks": old["tasks"],
    }
    required = {task["task_id"]: task["result_paths"][:1] for task in status["tasks"] if task["status"] == "completed"}
    return status, required


def write_reports(status: dict) -> None:
    write_text("README.md", """# TDC R3+R5 final correction review package\n\nThis package contains the corrected numerical results, reports, protocols, code, validation evidence, and indexes for separately delivered lossless tensor volumes. Start with `reports/STAGE_REPORT.md`, `STATUS.json`, and `DATA_ARTIFACTS.csv`.\n\nThe server-side experiment/correction scope is complete. `overall_revision_complete=false` only because manuscript edits, bibliography wording, and exact reviewer quotations must be checked in the manuscript-side source. G02 and G04 tensors are delivered as independently extractable sibling volumes listed in `external_indexes/` and `DATA_ARTIFACTS.csv`.\n""")
    write_text("reports/STAGE_REPORT.md", f"""# Final correction stage report\n\nGenerated: {GENERATED}\n\n## Outcome\n\nAll authorized scientific computations and correction checks are complete. No E1–E10 result was rerun or overwritten. Corrected results are stored in separate directories. G02 contains 400 independently rescored selected adversarial examples; G03 contains 52,000 per-clip timing rows; G04 contains 800 corrected selected examples; and G05/C08 contains 1,600 prediction-unfiltered clean examples.\n\n## Validation highlights\n\n- G02 legacy rescore passed with maximum feature error 4.303e-05, maximum score error 3.007e-06, and zero decision/prediction mismatches. The adverse MViT result was retained; score direction was not flipped.\n- G03 corrected method-identity and full timing gates passed.\n- G04 corrected selection/constraint validation passed; saturation and changed-selection counts are exported.\n- G05/C08 passed with overall clean FPR 20/1600 (1.25%).\n- C04 was rebuilt from source shards with round-trip parsing; before/after differences are exported.\n- G02 (4 volumes, 400 tensors) and G04 (8 volumes, 800 tensors) passed independent ZIP/CRC/hash/size validation.\n\n## Claim boundary\n\nThe evidence covers the declared digital model-space datasets, models, detectors, and attacks. It does not establish physical-world video-attack robustness. Structural export validation is separate from scientific validation.\n\n## Remaining manuscript-side work\n\nApply `reports/manuscript_change_map.md`, verify final bibliography language, and copy exact reviewer quotations from the manuscript-side reviewer-response source. These do not require more server experiments.\n""")
    unresolved = """# Unresolved items\n\nNo server experiment remains. The following are manuscript/release tasks, not missing computations:\n\n1. Verify exact reviewer quotations and bibliography wording against the manuscript-side source; that source was not present in the server transfer.\n2. Apply the exported claim limits and numerical replacements to the manuscript.\n3. Check dataset/model licenses before public redistribution.\n4. G06 is deferred_optional because A00 validated the complete cache; G07 remains an unauthorized optional extension.\n"""
    write_text("reports/UNRESOLVED_ITEMS.md", unresolved)
    write_text("reports/manuscript_change_map.md", """# Manuscript change map — corrected final\n\n- **R3.4 / threat model and adaptive evaluation:** describe the complete detector-path attack and report both favorable and adverse outcomes, including MViT AUC=0; do not reverse score direction.\n- **R5.2 / contributions:** express each contribution as a protocol-bounded, testable statement linked to the exported evidence matrix.\n- **R5.3 / related work and limitations:** position the method within adversarial-detection work and explicitly distinguish digital model-space evaluation from physical-world video attacks.\n- **C04:** replace derived tables and plots with the `C04_roundtrip_v2` outputs.\n- **G03:** use corrected method identities and both timing boundaries; do not mix adapter utility with independent test utility.\n- **G04:** report full and success-only outcomes, the actual optimization loss, saturation audit, candidate-selection effects, and constraint evidence.\n- **G05/C08:** report prediction-unfiltered overall/correct/wrong clean cohorts with frozen thresholds.\n\nExact reviewer quotations and final citation language must be copied from and checked against the manuscript-side reviewer-response source.\n""")


def build_manifest(status: dict, required: dict[str, list[str]]) -> dict:
    files = []
    for path in sorted(STAGE.rglob("*")):
        if not path.is_file() or path.name == "export_manifest.json":
            continue
        relative = path.relative_to(STAGE).as_posix()
        if not relative.isascii():
            raise SystemExit(f"non-ASCII archive member: {relative}")
        files.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path)})
    return {
        "format_version": 1,
        "run_id": RUN.name,
        "stage": "FINAL_CORRECTION_REVIEW",
        "scope_complete": True,
        "generated_at": GENERATED,
        "stage_scope_tasks": status["stage_scope_tasks"],
        "required_result_paths": required,
        "files": files,
    }


def main() -> None:
    for directory, expected in ((G02_VOLUMES, 400), (G04_VOLUMES, 800)):
        validation = json.loads((directory / "validation.json").read_text())
        if not validation.get("passed") or validation.get("tensor_count") != expected:
            raise SystemExit(f"tensor-volume gate failed: {directory}")
    copy_scoped_files()
    build_data_artifacts()
    corrected_reviewer_matrix()
    status, required = make_status()
    write_reports(status)
    write_text("STATUS.json", json.dumps(status, indent=2, sort_keys=True) + "\n")
    manifest = build_manifest(status, required)
    write_text("export_manifest.json", json.dumps(manifest, indent=2, sort_keys=True) + "\n")

    command = ["python", str(STAGE / "tools/validate_export.py"), str(STAGE), "--registry", str(STAGE / "TASK_REGISTRY.json")]
    completed = subprocess.run(command, text=True, capture_output=True)
    VALIDATION.write_text(completed.stdout, encoding="utf-8")
    if completed.returncode != 0:
        raise SystemExit(completed.stdout + completed.stderr)

    temporary = TARGET.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for path in sorted(STAGE.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(STAGE).as_posix())
    os.replace(temporary, TARGET)
    with zipfile.ZipFile(TARGET) as archive:
        bad_member = archive.testzip()
    if bad_member is not None:
        raise SystemExit(f"final archive CRC failure: {bad_member}")
    summary = {
        "generated_at": GENERATED,
        "package": str(TARGET),
        "bytes": TARGET.stat().st_size,
        "sha256": sha256(TARGET),
        "structural_validation": str(VALIDATION),
        "structural_validation_passed": True,
        "archive_crc_passed": True,
        "scientific_scope_complete": True,
        "g02_tensor_volume_directory": str(G02_VOLUMES),
        "g04_tensor_volume_directory": str(G04_VOLUMES),
        "overall_revision_complete": False,
        "remaining_work": "manuscript-side edits, exact reviewer quotation check, and release-license review only",
    }
    INDEX.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
