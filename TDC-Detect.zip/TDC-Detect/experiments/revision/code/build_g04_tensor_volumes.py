#!/usr/bin/env python3
"""Create independently extractable <=2 GiB lossless G04 selected-tensor volumes."""
from __future__ import annotations

import csv
import hashlib
import io
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

RUN = Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01")
OUT = Path("/root/tdc_r3r5_revision_20261022_01_g04_tensor_volumes")
MAX_RAW = 1750 * 1024 * 1024
MAX_VOLUME = 2 * 1024**3


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    items = []
    for index_path in sorted((RUN / "results/G04/full_corrected").glob("*/selected_adv_index.csv")):
        frame = pd.read_csv(index_path).sort_values(["attack", "source_rank"])
        model = index_path.parent.name
        for row in frame.itertuples(index=False):
            source = index_path.parent / row.relative_path
            if not source.is_file():
                raise SystemExit(f"missing tensor: {source}")
            observed_hash = sha256(source)
            if observed_hash != row.sha256:
                raise SystemExit(f"tensor hash mismatch: {source}")
            items.append({
                "action_model": model,
                "attack": row.attack,
                "source_rank": int(row.source_rank),
                "relative_path": f"results/G04/full_corrected/{model}/{row.relative_path}",
                "source_path": source,
                "bytes": source.stat().st_size,
                "sha256": observed_hash,
            })
    if len(items) != 800:
        raise SystemExit(f"expected 800 selected tensors, found {len(items)}")

    groups, current, current_bytes = [], [], 0
    for item in items:
        if current and current_bytes + item["bytes"] > MAX_RAW:
            groups.append(current)
            current, current_bytes = [], 0
        current.append(item)
        current_bytes += item["bytes"]
    if current:
        groups.append(current)

    volume_rows = []
    for number, group in enumerate(groups, 1):
        name = f"G04_SELECTED_ADV_VOLUME_{number:02d}.zip"
        target = OUT / name
        temporary = target.with_suffix(".zip.tmp")
        index_buffer = io.StringIO()
        fields = ["action_model", "attack", "source_rank", "relative_path", "member", "bytes", "sha256"]
        writer = csv.DictWriter(index_buffer, fieldnames=fields)
        writer.writeheader()
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_STORED, allowZip64=True) as archive:
            for item in group:
                member = f"selected_adv/{item['action_model']}/{item['attack']}/{item['source_path'].name}"
                archive.write(item["source_path"], member)
                writer.writerow({
                    "action_model": item["action_model"],
                    "attack": item["attack"],
                    "source_rank": item["source_rank"],
                    "relative_path": item["relative_path"],
                    "member": member,
                    "bytes": item["bytes"],
                    "sha256": item["sha256"],
                })
            archive.writestr("VOLUME_INDEX.csv", index_buffer.getvalue())
        os.replace(temporary, target)
        with zipfile.ZipFile(target) as archive:
            bad_member = archive.testzip()
        if bad_member is not None:
            raise SystemExit(f"ZIP CRC failure: {target}: {bad_member}")
        if target.stat().st_size > MAX_VOLUME:
            raise SystemExit(f"volume exceeds 2 GiB: {target}")
        volume_rows.append({
            "volume": name,
            "path": str(target),
            "bytes": target.stat().st_size,
            "sha256": sha256(target),
            "tensor_count": len(group),
            "raw_tensor_bytes": sum(item["bytes"] for item in group),
            "maximum_bytes": MAX_VOLUME,
            "independently_extractable": True,
        })

    pd.DataFrame(volume_rows).to_csv(OUT / "VOLUME_INDEX.csv", index=False)
    validation = {
        "protocol_id": "tdc-r3r5-g04-tensor-volumes-20261026-v1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "passed": sum(row["tensor_count"] for row in volume_rows) == 800
        and all(row["bytes"] <= MAX_VOLUME for row in volume_rows),
        "tensor_count": 800,
        "volume_count": len(volume_rows),
        "source_indexes": [
            f"results/G04/full_corrected/{model}/selected_adv_index.csv"
            for model in ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
        ],
        "volumes": volume_rows,
    }
    (OUT / "validation.json").write_text(json.dumps(validation, indent=2, sort_keys=True) + "\n")
    if not validation["passed"]:
        raise SystemExit(validation)


if __name__ == "__main__":
    main()
