#!/usr/bin/env python3
"""Add the common export-contract aliases to the independently validated C01 reuse."""

from __future__ import annotations

import gzip
import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

from cpu_common import RUN, SEED, write_csv, write_json

TASK = "C01"
PROTOCOL = "tdc-e7-cpu-correction-20261021-v1"


def write_gzip(path: Path, frame: pd.DataFrame) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    with gzip.open(temp, "wt", encoding="utf-8", newline="") as handle:
        frame.to_csv(handle, index=False)
    os.replace(temp, path)


def main() -> None:
    result = RUN / "results/C01"
    oof_path = result / "oof_scores.csv.gz"
    oof = pd.read_csv(oof_path, low_memory=False)
    aliases = {
        "run_id": PROTOCOL,
        "task_id": TASK,
        "dataset": "k400",
        "partition": "oof",
        "source_id": oof.relative_path.astype(str),
        "method": "TDC-v2",
        "score": oof.oof_score.to_numpy(float),
        "score_domain": "probability",
        "threshold": oof.training_fold_threshold.to_numpy(float),
        "predicted_adv": oof.predicted_adversarial.to_numpy(int),
    }
    for name, values in aliases.items():
        oof[name] = values
    required = ["run_id", "dataset", "model", "partition", "source_id", "pair_id", "relative_path",
                "attack", "method", "config", "is_adv", "attack_success", "fold", "score",
                "score_domain", "threshold", "predicted_adv"]
    retained = [column for column in oof.columns if column not in required]
    write_gzip(oof_path, oof[required + retained])

    metrics_path = result / "condition_metrics.csv"
    metrics = pd.read_csv(metrics_path)
    metrics["run_id"] = PROTOCOL
    metrics["task_id"] = TASK
    metrics["evaluation_protocol"] = "pair_grouped_5fold_oof"
    metrics["dataset"] = "k400"
    metrics["method"] = "TDC-v2"
    metrics["n_sources"] = metrics[["n_clean", "n_adv"]].min(axis=1).astype(int)
    metrics["threshold"] = np.nan
    metrics["threshold_note"] = "fold-specific training-clean thresholds are in oof_scores.csv.gz"
    write_csv(metrics_path, metrics)

    difference_path = result / "paired_differences.csv"
    differences = pd.read_csv(difference_path)
    methods = differences.comparison.str.split(" - ", n=1, expand=True)
    differences["task_id"] = TASK
    differences["contrast_id"] = differences.comparison.str.replace(" - ", "__minus__", regex=False)
    differences["method_a"] = methods[0]
    differences["method_b"] = methods[1]
    differences["condition_scope"] = differences.scope.replace({"macro_summary": "macro"})
    differences["metric"] = "roc_auc"
    differences["point_difference"] = differences.difference.fillna(differences.point_macro_difference)
    differences["n_boot_valid"] = differences.bootstrap_replicates.fillna(0).astype(int)
    differences["source_cluster_rule"] = "cross-model shared relative_path; fixed OOF scores"
    differences["seed"] = SEED
    differences["conditioning_note"] = "OOF fixed-score bootstrap; fold assignment/model fitting uncertainty excluded"
    write_csv(difference_path, differences)

    required_oof = set(required)
    validation = {
        "protocol_id": PROTOCOL,
        "task_id": TASK,
        "source_revalidation": str(RUN / "validation/C01.json"),
        "rows": len(oof),
        "required_score_columns_present": required_oof <= set(oof.columns),
        "scores_and_thresholds_finite": bool(np.isfinite(oof.score).all() and np.isfinite(oof.threshold).all()),
        "unique_model_config_pair_attack": not oof.duplicated(["model", "config", "pair_id", "attack"]).any(),
        "source_scientific_values_changed": False,
        "note": "Only common-contract aliases were added; original scientific columns and values were retained.",
    }
    validation["passed"] = all([validation["required_score_columns_present"],
                                validation["scores_and_thresholds_finite"],
                                validation["unique_model_config_pair_attack"]])
    write_json(RUN / "validation/C01_export_contract.json", validation)
    print(json.dumps(validation, indent=2))


if __name__ == "__main__":
    main()
