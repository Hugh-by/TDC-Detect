"""Shared deterministic CPU analysis utilities for the R3/R5 revision."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
from statistics import fmean

for name in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ.setdefault(name, "1")
os.environ.setdefault("CUDA_VISIBLE_DEVICES", "")

import numpy as np
import pandas as pd
import sklearn
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
BASE = Path(os.environ.get("TDC_BASE_ROOT", "/root/autodl-tmp/tsc/outputs/tdc-final-20260714"))
SUPP = Path(os.environ.get("TDC_SUPPLEMENT_ROOT", "/root/autodl-tmp/results_supp_20260817"))
SEED = 20260714
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
DATASETS = ("k400", "ucf101")
ATTACKS = ("fgsm", "pgd", "ofa-style", "flicker-style")
FEATURES = [
    "R_model", "R_label_change", "R_conf_var", "R_uniform_shift",
    "R_fft_conf_high", "R_fft_conf_entropy", "R_fft_vlad_high", "R_fft_vlad_entropy",
    "R_local_conf_max", "R_local_conf_top2", "R_local_shift_max", "R_local_shift_top2",
    "R_vlm", "vlad_original", "R_sem_mean", "R_sem_max", "R_sem_var",
    "R_fft_sem_high", "R_fft_sem_entropy", "R_local_sem_max", "R_local_sem_top2",
]
FFT = ["R_fft_conf_high", "R_fft_conf_entropy", "R_fft_vlad_high", "R_fft_vlad_entropy",
       "R_fft_sem_high", "R_fft_sem_entropy"]
FFT_HIGH = ["R_fft_conf_high", "R_fft_vlad_high", "R_fft_sem_high"]
FFT_ENTROPY = ["R_fft_conf_entropy", "R_fft_vlad_entropy", "R_fft_sem_entropy"]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def write_csv(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp, index=False)
    os.replace(temp, path)


def write_csv_gz(path: Path, frame: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temp, index=False, compression="gzip")
    os.replace(temp, path)


def load_e1(dataset: str, model: str, split: str) -> pd.DataFrame:
    path = BASE / "E1" / f"{dataset}_{model}_{split}.csv"
    frame = pd.read_csv(path, low_memory=False)
    if set(frame.protocol_id.astype(str)) != {"tdc-final-20260714"}:
        raise ValueError(f"protocol mismatch: {path}")
    if frame.duplicated(["pair_id", "attack"]).any():
        raise ValueError(f"duplicate pair/attack: {path}")
    if not np.isfinite(frame[FEATURES].to_numpy(float)).all():
        raise ValueError(f"non-finite feature: {path}")
    return frame


def make_lr(max_iter: int = 5000) -> Pipeline:
    return Pipeline([
        ("scaler", StandardScaler()),
        ("logistic", LogisticRegression(C=1.0, l1_ratio=0.0, class_weight="balanced",
                                          max_iter=max_iter, solver="lbfgs", random_state=SEED)),
    ])


def fit_lr(train: pd.DataFrame, feature_names: list[str], max_iter: int = 5000) -> Pipeline:
    if set(train.partition.astype(str)) != {"calibration"}:
        raise ValueError("fit input is not calibration-only")
    pipeline = make_lr(max_iter).fit(train[feature_names].to_numpy(float), train.is_adv.to_numpy(int))
    if int(pipeline.named_steps["logistic"].n_iter_[0]) >= max_iter:
        raise RuntimeError("LR reached max_iter")
    return pipeline


def score_lr(pipeline: Pipeline, frame: pd.DataFrame, feature_names: list[str]) -> np.ndarray:
    return pipeline.predict_proba(frame[feature_names].to_numpy(float))[:, 1]


def threshold_from_clean(frame: pd.DataFrame, scores: np.ndarray) -> float:
    clean = np.asarray(scores, float)[frame.is_adv.to_numpy(int) == 0]
    return float(np.quantile(clean, 0.99, method="higher"))


def model_state(pipeline: Pipeline, feature_names: list[str], threshold: float) -> dict:
    scaler = pipeline.named_steps["scaler"]
    lr = pipeline.named_steps["logistic"]
    return {
        "feature_order": feature_names, "dtype": "float64", "sklearn": sklearn.__version__,
        "scaler_mean": np.asarray(scaler.mean_).tolist(), "scaler_scale": np.asarray(scaler.scale_).tolist(),
        "scaler_var": np.asarray(scaler.var_).tolist(), "lr_coef": np.asarray(lr.coef_[0]).tolist(),
        "lr_intercept": float(lr.intercept_[0]), "lr_classes": np.asarray(lr.classes_).tolist(),
        "lr_n_iter": int(lr.n_iter_[0]), "C": 1.0, "l1_ratio": 0.0,
        "penalty_semantics": "L2", "class_weight": "balanced", "solver": "lbfgs",
        "max_iter": int(lr.max_iter), "random_state": SEED,
        "threshold": threshold, "threshold_source": "calibration clean 0.99 quantile method=higher",
        "decision": "score > threshold",
    }


def condition(frame: pd.DataFrame, attack: str, setting: str) -> pd.DataFrame:
    clean = frame[frame.attack == "clean"]
    adv = frame[frame.attack != "clean"] if attack == "pooled" else frame[frame.attack == attack]
    if setting == "success-only":
        adv = adv[pd.to_numeric(adv.attack_success, errors="coerce") == 1]
        clean = clean[clean.pair_id.isin(set(adv.pair_id))]
    result = pd.concat([clean, adv], ignore_index=True)
    if result.is_adv.nunique() != 2:
        raise ValueError(f"condition lacks class: {attack}/{setting}")
    if result[result.is_adv == 0].duplicated("pair_id").any():
        raise ValueError("clean rows duplicated")
    return result


def metric(labels: np.ndarray, scores: np.ndarray, threshold: float) -> dict:
    labels = np.asarray(labels, int)
    scores = np.asarray(scores, float)
    fpr, tpr, _ = roc_curve(labels, scores)
    predicted = scores > threshold
    clean, adv = labels == 0, labels == 1
    return {
        "roc_auc": float(roc_auc_score(labels, scores)),
        "pr_auc": float(average_precision_score(labels, scores)),
        "fpr_at_95_tpr": float(fpr[np.flatnonzero(tpr >= .95)[0]]),
        "tpr_at_1_fpr": float(np.max(tpr[fpr <= .01])) if np.any(fpr <= .01) else 0.0,
        "threshold_fpr": float(np.mean(predicted[clean])), "threshold_tpr": float(np.mean(predicted[adv])),
        "n_sources": int(pd.Series(np.arange(len(labels))).size),
        "n_clean": int(clean.sum()), "n_adv": int(adv.sum()),
    }


def score_lookup(full: pd.DataFrame, values: np.ndarray, selected: pd.DataFrame) -> np.ndarray:
    lookup = pd.Series(np.asarray(values, float), index=pd.MultiIndex.from_arrays(
        [full.pair_id.astype(str), full.attack.astype(str)]))
    if not lookup.index.is_unique:
        raise ValueError("score lookup keys not unique")
    return lookup.loc[list(zip(selected.pair_id.astype(str), selected.attack.astype(str)))].to_numpy(float)


def evaluate_methods(test: pd.DataFrame, methods: dict[str, np.ndarray], thresholds: dict[str, float],
                     protocol_id: str, task_id: str) -> pd.DataFrame:
    rows = []
    for attack in (*ATTACKS, "pooled"):
        for setting in ("full", "success-only"):
            selected = condition(test, attack, setting)
            for method, all_scores in methods.items():
                values = score_lookup(test, all_scores, selected)
                stats = metric(selected.is_adv.to_numpy(int), values, thresholds[method])
                stats["n_sources"] = int(selected.relative_path.nunique())
                rows.append({
                    "protocol_id": protocol_id, "task_id": task_id, "evaluation_protocol": "independent_calibration_test",
                    "dataset": str(test.dataset.iloc[0]), "model": str(test.action_model.iloc[0]),
                    "method": method, "config": "NA", "attack": attack, "setting": setting,
                    "threshold": thresholds[method], **stats,
                })
    return pd.DataFrame(rows)


def weighted_auc(labels: np.ndarray, scores: np.ndarray, cluster_indices: np.ndarray,
                 counts: np.ndarray) -> float:
    weights = counts[cluster_indices]
    return float(roc_auc_score(labels, scores, sample_weight=weights))


def batch_weighted_auc(labels: np.ndarray, scores: np.ndarray, cluster_indices: np.ndarray,
                       count_matrix: np.ndarray) -> np.ndarray:
    """Vectorized exact weighted AUC for many fixed-score bootstrap replicates."""
    labels = np.asarray(labels, int)
    scores = np.asarray(scores, float)
    order = np.argsort(scores, kind="mergesort")
    ordered_scores = scores[order]
    ordered_labels = labels[order]
    weights = count_matrix[:, np.asarray(cluster_indices, int)[order]]
    starts = np.r_[0, np.flatnonzero(np.diff(ordered_scores) != 0) + 1]
    negative = np.add.reduceat(weights * (ordered_labels == 0), starts, axis=1)
    positive = np.add.reduceat(weights * (ordered_labels == 1), starts, axis=1)
    negative_before = np.cumsum(negative, axis=1) - negative
    numerator = np.sum(positive * (negative_before + 0.5 * negative), axis=1)
    denominator = positive.sum(axis=1) * negative.sum(axis=1)
    if np.any(denominator <= 0):
        raise ValueError("bootstrap replicate lacks a binary class")
    return numerator / denominator


def bootstrap_macro(conditions: list[dict], contrasts: list[tuple[str, str]], protocol_id: str,
                    task_id: str, replicates: int = 1000) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Cross-condition paired source bootstrap with shared dataset/path weights."""
    universe = sorted({cluster for item in conditions for cluster in item["clusters"]})
    universe_index = {cluster: index for index, cluster in enumerate(universe)}
    prepared = []
    for item in conditions:
        prepared.append({
            **item,
            "cluster_indices": np.asarray([universe_index[value] for value in item["clusters"]], int),
            "labels": np.asarray(item["labels"], int),
            "scores": {key: np.asarray(value, float) for key, value in item["scores"].items()},
        })
    point_rows = []
    for left, right in contrasts:
        condition_differences = []
        for item in prepared:
            difference = float(roc_auc_score(item["labels"], item["scores"][left]) -
                               roc_auc_score(item["labels"], item["scores"][right]))
            condition_differences.append(difference)
            point_rows.append({
                "protocol_id": protocol_id, "task_id": task_id, "contrast_id": f"{left}__minus__{right}",
                "method_a": left, "method_b": right, "condition_scope": "condition",
                "dataset": item["dataset"], "model": item["model"], "attack": item["attack"],
                "setting": item["setting"], "metric": "roc_auc", "point_difference": difference,
                "bootstrap_mean": np.nan, "ci_low": np.nan, "ci_high": np.nan, "n_boot_valid": 0,
                "source_cluster_rule": "dataset + normalized relative_path; weights shared across models/methods",
                "seed": SEED, "conditioning_note": "fixed fitted models/scores; no refit",
            })
        point_rows.append({
            "protocol_id": protocol_id, "task_id": task_id, "contrast_id": f"{left}__minus__{right}",
            "method_a": left, "method_b": right, "condition_scope": "macro",
            "dataset": "macro", "model": "macro", "attack": "macro", "setting": "full",
            "metric": "roc_auc", "point_difference": fmean(condition_differences),
            "bootstrap_mean": np.nan, "ci_low": np.nan, "ci_high": np.nan, "n_boot_valid": 0,
            "source_cluster_rule": "dataset + normalized relative_path; weights shared across models/methods",
            "seed": SEED, "conditioning_note": "fixed fitted models/scores; no refit",
        })
    rng = np.random.default_rng(SEED)
    count_matrix = np.zeros((replicates, len(universe)), dtype=np.float64)
    for replicate in range(replicates):
        sampled = rng.integers(0, len(universe), len(universe))
        count_matrix[replicate] = np.bincount(sampled, minlength=len(universe))
    aucs: dict[tuple[int, str], np.ndarray] = {}
    required_methods = sorted({method for pair in contrasts for method in pair})
    for condition_index, item in enumerate(prepared):
        for method in required_methods:
            aucs[condition_index, method] = batch_weighted_auc(
                item["labels"], item["scores"][method], item["cluster_indices"], count_matrix)
    replicate_rows = []
    for left, right in contrasts:
        condition_arrays = []
        for index, item in enumerate(prepared):
            values = aucs[index, left] - aucs[index, right]
            condition_arrays.append(values)
            for replicate, value in enumerate(values):
                replicate_rows.append({
                    "protocol_id": protocol_id, "task_id": task_id, "replicate": replicate,
                    "contrast_id": f"{left}__minus__{right}", "condition_scope": "condition",
                    "dataset": item["dataset"], "model": item["model"], "attack": item["attack"],
                    "setting": item["setting"], "difference": float(value),
                })
        macro = np.mean(np.vstack(condition_arrays), axis=0)
        for replicate, value in enumerate(macro):
            replicate_rows.append({
                "protocol_id": protocol_id, "task_id": task_id, "replicate": replicate,
                "contrast_id": f"{left}__minus__{right}", "condition_scope": "macro",
                "dataset": "macro", "model": "macro", "attack": "macro", "setting": "full",
                "difference": float(value),
            })
    reps = pd.DataFrame(replicate_rows)
    points = pd.DataFrame(point_rows)
    keys = ["contrast_id", "condition_scope", "dataset", "model", "attack", "setting"]
    for key, group in reps.groupby(keys, sort=False):
        values = group.difference.to_numpy(float)
        mask = np.ones(len(points), dtype=bool)
        for column, value in zip(keys, key):
            mask &= points[column].astype(str).to_numpy() == str(value)
        points.loc[mask, "bootstrap_mean"] = float(values.mean())
        points.loc[mask, "ci_low"] = float(np.quantile(values, .025))
        points.loc[mask, "ci_high"] = float(np.quantile(values, .975))
        points.loc[mask, "n_boot_valid"] = len(values)
    return points, reps


def bootstrap_payload(test: pd.DataFrame, methods: dict[str, np.ndarray], attack: str = "pooled",
                      setting: str = "full") -> dict:
    selected = condition(test, attack, setting)
    clusters = [f"{selected.dataset.iloc[0]}|{path}" for path in selected.relative_path.astype(str)]
    return {
        "dataset": str(selected.dataset.iloc[0]), "model": str(selected.action_model.iloc[0]),
        "attack": attack, "setting": setting, "clusters": clusters,
        "labels": selected.is_adv.to_numpy(int),
        "scores": {method: score_lookup(test, values, selected) for method, values in methods.items()},
    }
