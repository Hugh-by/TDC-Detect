#!/usr/bin/env python3
"""C07 evidence synthesis and C08 input-availability audit (CPU only)."""

from __future__ import annotations

import hashlib
import json
import os
import time
from pathlib import Path

import numpy as np
import pandas as pd

from cpu_common import BASE, DATASETS, FEATURES, MODELS, RUN, SUPP, load_e1, write_csv, write_json

PROTOCOL = "tdc-r3r5-c07-c08-20261022-v1"
PREDICTION_ROOT = Path(os.environ.get(
    "TDC_UNFILTERED_PREDICTION_ROOT", "/root/autodl-tmp/tsc/outputs/repaired_clean_correct"))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def feature_group(name: str) -> str:
    if name == "R_vlm":
        return "clip_response_variability"
    if name.startswith("R_local_conf"):
        return "local_confidence"
    if name.startswith("R_local_shift"):
        return "local_action_shift"
    if name.startswith("R_local_sem"):
        return "local_cross_modal_discrepancy"
    if name.startswith("R_fft_conf"):
        return "global_confidence_order"
    if name.startswith("R_fft_vlad"):
        return "global_action_shift_order"
    if name.startswith("R_fft_sem"):
        return "global_cross_modal_order"
    if name in {"vlad_original", "R_sem_mean", "R_sem_max", "R_sem_var"}:
        return "global_cross_modal_discrepancy"
    return "global_action_response"


def rationale(name: str) -> dict[str, str]:
    group = feature_group(name)
    if "fft" in name:
        kind = "empirical_order_descriptor"
        motivation = "Summarize order-dependent variation across the five heterogeneous global probes."
        limitation = "The probe axis is not physical time; the two non-DC bins do not establish a spectral mechanism or causal importance."
    elif name in {"R_sem_mean", "R_sem_max", "R_sem_var", "vlad_original"} or "_sem_" in name:
        kind = "mathematically_defined_empirical_signal"
        motivation = "Measure action-model versus CLIP response discrepancy with the stated symmetric KL definition."
        limitation = "Discrepancy can arise on ambiguous clean clips and does not uniquely identify adversarial perturbation; KL remains tail-sensitive."
    elif name in {"R_uniform_shift", "R_local_shift_max", "R_local_shift_top2"}:
        kind = "mathematically_defined_empirical_signal"
        motivation = "Measure action-response change relative to the deployable full-clip original view."
        limitation = "Local content can naturally disagree with the full clip; this is not a matching-support causal baseline."
    elif name in {"R_model", "R_vlm", "R_conf_var", "R_label_change"}:
        kind = "mathematically_defined_empirical_signal"
        motivation = "Measure dispersion or instability of model responses across fixed probes."
        limitation = "Response instability is not attack-specific and can also reflect benign ambiguity or probe mismatch."
    else:
        kind = "empirical_summary"
        motivation = "Compact a fixed set of local or global confidence responses for supervised calibration."
        limitation = "No universal monotonic direction or causal interpretation is claimed; correlated features share fitted weight."
    return {
        "feature": name,
        "feature_group": group,
        "rationale_type": kind,
        "design_motivation": motivation,
        "supporting_evidence": "E5/E11/E12/E15 group or probe analyses plus C05/C09 targeted controls; evidence is empirical and condition-dependent.",
        "does_not_guarantee": limitation,
        "coefficient_interpretation": "Standardized conditional LR weight, not an independent or causal effect.",
    }


def run_c07() -> None:
    result = RUN / "results/C07"
    result.mkdir(parents=True, exist_ok=True)
    write_json(RUN / "protocols/C07.json", {
        "protocol_id": PROTOCOL,
        "task_id": "C07",
        "mode": "NO_GPU",
        "correlation_input": "E1 calibration rows only",
        "correlations": ["pearson", "spearman"],
        "coefficient_stability": "reuse E16 1000 source-bootstrap fits per dataset-model; no new bootstrap fits",
        "deployment_sources": ["E3", "E4", "E15"],
        "interpretation": "coefficients are conditional fitted weights, not causal feature importance",
        "gpu_used": False,
    })

    correlation_rows: list[dict] = []
    for dataset in DATASETS:
        for model in MODELS:
            frame = load_e1(dataset, model, "calibration")
            for method in ("pearson", "spearman"):
                matrix = frame[FEATURES].corr(method=method)
                for left_index, left in enumerate(FEATURES):
                    for right_index, right in enumerate(FEATURES):
                        correlation_rows.append({
                            "protocol_id": PROTOCOL,
                            "dataset": dataset,
                            "model": model,
                            "partition": "calibration",
                            "correlation_method": method,
                            "feature_a_index": left_index,
                            "feature_a": left,
                            "feature_b_index": right_index,
                            "feature_b": right,
                            "correlation": float(matrix.loc[left, right]),
                            "n_rows": len(frame),
                            "n_sources": int(frame.relative_path.nunique()),
                        })
    correlations = pd.DataFrame(correlation_rows)
    write_csv(result / "correlation.csv", correlations)
    unique_pairs = correlations[
        (correlations.correlation_method == "spearman") &
        (correlations.feature_a_index < correlations.feature_b_index)
    ].copy()
    unique_pairs["absolute_correlation"] = unique_pairs.correlation.abs()
    write_csv(result / "high_correlation_pairs.csv", unique_pairs.sort_values(
        ["absolute_correlation", "dataset", "model"], ascending=[False, True, True]).head(100))

    summary = pd.read_csv(SUPP / "E16/coefficient_bootstrap_summary.csv")
    summary.insert(0, "protocol_id_reuse", PROTOCOL)
    summary["source_protocol_id"] = "tdc-supplement-20260817"
    summary["interpretation_limit"] = "conditional standardized LR weight; correlated predictors prevent independent/causal attribution"
    write_csv(result / "coefficient_stability.csv", summary)
    ranks = pd.read_csv(SUPP / "E16/coefficient_rank_correlations.csv")
    ranks.insert(0, "protocol_id_reuse", PROTOCOL)
    ranks["interpretation_limit"] = "rank agreement does not prove feature causality or individual necessity"
    write_csv(result / "coefficient_rank_correlations.csv", ranks)

    deployment_parts: list[pd.DataFrame] = []
    e3 = pd.read_csv(BASE / "metrics/E3_leave_one_model_out.csv")
    e3 = e3[(e3.method == "TDC-v2") & (e3.setting == "full")].copy()
    e3["evidence_source"] = "E3_leave_one_model_out"
    e3["deployment_scenario"] = "new architecture; labeled attacks exist only for other architectures"
    e3["target"] = e3.dataset.astype(str) + "/" + e3.held_model.astype(str)
    deployment_parts.append(e3)
    e4 = pd.read_csv(BASE / "metrics/E4_cross_dataset_transfer.csv")
    e4 = e4[(e4.method == "TDC-v2") & (e4.setting == "full")].copy()
    e4["evidence_source"] = "E4_cross_dataset_transfer"
    e4["deployment_scenario"] = "new domain; source-domain attacks available; source threshold frozen"
    e4["target"] = e4.test_dataset.astype(str) + "/" + e4.model.astype(str)
    deployment_parts.append(e4)
    e15 = pd.read_csv(SUPP / "E15/cross_domain_branch_ablation.csv")
    e15 = e15[(e15.method == "TDC-v2") & (e15.setting == "full")].copy()
    e15["evidence_source"] = "E15_cross_domain_branch_ablation"
    e15["deployment_scenario"] = "new domain; branch evidence under frozen source-domain readout"
    e15["target"] = e15.test_dataset.astype(str) + "/" + e15.model.astype(str)
    deployment_parts.append(e15)
    deployment = pd.concat(deployment_parts, ignore_index=True, sort=False)
    deployment.insert(0, "protocol_id_reuse", PROTOCOL)
    deployment["threshold_interpretation"] = "test FPR/TPR observed under the stated frozen calibration threshold; not forced to 1% on target test"
    deployment["attack_free_limit"] = "LOMO/cross-domain transfer still uses labeled attacks in a source condition"
    write_csv(result / "deployment_table.csv", deployment)
    scenarios = pd.DataFrame([
        {"scenario": "new architecture with representative clean and attack calibration", "supported_action": "extract features and fit architecture-specific scaler/LR/threshold", "evidence": "E1 per-condition fitting", "limitation": "feature extraction and attack generation dominate calibration cost"},
        {"scenario": "new architecture without target attacks; attacks available on other architectures", "supported_action": "freeze a LOMO source-trained readout and audit target clean FPR", "evidence": "E3", "limitation": "not attack-free training and target threshold behavior varies"},
        {"scenario": "new domain without target attacks; source-domain attacks available", "supported_action": "freeze source-domain readout and threshold", "evidence": "E4/E15", "limitation": "target-clean recalibration would be a different protocol"},
        {"scenario": "only target clean data, no labeled attacks anywhere", "supported_action": "current supervised LR cannot be trained unchanged", "evidence": "not supported by current method", "limitation": "clean-only anomaly scoring is future work, not an existing result"},
    ])
    scenarios.insert(0, "protocol_id", PROTOCOL)
    write_csv(result / "deployment_scenarios.csv", scenarios)
    write_csv(result / "feature_rationale.csv", pd.DataFrame([rationale(name) for name in FEATURES]))

    selection = f"""# C07 selection-history audit

Protocol: `{PROTOCOL}`. This is an evidence-bound audit, not a retrospective preregistration claim.

## What can be established

- The executed E1–E10 server tree, launch scripts, manifests, logs, outputs, and later validation copies form a consistent path/content evidence chain for `tdc-final-20260714`.
- The recovered E1 calibration/test source paths are disjoint for all eight dataset–model conditions.
- The later E11–E16 supplement is separately versioned as `tdc-supplement-20260817`; it is not treated as part of the original July run.
- The new C03–C09 controls were specified by the present handoff before this run and write only to the new run root.

## What cannot be established

- The historical working tree has no `.git` metadata, commit, or reflog. Path, byte hashes, logs, and outputs cannot prove the full sequence of earlier exploratory choices.
- Source-disjoint calibration/test prevents direct sample leakage, but it does not remove researcher degrees of freedom from repeated inspection of an old test set.
- The original E7 manuscript claim and recovered server E7 were inconsistent. C01 is a new correction under the declared GroupKFold/per-configuration-refit protocol, not recovered proof of the missing historical run.

## Consequence for claims

Existing test results may support transparent retrospective evidence, but must not be described as historically preregistered or as proof that the test set was never consulted during feature/probe design. Any configuration selected because of the current old-test comparisons is exploratory and requires a genuinely new source holdout for confirmatory language.

Primary evidence: `handoff/evidence/RECOVERY_REPORT.md`, `handoff/evidence/paper_result_provenance.csv`, `provenance/input_manifest.csv`, and `validation/A00.json`.
"""
    (result / "selection_history.md").write_text(selection, encoding="utf-8")

    validation = {
        "protocol_id": PROTOCOL,
        "task_id": "C07",
        "passed": bool(np.isfinite(correlations.correlation.to_numpy(float)).all()),
        "correlation_rows": len(correlations),
        "coefficient_summary_rows": len(summary),
        "rank_correlation_rows": len(ranks),
        "deployment_evidence_rows": len(deployment),
        "feature_rationale_rows": len(FEATURES),
        "coefficient_bootstrap_refit_run": False,
        "gpu_used": False,
    }
    write_json(RUN / "validation/C07.json", validation)


def run_c08() -> None:
    result = RUN / "results/C08"
    result.mkdir(parents=True, exist_ok=True)
    write_json(RUN / "protocols/C08.json", {
        "protocol_id": PROTOCOL,
        "task_id": "C08",
        "required_input": "unfiltered K400 clean 21D features for original-correct and original-wrong clips",
        "fixed_detector": "historical full21 detector and threshold",
        "status": "blocked_input",
        "gpu_used": False,
    })
    rows = []
    feature_columns = set(FEATURES)
    for path in sorted(PREDICTION_ROOT.glob("*_all.csv")):
        frame = pd.read_csv(path, low_memory=False)
        present = sorted(feature_columns.intersection(frame.columns))
        rows.append({
            "protocol_id": PROTOCOL,
            "path": str(path),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
            "model": str(frame.action_model.iloc[0]) if len(frame) else path.stem.replace("_all", ""),
            "rows": len(frame),
            "original_correct": int((frame.clean_correct == 1).sum()),
            "original_wrong": int((frame.clean_correct == 0).sum()),
            "error_rows": int(frame.error.notna().sum()),
            "full21_columns_present": len(present),
            "present_feature_columns": ";".join(present) if present else "NA",
            "usable_for_c08_fpr": False,
            "reason": "ground truth/prediction/correctness exist, but detector features or scores are absent",
        })
    inventory = pd.DataFrame(rows)
    write_csv(result / "availability_inventory.csv", inventory)
    report = f"""# C08 unfiltered-clean availability report

Status: **blocked_input** under `{PROTOCOL}`.

The server contains four unfiltered K400 clean prediction tables under `{PREDICTION_ROOT}`. Together they have {int(inventory.rows.sum()):,} model–clip rows, including {int(inventory.original_wrong.sum()):,} rows marked original-wrong. These tables contain ground truth, action prediction, confidence, and correctness, but **zero of the required 21 detector features** and no frozen full-detector score.

Therefore the requested original-correct/original-wrong/overall detector FPR cannot be estimated on CPU from the available files. Reporting only the already correctness-filtered E1 clean cohort would not answer C08, and no empty `clean_scores.csv.gz`, `stratified_fpr.csv`, or `sampling_weights.csv` is created.

Required next input: run G05 only after explicit GPU-mode authorization, using a pre-fixed unfiltered clean cohort; retain ground truth, prediction/correctness, full 21D features, frozen historical detector score/threshold, and sampling weights. No attacks are required for G05.
"""
    (result / "availability_report.md").write_text(report, encoding="utf-8")
    validation = {
        "protocol_id": PROTOCOL,
        "task_id": "C08",
        "status": "blocked_input",
        "passed": False,
        "prediction_tables_found": len(inventory),
        "prediction_rows": int(inventory.rows.sum()),
        "original_wrong_rows": int(inventory.original_wrong.sum()),
        "full21_feature_columns_present_max": int(inventory.full21_columns_present.max()),
        "scientific_reason": "unfiltered detector features/scores are absent; FPR cannot be computed",
        "next_task": "G05 after explicit GPU mode authorization",
        "gpu_used": False,
    }
    write_json(RUN / "validation/C08.json", validation)


def main() -> None:
    started = time.perf_counter()
    gate = json.loads((RUN / "validation/A00.json").read_text(encoding="utf-8"))
    if not gate.get("all_a00_gates_passed"):
        raise RuntimeError("A00 gate has not passed")
    run_c07()
    run_c08()
    write_json(RUN / "logs/C07_C08_run_summary.json", {
        "protocol_id": PROTOCOL,
        "elapsed_seconds": time.perf_counter() - started,
        "C07": "completed",
        "C08": "blocked_input_documented",
        "gpu_used": False,
    })
    print(json.dumps(json.loads((RUN / "logs/C07_C08_run_summary.json").read_text()), indent=2))


if __name__ == "__main__":
    main()
