#!/usr/bin/env python3
"""Independent G02 selected-tensor rescore through historical score_frames."""
import argparse, hashlib, json, os, sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import torch

RUN=Path(os.environ.get("TDC_RUN_ROOT","/root/autodl-tmp/tdc_r3r5_revision_20261022_01")); PROJECT=Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master"); BASE_PROTOCOL=Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714"); CLASSES=Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for p in (PROJECT,RUN/"code"):
 if str(p) not in sys.path: sys.path.insert(0,str(p))
from cpu_common import FEATURES
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models, score_frames
from TSC_Detect.tsc_action_model import get_action_probs
from TSC_Detect.tsc_sampling import build_frozen_global_views
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL="tdc-r3r5-g02-legacy-rescore-20261026-v1"; EPS=8/255
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def atomic_json(path,value):
 path.parent.mkdir(parents=True,exist_ok=True); t=path.with_suffix(path.suffix+'.tmp'); t.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n'); os.replace(t,path)
def logistic(features,state):
 x=np.asarray([features[n] for n in state['feature_order']],float); z=np.sum((x-np.asarray(state['scaler_mean']))/np.asarray(state['scaler_scale'])*np.asarray(state['lr_coef']))+float(state['lr_intercept']); return float(1/(1+np.exp(-np.clip(z,-700,700))))

def main():
 p=argparse.ArgumentParser(); p.add_argument('--model',choices=('csn_r101','mvit_base_16x4'),required=True); p.add_argument('--mode',choices=('adaptive','lambda0_control'),required=True); p.add_argument('--device',default='cuda:0'); p.add_argument('--limit',type=int,default=100); p.add_argument('--output-name',default='legacy_rescore_v2'); a=p.parse_args()
 device=torch.device(a.device); out=RUN/'results/G02'/a.output_name; shards=out/'shards'; shards.mkdir(parents=True,exist_ok=True)
 index=pd.read_csv(RUN/'results/G02/full/selected_adv_index.csv'); index=index[(index.action_model==a.model)&(index['mode']==a.mode)].sort_values('source_rank').head(a.limit)
 selected=pd.read_csv(RUN/'results/G02/full/selected.csv.gz',float_precision='round_trip'); selected=selected[(selected.action_model==a.model)&(selected['mode']==a.mode)].set_index('source_rank')
 clean_saved=pd.read_csv(RUN/'results/G02/full/clean_scores.csv.gz',float_precision='round_trip'); clean_saved=clean_saved[clean_saved.action_model==a.model].set_index('source_rank')
 manifest=pd.read_csv(BASE_PROTOCOL/'manifests'/f'k400_{a.model}_test_fixed100.csv').sort_values('relative_path').reset_index(drop=True)
 state_path=RUN/'protocols/G05_v2_frozen_states'/f'{a.model}.json'; state=json.loads(state_path.read_text()); state_hash=sha(state_path)
 action,clip,processor=load_real_models(device,a.model); classes=read_class_names(CLASSES)
 args=SimpleNamespace(protocol_id='tdc-final-20260714',mock_models=False,seed=20260714,num_frames=32,num_random=2,prompt_template=DEFAULT_PROMPT_TEMPLATES[0],prompt_templates=DEFAULT_PROMPT_TEMPLATES,max_clip_frames=8,num_local_windows=4,local_window_frames=None,max_global_views=None,base_views_only=False)
 for row in index.itertuples(index=False):
  rank=int(row.source_rank); path=shards/f'{a.model}_{a.mode}_{rank:03d}.json'
  if path.exists():
   try:
    if json.loads(path.read_text()).get('complete'): continue
   except Exception: pass
  tensor_path=Path(row.path); tensor=torch.load(tensor_path,map_location='cpu',weights_only=True).to(torch.float32).contiguous(); source=manifest.iloc[rank-1]
  # Reconstruct clean on CUDA, matching the original attack worker's interpolation device.
  clean=prepare_attack_frames(load_frames(Path(source.path)),a.model,device).detach().cpu().to(torch.float32); linf=float((tensor-clean).abs().max())
  rgb=tensor.numpy(); features=score_frames(rgb,classes,args,action_model=action,clip_model=clip,clip_processor=processor,device=device,video_id=str(tensor_path)); legacy_score=logistic(features,state)
  original=build_frozen_global_views(rgb)['original']; probs,pred,conf=get_action_probs(action,original,device)
  saved=selected.loc[rank]; old_features={n:float(saved[f'feature__{n}']) for n in FEATURES}; errors={n:float(features[n])-old_features[n] for n in FEATURES}
  atomic_json(path,{"protocol_id":PROTOCOL,"complete":True,"action_model":a.model,"mode":a.mode,"source_rank":rank,"relative_path":row.relative_path,"tensor_path":str(tensor_path),"tensor_sha256_expected":row.sha256,"tensor_sha256_actual":sha(tensor_path),"tensor_shape":list(tensor.shape),"tensor_dtype":str(tensor.dtype),"tensor_min":float(tensor.min()),"tensor_max":float(tensor.max()),"measured_linf":linf,"epsilon":EPS,"constraint_passed":bool(linf<=EPS+1e-7 and tensor.min()>=0 and tensor.max()<=1),"clean_pred_saved":int(clean_saved.loc[rank].clean_pred),"adv_pred_legacy":int(pred),"adv_pred_saved":int(saved.attacked_pred),"attack_success_legacy":int(pred)!=int(clean_saved.loc[rank].clean_pred),"attack_success_saved":bool(saved.attack_success),"legacy_score":legacy_score,"saved_score":float(saved.detector_score),"score_error":legacy_score-float(saved.detector_score),"threshold":float(state['threshold']),"legacy_decision":legacy_score>float(state['threshold']),"saved_decision":bool(saved.detector_score>float(state['threshold'])),"frozen_detector_state":str(state_path),"frozen_detector_state_sha256":state_hash,"feature_order":FEATURES,"legacy_features":{n:float(features[n]) for n in FEATURES},"saved_features":old_features,"feature_errors":errors,"max_abs_feature_error":max(abs(x) for x in errors.values()),"tensor_quantization":"none; lossless float32 input to historical score_frames"})
  print(json.dumps({'model':a.model,'mode':a.mode,'source':rank}),flush=True)
 records=[json.loads(p.read_text()) for p in sorted(shards.glob(f'{a.model}_{a.mode}_*.json')) if json.loads(p.read_text()).get('complete')]
 records=[r for r in records if r['source_rank']<=a.limit]
 atomic_json(out/f'validation_{a.model}_{a.mode}.json',{"protocol_id":PROTOCOL,"passed":bool(len(records)==a.limit and all(r['constraint_passed'] and r['tensor_sha256_actual']==r['tensor_sha256_expected'] for r in records)),"records":len(records),"expected":a.limit,"maximum_linf":max(r['measured_linf'] for r in records),"maximum_abs_feature_error":max(r['max_abs_feature_error'] for r in records),"maximum_abs_score_error":max(abs(r['score_error']) for r in records)})
if __name__=='__main__':main()
