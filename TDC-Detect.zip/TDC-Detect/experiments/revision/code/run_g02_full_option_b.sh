#!/usr/bin/env bash
set -euo pipefail

RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
CODE="$RUN/code"
LOGS="$RUN/logs/G02_full"
mkdir -p "$LOGS"

run_four() {
  local stage="$1"
  local pids=()
  for spec in "0 csn_r101 0" "1 csn_r101 1" "2 mvit_base_16x4 0" "3 mvit_base_16x4 1"; do
    read -r gpu model worker <<<"$spec"
    uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i "$gpu" | tr -d ' ')"
    CUDA_VISIBLE_DEVICES="$gpu" TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
      python "$CODE/run_g02_full_worker.py" --model "$model" --stage "$stage" --worker-index "$worker" --workers 2 \
      >>"$LOGS/${stage}_${model}_w${worker}.log" 2>&1 &
    pids+=("$!")
  done
  failed=0
  for pid in "${pids[@]}"; do
    if ! wait "$pid"; then failed=1; fi
  done
  if [[ "$failed" != 0 ]]; then
    echo "G02 $stage worker failure" >&2
    return 1
  fi
}

calibration_complete="$(python - "$RUN" <<'PY'
import json, sys
from pathlib import Path
run = Path(sys.argv[1])
files = [run / "results/G02/full" / model / "worker_status" / f"calibration_{worker}.json"
         for model in ("csn_r101", "mvit_base_16x4") for worker in range(2)]
try:
    ok = all(json.loads(path.read_text()).get("complete") is True for path in files)
except Exception:
    ok = False
print("yes" if ok else "no")
PY
)"
if [[ "$calibration_complete" != "yes" ]]; then
  run_four calibration
fi
if [[ ! -s "$RUN/results/G02/full/csn_r101/lambda_selection.json" ]]; then
  python "$CODE/finalize_g02_calibration.py" --model csn_r101 >"$LOGS/finalize_csn_r101.log" 2>&1
fi
if [[ ! -s "$RUN/results/G02/full/mvit_base_16x4/lambda_selection.json" ]]; then
  python "$CODE/finalize_g02_calibration.py" --model mvit_base_16x4 >"$LOGS/finalize_mvit_base_16x4.log" 2>&1
fi
run_four test
echo "$(date -u '+%FT%TZ') G02_OPTION_B_WORKERS_COMPLETE" >"$LOGS/COMPLETE"
