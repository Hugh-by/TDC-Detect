#!/usr/bin/env python3
import json, math
from pathlib import Path
import pandas as pd

RUN=Path("/root/autodl-tmp/tdc_r3r5_revision_20261022_01"); ROOT=RUN/"results/G05/full_corrected"; PROTOCOL="tdc-r3r5-g05-corrected-20261025-v2"
def wilson(k,n,z=1.959963984540054):
    if n==0:return (float('nan'),float('nan'))
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d; h=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d; return c-h,c+h
frames=[]; validations=[]
for model in ("csn_r101","mvit_base_16x4","slowfast_r50","x3d_m"):
    v=json.loads((ROOT/model/"validation.json").read_text()); validations.append(v)
    f=pd.read_csv(ROOT/model/"clean_features.csv.gz",float_precision="round_trip"); frames.append(f)
allf=pd.concat(frames,ignore_index=True); rows=[]
for model,group in list(allf.groupby("action_model"))+[("all_models",allf)]:
    for name,sub in (("overall",group),("original_correct",group[group.correct_flag.astype(bool)]),("original_wrong",group[~group.correct_flag.astype(bool)])):
        n=len(sub); k=int(sub.false_positive.astype(bool).sum()); lo,hi=wilson(k,n); rows.append({"protocol_id":PROTOCOL,"action_model":model,"cohort":name,"n":n,"false_positives":k,"fpr":k/n if n else float('nan'),"ci_low":lo,"ci_high":hi,"ci_method":"Wilson 95%"})
pd.DataFrame(rows).to_csv(ROOT/"stratified_fpr.csv",index=False); allf.to_csv(ROOT/"clean_features_all.csv.gz",index=False,compression="gzip")
(ROOT/"validation.json").write_text(json.dumps({"protocol_id":PROTOCOL,"passed":all(v.get("passed") for v in validations) and len(allf)==1600,"rows":len(allf),"models":4,"prediction_unfiltered":True,"calibration_overlap":0},indent=2,sort_keys=True)+"\n")
