#!/usr/bin/env bash
set -euo pipefail

RUN=${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}
METHODS=(action_single e14_action_shift9 action_stats12 discrepancy9 full_g5l4 light_g3l2 single_discrepancy)
MODELS=(csn_r101 mvit_base_16x4)

export TDC_RUN_ROOT="$RUN"
export CUDA_VISIBLE_DEVICES=0
export TDC_GPU_UUID=GPU-63d77c6b-2425-4eee-1457-06df61c4e541
export OMP_NUM_THREADS=2 OPENBLAS_NUM_THREADS=2 MKL_NUM_THREADS=2 NUMEXPR_NUM_THREADS=2

for model in "${MODELS[@]}"; do
  for method in "${METHODS[@]}"; do
    python "$RUN/code/run_g03_method_pilot.py" \
      --model "$model" --method "$method" --device cuda:0 \
      --videos 20 --repeats 3 --warmups 10 \
      2>&1 | tee "$RUN/logs/G03_${model}_${method}_20261023.log"
  done
done

python "$RUN/code/finalize_g03_pilot.py" 2>&1 | tee "$RUN/logs/G03_finalize_20261023.log"
