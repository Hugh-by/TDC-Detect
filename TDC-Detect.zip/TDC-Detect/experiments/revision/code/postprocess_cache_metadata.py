#!/usr/bin/env python3
"""Enrich shared model metadata without changing fitted numeric arrays or scores."""

from __future__ import annotations

import json

import sklearn

from cpu_common import DATASETS, FEATURES, MODELS, RUN, SEED, write_json

PROTOCOL = "tdc-r3r5-cache-cpu-20261022-v1"


def main() -> None:
    permutation_metadata = []
    for dataset in DATASETS:
        for model in MODELS:
            condition = f"{dataset}_{model}"
            c04_path = RUN / f"models/C04/{condition}.json"
            c04 = json.loads(c04_path.read_text())
            common = {"classes": [0, 1], "max_iter": 5000, "class_weight": "balanced",
                      "random_state": SEED, "sklearn": sklearn.__version__, "penalty_semantics": "L2"}
            c04["raw_lr"].update(common)
            c04["pca_lr"].update(common)
            c04["scaler"] = {"fit_partition": "calibration", "state_arrays": [
                "raw_scaler_mean", "raw_scaler_scale", "pca_scaler_mean", "pca_scaler_scale"]}
            c04["prediction_reload_validation"] = "validation/NO_GPU_scientific_validation.json"
            write_json(c04_path, c04)

            states_path = RUN / f"models/C05/{condition}_permutations.json"
            states = json.loads(states_path.read_text())
            permutation_metadata.append({"condition": condition, "state_file": str(states_path.relative_to(RUN)),
                "states": len(states), "shared_feature_order": FEATURES, "sklearn": sklearn.__version__,
                "pipeline": {"scaler": "StandardScaler calibration-only", "classifier": "LogisticRegression",
                             "C": 1.0, "l1_ratio": 0.0, "solver": "lbfgs", "class_weight": "balanced",
                             "max_iter": 5000, "random_state": SEED, "classes": [0, 1]},
                "decision": "score > permutation-specific calibration-clean threshold"})
    write_json(RUN / "models/C05/permutation_state_metadata.json", {
        "protocol_id": PROTOCOL, "task_id": "C05-B", "conditions": permutation_metadata,
        "note": "Shared metadata applies to every one of the 120 explicitly stored per-condition states."})
    index_path = RUN / "models/C05/INDEX.json"
    index = json.loads(index_path.read_text())
    index["permutation_state_metadata"] = "models/C05/permutation_state_metadata.json"
    write_json(index_path, index)
    print(json.dumps({"conditions": len(permutation_metadata), "C04_metadata_enriched": True,
                      "C05_shared_permutation_metadata": True}, indent=2))


if __name__ == "__main__":
    main()
