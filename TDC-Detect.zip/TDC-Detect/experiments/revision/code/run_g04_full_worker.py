#!/usr/bin/env python3
"""G04 full structured-attack convergence worker for one action model."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
BASE_PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path: sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1, score_lr, threshold_from_clean
from gpu_full_detector import DetectorState, FullDetector, action_loss_and_probs, action_probs, build_text_features
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g04-full-option-b-20261023-v1"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
EPSILON, ALPHA, STEPS = 8 / 255, 2 / 255, 100
CHECKPOINTS = (10, 20, 40, 100)


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def valid(path: Path) -> dict | None:
    try: value = json.loads(path.read_text())
    except Exception: return None
    return value if value.get("complete") and value.get("protocol_id") == PROTOCOL_ID else None


def score(detector, action_model, candidate, model, clean_pred, threshold) -> dict:
    started = time.perf_counter()
    with torch.no_grad():
        features, logit, detector_score, _, _ = detector.exact_forward(candidate)
        probability = action_probs(action_model, candidate, model)
    torch.cuda.synchronize(candidate.device)
    return {
        "action_loss": float(-probability[clean_pred].clamp_min(1e-30).log()),
        "attacked_pred": int(probability.argmax()),
        "attack_success": int(probability.argmax()) != clean_pred,
        "detector_logit": float(logit), "detector_score": float(detector_score),
        "detector_evaded": float(detector_score) <= threshold,
        "score_seconds": time.perf_counter() - started,
        "features": {name: float(features[name]) for name in FEATURES},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=MODELS, required=True)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    authorization = json.loads((RUN / "protocols/authorization.json").read_text())
    if authorization.get("selected_option") != "B": raise RuntimeError("option B not authorized")
    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    output = RUN / "results/G04/full" / args.model
    shards = output / "source_shards"
    output.mkdir(parents=True, exist_ok=True)

    calibration = load_e1("k400", args.model, "calibration")
    pipeline = fit_lr(calibration, FEATURES)
    threshold = threshold_from_clean(calibration, score_lr(pipeline, calibration, FEATURES))
    state = DetectorState.from_pipeline(pipeline, threshold, device)
    manifest = pd.read_csv(BASE_PROTOCOL / "manifests" / f"k400_{args.model}_test_fixed100.csv").sort_values("relative_path").head(100)
    action_model, clip_model, processor = load_real_models(device, args.model)
    for parameter in action_model.parameters(): parameter.requires_grad_(False)
    for parameter in clip_model.parameters(): parameter.requires_grad_(False)
    text = build_text_features(clip_model, processor, read_class_names(CLASSES), device)
    detector = FullDetector(action_model, clip_model, processor, text, args.model, state)

    for source_rank, row in enumerate(manifest.itertuples(index=False), 1):
        clean = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach()
        with torch.no_grad(): clean_probability = action_probs(action_model, clean, args.model)
        clean_pred = int(clean_probability.argmax())
        for attack in ("ofa", "flicker"):
            shard = shards / f"{source_rank:03d}_{attack}.json"
            if valid(shard) is not None:
                print(json.dumps({"reused": str(shard)}), flush=True); continue
            delta = torch.zeros((len(clean), 1, 1, 3), device=device) if attack == "flicker" else torch.zeros_like(clean)
            attacked_frame = None
            trajectory, checkpoint_rows = [], []
            best_action_loss = -float("inf")
            best_action_tensor = None
            torch.cuda.reset_peak_memory_stats(device)
            for step in range(1, STEPS + 1):
                delta = delta.detach().requires_grad_(True)
                candidate = (clean + delta).clamp(0, 1)
                started = time.perf_counter()
                loss, _ = action_loss_and_probs(action_model, candidate, args.model, clean_pred)
                gradient = torch.autograd.grad(loss, delta)[0]
                if attack == "ofa":
                    if attacked_frame is None:
                        attacked_frame = int(gradient.abs().flatten(1).mean(1).argmax())
                    gradient_mask = torch.zeros_like(gradient); gradient_mask[attacked_frame] = 1
                    gradient = gradient * gradient_mask
                delta = (delta.detach() + ALPHA * gradient.sign()).clamp(-EPSILON, EPSILON)
                if attack == "ofa":
                    parameter_mask = torch.zeros_like(delta); parameter_mask[attacked_frame] = 1
                    delta = parameter_mask * delta
                    delta = ((clean + delta).clamp(0, 1) - clean).detach()
                else:
                    delta = delta.detach()
                torch.cuda.synchronize(device)
                step_seconds = time.perf_counter() - started
                candidate = (clean + delta).clamp(0, 1)
                with torch.no_grad(): probability = action_probs(action_model, candidate, args.model)
                action_loss = float(-probability[clean_pred].clamp_min(1e-30).log())
                entry = {
                    "step": step, "action_loss": action_loss, "attacked_pred": int(probability.argmax()),
                    "attack_success": int(probability.argmax()) != clean_pred,
                    "measured_linf": float((candidate - clean).abs().max()), "seconds": step_seconds,
                    "parameter_spatial_std_max": float(delta.std(dim=(1, 2), unbiased=False).max()),
                }
                if action_loss > best_action_loss:
                    best_action_loss = action_loss
                    best_action_tensor = candidate.detach().cpu().to(torch.float32).clone()
                if step in CHECKPOINTS:
                    measured = score(detector, action_model, candidate, args.model, clean_pred, threshold)
                    entry.update({key: value for key, value in measured.items() if key != "features"})
                    checkpoint_rows.append({"step": step, **measured, "measured_linf": entry["measured_linf"]})
                trajectory.append(entry)
                if step % 10 == 0:
                    print(json.dumps({"model": args.model, "source": source_rank, "attack": attack, "step": step}), flush=True)
            assert best_action_tensor is not None
            best_score = score(detector, action_model, best_action_tensor.to(device), args.model, clean_pred, threshold)
            last_score = checkpoint_rows[-1]
            atomic_json(shard, {
                "protocol_id": PROTOCOL_ID, "complete": True, "action_model": args.model,
                "gpu_uuid": gpu_uuid, "source_rank": source_rank, "relative_path": row.relative_path,
                "video_path": row.path, "partition": "test", "attack": attack,
                "epsilon": EPSILON, "alpha": ALPHA, "steps": STEPS, "initialization": "zero",
                "clean_pred": clean_pred, "threshold": threshold, "attacked_frame": attacked_frame,
                "structure": "one fixed temporal frame" if attack == "ofa" else "delta[T,1,1,3] spatially broadcast",
                "selection_rule": "maximum action loss over steps 1..100; detector score not used",
                "trajectory": trajectory, "checkpoint_rows": checkpoint_rows,
                "best_action_selected": best_score, "last_iterate": last_score,
                "peak_memory_bytes": int(torch.cuda.max_memory_allocated(device)),
            })

    records = [valid(path) for path in sorted(shards.glob("*.json"))]
    records = [item for item in records if item is not None]
    if len(records) != 200: raise RuntimeError(f"G04 {args.model}: {len(records)}/200 sources-attacks")
    trajectory_rows, checkpoint_rows, selected_rows = [], [], []
    for item in records:
        common = {key: item[key] for key in ("protocol_id", "action_model", "gpu_uuid", "source_rank", "relative_path", "partition", "attack", "epsilon", "alpha", "clean_pred", "threshold", "attacked_frame")}
        trajectory_rows.extend(common | row for row in item["trajectory"])
        checkpoint_rows.extend(common | row for row in item["checkpoint_rows"])
        for selection, field in (("best_action_loss", "best_action_selected"), ("last_iterate", "last_iterate")):
            selected_rows.append(common | {"selection": selection} | item[field])
    trajectory_frame = pd.DataFrame(trajectory_rows)
    trajectory_frame.to_csv(output / "trajectory.csv.gz", index=False, compression="gzip")
    pd.DataFrame(checkpoint_rows).to_csv(output / "checkpoint_scores.csv.gz", index=False, compression="gzip")
    pd.DataFrame(selected_rows).to_csv(output / "selected_scores.csv.gz", index=False, compression="gzip")
    atomic_json(output / "validation.json", {
        "protocol_id": PROTOCOL_ID, "passed": bool(len(records) == 200 and (trajectory_frame.measured_linf <= EPSILON + 1e-7).all()),
        "records": len(records), "trajectory_rows": len(trajectory_frame), "sources": 100,
        "attacks": ["ofa", "flicker"], "checkpoints": list(CHECKPOINTS),
        "ofa_fixed_frame_passed": all(item["attacked_frame"] is not None for item in records if item["attack"] == "ofa"),
        "flicker_spatial_constant_passed": bool((trajectory_frame.loc[trajectory_frame.attack == "flicker", "parameter_spatial_std_max"] == 0).all()),
        "gpu_uuid": gpu_uuid,
    })
    print(json.dumps({"G04_full_complete": True, "model": args.model, "records": len(records)}), flush=True)


if __name__ == "__main__":
    main()
