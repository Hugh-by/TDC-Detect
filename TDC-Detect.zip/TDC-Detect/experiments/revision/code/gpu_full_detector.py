"""Exact-forward, BPDA-backward implementation of the frozen 21-D TDC detector.

The historical project remains read-only.  This module is a revision-only
implementation for G01/G02.  It accepts prepared RGB clips [T,H,W,C] in [0,1].
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

import numpy as np
import torch
import torch.nn.functional as F


FEATURES = [
    "R_model", "R_label_change", "R_conf_var", "R_uniform_shift",
    "R_fft_conf_high", "R_fft_conf_entropy", "R_fft_vlad_high", "R_fft_vlad_entropy",
    "R_local_conf_max", "R_local_conf_top2", "R_local_shift_max", "R_local_shift_top2",
    "R_vlm", "vlad_original", "R_sem_mean", "R_sem_max", "R_sem_var",
    "R_fft_sem_high", "R_fft_sem_entropy", "R_local_sem_max", "R_local_sem_top2",
]
GLOBAL_NAMES = ("original", "early_crop", "late_crop", "temporal_sparse", "motion_aware")
LOCAL_NAMES = ("local_0", "local_1", "local_2", "local_3")
PROMPTS = ("a video of a person {}", "a video of {}", "an action of {}")
CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD = (0.26862954, 0.26130258, 0.27577711)


@dataclass
class DetectorState:
    feature_order: list[str]
    scaler_mean: torch.Tensor
    scaler_scale: torch.Tensor
    coef: torch.Tensor
    intercept: torch.Tensor
    threshold: float

    @classmethod
    def from_pipeline(cls, pipeline, threshold: float, device: torch.device):
        scaler = pipeline.named_steps["scaler"]
        lr = pipeline.named_steps["logistic"]
        return cls(
            feature_order=list(FEATURES),
            scaler_mean=torch.as_tensor(scaler.mean_, dtype=torch.float64, device=device),
            scaler_scale=torch.as_tensor(scaler.scale_, dtype=torch.float64, device=device),
            coef=torch.as_tensor(lr.coef_[0], dtype=torch.float64, device=device),
            intercept=torch.as_tensor(lr.intercept_[0], dtype=torch.float64, device=device),
            threshold=float(threshold),
        )


def _sym_kl(p: torch.Tensor, q: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    p = p.to(torch.float64).clamp(eps, 1.0)
    q = q.to(torch.float64).clamp(eps, 1.0)
    p = p / p.sum(-1, keepdim=True)
    q = q / q.sum(-1, keepdim=True)
    return 0.5 * ((p * (p / q).log()).sum(-1) + (q * (q / p).log()).sum(-1))


def _fft(values: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
    values = values.to(torch.float64)
    centered = values - values.mean()
    power = torch.fft.rfft(centered).abs().square()
    non_dc = power[1:]
    total = non_dc.sum()
    midpoint = max(len(non_dc) // 2, 1)
    safe_total = total.clamp_min(1e-30)
    ratio = non_dc[midpoint:].sum() / safe_total
    probs = non_dc / safe_total
    if len(non_dc) > 1:
        entropy = -(probs * (probs + 1e-12).log()).sum() / np.log(len(non_dc))
    else:
        entropy = total * 0.0
    valid = (values.std(unbiased=False) >= 1e-12) & (total > 1e-12)
    zero = total * 0.0
    return torch.where(valid, ratio, zero), torch.where(valid, entropy, zero)


def _hard_forward_soft_label_change(action: torch.Tensor, temperature: float = 0.05) -> torch.Tensor:
    labels = action.argmax(-1)
    counts = torch.stack([(labels == k).sum() for k in labels.unique()])
    hard = 1.0 - counts.max().to(action.dtype) / len(action)
    logp = action.clamp_min(1e-12).log() / temperature
    soft = logp.softmax(-1).sum(0)
    surrogate = 1.0 - soft.max() / len(action)
    return surrogate + (hard - surrogate).detach()


def aggregate_features(
    global_action: torch.Tensor,
    global_clip: torch.Tensor,
    local_action: torch.Tensor,
    local_clip: torch.Tensor,
) -> dict[str, torch.Tensor]:
    """Aggregate response probabilities in exactly the historical 21-D order."""
    ga = global_action.to(torch.float64)
    gc = global_clip.to(torch.float64)
    la = local_action.to(torch.float64)
    lc = local_clip.to(torch.float64)
    sem = _sym_kl(ga, gc)
    conf = ga.max(-1).values
    shift = _sym_kl(ga[0].expand_as(ga), ga)
    fft_conf = _fft(conf)
    fft_sem = _fft(sem)
    fft_shift = _fft(shift)
    local_sem = _sym_kl(la, lc)
    local_conf = la.max(-1).values
    local_shift = _sym_kl(ga[0].expand_as(la), la)

    def top2(x: torch.Tensor) -> torch.Tensor:
        return x.topk(min(2, len(x))).values.mean()

    return {
        "R_model": ga.var(0, unbiased=False).mean(),
        "R_label_change": _hard_forward_soft_label_change(ga),
        "R_conf_var": conf.var(unbiased=False),
        "R_uniform_shift": shift[1:].mean(),
        "R_fft_conf_high": fft_conf[0],
        "R_fft_conf_entropy": fft_conf[1],
        "R_fft_vlad_high": fft_shift[0],
        "R_fft_vlad_entropy": fft_shift[1],
        "R_local_conf_max": local_conf.max(),
        "R_local_conf_top2": top2(local_conf),
        "R_local_shift_max": local_shift.max(),
        "R_local_shift_top2": top2(local_shift),
        "R_vlm": gc.var(0, unbiased=False).mean(),
        "vlad_original": sem[0],
        "R_sem_mean": sem.mean(),
        "R_sem_max": sem.max(),
        "R_sem_var": sem.var(unbiased=False),
        "R_fft_sem_high": fft_sem[0],
        "R_fft_sem_entropy": fft_sem[1],
        "R_local_sem_max": local_sem.max(),
        "R_local_sem_top2": top2(local_sem),
    }


def detector_logit(features: dict[str, torch.Tensor], state: DetectorState) -> torch.Tensor:
    vector = torch.stack([features[name].to(torch.float64) for name in state.feature_order])
    return (((vector - state.scaler_mean) / state.scaler_scale) * state.coef).sum() + state.intercept


def _motion_indices(rgb: torch.Tensor) -> torch.Tensor:
    value = rgb.detach().to(torch.float32)
    luma = 0.299 * value[..., 0] + 0.587 * value[..., 1] + 0.114 * value[..., 2]
    scores = torch.zeros(len(value), device=value.device, dtype=torch.float64)
    if len(value) > 1:
        scores[1:] = (luma[1:] - luma[:-1]).abs().to(torch.float64).mean((1, 2))
    target = len(value) // 2
    candidates = sorted(range(1, len(value) - 1), key=lambda i: (-float(scores[i]), i))
    selected = sorted({0, len(value) - 1, *candidates[: max(target - 2, 0)]})
    return torch.as_tensor(selected, device=value.device, dtype=torch.long)


def view_indices(rgb: torch.Tensor) -> dict[str, torch.Tensor]:
    length = len(rgb)
    if length not in (16, 32):
        raise ValueError(f"prepared clip must have 16/32 frames, got {length}")
    crop = 3 * length // 4
    edges = np.linspace(0, length, 5, dtype=np.int64)
    result = {
        "original": torch.arange(length, device=rgb.device),
        "early_crop": torch.arange(crop, device=rgb.device),
        "late_crop": torch.arange(length - crop, length, device=rgb.device),
        "temporal_sparse": torch.arange(0, length, 2, device=rgb.device),
        "motion_aware": _motion_indices(rgb),
    }
    for i, (start, end) in enumerate(zip(edges[:-1], edges[1:])):
        result[f"local_{i}"] = torch.arange(int(start), int(end), device=rgb.device)
    return result


def action_input(view: torch.Tensor, model_name: str):
    profiles = {
        "csn_r101": (32, 224, None),
        "mvit_base_16x4": (16, 224, None),
        "slowfast_r50": (32, 256, 4),
        "x3d_m": (16, 256, None),
    }
    frames, crop, alpha = profiles[model_name]
    value = view.permute(3, 0, 1, 2).unsqueeze(0)
    if value.shape[2:] != (frames, crop, crop):
        value = F.interpolate(value, (frames, crop, crop), mode="trilinear", align_corners=True)
    mean = value.new_tensor((0.45, 0.45, 0.45)).view(1, 3, 1, 1, 1)
    std = value.new_tensor((0.225, 0.225, 0.225)).view(1, 3, 1, 1, 1)
    value = (value - mean) / std
    if alpha is None:
        return value
    indices = torch.linspace(0, frames - 1, frames // alpha, device=value.device).long()
    return [value.index_select(2, indices), value]


def action_probs(model, view: torch.Tensor, model_name: str) -> torch.Tensor:
    output = model(action_input(view, model_name))
    return output[0].clamp_min(1e-12) if model_name == "x3d_m" else output[0].softmax(0)


def action_loss_and_probs(model, view: torch.Tensor, model_name: str, label: int) -> tuple[torch.Tensor, torch.Tensor]:
    """Stable -log p(label) objective plus probabilities for an action model."""
    output = model(action_input(view, model_name))[0]
    if model_name == "x3d_m":
        probabilities = output.clamp_min(1e-30)
        return -probabilities[label].log(), probabilities
    return -F.log_softmax(output, dim=0)[label], output.softmax(0)


def _clip_surrogate_pixels(frames: torch.Tensor) -> torch.Tensor:
    value = frames.permute(0, 3, 1, 2)
    height, width = value.shape[-2:]
    scale = 224.0 / min(height, width)
    rh, rw = int(round(height * scale)), int(round(width * scale))
    value = F.interpolate(value, (rh, rw), mode="bicubic", align_corners=False, antialias=True)
    top, left = (rh - 224) // 2, (rw - 224) // 2
    value = value[:, :, top : top + 224, left : left + 224]
    mean = value.new_tensor(CLIP_MEAN).view(1, 3, 1, 1)
    std = value.new_tensor(CLIP_STD).view(1, 3, 1, 1)
    return (value - mean) / std


def clip_frame_indices(length: int, device: torch.device) -> torch.Tensor:
    if length <= 8:
        return torch.arange(length, device=device)
    return torch.as_tensor(np.linspace(0, length - 1, 8).astype(np.int64), device=device)


def exact_clip_pixels(view: torch.Tensor, processor) -> tuple[torch.Tensor, torch.Tensor]:
    indices = clip_frame_indices(len(view), view.device)
    selected = view.index_select(0, indices)
    quantized = (selected.detach().clamp(0, 1) * 255.0).round().to(torch.uint8).cpu().numpy()
    exact = processor(images=list(quantized), return_tensors="pt")["pixel_values"].to(view.device)
    return indices, exact


def clip_probs(
    clip_model,
    view: torch.Tensor,
    text_features: torch.Tensor,
    processor=None,
    exact_pixels: torch.Tensor | None = None,
) -> torch.Tensor:
    indices = clip_frame_indices(len(view), view.device)
    selected = view.index_select(0, indices)
    surrogate = _clip_surrogate_pixels(selected)
    if exact_pixels is None:
        if processor is None:
            raise ValueError("processor or exact_pixels is required")
        _, exact_pixels = exact_clip_pixels(view, processor)
    pixels = surrogate + (exact_pixels.to(surrogate) - surrogate).detach()
    output = clip_model.get_image_features(pixel_values=pixels)
    features = output.pooler_output if hasattr(output, "pooler_output") else output
    features = features / features.norm(dim=-1, keepdim=True)
    scale = clip_model.logit_scale.exp()
    logits = scale * torch.einsum("id,tcd->itc", features, text_features)
    return logits.mean((0, 1)).softmax(0)


def build_text_features(clip_model, processor, class_names: Iterable[str], device: torch.device) -> torch.Tensor:
    names = list(class_names)
    texts = [template.format(name) for template in PROMPTS for name in names]
    inputs = processor(text=texts, return_tensors="pt", padding=True)
    inputs = {key: value.to(device) for key, value in inputs.items() if torch.is_tensor(value)}
    with torch.no_grad():
        output = clip_model.get_text_features(**inputs)
        value = output.pooler_output if hasattr(output, "pooler_output") else output
        value = value / value.norm(dim=-1, keepdim=True)
    return value.reshape(len(PROMPTS), len(names), -1).detach()


class FullDetector:
    def __init__(self, action_model, clip_model, clip_processor, text_features, model_name: str, state: DetectorState):
        self.action_model = action_model
        self.clip_model = clip_model
        self.processor = clip_processor
        self.text_features = text_features
        self.model_name = model_name
        self.state = state

    def responses(self, rgb: torch.Tensor, require_grad: bool = False):
        indices = view_indices(rgb)
        names = GLOBAL_NAMES + LOCAL_NAMES
        action, clip, exact = [], [], {}
        context = torch.enable_grad() if require_grad else torch.no_grad()
        with context:
            for name in names:
                view = rgb.index_select(0, indices[name])
                _, exact[name] = exact_clip_pixels(view, self.processor)
                action.append(action_probs(self.action_model, view, self.model_name))
                clip.append(clip_probs(self.clip_model, view, self.text_features, exact_pixels=exact[name]))
        return torch.stack(action[:5]), torch.stack(clip[:5]), torch.stack(action[5:]), torch.stack(clip[5:]), indices, exact

    def exact_forward(self, rgb: torch.Tensor):
        ga, gc, la, lc, indices, exact = self.responses(rgb, require_grad=False)
        features = aggregate_features(ga, gc, la, lc)
        logit = detector_logit(features, self.state)
        return features, logit, logit.sigmoid(), indices, exact

    def logit_and_vjp_gradient(self, rgb: torch.Tensor):
        """Return exact detector forward and low-memory BPDA input gradient."""
        ga0, gc0, la0, lc0, indices, exact = self.responses(rgb, require_grad=False)
        responses = [x.detach().to(torch.float64).requires_grad_(True) for x in (ga0, gc0, la0, lc0)]
        features = aggregate_features(*responses)
        logit = detector_logit(features, self.state)
        adjoints = torch.autograd.grad(logit, responses)
        total = torch.zeros_like(rgb)
        for group_index, names in enumerate((GLOBAL_NAMES, GLOBAL_NAMES, LOCAL_NAMES, LOCAL_NAMES)):
            for row, name in enumerate(names):
                view = rgb.index_select(0, indices[name])
                if group_index in (0, 2):
                    response = action_probs(self.action_model, view, self.model_name)
                else:
                    response = clip_probs(self.clip_model, view, self.text_features, exact_pixels=exact[name])
                scalar = (response.to(torch.float64) * adjoints[group_index][row]).sum()
                grad = torch.autograd.grad(scalar, rgb, retain_graph=False)[0]
                total.add_(grad)
        return features, logit.detach(), logit.detach().sigmoid(), total, {
            "global_action_adjoint_norm": float(adjoints[0].norm()),
            "global_clip_adjoint_norm": float(adjoints[1].norm()),
            "local_action_adjoint_norm": float(adjoints[2].norm()),
            "local_clip_adjoint_norm": float(adjoints[3].norm()),
        }
