#!/usr/bin/env python3
"""Rebuild C04 summaries from immutable score shards with lossless CSV parsing."""
import json, sys
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve
RUN=Path('/root/autodl-tmp/tdc_r3r5_revision_20261022_01'); sys.path.insert(0,str(RUN/'code'))
from cpu_common import ATTACKS, bootstrap_macro, bootstrap_payload, write_csv, write_csv_gz
SRC=RUN/'results/C04'; OUT=RUN/'results/C04_roundtrip_v2'; OUT.mkdir(parents=True,exist_ok=True); PROTOCOL='tdc-r3r5-c04-roundtrip-repair-20261026-v1'; METHODS=('raw_probs7200_lr','raw_probs_pca21_lr','full21_lr')
files=sorted((SRC/'shards').glob('*_scores.csv.gz')); scores=pd.concat([pd.read_csv(p,keep_default_na=False,float_precision='round_trip') for p in files],ignore_index=True); write_csv_gz(OUT/'sample_scores.csv.gz',scores)
rows=[]; payloads=[]
for (dataset,model),part in scores.groupby(['dataset','model'],sort=True):
 keys=['dataset','model','partition','pair_id','relative_path','attack','is_adv','attack_success']; wide=part.pivot(index=keys,columns='method',values='score').reset_index(); wide['action_model']=model; payloads.append(bootstrap_payload(wide,{m:wide[m].to_numpy(float) for m in METHODS}))
 for attack in (*ATTACKS,'pooled'):
  base_clean=wide[wide.attack=='clean']; base_adv=wide[wide.attack!='clean'] if attack=='pooled' else wide[wide.attack==attack]
  for setting in ('full','success-only'):
   adv=base_adv if setting=='full' else base_adv[pd.to_numeric(base_adv.attack_success,errors='coerce')==1]; clean=base_clean if setting=='full' else base_clean[base_clean.pair_id.isin(set(adv.pair_id))]
   chosen=pd.concat([clean,adv],ignore_index=True); labels=chosen.is_adv.to_numpy(int)
   for method in METHODS:
    values=chosen[method].to_numpy(float); threshold=float(part[part.method==method].threshold.iloc[0]); fpr,tpr,_=roc_curve(labels,values); pred=values>threshold; cm=labels==0; am=labels==1
    rows.append({'protocol_id':PROTOCOL,'task_id':'C04','dataset':dataset,'model':model,'method':method,'attack':attack,'setting':setting,'threshold':threshold,'roc_auc':float(roc_auc_score(labels,values)),'pr_auc':float(average_precision_score(labels,values)),'fpr_at_95_tpr':float(fpr[np.flatnonzero(tpr>=.95)[0]]),'tpr_at_1_fpr':float(np.max(tpr[fpr<=.01])),'threshold_fpr':float(pred[cm].mean()),'threshold_tpr':float(pred[am].mean()),'n_sources':int(chosen.relative_path.nunique()),'n_clean':int(cm.sum()),'n_adv':int(am.sum())})
metrics=pd.DataFrame(rows); write_csv(OUT/'condition_metrics.csv',metrics)
diffs,reps=bootstrap_macro(payloads,[('raw_probs7200_lr','full21_lr'),('raw_probs_pca21_lr','full21_lr')],PROTOCOL,'C04'); write_csv(OUT/'paired_differences.csv',diffs); write_csv_gz(OUT/'bootstrap_replicates.csv.gz',reps)
write_csv(OUT/'figure_source_data.csv',metrics[(metrics.attack=='pooled')&(metrics.setting=='full')].copy())
old_scores=pd.read_csv(SRC/'sample_scores.csv.gz',float_precision='round_trip'); score_keys=['dataset','model','pair_id','attack','method']; old_aligned=old_scores.set_index(score_keys).loc[scores.set_index(score_keys).index].score.to_numpy(float); score_delta=scores.score.to_numpy(float)-old_aligned
old_metrics=pd.read_csv(SRC/'condition_metrics.csv',float_precision='round_trip'); mk=['dataset','model','method','attack','setting']; joined=metrics.merge(old_metrics,on=mk,suffixes=('_new','_old')); metric_cols=['roc_auc','pr_auc','fpr_at_95_tpr','tpr_at_1_fpr','threshold_fpr','threshold_tpr']; comparison=[]
for col in metric_cols:
 d=joined[f'{col}_new']-joined[f'{col}_old']; comparison.append({'artifact':'condition_metrics','field':col,'maximum_absolute_difference':float(d.abs().max()),'changed_rows':int((d!=0).sum())})
comparison.append({'artifact':'sample_scores','field':'score','maximum_absolute_difference':float(np.max(np.abs(score_delta))),'changed_rows':int(np.count_nonzero(score_delta))}); write_csv(OUT/'before_after_comparison.csv',pd.DataFrame(comparison))
expected_rows=sum(len(pd.read_csv(p,usecols=['score'],float_precision='round_trip')) for p in files)
unique_keys=not scores.duplicated(['dataset','model','pair_id','attack','method']).any()
validation={'protocol_id':PROTOCOL,'passed':bool(len(files)==8 and len(scores)==expected_rows and len(metrics)==240 and unique_keys and np.isfinite(scores.score).all()),'source_shards':len(files),'sample_score_rows':len(scores),'expected_sample_score_rows_from_shards':expected_rows,'unique_sample_method_keys':unique_keys,'condition_metric_rows':len(metrics),'bootstrap_rows':len(reps),'float_parser':'pandas float_precision=round_trip','source':'immutable C04 score shards; no refit and no GPU'}; (OUT/'validation.json').write_text(json.dumps(validation,indent=2,sort_keys=True)+'\n')
