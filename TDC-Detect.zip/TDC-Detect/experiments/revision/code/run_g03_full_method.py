#!/usr/bin/env python3
"""Isolated G03 full timing worker for one dataset/model/method."""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import torch

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
PROJECT = Path("/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master")
BASE_PROTOCOL = Path("/root/autodl-tmp/tsc/final_protocols/tdc-final-20260714")
CLASSES = Path("/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv")
for path in (PROJECT, RUN / "code"):
    if str(path) not in sys.path: sys.path.insert(0, str(path))

from cpu_common import FEATURES, fit_lr, load_e1
from TSC_Detect.attack_rgb import prepare_attack_frames
from TSC_Detect.tsc_action_model import get_action_probs, install_deterministic_attack_pooling
from TSC_Detect.tsc_features import compute_tsc_features, local_window_features, symmetric_kl
from TSC_Detect.tsc_sampling import build_frozen_global_views, build_frozen_local_views
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES, get_vlm_context_probs
from TSC_Detect.utils_video import load_frames, read_class_names

PROTOCOL_ID = "tdc-r3r5-g03-full-corrected-20261025-v2"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
METHODS = ("action_single", "e14_action_shift9_lr", "action_stats12_lr", "discrepancy9_lr", "full_g5l4_lr", "light_g3l2_adapter", "single_discrepancy_lr")
ACTION_FEATURES = FEATURES[:12]


def state_score(features: dict[str, float], state: dict) -> float:
    order = state["feature_order"]
    vector = np.asarray([features[name] for name in order], dtype=np.float64)
    z = np.sum((vector - np.asarray(state["scaler_mean"])) / np.asarray(state["scaler_scale"]) * np.asarray(state["lr_coef"])) + float(state["lr_intercept"])
    return float(1 / (1 + np.exp(-np.clip(z, -700, 700))))


def pipeline_state(pipeline, order: list[str]) -> dict:
    scaler, lr = pipeline.named_steps["scaler"], pipeline.named_steps["logistic"]
    return {"feature_order": order, "scaler_mean": scaler.mean_.tolist(), "scaler_scale": scaler.scale_.tolist(), "lr_coef": lr.coef_[0].tolist(), "lr_intercept": float(lr.intercept_[0])}


def load_action_only(device, name):
    import pytorchvideo.models.hub as models
    factories = {"csn_r101": models.csn_r101, "slowfast_r50": models.slowfast_r50,
                 "x3d_m": models.x3d_m, "mvit_base_16x4": models.mvit_base_16x4}
    model = factories[name](True).eval().to(device)
    install_deterministic_attack_pooling(model); model._tdc_action_model_name = name
    return model


def load_clip_only(device):
    from transformers import CLIPModel, CLIPProcessor
    return (CLIPModel.from_pretrained("openai/clip-vit-base-patch32").eval().to(device),
            CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32"))


def load_e14_state(dataset, model, method):
    path = RUN / "models/G03_method_identity_v2" / f"{dataset}_{model}_{method}.json"
    value = json.loads(path.read_text())
    import hashlib
    value["state_path"] = str(path); value["state_sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset", choices=("k400", "ucf101"), required=True)
    parser.add_argument("--model", choices=MODELS, required=True)
    parser.add_argument("--method", choices=METHODS, required=True)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--videos", type=int, default=100)
    parser.add_argument("--repeats", type=int, default=5)
    parser.add_argument("--warmups", type=int, default=10)
    parser.add_argument("--output-name", default="full_corrected")
    args = parser.parse_args()
    if args.dataset == "ucf101" and args.method == "light_g3l2_adapter":
        raise RuntimeError("light_g3l2 unavailable for UCF101: no independent UCF light calibration adapter")
    authorization = json.loads((RUN / "protocols/authorization.json").read_text())
    if authorization.get("selected_option") != "B": raise RuntimeError("option B not authorized")
    device = torch.device(args.device)
    gpu_uuid = os.environ.get("TDC_GPU_UUID", "unknown")
    gate = json.loads((RUN / "protocols/G03_METHOD_IDENTITY_GATE.json").read_text())
    if gate.get("passed") is not True: raise RuntimeError("G03 method identity gate not passed")
    output = RUN / f"results/G03/{args.output_name}/shards" / f"{args.dataset}_{args.model}_{args.method}.csv.gz"
    output.parent.mkdir(parents=True, exist_ok=True)
    expected = args.videos * args.repeats * 2
    if output.exists():
        old = pd.read_csv(output)
        if len(old) == expected and old.protocol_id.eq(PROTOCOL_ID).all() and not old.duplicated(["source_id", "repeat", "timing_boundary"]).any():
            print(json.dumps({"reused": str(output)})); return

    if args.dataset == "k400":
        manifest_path = BASE_PROTOCOL / "manifests" / f"k400_{args.model}_test_fixed100.csv"
    else:
        manifest_path = BASE_PROTOCOL / "manifests/ucf101_test_fixed100.csv"
    manifest = pd.read_csv(manifest_path).sort_values("relative_path").head(args.videos)
    if len(manifest) != args.videos: raise RuntimeError(f"manifest {len(manifest)}/{args.videos}")
    calibration = load_e1(args.dataset, args.model, "calibration")
    full_state = pipeline_state(fit_lr(calibration, FEATURES), FEATURES)
    action_state = pipeline_state(fit_lr(calibration, ACTION_FEATURES), ACTION_FEATURES)
    light_state = None
    if args.method == "light_g3l2_adapter":
        raw = json.loads((RUN / "models/C01" / args.model / "g3_l2/fold_0.json").read_text())
        light_state = {"feature_order": raw["feature_order"], "scaler_mean": raw["scaler"]["mean"], "scaler_scale": raw["scaler"]["scale"], "lr_coef": raw["logistic"]["coef"], "lr_intercept": raw["logistic"]["intercept"]}
    e14_state = load_e14_state(args.dataset, args.model, args.method) if args.method in ("e14_action_shift9_lr", "discrepancy9_lr", "single_discrepancy_lr") else None
    classes = read_class_names(CLASSES)
    action_model = load_action_only(device, args.model)
    need_clip_model = args.method in ("single_discrepancy_lr", "discrepancy9_lr", "full_g5l4_lr", "light_g3l2_adapter")
    clip_model, processor = load_clip_only(device) if need_clip_model else (None, None)
    action_parameter_count = sum(parameter.numel() for parameter in action_model.parameters())
    clip_parameter_count = sum(parameter.numel() for parameter in clip_model.parameters()) if clip_model is not None else 0
    torch.cuda.synchronize(device)
    resident_model_allocated = int(torch.cuda.memory_allocated(device)); resident_model_reserved = int(torch.cuda.memory_reserved(device))
    prepared = []
    for row in manifest.itertuples(index=False):
        rgb = prepare_attack_frames(load_frames(Path(row.path)), args.model, device).detach().cpu().numpy().astype(np.float32)
        prepared.append((row.relative_path, row.path, rgb))

    def infer(rgb: np.ndarray) -> tuple[float, int, int]:
        global_views = build_frozen_global_views(rgb)
        if args.method == "action_single":
            _, _, confidence = get_action_probs(action_model, global_views["original"], device)
            return confidence, 1, 0
        if args.method == "single_discrepancy_lr":
            view = global_views["original"]
            action, _, _ = get_action_probs(action_model, view, device)
            clip = get_vlm_context_probs(clip_model, processor, view, classes, device, prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8)
            return state_score({"D_0": symmetric_kl(action, clip)}, e14_state), 1, 1
        local_views = build_frozen_local_views(rgb)
        selected_global = list(global_views.items()) if args.method != "light_g3l2_adapter" else list(global_views.items())[:3]
        selected_local = list(local_views.items()) if args.method != "light_g3l2_adapter" else list(local_views.items())[:2]
        selected = dict(selected_global + selected_local)
        need_clip = args.method in ("discrepancy9_lr", "full_g5l4_lr", "light_g3l2_adapter")
        action, clip = {}, {}
        for name, view in selected.items():
            action[name], _, _ = get_action_probs(action_model, view, device)
            if need_clip:
                clip[name] = get_vlm_context_probs(clip_model, processor, view, classes, device, prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8)
        if args.method == "e14_action_shift9_lr":
            values = {f"action_shift_{i}": symmetric_kl(action["original"], action[name]) for i, name in enumerate(list(selected)[1:], 1)}
            return state_score(values, e14_state), len(selected), 0
        if args.method == "discrepancy9_lr":
            values = {f"D_{i}": symmetric_kl(action[name], clip[name]) for i, name in enumerate(selected)}
            return state_score(values, e14_state), len(selected), len(selected)
        global_action = {name: action[name] for name, _ in selected_global}
        local_action = {name: action[name] for name, _ in selected_local}
        if args.method == "action_stats12_lr":
            features = compute_tsc_features(global_action, global_action, primary_view="original")
            features.update(local_window_features(local_action, local_action, reference_action_probs=global_action["original"]))
            return state_score(features, action_state), len(selected), 0
        global_clip = {name: clip[name] for name, _ in selected_global}
        local_clip = {name: clip[name] for name, _ in selected_local}
        features = compute_tsc_features(global_action, global_clip, primary_view="original")
        features.update(local_window_features(local_action, local_clip, reference_action_probs=global_action["original"]))
        return state_score(features, full_state if args.method == "full_g5l4_lr" else light_state), len(selected), len(selected)

    for index in range(args.warmups): infer(prepared[index % len(prepared)][2])
    torch.cuda.synchronize(device)
    rows = []
    for repeat in range(args.repeats):
        boundaries = ("A_predecoded", "B_path_to_score") if repeat % 2 == 0 else ("B_path_to_score", "A_predecoded")
        for relative_path, path, rgb in prepared:
            for boundary in boundaries:
                torch.cuda.reset_peak_memory_stats(device); torch.cuda.synchronize(device)
                started = time.perf_counter()
                current = rgb if boundary == "A_predecoded" else prepare_attack_frames(load_frames(Path(path)), args.model, device).detach().cpu().numpy().astype(np.float32)
                value, action_calls, clip_calls = infer(current)
                torch.cuda.synchronize(device)
                rows.append({
                    "protocol_id": PROTOCOL_ID, "dataset": args.dataset, "model": args.model, "method": args.method,
                    "source_id": relative_path, "repeat": repeat, "timing_boundary": boundary,
                    "seconds": time.perf_counter() - started, "score": value,
                    "peak_allocated": torch.cuda.max_memory_allocated(device), "peak_reserved": torch.cuda.max_memory_reserved(device),
                    "resident_memory": resident_model_allocated, "resident_reserved": resident_model_reserved, "gpu_uuid": gpu_uuid,
                    "warmups": args.warmups, "logical_action_view_calls": action_calls, "logical_clip_view_calls": clip_calls,
                    "process_isolation": "one dataset-model-method worker; all G03 workers serial on GPU0",
                    "frozen_action_parameters": action_parameter_count,
                    "frozen_clip_parameters": clip_parameter_count,
                    "clip_model_loaded": bool(clip_model is not None),
                    "readout_trainable_parameters": 13 if args.method == "action_stats12_lr" else (22 if args.method in ("full_g5l4_lr", "light_g3l2_adapter") else (len(e14_state["feature_order"])+1 if e14_state else 0)),
                    "method_state_sha256": e14_state.get("state_sha256", "runtime_fitted_calibration_state") if e14_state else "runtime_fitted_calibration_state",
                    "utility_source": "C01 OOF only; adapter score is timing-only" if args.method == "light_g3l2_adapter" else (e14_state.get("utility_source") if e14_state else "E1/C02 frozen calibration utility"),
                })
        print(json.dumps({"dataset": args.dataset, "model": args.model, "method": args.method, "repeat": repeat + 1}), flush=True)
    frame = pd.DataFrame(rows)
    if len(frame) != expected or frame.duplicated(["source_id", "repeat", "timing_boundary"]).any(): raise RuntimeError("G03 row gate failed")
    temp = output.with_suffix(output.suffix + ".tmp")
    frame.to_csv(temp, index=False, compression="gzip"); os.replace(temp, output)
    print(json.dumps({"complete": str(output), "rows": len(frame)}), flush=True)


if __name__ == "__main__":
    main()
