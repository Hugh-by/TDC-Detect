#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"; LOG="$RUN/logs/G03_full_corrected"; mkdir -p "$LOG"
methods=(action_single e14_action_shift9_lr action_stats12_lr discrepancy9_lr full_g5l4_lr light_g3l2_adapter single_discrepancy_lr)
models=(csn_r101 mvit_base_16x4 slowfast_r50 x3d_m); uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i 0|tr -d ' ')"
for dataset in k400 ucf101; do for model in "${models[@]}"; do for method in "${methods[@]}"; do
  [[ "$dataset" == ucf101 && "$method" == light_g3l2_adapter ]] && continue
  CUDA_VISIBLE_DEVICES=0 TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
    python "$RUN/code/run_g03_full_method.py" --dataset "$dataset" --model "$model" --method "$method" \
    --videos 100 --repeats 5 --warmups 10 --output-name full_corrected \
    >"$LOG/${dataset}_${model}_${method}.log" 2>&1
done; done; done
python - "$RUN" <<'PY'
import json, sys
from pathlib import Path
import pandas as pd
run=Path(sys.argv[1]); root=run/'results/G03/full_corrected/shards'; files=list(root.glob('*.csv.gz'))
passed=len(files)==52 and all(len(pd.read_csv(p))==1000 for p in files)
value={'protocol_id':'tdc-r3r5-g03-full-corrected-20261025-v2','passed':passed,'shards':len(files),'expected_shards':52,'rows':sum(len(pd.read_csv(p)) for p in files),'timing_gpu_policy':'all formal workers serial on physical GPU0'}
(run/'results/G03/full_corrected/validation.json').parent.mkdir(parents=True,exist_ok=True); (run/'results/G03/full_corrected/validation.json').write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
if not passed: raise SystemExit(value)
PY
echo G03_FULL_CORRECTED_COMPLETE >"$LOG/COMPLETE"
