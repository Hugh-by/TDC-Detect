#!/usr/bin/env bash
set -euo pipefail
RUN="${TDC_RUN_ROOT:-/root/autodl-tmp/tdc_r3r5_revision_20261022_01}"
LOGDIR="$RUN/logs/G04_full_corrected"
mkdir -p "$LOGDIR"
pids=()
for spec in "0 csn_r101" "1 mvit_base_16x4" "2 slowfast_r50" "3 x3d_m"; do
  read -r gpu model <<<"$spec"
  uuid="$(nvidia-smi --query-gpu=uuid --format=csv,noheader -i "$gpu" | tr -d ' ')"
  CUDA_VISIBLE_DEVICES="$gpu" TDC_GPU_UUID="$uuid" HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
    python "$RUN/code/run_g04_full_corrected_worker.py" --model "$model" --output-name full_corrected \
    >"$LOGDIR/${model}.log" 2>&1 &
  pids+=("$!")
done
failed=0
for pid in "${pids[@]}"; do
  if ! wait "$pid"; then failed=1; fi
done
[[ "$failed" == 0 ]] || exit 1
python - "$RUN" <<'PY'
import json, sys
from pathlib import Path
run = Path(sys.argv[1])
items = []
for name in ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m"):
    path = run / "results/G04/full_corrected" / name / "validation.json"
    value = json.loads(path.read_text())
    if not value.get("passed") or value.get("records") != 200 or value.get("selected_tensors") != 200:
        raise SystemExit(f"invalid corrected G04 result: {name}: {value}")
    items.append(value)
(run / "logs/G04_full_corrected/COMPLETE").write_text("G04_FULL_CORRECTED_COMPLETE\n")
PY
