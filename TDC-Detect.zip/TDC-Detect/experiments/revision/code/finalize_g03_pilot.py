#!/usr/bin/env python3
from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
import pandas as pd

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
ROOT = RUN / "results" / "G03" / "pilot"
MODELS = ("csn_r101", "mvit_base_16x4")
METHODS = ("action_single", "e14_action_shift9", "action_stats12", "discrepancy9", "full_g5l4", "light_g3l2", "single_discrepancy")


def atomic_json(path: Path, value: object) -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)


def cluster_ci(group: pd.DataFrame, seed: int = 20260714) -> tuple[float, float]:
    pivot = group.groupby("source_id").seconds.mean()
    values = pivot.to_numpy(float)
    rng = np.random.default_rng(seed)
    estimates = np.asarray([rng.choice(values, len(values), replace=True).mean() for _ in range(2000)])
    return tuple(np.quantile(estimates, [0.025, 0.975]))


def main() -> None:
    paths = [ROOT / "shards" / f"{model}_{method}.csv.gz" for model in MODELS for method in METHODS]
    missing = [str(path) for path in paths if not path.exists()]
    if missing: raise RuntimeError(f"missing G03 shards: {missing}")
    frame = pd.concat([pd.read_csv(path) for path in paths], ignore_index=True)
    if len(frame) != 1680 or frame.duplicated(["model", "method", "source_id", "repeat", "timing_boundary"]).any():
        raise RuntimeError(f"G03 coverage/key gate failed: {len(frame)}/1680")
    frame.to_csv(ROOT / "per_clip_runtime.csv.gz", index=False, compression="gzip")
    rows = []
    for keys, group in frame.groupby(["model", "method", "timing_boundary"], sort=False):
        low, high = cluster_ci(group)
        rows.append({
            "protocol_id": group.protocol_id.iloc[0], "dataset": "k400", "model": keys[0], "method": keys[1], "timing_boundary": keys[2],
            "n_clips": group.source_id.nunique(), "repeats": group.repeat.nunique(),
            "mean_seconds": group.seconds.mean(), "median_seconds": group.seconds.median(), "p95_seconds": group.seconds.quantile(.95),
            "source_cluster_ci_low": low, "source_cluster_ci_high": high,
            "peak_allocated": group.peak_allocated.max(), "peak_reserved": group.peak_reserved.max(),
        })
    summary = pd.DataFrame(rows)
    summary.to_csv(ROOT / "condition_latency.csv", index=False)
    ratios = []
    for (model, boundary), group in summary.groupby(["model", "timing_boundary"]):
        lookup = dict(zip(group.method, group.mean_seconds))
        for denominator in ("action_single", "e14_action_shift9", "single_discrepancy"):
            ratios.append({"model": model, "timing_boundary": boundary, "numerator": "full_g5l4", "denominator": denominator,
                           "ratio": lookup["full_g5l4"] / lookup[denominator]})
    pd.DataFrame(ratios).to_csv(ROOT / "ratio_table.csv", index=False)
    trace = frame.groupby(["model", "method"], as_index=False).agg(
        logical_action_view_calls=("logical_action_view_calls", "first"), logical_clip_view_calls=("logical_clip_view_calls", "first"),
        process_isolation=("process_isolation", "first"), gpu_uuid=("gpu_uuid", "first"),
    )
    trace["action_only_skips_clip"] = trace.apply(lambda row: bool(row.logical_clip_view_calls == 0) if row.method in ("action_single", "e14_action_shift9", "action_stats12") else "NA", axis=1)
    trace.to_csv(ROOT / "call_trace.csv", index=False)
    parameters = frame.groupby(["model", "method"], as_index=False).agg(
        frozen_action_parameters=("frozen_action_parameters", "first"), frozen_clip_parameters=("frozen_clip_parameters", "first"),
        readout_trainable_parameters=("readout_trainable_parameters", "first"),
    )
    parameters["scaler_state_values"] = parameters.readout_trainable_parameters.map(lambda x: 24 if x == 13 else (42 if x == 22 else 0))
    parameters.to_csv(ROOT / "parameter_table.csv", index=False)
    definitions = [json.loads((ROOT / "shards" / f"{model}_{method}.definition.json").read_text()) for model in MODELS for method in METHODS]
    atomic_json(ROOT / "method_definition.json", definitions)
    atomic_json(ROOT / "validation.json", {
        "passed": True, "protocol_id": str(frame.protocol_id.iloc[0]), "rows": len(frame), "models": list(MODELS), "methods": list(METHODS),
        "boundaries": sorted(frame.timing_boundary.unique()), "warmups": sorted(frame.warmups.unique().tolist()),
        "finite": bool(np.isfinite(frame[["seconds", "score", "peak_allocated", "peak_reserved"]]).all().all()),
        "unique_keys": True, "quiet_window_required": True,
    })
    print(json.dumps({"G03_pilot_complete": True, "rows": len(frame), "output": str(ROOT)}))


if __name__ == "__main__": main()
