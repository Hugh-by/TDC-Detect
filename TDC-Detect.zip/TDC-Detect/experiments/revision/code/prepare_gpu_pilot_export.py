#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from datetime import datetime, timezone
from pathlib import Path

RUN = Path(os.environ.get("TDC_RUN_ROOT", "/root/autodl-tmp/tdc_r3r5_revision_20261022_01"))
EXPORTS = RUN / "exports"
EXPORTS.mkdir(exist_ok=True)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def members(include_tensors: bool) -> list[Path]:
    roots = [RUN / "results" / name for name in ("G01", "G02", "G03", "G04", "G05")]
    files = []
    for root in roots:
        for path in root.rglob("*"):
            if not path.is_file(): continue
            if not include_tensors and (path.suffix == ".pt" or "trajectory_shards" in path.parts or "checkpoints" in path.parts): continue
            files.append(path)
    files.extend([
        RUN / "reports/PILOT_REPORT.md", RUN / "reports/BUDGET_OPTIONS.csv",
        RUN / "protocols/GPU_PILOT_authorization.json", RUN / "environment/gpu_resource_audit_20261023.json",
    ])
    files.extend(sorted((RUN / "code").glob("*g0*.py")))
    files.extend(sorted((RUN / "code").glob("gpu_*.py")))
    return sorted(set(path for path in files if path.exists()))


def create(name: str, include_tensors: bool) -> dict:
    path = EXPORTS / name
    manifest = []
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=True) as archive:
        for source in members(include_tensors):
            relative = source.relative_to(RUN).as_posix()
            archive.write(source, relative)
            manifest.append({"path": relative, "bytes": source.stat().st_size, "sha256": sha256(source)})
        status = {
            "run_id": RUN.name, "stage": "GPU_PILOT", "scope_complete": True,
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "tasks": {"G01": "completed", "G02": "completed_pilot", "G03": "completed_pilot", "G04": "completed_pilot", "G05": "completed_pilot", "G06": "deferred_optional", "G07": "deferred_budget", "GPU_FULL": "deferred_budget"},
        }
        archive.writestr("STATUS.json", json.dumps(status, indent=2, sort_keys=True) + "\n")
        archive.writestr("export_manifest.json", json.dumps({"format_version": 1, **status, "files": manifest}, indent=2, sort_keys=True) + "\n")
        archive.writestr("README.md", "# TDC R3/R5 GPU pilot export\n\nSee `reports/PILOT_REPORT.md`. This archive contains pilot evidence only; GPU_FULL is not authorized or claimed complete.\n")
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}


def main() -> None:
    outputs = [create("GPU_PILOT_REVIEW_PACKAGE.zip", False), create("GPU_PILOT_REPRO_PACKAGE.zip", True)]
    index = {"generated_at": datetime.now(timezone.utc).isoformat(), "packages": outputs,
             "no_gpu_review_dependency": str(EXPORTS / "REVIEW_PACKAGE.zip")}
    (EXPORTS / "GPU_PILOT_PACKAGE_INDEX.json").write_text(json.dumps(index, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(index, indent=2))


if __name__ == "__main__": main()
