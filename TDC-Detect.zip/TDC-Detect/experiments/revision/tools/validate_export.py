"""Validate portable export structure and hashes, not scientific correctness.

Usage: python validate_export.py EXPORT_ROOT --registry TASK_REGISTRY.json
Exit 0: structural checks pass; exit 1: structural errors; exit 2: malformed input.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

STATES = {'not_started', 'running', 'completed', 'failed', 'blocked_input',
          'blocked_resource', 'deferred_budget', 'deferred_optional'}


def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def validate(root, registry):
    root = Path(root).resolve()
    errors, warnings = [], []

    def safe_file(relative):
        if not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative:
            raise ValueError('invalid relative path: ' + repr(relative))
        p = PurePosixPath(relative)
        if p.is_absolute() or '..' in p.parts or str(p) != relative:
            raise ValueError('non-canonical/unsafe path: ' + repr(relative))
        path = root.joinpath(*p.parts)
        if not path.resolve().is_relative_to(root):
            raise ValueError('path escapes export root: ' + relative)
        if any(q.is_symlink() for q in (path, *path.parents) if q != root and q.is_relative_to(root)):
            raise ValueError('symlink is not a portable export file: ' + relative)
        return path

    manifest = json.loads((root / 'export_manifest.json').read_text(encoding='utf-8-sig'))
    status = json.loads((root / 'STATUS.json').read_text(encoding='utf-8-sig'))
    if manifest.get('format_version') != 1:
        errors.append('format_version must be 1')
    for key in ('run_id', 'stage', 'generated_at', 'files', 'scope_complete', 'required_result_paths'):
        if key not in manifest:
            errors.append('manifest missing ' + key)
    if not isinstance(manifest.get('scope_complete'), bool):
        errors.append('scope_complete must be boolean')
    if status.get('run_id') != manifest.get('run_id'):
        errors.append('STATUS and manifest run_id mismatch')
    listed = set()
    for entry in manifest.get('files', []):
        try:
            name = entry['path']
            path = safe_file(name)
            if name == 'export_manifest.json' or name in listed:
                errors.append('self reference or duplicate file: ' + name)
            listed.add(name)
            if not name.isascii():
                errors.append('non-ASCII package member: ' + name)
            if not path.is_file():
                errors.append('missing file: ' + name)
                continue
            if path.stat().st_size != entry.get('bytes'):
                errors.append('size mismatch: ' + name)
            if sha256(path) != entry.get('sha256'):
                errors.append('hash mismatch: ' + name)
        except (KeyError, TypeError, ValueError) as exc:
            errors.append(str(exc))
    minimum = {'README.md', 'STATUS.json', 'DATA_ARTIFACTS.csv', 'SOURCE_HASHES.csv',
               'reports/STAGE_REPORT.md', 'reports/RESULTS_AT_A_GLANCE.csv',
               'reports/reviewer_evidence_matrix.csv', 'reports/manuscript_change_map.md',
               'reports/UNRESOLVED_ITEMS.md', 'reports/RESOURCE_USAGE.csv'}
    errors.extend('required file not in manifest: ' + n for n in sorted(minimum - listed))
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    errors.extend('unhashed file: ' + n for n in sorted(actual - listed - {'export_manifest.json'}))

    entries = status.get('tasks', [])
    ids = [t.get('task_id') for t in entries]
    if len(ids) != len(set(ids)):
        errors.append('duplicate task_id in STATUS')
    expected = {t['task_id'] for t in registry['tasks']}
    if set(ids) != expected:
        errors.append('STATUS task coverage differs from registry')
    by_id = {t.get('task_id'): t for t in entries}
    required_results = manifest.get('required_result_paths', {})
    for t in entries:
        tid = str(t.get('task_id'))
        state = t.get('status')
        if state not in STATES:
            errors.append(tid + ': invalid state')
        if state == 'completed':
            for key in ('protocol_id', 'input_hash_manifest', 'result_paths', 'validation_paths'):
                if not t.get(key):
                    errors.append(tid + ': completed task lacks ' + key)
            if not required_results.get(tid):
                errors.append(tid + ': completed task lacks required_result_paths declaration')
            paths = list(t.get('result_paths', [])) + list(t.get('validation_paths', []))
            paths += list(required_results.get(tid, []))
            paths += [t['input_hash_manifest']] if t.get('input_hash_manifest') else []
            for name in paths:
                try:
                    if name not in listed or not safe_file(name).is_file():
                        errors.append(tid + ': completed artifact not exported/hashed: ' + str(name))
                except ValueError as exc:
                    errors.append(str(exc))
        elif state not in {'not_started', 'running'} and not t.get('reason'):
            errors.append(tid + ': non-completed state needs reason')
    scope = status.get('stage_scope_tasks', [])
    if manifest.get('scope_complete'):
        if not scope:
            errors.append('scope_complete requires nonempty stage_scope_tasks')
        for tid in scope:
            if by_id.get(tid, {}).get('status') not in {'completed', 'deferred_optional'}:
                errors.append('scope declared complete with unfinished task: ' + str(tid))
    if status.get('template_only'):
        errors.append('STATUS is still a template, not actual run state')
    warnings.append('Structural validation only: scientific checks require independent evidence.')
    return {'validation_scope': 'export_structure_and_hashes_only', 'passed': not errors,
            'files_checked': len(listed), 'errors': errors, 'warnings': warnings}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('export_root', type=Path)
    parser.add_argument('--registry', required=True, type=Path)
    args = parser.parse_args()
    try:
        report = validate(args.export_root, json.loads(args.registry.read_text(encoding='utf-8-sig')))
    except (OSError, ValueError, TypeError, KeyError) as exc:
        print(json.dumps({'passed': False, 'error': str(exc)}, ensure_ascii=False, indent=2))
        return 2
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
