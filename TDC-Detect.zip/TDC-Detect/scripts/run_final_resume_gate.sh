#!/usr/bin/env bash
set -euo pipefail

GPU=${1:-0}
PROTOCOL=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc/final_protocols/${PROTOCOL}
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
MANIFEST=${ROOT}/manifests/k400_x3d_m_test_selected.csv
CLASSES=/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
WORK=${ROOT}/gates/resume_work

rm -rf "${WORK}"
mkdir -p "${WORK}"
cd "${PROJECT}"
export CUDA_VISIBLE_DEVICES=${GPU}
export CUBLAS_WORKSPACE_CONFIG=:4096:8

common=(
  --manifest "${MANIFEST}" --dataset k400 --partition test --action-model x3d_m
  --class-names "${CLASSES}" --attacks fgsm --device cuda:0
)
python -m TSC_Detect.run_final_extract "${common[@]}" --max-videos 5 --output-csv "${WORK}/continuous.csv"
python -m TSC_Detect.run_final_extract "${common[@]}" --max-videos 2 --output-csv "${WORK}/resumed.csv"
python -m TSC_Detect.run_final_extract "${common[@]}" --max-videos 5 --output-csv "${WORK}/resumed.csv" --resume

python - "${WORK}" "${ROOT}/gates/resume_gate_report.json" <<'PY'
import csv, hashlib, json, sys
from pathlib import Path
work, report_path = map(Path, sys.argv[1:])
def canonical(path):
    with path.open(encoding='utf-8', newline='') as f:
        rows=list(csv.DictReader(f)); fields=rows[0].keys()
    rows.sort(key=lambda r:(r['pair_id'],r['attack']))
    data='\n'.join(','.join(r[k] for k in fields) for r in rows).encode()
    return rows, hashlib.sha256(data).hexdigest()
left, left_hash=canonical(work/'continuous.csv')
right, right_hash=canonical(work/'resumed.csv')
report={
  'protocol_id':'tdc-final-20260714', 'continuous_rows':len(left), 'resumed_rows':len(right),
  'continuous_sorted_sha256':left_hash, 'resumed_sorted_sha256':right_hash,
  'pass':len(left)==10 and left_hash==right_hash,
}
report_path.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps(report,indent=2,sort_keys=True))
raise SystemExit(0 if report['pass'] else 1)
PY
