#!/usr/bin/env bash
set -euo pipefail
DATASET=$1
MODEL=$2
GPU=$3
P=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
CLASSES=/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
if [[ "${DATASET}" == "k400" ]]; then
  MANIFEST="${ROOT}/final_protocols/${P}/manifests/k400_${MODEL}_test_fixed100.csv"
else
  MANIFEST="${ROOT}/final_protocols/${P}/manifests/ucf101_test_fixed100.csv"
fi
OUTPUT="${ROOT}/outputs/${P}/E9/${DATASET}_${MODEL}.csv"
STATUS=$(python "${PROJECT}/scripts/validate_or_quarantine_final_raw.py" \
  --path "${OUTPUT}" --expected 2000 --keys method,repeat,relative_path \
  --finite seconds,peak_memory_bytes \
  --quarantine-dir "${ROOT}/final_protocols/${P}/logs/recovery/E9")
[[ "${STATUS}" == "COMPLETE" ]] && exit 0
export CUDA_VISIBLE_DEVICES=${GPU} CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "${PROJECT}"
python -m TSC_Detect.run_final_e9_runtime \
  --manifest "${MANIFEST}" --dataset "${DATASET}" --model "${MODEL}" \
  --class-names "${CLASSES}" --output "${OUTPUT}" --device cuda:0 \
  --warmups 10 --repeats 5
