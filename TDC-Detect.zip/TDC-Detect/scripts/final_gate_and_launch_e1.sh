#!/usr/bin/env bash
set -euo pipefail

PROTOCOL=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc/final_protocols/${PROTOCOL}
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
FORMAL=/root/autodl-tmp/tsc/outputs/${PROTOCOL}
MODELS=(csn_r101 mvit_base_16x4 slowfast_r50 x3d_m)
GPUS=(0 1 2 3)

stamp() { date -Is; }
echo "$(stamp) waiting for corrected model gate reports"
while true; do
  ready=1
  for model in "${MODELS[@]}"; do
    [ -s "${ROOT}/gates/model/${model}_gate_report.json" ] || ready=0
  done
  [ "${ready}" -eq 1 ] && break
  sleep 30
done

python - "${ROOT}" <<'PY'
import json, pathlib, sys
root=pathlib.Path(sys.argv[1])
models=('csn_r101','mvit_base_16x4','slowfast_r50','x3d_m')
bad=[]
for model in models:
    report=json.loads((root/'gates/model'/f'{model}_gate_report.json').read_text())
    if not report.get('pass'):
        bad.append(model)
if bad:
    raise SystemExit('Corrected model gates failed: '+', '.join(bad))
PY

cd "${PROJECT}"
python scripts/build_final_gate_report.py --protocol-root "${ROOT}" --output-root "${FORMAL}"
echo "$(stamp) G1-G9 PASS; launching E1"
mkdir -p "${ROOT}/logs/E1"
: > "${ROOT}/logs/E1/pids.txt"
for index in "${!MODELS[@]}"; do
  model=${MODELS[$index]}
  gpu=${GPUS[$index]}
  nohup bash scripts/run_final_e1_model_queue.sh "${model}" "${gpu}" \
    >> "${ROOT}/logs/E1/${model}.log" 2>&1 &
  echo "${model} $!" >> "${ROOT}/logs/E1/pids.txt"
done
echo "$(stamp) E1 queues launched"
