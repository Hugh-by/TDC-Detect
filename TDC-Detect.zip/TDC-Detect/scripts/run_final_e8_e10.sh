#!/usr/bin/env bash
set -euo pipefail

P=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc
PROTOCOL_ROOT=${ROOT}/final_protocols/${P}
OUTPUT_ROOT=${ROOT}/outputs/${P}
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
MODELS=(csn_r101 mvit_base_16x4 slowfast_r50 x3d_m)
E8_MODELS=(csn_r101 mvit_base_16x4)
DATASETS=(k400 ucf101)
cd "${PROJECT}"

event() { echo "$(date -Is) $*" | tee -a "${PROTOCOL_ROOT}/ops/events.log"; }
marker() { printf '%s\n' "$(date -Is)" > "${OUTPUT_ROOT}/$1"; }
run_retry() {
  local log=$1; shift
  local attempt
  for attempt in 1 2 3; do
    if "$@" >>"${log}" 2>&1; then return 0; fi
    event "RECOVERY_RETRY phase=POST_E1 attempt=${attempt} command=$*"
    sleep 60
  done
  return 1
}
wait_all() {
  local failed=0 pid
  for pid in "$@"; do
    if ! wait "${pid}"; then failed=1; fi
  done
  return "${failed}"
}

event "PHASE_LAUNCH phase=E8"
mkdir -p "${OUTPUT_ROOT}/E8" "${PROTOCOL_ROOT}/logs/E8" "${OUTPUT_ROOT}/metrics"
pids=()
for i in "${!E8_MODELS[@]}"; do
  run_retry "${PROTOCOL_ROOT}/logs/E8/${E8_MODELS[$i]}.log" \
    bash scripts/run_final_e8_model.sh "${E8_MODELS[$i]}" "$i" &
  pids+=("$!")
done
wait_all "${pids[@]}"
python scripts/eval_final_e8_e10.py \
  --e1-root "${OUTPUT_ROOT}/E1" --e8-root "${OUTPUT_ROOT}/E8" \
  --output-root "${OUTPUT_ROOT}/metrics"
python - "${OUTPUT_ROOT}" <<'PY'
import json, pathlib, sys
import pandas as pd
r=pathlib.Path(sys.argv[1])
for model in ('csn_r101','mvit_base_16x4'):
    f=pd.read_csv(r/f'E8/{model}_candidates.csv')
    if len(f)!=480 or f.duplicated(['stage','pair_id','tradeoff_lambda','restart']).any(): raise SystemExit(f'E8 candidate mismatch: {model}')
    j=json.loads((r/f'E8/{model}_tuning.json').read_text())
    if j['chosen_lambda'] not in (.1,1.,10.): raise SystemExit(f'E8 lambda mismatch: {model}')
if len(pd.read_csv(r/'metrics/E8_adaptive_metrics.csv'))!=4: raise SystemExit('E8 metric row mismatch')
if len(pd.read_csv(r/'metrics/E8_selected_candidates.csv'))!=200: raise SystemExit('E8 selection row mismatch')
if len(pd.read_csv(r/'metrics/E8_lambda_tuning.csv'))!=6: raise SystemExit('E8 tuning row mismatch')
PY
marker E8_COMPLETE
event "PHASE_COMPLETE phase=E8"

event "PHASE_LAUNCH phase=E10"
mkdir -p "${OUTPUT_ROOT}/E10" "${PROTOCOL_ROOT}/logs/E10"
pids=()
for i in "${!MODELS[@]}"; do
  run_retry "${PROTOCOL_ROOT}/logs/E10/${MODELS[$i]}.log" \
    bash scripts/run_final_e10_model.sh "${MODELS[$i]}" "$i" &
  pids+=("$!")
done
wait_all "${pids[@]}"
python scripts/eval_final_e8_e10.py \
  --e1-root "${OUTPUT_ROOT}/E1" --e10-root "${OUTPUT_ROOT}/E10" \
  --output-root "${OUTPUT_ROOT}/metrics"
python - "${OUTPUT_ROOT}" <<'PY'
import pathlib, sys
import pandas as pd
r=pathlib.Path(sys.argv[1])
for model in ('csn_r101','mvit_base_16x4','slowfast_r50','x3d_m'):
    f=pd.read_csv(r/f'E10/{model}.csv')
    if len(f)!=800 or f.duplicated(['pair_id','attack']).any(): raise SystemExit(f'E10 row mismatch: {model}')
if len(pd.read_csv(r/'metrics/E10_main_attack_integrity.csv'))!=32: raise SystemExit('E10 integrity row mismatch')
if len(pd.read_csv(r/'metrics/E10_perceptual_quality.csv'))!=16: raise SystemExit('E10 perceptual row mismatch')
PY
marker E10_COMPLETE
event "PHASE_COMPLETE phase=E10"

# E9 is intentionally isolated and serial: no other GPU job runs while timing.
event "PHASE_LAUNCH phase=E9 mode=isolated_serial"
mkdir -p "${OUTPUT_ROOT}/E9" "${PROTOCOL_ROOT}/logs/E9"
for dataset in "${DATASETS[@]}"; do
  for model in "${MODELS[@]}"; do
    run_retry "${PROTOCOL_ROOT}/logs/E9/${dataset}_${model}.log" \
      bash scripts/run_final_e9_condition.sh "${dataset}" "${model}" 0
  done
done
python scripts/eval_final_e8_e10.py \
  --e1-root "${OUTPUT_ROOT}/E1" --e9-root "${OUTPUT_ROOT}/E9" \
  --output-root "${OUTPUT_ROOT}/metrics"
python - "${OUTPUT_ROOT}" <<'PY'
import pathlib, sys
import pandas as pd
r=pathlib.Path(sys.argv[1])
files=list((r/'E9').glob('*.csv'))
if len(files)!=8 or any(len(pd.read_csv(f))!=2000 for f in files): raise SystemExit('E9 raw row mismatch')
if len(pd.read_csv(r/'metrics/E9_runtime_memory.csv'))!=32: raise SystemExit('E9 metric row mismatch')
PY
marker E9_COMPLETE
event "PHASE_COMPLETE phase=E9"

marker E1_E10_COMPLETE
event "PHASE_COMPLETE phase=E1_E10"
while [ ! -f scripts/build_final_deliverables.py ]; do
  event "WAITING phase=FINAL_DELIVERABLES reason=builder_not_ready"
  sleep 300
done
python scripts/build_final_deliverables.py \
  --protocol-root "${PROTOCOL_ROOT}" --output-root "${OUTPUT_ROOT}"
marker FINAL_EXPORT_COMPLETE
event "PHASE_COMPLETE phase=FINAL_EXPORT"
