from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from TSC_Detect.attack_rgb import make_attack, model_input, prepare_attack_frames, probabilities
from TSC_Detect.run_final_extract import (
    ATTACK_SETTINGS, BASELINE_FIELDS, OUTPUT_FIELDS, PROTOCOL_ID, SEED, all_features, stable_seed,
)
from TSC_Detect.run_tsc_detect import load_real_models
from TSC_Detect.tsc_action_model import ACTION_MODEL_PROFILES, process_action_view
from TSC_Detect.tsc_vlm import DEFAULT_PROMPT_TEMPLATES
from TSC_Detect.utils_video import load_frames, read_class_names


def read_rows(path: Path, limit: int) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))[:limit]


def finite_mapping(values: dict[str, object]) -> bool:
    for value in values.values():
        if isinstance(value, (int, float, np.number)) and not math.isfinite(float(value)):
            return False
    return True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", choices=sorted(ACTION_MODEL_PROFILES), required=True)
    parser.add_argument("--device", required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--class-names", required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--samples", type=int, default=20)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    torch.use_deterministic_algorithms(True, warn_only=True)
    rows = read_rows(args.manifest, args.samples)
    classes = read_class_names(args.class_names)
    model, clip_model, clip_processor = load_real_models(device, args.model)
    report: dict[str, object] = {"protocol_id": PROTOCOL_ID, "model": args.model, "samples": len(rows)}

    first_frames = load_frames(Path(rows[0]["path"]))
    direct = process_action_view(first_frames, args.model, device)
    prepared_rgb = prepare_attack_frames(first_frames, args.model, device)
    prepared = model_input(prepared_rgb, args.model)
    direct_parts = direct if isinstance(direct, list) else [direct]
    prepared_parts = prepared if isinstance(prepared, list) else [prepared]
    tensor_diff = max(float((left - right).abs().max()) for left, right in zip(direct_parts, prepared_parts))
    with torch.no_grad():
        direct_out = model(direct)
        prepared_out = model(prepared)
    output_diff = float((direct_out - prepared_out).abs().max())
    g2_pass = tensor_diff <= 1e-6 and output_diff <= 1e-6
    report["G2_preprocessing"] = {"pass": g2_pass, "tensor_max_abs_diff": tensor_diff, "output_max_abs_diff": output_diff}

    feature_args = argparse.Namespace(
        seed=SEED, protocol_id=PROTOCOL_ID, num_frames=ACTION_MODEL_PROFILES[args.model].num_frames,
        num_random=0, max_global_views=None, base_views_only=False, num_local_windows=4,
        local_window_frames=None, mock_models=False, prompt_template=DEFAULT_PROMPT_TEMPLATES[0],
        prompt_templates=DEFAULT_PROMPT_TEMPLATES, max_clip_frames=8,
    )
    attack_records: list[dict[str, object]] = []
    feature_records: list[dict[str, object]] = []
    attacks = list(ATTACK_SETTINGS)
    for video_index, row in enumerate(rows):
        path = Path(row["path"])
        relative = row["relative_path"]
        source = load_frames(path)
        clean_tensor = prepare_attack_frames(source, args.model, device).detach()
        clean_rgb = clean_tensor.cpu().numpy().astype(np.float32)
        with torch.no_grad():
            clean_probs = probabilities(model, clean_tensor, args.model)[0]
        clean_pred = int(clean_probs.argmax())
        clean_features = all_features(clean_rgb, classes, feature_args, model, clip_model, clip_processor, device, str(path), clean_pred)
        feature_records.append({"relative_path": relative, "row_type": "clean", "attack": "clean", **clean_features})

        selected_attack = attacks[video_index % len(attacks)]
        for attack in attacks:
            setting = ATTACK_SETTINGS[attack]
            seed = stable_seed(relative, args.model, attack)
            first = make_attack(model, source, args.model, device, setting["internal"], setting["eps"], setting["alpha"], setting["iters"], seed)
            second = make_attack(model, source, args.model, device, setting["internal"], setting["eps"], setting["alpha"], setting["iters"], seed)
            deterministic = np.array_equal(first.rgb, second.rgb)
            valid = (
                deterministic and np.isfinite(first.rgb).all() and math.isfinite(first.linf)
                and first.linf <= setting["eps"] + 1 / 255
                and first.clean_pred == second.clean_pred and first.adv_pred == second.adv_pred
            )
            attack_records.append({
                "relative_path": relative, "attack": attack, "seed": seed, "clean_pred": first.clean_pred,
                "adv_pred": first.adv_pred, "clean_conf": first.clean_conf, "adv_conf": first.adv_conf,
                "attack_success": int(first.attack_success), "linf": first.linf,
                "selected_frame": "" if first.attacked_frame is None else first.attacked_frame,
                "deterministic": int(deterministic), "valid": int(valid),
            })
            if attack == selected_attack:
                adv_features = all_features(first.rgb, classes, feature_args, model, clip_model, clip_processor, device, str(path), clean_pred)
                feature_records.append({"relative_path": relative, "row_type": "adversarial", "attack": attack, **adv_features})
        print(f"{args.model}: gate video {video_index + 1}/{len(rows)}", flush=True)

    attack_fields = list(attack_records[0])
    with (args.output_dir / f"{args.model}_attack_gate.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=attack_fields)
        writer.writeheader(); writer.writerows(attack_records)
    feature_fields = list(feature_records[0])
    with (args.output_dir / f"{args.model}_feature_gate.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=feature_fields)
        writer.writeheader(); writer.writerows(feature_records)

    g5_pass = len(attack_records) == args.samples * len(attacks) and all(bool(row["valid"]) for row in attack_records)
    required_baselines = set(BASELINE_FIELDS) | {"msp_score", "predictive_entropy", "vlad_original", "vlad2_onehot_pred"}
    g6_pass = len(feature_records) == args.samples * 2 and all(finite_mapping(row) for row in feature_records)
    g7_pass = all(required_baselines <= set(row) for row in feature_records) and all(
        sum(record["relative_path"] == row["relative_path"] for record in feature_records) == 2 for row in rows
    )
    report["G5_attack_integrity"] = {"pass": g5_pass, "rows": len(attack_records), "expected": args.samples * len(attacks)}
    report["G6_feature_integrity"] = {"pass": g6_pass, "rows": len(feature_records), "expected": args.samples * 2}
    report["G7_baseline_parity"] = {"pass": g7_pass, "required_columns": sorted(required_baselines)}
    report["pass"] = all(bool(report[name]["pass"]) for name in ("G2_preprocessing", "G5_attack_integrity", "G6_feature_integrity", "G7_baseline_parity"))
    (args.output_dir / f"{args.model}_gate_report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True), flush=True)
    if not report["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
