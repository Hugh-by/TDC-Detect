from __future__ import annotations

import hashlib
import json
import os
import platform
import subprocess
from pathlib import Path

import numpy
import pandas
import pytorchvideo
import sklearn
import torch
import torchvision
import transformers


PROTOCOL_ID = "tdc-final-20260714"
CHECKPOINTS = {
    "csn_r101": Path("/root/.cache/torch/hub/checkpoints/CSN_32x2_R101.pyth"),
    "slowfast_r50": Path("/root/.cache/torch/hub/checkpoints/SLOWFAST_8x8_R50.pyth"),
    "x3d_m": Path("/root/.cache/torch/hub/checkpoints/X3D_M.pyth"),
    "mvit_base_16x4": Path("/root/.cache/torch/hub/checkpoints/MVIT_B_16x4.pyth"),
    "clip": Path("/root/.cache/huggingface/hub/models--openai--clip-vit-base-patch32/blobs/a63082132ba4f97a80bea76823f544493bffa8082296d62d71581a4feff1576f"),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> None:
    output = Path(os.environ["TDC_ENV_OUTPUT"])
    output.mkdir(parents=True, exist_ok=True)
    gpu = subprocess.run(
        ["nvidia-smi", "--query-gpu=index,name,memory.total,driver_version", "--format=csv,noheader"],
        check=True, capture_output=True, text=True,
    ).stdout.strip().splitlines()
    report = {
        "protocol_id": PROTOCOL_ID,
        "python": platform.python_version(),
        "platform": platform.platform(),
        "packages": {
            "torch": torch.__version__, "torchvision": torchvision.__version__,
            "pytorchvideo": getattr(pytorchvideo, "__version__", "unknown"),
            "transformers": transformers.__version__, "numpy": numpy.__version__,
            "pandas": pandas.__version__, "scikit_learn": sklearn.__version__,
        },
        "cuda": {"available": torch.cuda.is_available(), "runtime": torch.version.cuda, "devices": torch.cuda.device_count(), "gpus": gpu},
        "determinism": {
            "seed": 20260714,
            "cublas_workspace_config": ":4096:8",
            "torch_deterministic_algorithms": True,
            "cudnn_deterministic": True,
            "cudnn_benchmark": False,
        },
        "checkpoints": {
            name: {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}
            for name, path in CHECKPOINTS.items()
        },
    }
    report["pass"] = report["cuda"]["available"] and report["cuda"]["devices"] == 4 and all(item["sha256"] for item in report["checkpoints"].values())
    (output / "environment.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    subprocess.run([os.sys.executable, "-m", "pip", "freeze"], check=True, stdout=(output / "pip_freeze.txt").open("w", encoding="utf-8"))
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
