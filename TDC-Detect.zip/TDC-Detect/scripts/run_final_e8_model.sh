#!/usr/bin/env bash
set -euo pipefail
MODEL=$1
GPU=$2
P=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
CLASSES=/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
OUTPUT=${ROOT}/outputs/${P}/E8/${MODEL}_candidates.csv
TUNING=${ROOT}/outputs/${P}/E8/${MODEL}_tuning.json
FINITE=measured_linf,detector_score,R_model,R_label_change,R_conf_var,R_uniform_shift,R_fft_conf_high,R_fft_conf_entropy,R_fft_vlad_high,R_fft_vlad_entropy,R_local_conf_max,R_local_conf_top2,R_local_shift_max,R_local_shift_top2,R_vlm,vlad_original,R_sem_mean,R_sem_max,R_sem_var,R_fft_sem_high,R_fft_sem_entropy,R_local_sem_max,R_local_sem_top2
STATUS=$(python "${PROJECT}/scripts/validate_or_quarantine_final_raw.py" \
  --path "${OUTPUT}" --expected 480 --keys stage,pair_id,tradeoff_lambda,restart \
  --finite "${FINITE}" \
  --quarantine-dir "${ROOT}/final_protocols/${P}/logs/recovery/E8")
export CUDA_VISIBLE_DEVICES=${GPU} CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "${PROJECT}"
python -m TSC_Detect.run_final_e8_adaptive \
  --calibration-manifest "${ROOT}/final_protocols/${P}/manifests/k400_${MODEL}_calibration_fixed20.csv" \
  --test-manifest "${ROOT}/final_protocols/${P}/manifests/k400_${MODEL}_test_fixed100.csv" \
  --e1-calibration "${ROOT}/outputs/${P}/E1/k400_${MODEL}_calibration.csv" \
  --model "${MODEL}" --class-names "${CLASSES}" \
  --output "${OUTPUT}" \
  --tuning-json "${TUNING}" \
  --device cuda:0 --resume
