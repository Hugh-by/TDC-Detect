#!/usr/bin/env bash
set -euo pipefail

ROOT=/root/autodl-tmp
CODE=${ROOT}/inspection_reference/root/TSC/VLAD-master
MAIN=${ROOT}/tsc/outputs/repaired_ucf101_main
CALIB=${ROOT}/tsc/outputs/repaired_ucf101_calibration
OUT=${ROOT}/tsc/outputs/repaired_ucf101_eval
MAX_JOBS=${MAX_JOBS:-4}

mkdir -p "${OUT}"
cd "${CODE}"

evaluate_one() {
  local model="$1" attack="$2" setting="$3" input="$4"
  local prefix="${OUT}/${model}_${attack}_${setting}"

  python -m TSC_Detect.eval_tsc_v2_features \
    --calib-clean "${CALIB}/${model}_clean_calib.csv" \
    --inputs "${input}" \
    --name "${model}_${attack}_${setting}" \
    --output-prefix "${prefix}" \
    --n-boot 1000

  python tests/eval_group5.py \
    --input "${input}" \
    --output "${prefix}_group5.csv" \
    --folds 5 --n-boot 1000
}

for model in x3d_m mvit_base_16x4 slowfast_r50 csn_r101; do
  for attack in fgsm_v pgd_v ofa flick; do
    for setting in full success; do
      if [[ "${setting}" == full ]]; then
        input="${MAIN}/${model}_${attack}_tsc_raw.csv"
      else
        input="${MAIN}/${model}_${attack}_tsc_success.csv"
      fi
      evaluate_one "${model}" "${attack}" "${setting}" "${input}" &
      while (( $(jobs -rp | wc -l) >= MAX_JOBS )); do
        wait -n
      done
    done
  done
done
wait

python tests/build_repaired_summary.py --root "${OUT}" --dataset ucf101
