#!/usr/bin/env bash
set -euo pipefail

MODEL="${1:?model required}"
GPU="${2:?gpu required}"
ROOT=/root/autodl-tmp
CODE=${ROOT}/inspection_reference/root/TSC/VLAD-master
OUT=${ROOT}/tsc/outputs/repaired_k400_main
MANIFEST=${ROOT}/tsc/outputs/repaired_clean_correct/${MODEL}_correct_split.csv
CLASSES=${ROOT}/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
FGSM_OUT=${OUT}/${MODEL}_fgsm_v_tsc_raw.csv

cd "${CODE}"
export CUDA_VISIBLE_DEVICES="${GPU}"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

# The repaired FGSM jobs were started before this queue. Do not contend for
# the same GPU; continue automatically when that model's FGSM process exits.
while pgrep -f "TSC_Detect.run_tsc_attack_probe.*${FGSM_OUT}" >/dev/null; do
  sleep 30
done

run_attack() {
  local tag="$1"
  local attack="$2"
  local iters="$3"
  python -m TSC_Detect.run_tsc_attack_probe \
    --manifest "${MANIFEST}" \
    --manifest-splits test \
    --class-names "${CLASSES}" \
    --device cuda \
    --action-model "${MODEL}" \
    --num-frames 32 \
    --num-random 0 \
    --max-clip-frames 8 \
    --num-local-windows 4 \
    --score-mode max_evidence \
    --prompt-templates \
      "a video of a person {}" \
      "a video of {}" \
      "an action of {}" \
    --attack "${attack}" \
    --attack-split-name "${tag}" \
    --eps 0.03 \
    --iters "${iters}" \
    --alpha 0.00784313725490196 \
    --resume \
    --output-csv "${OUT}/${MODEL}_${tag}_tsc_raw.csv"
}

run_attack pgd_v pgd 40
run_attack ofa ofa 10
run_attack flick flick 10
