from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from eval_final_e1_e5 import PROTOCOL, TDC_V2, fit_model, metric_row, threshold_at_clean_fpr


MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
E8_MODELS = ("csn_r101", "mvit_base_16x4")
DATASETS = ("k400", "ucf101")
ATTACKS = ("fgsm", "pgd", "ofa-style", "flicker-style")


def require_protocol(frame: pd.DataFrame, source: Path) -> None:
    if len(frame) == 0 or set(frame.protocol_id) != {PROTOCOL}:
        raise ValueError(f"Protocol/empty input error: {source}")


def choose_restart(group: pd.DataFrame) -> pd.Series:
    successful = group[group.attack_success == 1]
    pool = successful if len(successful) else group
    return pool.sort_values(["detector_score", "restart"], ascending=[True, True]).iloc[0]


def evaluate_e8(e1_root: Path, e8_root: Path, output_root: Path) -> None:
    metric_rows: list[dict[str, object]] = []
    selected_rows: list[pd.Series] = []
    tuning_rows: list[dict[str, object]] = []
    for model in E8_MODELS:
        calibration_path = e1_root / f"k400_{model}_calibration.csv"
        test_path = e1_root / f"k400_{model}_test.csv"
        calibration = pd.read_csv(calibration_path); test_e1 = pd.read_csv(test_path)
        require_protocol(calibration, calibration_path); require_protocol(test_e1, test_path)
        classifier = fit_model(calibration, TDC_V2)
        cal_scores = classifier.predict_proba(calibration[TDC_V2].to_numpy(float))[:, 1]
        threshold = threshold_at_clean_fpr(calibration.is_adv.to_numpy(int), cal_scores)

        candidate_path = e8_root / f"{model}_candidates.csv"
        candidates = pd.read_csv(candidate_path); require_protocol(candidates, candidate_path)
        if len(candidates) != 480:
            raise ValueError(f"E8 {model}: expected 480 candidate rows, got {len(candidates)}")
        if candidates.duplicated(["stage", "pair_id", "tradeoff_lambda", "restart"]).any():
            raise ValueError(f"E8 {model}: duplicate candidates")
        if set(candidates.steps) != {40} or set(candidates.eot_views) != {8} or set(candidates.bpda_semantic) != {1}:
            raise ValueError(f"E8 {model}: adaptive definition mismatch")
        if not np.array_equal(candidates.attack_success.to_numpy(int), (candidates.clean_pred.to_numpy(int) != candidates.attacked_pred.to_numpy(int)).astype(int)):
            raise ValueError(f"E8 {model}: attack-success metadata mismatch")
        if not np.isfinite(candidates[["measured_linf", "detector_score", *TDC_V2]].to_numpy(float)).all():
            raise ValueError(f"E8 {model}: non-finite candidates")
        if (candidates.measured_linf > 8 / 255 + 1 / 255 + 1e-8).any():
            raise ValueError(f"E8 {model}: perturbation budget violation")

        tuning_record = json.loads((e8_root / f"{model}_tuning.json").read_text(encoding="utf-8"))
        chosen_lambda = float(tuning_record["chosen_lambda"])
        if tuning_record["selection_partition"] != "calibration" or tuning_record["calibration_videos"] != 20:
            raise ValueError(f"E8 {model}: tuning was not calibration-only fixed20")
        if abs(float(tuning_record["deployment_threshold"]) - threshold) > 1e-12:
            raise ValueError(f"E8 {model}: threshold mismatch")
        for row in tuning_record["tuning_summary"]:
            tuning_rows.append({"protocol_id": PROTOCOL, "experiment": "E8", "model": model, **row, "chosen": int(np.isclose(float(row["tradeoff_lambda"]), chosen_lambda))})

        test = candidates[candidates.stage == "test"]
        if len(test) != 300 or not np.allclose(test.tradeoff_lambda, chosen_lambda):
            raise ValueError(f"E8 {model}: invalid fixed-lambda test candidates")
        selected = pd.DataFrame([choose_restart(group) for _, group in test.groupby("pair_id", sort=True)])
        if len(selected) != 100:
            raise ValueError(f"E8 {model}: expected 100 selected test attacks")
        selected_rows.extend(row for _, row in selected.iterrows())

        pair_ids = set(selected.pair_id)
        clean = test_e1[(test_e1.attack == "clean") & test_e1.pair_id.isin(pair_ids)].copy()
        if len(clean) != 100 or set(clean.pair_id) != pair_ids:
            raise ValueError(f"E8 {model}: E1 clean/test alignment mismatch")
        clean["detector_score"] = classifier.predict_proba(clean[TDC_V2].to_numpy(float))[:, 1]
        success_rate = float(selected.attack_success.mean())
        joint_rate = float(((selected.attack_success == 1) & (selected.detector_score <= threshold)).mean())
        success = selected[selected.attack_success == 1]
        evasion_given_success = float((success.detector_score <= threshold).mean()) if len(success) else 0.0
        for setting in ("full", "success-only"):
            adv = selected if setting == "full" else success
            if not len(adv):
                raise ValueError(f"E8 {model}: success-only has no successful attacks")
            clean_condition = clean if setting == "full" else clean[clean.pair_id.isin(set(adv.pair_id))]
            labels = np.concatenate((np.zeros(len(clean_condition), dtype=int), np.ones(len(adv), dtype=int)))
            scores = np.concatenate((clean_condition.detector_score.to_numpy(float), adv.detector_score.to_numpy(float)))
            metric_rows.append({
                "protocol_id": PROTOCOL, "experiment": "E8", "dataset": "k400", "model": model,
                "attack": "adaptive-eot-bpda-pgd", "setting": setting, "method": "TDC-v2",
                "chosen_lambda": chosen_lambda, "attack_success_rate": success_rate,
                "joint_success_evasion_rate": joint_rate, "evasion_given_success": evasion_given_success,
                "mean_linf": float(selected.measured_linf.mean()), **metric_row(labels, scores, threshold),
            })
    pd.DataFrame(metric_rows).to_csv(output_root / "E8_adaptive_metrics.csv", index=False)
    pd.DataFrame(selected_rows).to_csv(output_root / "E8_selected_candidates.csv", index=False)
    pd.DataFrame(tuning_rows).to_csv(output_root / "E8_lambda_tuning.csv", index=False)


def evaluate_e9(e9_root: Path, output_root: Path) -> None:
    rows: list[dict[str, object]] = []
    methods = {"action_only", "strict_vlad", "temporal_shuffle", "tdc_v2"}
    for dataset in DATASETS:
        for model in MODELS:
            path = e9_root / f"{dataset}_{model}.csv"
            frame = pd.read_csv(path); require_protocol(frame, path)
            if len(frame) != 2000 or set(frame.method) != methods:
                raise ValueError(f"E9 {dataset}/{model}: row/method mismatch")
            counts = frame.groupby(["method", "repeat"]).size()
            if set(counts) != {100} or set(frame.repeat) != set(range(5)):
                raise ValueError(f"E9 {dataset}/{model}: repeat/video count mismatch")
            if frame.duplicated(["method", "repeat", "relative_path"]).any():
                raise ValueError(f"E9 {dataset}/{model}: duplicate timing rows")
            if not np.isfinite(frame[["seconds", "peak_memory_bytes"]].to_numpy(float)).all() or (frame.seconds <= 0).any():
                raise ValueError(f"E9 {dataset}/{model}: invalid timing/memory")
            means = frame.groupby("method").seconds.mean().to_dict()
            baseline = float(means["action_only"])
            for method, group in frame.groupby("method", sort=True):
                seconds = group.seconds.to_numpy(float)
                rows.append({
                    "protocol_id": PROTOCOL, "experiment": "E9", "dataset": dataset, "model": model,
                    "method": method, "videos": int(group.relative_path.nunique()), "repeats": int(group.repeat.nunique()),
                    "mean_seconds_per_video": float(seconds.mean()), "std_seconds_per_video": float(seconds.std(ddof=1)),
                    "median_seconds_per_video": float(np.median(seconds)), "p95_seconds_per_video": float(np.quantile(seconds, .95)),
                    "peak_memory_bytes": int(group.peak_memory_bytes.max()),
                    "peak_memory_gib": float(group.peak_memory_bytes.max() / 2**30),
                    "relative_overhead_vs_action": float(seconds.mean() / baseline),
                    "relative_overhead_vs_strict_vlad": float(seconds.mean() / means["strict_vlad"]),
                    "relative_overhead_vs_temporal_shuffle": float(seconds.mean() / means["temporal_shuffle"]),
                })
    pd.DataFrame(rows).to_csv(output_root / "E9_runtime_memory.csv", index=False)


def evaluate_e10(e1_root: Path, e10_root: Path, output_root: Path) -> None:
    integrity_rows: list[dict[str, object]] = []
    perceptual_rows: list[dict[str, object]] = []
    for dataset in DATASETS:
        for model in MODELS:
            parts = []
            for partition in ("calibration", "test"):
                path = e1_root / f"{dataset}_{model}_{partition}.csv"
                frame = pd.read_csv(path); require_protocol(frame, path); parts.append(frame)
            main = pd.concat(parts, ignore_index=True)
            adv = main[main.attack != "clean"]
            if not np.isfinite(adv.measured_linf.to_numpy(float)).all():
                raise ValueError(f"E10 derived {dataset}/{model}: non-finite L-inf")
            for attack in ATTACKS:
                group = adv[adv.attack == attack]
                if not len(group):
                    raise ValueError(f"E10 derived {dataset}/{model}/{attack}: empty")
                linf = group.measured_linf.to_numpy(float)
                integrity_rows.append({
                    "protocol_id": PROTOCOL, "experiment": "E10", "dataset": dataset, "model": model,
                    "attack": attack, "rows": len(group), "attack_success_rate": float(group.attack_success.mean()),
                    "mean_linf": float(linf.mean()), "p95_linf": float(np.quantile(linf, .95)), "max_linf": float(linf.max()),
                    "budget_violations": int(np.sum(linf > 8 / 255 + 1 / 255 + 1e-8)),
                })
    for model in MODELS:
        path = e10_root / f"{model}.csv"
        frame = pd.read_csv(path); require_protocol(frame, path)
        if len(frame) != 800 or frame.duplicated(["pair_id", "attack"]).any():
            raise ValueError(f"E10 {model}: expected 800 unique rows")
        if set(frame.attack) != set(ATTACKS) or set(frame.groupby("attack").size()) != {200}:
            raise ValueError(f"E10 {model}: attack/count mismatch")
        if not np.array_equal(frame.attack_success.to_numpy(int), (frame.clean_pred.to_numpy(int) != frame.attacked_pred.to_numpy(int)).astype(int)):
            raise ValueError(f"E10 {model}: attack-success metadata mismatch")
        numeric = frame[["measured_linf", "psnr", "mean_ssim", "min_ssim"]].to_numpy(float)
        if not np.isfinite(numeric).all():
            raise ValueError(f"E10 {model}: non-finite perceptual output")
        for attack, group in frame.groupby("attack", sort=True):
            perceptual_rows.append({
                "protocol_id": PROTOCOL, "experiment": "E10", "dataset": "k400", "model": model,
                "attack": attack, "videos": len(group), "attack_success_rate": float(group.attack_success.mean()),
                "mean_linf": float(group.measured_linf.mean()), "max_linf": float(group.measured_linf.max()),
                "mean_psnr": float(group.psnr.mean()), "std_psnr": float(group.psnr.std(ddof=1)),
                "min_psnr": float(group.psnr.min()), "mean_ssim": float(group.mean_ssim.mean()),
                "std_ssim": float(group.mean_ssim.std(ddof=1)), "minimum_frame_ssim": float(group.min_ssim.min()),
            })
    integrity = pd.DataFrame(integrity_rows)
    if len(integrity) != 32 or integrity.budget_violations.sum() != 0:
        raise ValueError("E10 main-row integrity summary failed")
    integrity.to_csv(output_root / "E10_main_attack_integrity.csv", index=False)
    pd.DataFrame(perceptual_rows).to_csv(output_root / "E10_perceptual_quality.csv", index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--e1-root", type=Path, required=True)
    parser.add_argument("--e8-root", type=Path)
    parser.add_argument("--e9-root", type=Path)
    parser.add_argument("--e10-root", type=Path)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args(); args.output_root.mkdir(parents=True, exist_ok=True)
    if args.e8_root: evaluate_e8(args.e1_root, args.e8_root, args.output_root)
    if args.e9_root: evaluate_e9(args.e9_root, args.output_root)
    if args.e10_root: evaluate_e10(args.e1_root, args.e10_root, args.output_root)


if __name__ == "__main__":
    main()
