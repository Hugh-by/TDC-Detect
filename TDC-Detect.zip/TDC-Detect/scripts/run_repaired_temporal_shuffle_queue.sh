#!/usr/bin/env bash
set -euo pipefail

MODEL="${1:?model required}"
GPU="${2:?gpu required}"
ROOT=/root/autodl-tmp
CODE=${ROOT}/inspection_reference/root/TSC/VLAD-master
CLASSES=${ROOT}/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
OUT=${ROOT}/tsc/outputs/repaired_temporal_shuffle_main

cd "${CODE}"
export CUDA_VISIBLE_DEVICES="${GPU}"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1
mkdir -p "${OUT}"

run_attack() {
  local dataset="$1" manifest="$2" tag="$3" attack="$4" iters="$5"
  python -m TSC_Detect.run_temporal_shuffle_probe \
    --manifest "${manifest}" --manifest-splits test \
    --class-names "${CLASSES}" --device cuda --action-model "${MODEL}" \
    --attack "${attack}" --attack-split-name "${tag}" \
    --eps 0.03 --iters "${iters}" --alpha 0.00784313725490196 \
    --resume --output-csv "${OUT}/${dataset}_${MODEL}_${tag}_ts_raw.csv"
}

seed_clean() {
  local source="$1" target="$2"
  python -m TSC_Detect.seed_temporal_clean_rows --source "${source}" --output "${target}"
}

K400=${ROOT}/tsc/outputs/repaired_clean_correct/${MODEL}_correct_split.csv
UCF101=${ROOT}/tsc/data/manifests/ucf101_repaired_c20_t10.csv

for dataset_manifest in "k400:${K400}" "ucf101:${UCF101}"; do
  dataset="${dataset_manifest%%:*}"
  manifest="${dataset_manifest#*:}"
  run_attack "${dataset}" "${manifest}" fgsm_v fgsm 1
  fgsm_file="${OUT}/${dataset}_${MODEL}_fgsm_v_ts_raw.csv"
  seed_clean "${fgsm_file}" "${OUT}/${dataset}_${MODEL}_pgd_v_ts_raw.csv"
  run_attack "${dataset}" "${manifest}" pgd_v pgd 40
  seed_clean "${fgsm_file}" "${OUT}/${dataset}_${MODEL}_ofa_ts_raw.csv"
  run_attack "${dataset}" "${manifest}" ofa ofa 10
  seed_clean "${fgsm_file}" "${OUT}/${dataset}_${MODEL}_flick_ts_raw.csv"
  run_attack "${dataset}" "${manifest}" flick flick 10
done
