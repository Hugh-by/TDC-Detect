#!/usr/bin/env bash
set -euo pipefail

ROOT=/root/autodl-tmp
TSC=${ROOT}/inspection_reference/root/TSC
OUT=${ROOT}/tsc/outputs/repaired_runtime
LOG=${OUT}/logs
mkdir -p "${OUT}" "${LOG}"

models=(x3d_m mvit_base_16x4 slowfast_r50 csn_r101)
for model in "${models[@]}"; do
  CUDA_VISIBLE_DEVICES=0 \
    HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
    python "${TSC}/paper_workspace/scripts/measure_repaired_runtime.py" \
      --model "${model}" --n-videos 100 --warmup-videos 3 \
      --output "${OUT}/${model}_runtime.csv" \
      >"${LOG}/${model}.log" 2>&1
done

python "${TSC}/paper_workspace/scripts/build_repaired_runtime_tables.py"
