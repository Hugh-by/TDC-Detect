from __future__ import annotations

import argparse
import json
from pathlib import Path


MODELS = ("csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4")
PROTOCOL_ID = "tdc-final-20260714"


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    model_reports = {model: load(args.protocol_root / "gates/model" / f"{model}_gate_report.json") for model in MODELS}
    environment = load(args.protocol_root / "environment/environment.json")
    manifests = load(args.protocol_root / "manifests/manifest_summary.json")
    resume = load(args.protocol_root / "gates/resume_gate_report.json")
    sampling = load(args.protocol_root / "gates/sampling_gate_report.json")
    output_entries = list(args.output_root.iterdir()) if args.output_root.exists() else []
    split_pass = (
        manifests["missing_files"] == 0
        and not manifests["cross_model_calibration_test_overlaps"]
        and not manifests["ucf101"]["group_overlap"]
        and all(
            data["splits"][split]["selected"] <= 2000
            for data in manifests["models"].values() for split in ("calibration", "test")
        )
    )
    gates = {
        "G1": {"pass": bool(environment["pass"]), "evidence": "environment/environment.json"},
        "G2": {"pass": all(report["G2_preprocessing"]["pass"] for report in model_reports.values()), "evidence": "gates/model/*_gate_report.json"},
        "G3": {"pass": bool(sampling["pass"]), "evidence": "gates/sampling_gate_report.json"},
        "G4": {"pass": split_pass, "evidence": "manifests/manifest_summary.json"},
        "G5": {"pass": all(report["G5_attack_integrity"]["pass"] for report in model_reports.values()), "evidence": "gates/model/*_attack_gate.csv"},
        "G6": {"pass": all(report["G6_feature_integrity"]["pass"] for report in model_reports.values()), "evidence": "gates/model/*_feature_gate.csv"},
        "G7": {"pass": all(report["G7_baseline_parity"]["pass"] for report in model_reports.values()), "evidence": "gates/model/*_feature_gate.csv"},
        "G8": {"pass": bool(resume["pass"]), "evidence": "gates/resume_gate_report.json"},
        "G9": {"pass": args.output_root.name == PROTOCOL_ID and not output_entries, "evidence": str(args.output_root)},
    }
    report = {
        "protocol_id": PROTOCOL_ID,
        "status": "PASS" if all(value["pass"] for value in gates.values()) else "FAIL",
        "gates": gates,
        "formal_output_entries_at_gate_time": [entry.name for entry in output_entries],
    }
    path = args.protocol_root / "gates/gate_report.json"
    path.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if report["status"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
