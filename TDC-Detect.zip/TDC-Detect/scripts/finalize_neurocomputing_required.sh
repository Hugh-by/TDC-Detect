#!/usr/bin/env bash
set -euo pipefail

ROOT=/root/autodl-tmp
TSC=${ROOT}/inspection_reference/root/TSC
CODE=${TSC}/VLAD-master
TS_MAIN=${ROOT}/tsc/outputs/repaired_temporal_shuffle_main
TS_EVAL=${ROOT}/tsc/outputs/repaired_temporal_shuffle_eval
SENS=${ROOT}/tsc/outputs/repaired_sensitivity
mkdir -p "${TS_EVAL}" "${SENS}"

models=(x3d_m mvit_base_16x4 slowfast_r50 csn_r101)
attacks=(fgsm_v pgd_v ofa flick)

expected_k400() {
  case "$1" in
    x3d_m) echo 5010 ;;
    mvit_base_16x4) echo 5244 ;;
    slowfast_r50) echo 4990 ;;
    csn_r101) echo 4932 ;;
  esac
}

while true; do
  complete=0
  total=32
  for model in "${models[@]}"; do
    k400_target=$(expected_k400 "${model}")
    for attack in "${attacks[@]}"; do
      for spec in "k400:${k400_target}" "ucf101:2020"; do
        dataset=${spec%%:*}
        target=${spec#*:}
        path="${TS_MAIN}/${dataset}_${model}_${attack}_ts_raw.csv"
        rows=0
        [[ -f "${path}" ]] && rows=$(awk 'END{print NR-1}' "${path}")
        [[ "${rows}" -eq "${target}" ]] && complete=$((complete + 1))
        if [[ "${rows}" -gt "${target}" ]]; then
          echo "ERROR rows exceed target: ${path} ${rows}/${target}"
          exit 1
        fi
      done
    done
  done
  echo "$(date -Is) Temporal Shuffle complete files: ${complete}/${total}"
  [[ "${complete}" -eq "${total}" ]] && break
  if ! pgrep -f 'run_repaired_temporal_shuffle_queue|run_temporal_shuffle_probe' >/dev/null; then
    echo "ERROR Temporal Shuffle queues stopped before completion"
    exit 1
  fi
  sleep 60
done

cd "${CODE}"
for dataset in k400 ucf101; do
  for model in "${models[@]}"; do
    for attack in "${attacks[@]}"; do
      python tests/eval_temporal_shuffle_group5.py \
        --input "${TS_MAIN}/${dataset}_${model}_${attack}_ts_raw.csv" \
        --output-prefix "${TS_EVAL}/${dataset}_${model}_${attack}" \
        --folds 5 --n-boot 1000
    done
  done
done

cd "${TSC}"
python paper_workspace/scripts/build_repaired_temporal_shuffle_summary.py
python paper_workspace/scripts/eval_repaired_paired_baselines.py

for model in "${models[@]}"; do
  CUDA_VISIBLE_DEVICES=0 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 \
    python paper_workspace/scripts/run_repaired_sensitivity_probe.py \
      --model "${model}" --max-videos 25 --output-dir "${SENS}" \
      >"${SENS}/${model}.log" 2>&1
done
python paper_workspace/scripts/eval_repaired_sensitivity.py

echo "$(date -Is) ALL REQUIRED NEUROCOMPUTING EXPERIMENTS COMPLETE"
