#!/usr/bin/env bash
set -euo pipefail

MODEL=${1:?model required}
GPU=${2:?gpu required}
PLAN=${3:?plan file required}
P=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc
PROTOCOL_ROOT=${ROOT}/final_protocols/${P}
OUTPUT_ROOT=${ROOT}/outputs/${P}/E1
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
CLASSES=/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
export CUDA_VISIBLE_DEVICES=${GPU} CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "${PROJECT}"

while read -r DATASET PARTITION; do
  [ -n "${DATASET}" ] || continue
  if [ "${DATASET}" = k400 ]; then
    MANIFEST=${PROTOCOL_ROOT}/manifests/k400_${MODEL}_${PARTITION}_selected.csv
  else
    MANIFEST=${PROTOCOL_ROOT}/manifests/ucf101_group_disjoint.csv
  fi
  python -m TSC_Detect.run_final_extract \
    --manifest "${MANIFEST}" --dataset "${DATASET}" --partition "${PARTITION}" \
    --action-model "${MODEL}" --class-names "${CLASSES}" \
    --output-csv "${OUTPUT_ROOT}/${DATASET}_${MODEL}_${PARTITION}.csv" \
    --device cuda:0 --resume
done < "${PLAN}"
