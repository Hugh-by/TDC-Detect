from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler


PROTOCOL = "tdc-final-20260714"
SEED = 20260714
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
DATASETS = ("k400", "ucf101")
ATTACKS = ("fgsm", "pgd", "ofa-style", "flicker-style")

TDC_V1 = ["vlad_original", "R_sem_var", "R_uniform_shift", "R_model", "R_conf_var", "R_label_change"]
ACTION_FEATURES = [
    "R_model", "R_label_change", "R_conf_var", "R_uniform_shift",
    "R_fft_conf_high", "R_fft_conf_entropy", "R_fft_vlad_high", "R_fft_vlad_entropy",
    "R_local_conf_max", "R_local_conf_top2", "R_local_shift_max", "R_local_shift_top2",
]
VLM_FEATURES = ["R_vlm"]
SEMANTIC_FEATURES = [
    "vlad_original", "R_sem_mean", "R_sem_max", "R_sem_var",
    "R_fft_sem_high", "R_fft_sem_entropy", "R_local_sem_max", "R_local_sem_top2",
]
FREQUENCY_FEATURES = [name for name in ACTION_FEATURES + SEMANTIC_FEATURES if name.startswith("R_fft_")]
LOCAL_FEATURES = [name for name in ACTION_FEATURES + SEMANTIC_FEATURES if name.startswith("R_local_")]
TDC_V2 = list(dict.fromkeys(ACTION_FEATURES + VLM_FEATURES + SEMANTIC_FEATURES))
TS_FEATURES = [
    "ts_prob_shift_mean", "ts_prob_shift_max", "ts_label_change",
    "ts_conf_drop", "ts_conf_var", "ts_vote_entropy",
]

LEARNED_METHODS = {
    "Temporal Shuffle-LR": TS_FEATURES,
    "TDC-v1": TDC_V1,
    "TDC-v2": TDC_V2,
}
FIXED_METHODS = {
    "MSP": "msp_score",
    "Predictive entropy": "predictive_entropy",
    "Strict VLAD-1": "strict_vlad1",
    "VLAD-2": "strict_vlad2",
    "Prompt-matched VLAD": "prompt_matched_vlad",
    "Temporal Shuffle-KL": "ts_prob_shift_mean",
}
ABLATIONS = {
    "TDC-v1": TDC_V1,
    "TDC-v2": TDC_V2,
    "TDC-v2 without local": [name for name in TDC_V2 if name not in LOCAL_FEATURES],
    "TDC-v2 without semantic": [name for name in TDC_V2 if name not in SEMANTIC_FEATURES],
    "TDC-v2 without frequency-order": [name for name in TDC_V2 if name not in FREQUENCY_FEATURES],
    "TDC-v2 without action": [name for name in TDC_V2 if name not in ACTION_FEATURES],
    "TDC-v2 without VLM": [name for name in TDC_V2 if name not in VLM_FEATURES],
}


def read_frame(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if not len(frame):
        raise ValueError(f"Empty input: {path}")
    if set(frame["protocol_id"]) != {PROTOCOL}:
        raise ValueError(f"Protocol mismatch: {path}")
    if frame.duplicated(["pair_id", "attack"]).any():
        raise ValueError(f"Duplicate pair/attack rows: {path}")
    return frame


def one_clean(frame: pd.DataFrame) -> pd.DataFrame:
    clean = frame[frame.attack == "clean"]
    if clean.duplicated("pair_id").any():
        raise ValueError("Clean rows are duplicated")
    return clean


def condition(frame: pd.DataFrame, attack: str, setting: str) -> pd.DataFrame:
    clean = one_clean(frame)
    adv = frame[frame.attack != "clean"] if attack == "pooled" else frame[frame.attack == attack]
    if setting == "success-only":
        adv = adv[adv.attack_success == 1]
        ids = set(adv.pair_id)
        clean = clean[clean.pair_id.isin(ids)]
    return pd.concat([clean, adv], ignore_index=True)


def fit_model(train: pd.DataFrame, features: list[str]) -> Pipeline:
    if train.is_adv.nunique() != 2:
        raise ValueError("Training data must contain both classes")
    return Pipeline([
        ("scaler", StandardScaler()),
        ("logistic", LogisticRegression(C=1.0, l1_ratio=0, class_weight="balanced", max_iter=5000, random_state=SEED)),
    ]).fit(train[features].to_numpy(float), train.is_adv.to_numpy(int))


def score_methods(train: pd.DataFrame, test: pd.DataFrame, learned: dict[str, list[str]] = LEARNED_METHODS, include_fixed: bool = True) -> tuple[dict[str, np.ndarray], dict[str, np.ndarray]]:
    calibration: dict[str, np.ndarray] = {}
    testing: dict[str, np.ndarray] = {}
    if include_fixed:
        for method, column in FIXED_METHODS.items():
            calibration[method] = train[column].to_numpy(float)
            testing[method] = test[column].to_numpy(float)
    for method, features in learned.items():
        model = fit_model(train, features)
        calibration[method] = model.predict_proba(train[features].to_numpy(float))[:, 1]
        testing[method] = model.predict_proba(test[features].to_numpy(float))[:, 1]
    return calibration, testing


def threshold_at_clean_fpr(labels: np.ndarray, scores: np.ndarray, target: float = 0.01) -> float:
    clean = scores[labels == 0]
    if not len(clean):
        raise ValueError("No clean calibration scores")
    return float(np.quantile(clean, 1.0 - target, method="higher"))


def metric_row(labels: np.ndarray, scores: np.ndarray, threshold: float) -> dict[str, float]:
    if len(np.unique(labels)) != 2:
        raise ValueError("Metrics require both classes")
    fpr, tpr, _ = roc_curve(labels, scores)
    fpr95 = float(fpr[np.flatnonzero(tpr >= 0.95)[0]])
    tpr1 = float(np.max(tpr[fpr <= 0.01])) if np.any(fpr <= 0.01) else 0.0
    predicted = scores > threshold
    clean = labels == 0
    adv = labels == 1
    return {
        "roc_auc": float(roc_auc_score(labels, scores)),
        "pr_auc": float(average_precision_score(labels, scores)),
        "fpr_at_95_tpr": fpr95,
        "tpr_at_1_fpr": tpr1,
        "deployment_threshold": threshold,
        "threshold_tpr": float(np.mean(predicted[adv])),
        "threshold_fpr": float(np.mean(predicted[clean])),
        "n_clean": int(clean.sum()),
        "n_adv": int(adv.sum()),
    }


def evaluate_condition(train: pd.DataFrame, test: pd.DataFrame, learned: dict[str, list[str]] = LEARNED_METHODS) -> tuple[list[dict[str, object]], dict[str, np.ndarray]]:
    cal_scores, test_scores = score_methods(train, test, learned)
    y_cal = train.is_adv.to_numpy(int)
    y_test = test.is_adv.to_numpy(int)
    rows = []
    for method, scores in test_scores.items():
        threshold = threshold_at_clean_fpr(y_cal, cal_scores[method])
        rows.append({"method": method, **metric_row(y_test, scores, threshold)})
    return rows, test_scores


def bootstrap_strongest(test: pd.DataFrame, scores: dict[str, np.ndarray], n_boot: int = 1000) -> tuple[dict[str, object], list[dict[str, object]]]:
    y = test.is_adv.to_numpy(int)
    auc = {name: roc_auc_score(y, value) for name, value in scores.items()}
    candidates = [name for name in scores if name not in {"TDC-v1", "TDC-v2"}]
    strongest = max(candidates, key=lambda name: auc[name])
    groups = [indices.to_numpy(int) for _, indices in test.groupby("pair_id", sort=True).groups.items()]
    rng = np.random.default_rng(SEED)
    replicates: list[dict[str, object]] = []
    while len(replicates) < n_boot:
        chosen = rng.integers(0, len(groups), len(groups))
        indices = np.concatenate([groups[index] for index in chosen])
        labels = y[indices]
        if len(np.unique(labels)) != 2:
            continue
        names = {"TDC-v2", strongest, "VLAD-2", "Temporal Shuffle-LR"}
        replicate_auc = {name: roc_auc_score(labels, scores[name][indices]) for name in names}
        tdc_auc = replicate_auc["TDC-v2"]
        baseline_auc = replicate_auc[strongest]
        replicates.append({
            "replicate": len(replicates), "tdc_v2_auc": float(tdc_auc),
            "baseline_auc": float(baseline_auc), "difference": float(tdc_auc - baseline_auc),
            "vlad2_auc": float(replicate_auc["VLAD-2"]),
            "difference_vs_vlad2": float(tdc_auc - replicate_auc["VLAD-2"]),
            "temporal_shuffle_lr_auc": float(replicate_auc["Temporal Shuffle-LR"]),
            "difference_vs_temporal_shuffle_lr": float(tdc_auc - replicate_auc["Temporal Shuffle-LR"]),
        })
    values = np.asarray([row["difference"] for row in replicates])
    tdc_values = np.asarray([row["tdc_v2_auc"] for row in replicates])
    baseline_values = np.asarray([row["baseline_auc"] for row in replicates])
    vlad2_differences = np.asarray([row["difference_vs_vlad2"] for row in replicates])
    shuffle_differences = np.asarray([row["difference_vs_temporal_shuffle_lr"] for row in replicates])
    summary = {
        "baseline": strongest,
        "tdc_v2_auc": float(auc["TDC-v2"]),
        "tdc_v2_ci_low": float(np.quantile(tdc_values, 0.025)),
        "tdc_v2_ci_high": float(np.quantile(tdc_values, 0.975)),
        "baseline_auc": float(auc[strongest]),
        "baseline_ci_low": float(np.quantile(baseline_values, 0.025)),
        "baseline_ci_high": float(np.quantile(baseline_values, 0.975)),
        "difference": float(auc["TDC-v2"] - auc[strongest]),
        "ci_low": float(np.quantile(values, 0.025)),
        "ci_high": float(np.quantile(values, 0.975)),
        "p_two_sided": float(min(1.0, 2 * min(np.mean(values <= 0), np.mean(values >= 0)))),
        "vlad2_auc": float(auc["VLAD-2"]),
        "difference_vs_vlad2": float(auc["TDC-v2"] - auc["VLAD-2"]),
        "vlad2_difference_ci_low": float(np.quantile(vlad2_differences, 0.025)),
        "vlad2_difference_ci_high": float(np.quantile(vlad2_differences, 0.975)),
        "vlad2_p_two_sided": float(min(1.0, 2 * min(np.mean(vlad2_differences <= 0), np.mean(vlad2_differences >= 0)))),
        "temporal_shuffle_lr_auc": float(auc["Temporal Shuffle-LR"]),
        "difference_vs_temporal_shuffle_lr": float(auc["TDC-v2"] - auc["Temporal Shuffle-LR"]),
        "temporal_shuffle_lr_difference_ci_low": float(np.quantile(shuffle_differences, 0.025)),
        "temporal_shuffle_lr_difference_ci_high": float(np.quantile(shuffle_differences, 0.975)),
        "temporal_shuffle_lr_p_two_sided": float(min(1.0, 2 * min(np.mean(shuffle_differences <= 0), np.mean(shuffle_differences >= 0)))),
        "valid_replicates": len(replicates),
    }
    return summary, replicates


def write_rows(path: Path, rows: list[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=1000)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)

    data: dict[tuple[str, str, str], pd.DataFrame] = {}
    for dataset in DATASETS:
        for model in MODELS:
            for partition in ("calibration", "test"):
                data[dataset, model, partition] = read_frame(args.input_root / f"{dataset}_{model}_{partition}.csv")

    e1_rows: list[dict[str, object]] = []
    bootstrap_summary: list[dict[str, object]] = []
    bootstrap_rows: list[dict[str, object]] = []
    for dataset in DATASETS:
        for model in MODELS:
            calibration = data[dataset, model, "calibration"]
            test_all = data[dataset, model, "test"]
            success_rate = test_all[test_all.attack != "clean"].groupby("attack").attack_success.mean().to_dict()
            for attack in (*ATTACKS, "pooled"):
                for setting in ("full", "success-only"):
                    test = condition(test_all, attack, setting)
                    metrics, scores = evaluate_condition(calibration, test)
                    prefix = {"protocol_id": PROTOCOL, "experiment": "E1", "dataset": dataset, "model": model, "attack": attack, "setting": setting}
                    for row in metrics:
                        e1_rows.append({**prefix, **row, "attack_success_rate": float(np.mean(list(success_rate.values()))) if attack == "pooled" else float(success_rate[attack])})
                    summary, replicates = bootstrap_strongest(test, scores, args.bootstrap)
                    bootstrap_summary.append({**prefix, **summary})
                    bootstrap_rows.extend({**prefix, "baseline": summary["baseline"], **row} for row in replicates)
    write_rows(args.output_root / "E1_metrics.csv", e1_rows)
    write_rows(args.output_root / "E1_paired_bootstrap_summary.csv", bootstrap_summary)
    write_rows(args.output_root / "E1_paired_bootstrap_replicates.csv", bootstrap_rows)

    e2_rows: list[dict[str, object]] = []
    for dataset in DATASETS:
        for model in MODELS:
            cal_all = data[dataset, model, "calibration"]
            test_all = data[dataset, model, "test"]
            for held in ATTACKS:
                train = pd.concat([one_clean(cal_all), cal_all[(cal_all.attack != "clean") & (cal_all.attack != held)]], ignore_index=True)
                for setting in ("full", "success-only"):
                    test = condition(test_all, held, setting)
                    metrics, _ = evaluate_condition(train, test, LEARNED_METHODS)
                    e2_rows.extend({"protocol_id": PROTOCOL, "experiment": "E2", "dataset": dataset, "model": model, "held_attack": held, "setting": setting, **row} for row in metrics)
    write_rows(args.output_root / "E2_leave_one_attack_out.csv", e2_rows)

    e3_rows: list[dict[str, object]] = []
    for dataset in DATASETS:
        for held_model in MODELS:
            train = pd.concat([data[dataset, model, "calibration"] for model in MODELS if model != held_model], ignore_index=True)
            test_all = data[dataset, held_model, "test"]
            for setting in ("full", "success-only"):
                test = condition(test_all, "pooled", setting)
                metrics, _ = evaluate_condition(train, test, LEARNED_METHODS)
                e3_rows.extend({"protocol_id": PROTOCOL, "experiment": "E3", "dataset": dataset, "held_model": held_model, "setting": setting, **row} for row in metrics)
    write_rows(args.output_root / "E3_leave_one_model_out.csv", e3_rows)

    e4_rows: list[dict[str, object]] = []
    for model in MODELS:
        train = data["k400", model, "calibration"]
        test_all = data["ucf101", model, "test"]
        for setting in ("full", "success-only"):
            test = condition(test_all, "pooled", setting)
            metrics, _ = evaluate_condition(train, test, LEARNED_METHODS)
            e4_rows.extend({"protocol_id": PROTOCOL, "experiment": "E4", "train_dataset": "k400", "test_dataset": "ucf101", "model": model, "setting": setting, **row} for row in metrics)
    write_rows(args.output_root / "E4_cross_dataset_transfer.csv", e4_rows)

    e5_rows: list[dict[str, object]] = []
    for dataset in DATASETS:
        for model in MODELS:
            train = data[dataset, model, "calibration"]
            test_all = data[dataset, model, "test"]
            for attack in (*ATTACKS, "pooled"):
                for setting in ("full", "success-only"):
                    test = condition(test_all, attack, setting)
                    cal_scores, test_scores = score_methods(train, test, ABLATIONS, include_fixed=False)
                    y_cal = train.is_adv.to_numpy(int); y_test = test.is_adv.to_numpy(int)
                    for method, scores in test_scores.items():
                        threshold = threshold_at_clean_fpr(y_cal, cal_scores[method])
                        e5_rows.append({"protocol_id": PROTOCOL, "experiment": "E5", "dataset": dataset, "model": model, "attack": attack, "setting": setting, "method": method, **metric_row(y_test, scores, threshold)})
    write_rows(args.output_root / "E5_feature_group_ablation.csv", e5_rows)

    schema = {
        "protocol_id": PROTOCOL, "seed": SEED, "tdc_v1": TDC_V1, "tdc_v2": TDC_V2,
        "detector_pipeline": {
            "scaler": "StandardScaler fitted on calibration only",
            "classifier": "LogisticRegression", "C": 1.0, "l1_ratio": 0.0,
            "penalty_equivalent": "L2", "solver": "lbfgs", "class_weight": "balanced",
            "max_iter": 5000, "deployment_clean_fpr_target": 0.01,
        },
        "bootstrap": {
            "unit": "source video / pair_id", "replicates": int(args.bootstrap),
            "interval": "percentile 95%", "paired": True,
            "comparisons": ["TDC-v2 vs VLAD-2", "TDC-v2 vs Temporal Shuffle-LR", "TDC-v2 vs strongest matched baseline"],
        },
        "feature_groups": {"action": ACTION_FEATURES, "vlm": VLM_FEATURES, "semantic": SEMANTIC_FEATURES, "frequency_order": FREQUENCY_FEATURES, "local": LOCAL_FEATURES},
        "learned_baselines": LEARNED_METHODS, "fixed_baselines": FIXED_METHODS,
    }
    (args.output_root / "E1_E5_evaluation_schema.json").write_text(json.dumps(schema, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"Saved E1-E5 evaluation to {args.output_root}")


if __name__ == "__main__":
    main()
