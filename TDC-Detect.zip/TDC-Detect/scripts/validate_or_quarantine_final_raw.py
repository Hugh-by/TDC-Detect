from __future__ import annotations

import argparse
import csv
import math
import sys
from datetime import datetime
from pathlib import Path


PROTOCOL = "tdc-final-20260714"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--path", type=Path, required=True)
    parser.add_argument("--expected", type=int, required=True)
    parser.add_argument("--keys", required=True, help="Comma-separated uniqueness fields")
    parser.add_argument("--finite", default="", help="Comma-separated fields that must be present and finite")
    parser.add_argument("--quarantine-dir", type=Path, required=True)
    args = parser.parse_args()
    if not args.path.exists():
        print("ABSENT")
        return
    keys = tuple(value.strip() for value in args.keys.split(",") if value.strip())
    finite = tuple(value.strip() for value in args.finite.split(",") if value.strip())
    rows = 0
    valid = True
    seen: set[tuple[str, ...]] = set()
    try:
        with args.path.open(encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            valid = {"protocol_id", *keys, *finite} <= set(reader.fieldnames or ())
            for row in reader:
                rows += 1
                key = tuple(row.get(name, "") for name in keys)
                valid = valid and row.get("protocol_id") == PROTOCOL and all(key) and key not in seen
                if valid and finite:
                    try:
                        valid = all(row.get(name, "") != "" and math.isfinite(float(row[name])) for name in finite)
                    except (KeyError, TypeError, ValueError):
                        valid = False
                seen.add(key)
    except (OSError, UnicodeError, csv.Error):
        valid = False
    if valid and rows == args.expected:
        print("COMPLETE")
        return
    if valid and rows < args.expected:
        print("PARTIAL")
        return
    args.quarantine_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().astimezone().strftime("%Y%m%dT%H%M%S%f%z")
    target = args.quarantine_dir / f"{args.path.name}.{stamp}.invalid"
    args.path.replace(target)
    print(f"Quarantined invalid raw output at {target}", file=sys.stderr)
    print("QUARANTINED")


if __name__ == "__main__":
    main()
