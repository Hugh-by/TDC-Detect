#!/usr/bin/env bash
set -euo pipefail

ROOT=/root/autodl-tmp
CODE=${ROOT}/inspection_reference/root/TSC/VLAD-master
MAX_JOBS=${MAX_JOBS:-4}
cd "${CODE}"

run_one() {
  local main="$1" eval_dir="$2" model="$3" attack="$4" setting="$5"
  local suffix=raw
  [[ "${setting}" == success ]] && suffix=success
  python tests/eval_group5.py \
    --input "${main}/${model}_${attack}_tsc_${suffix}.csv" \
    --output "${eval_dir}/${model}_${attack}_${setting}_group5.csv" \
    --folds 5 --n-boot 1000
}

for dataset in k400 ucf101; do
  main="${ROOT}/tsc/outputs/repaired_${dataset}_main"
  eval_dir="${ROOT}/tsc/outputs/repaired_${dataset}_eval"
  for model in x3d_m mvit_base_16x4 slowfast_r50 csn_r101; do
    for attack in fgsm_v pgd_v ofa flick; do
      for setting in full success; do
        run_one "${main}" "${eval_dir}" "${model}" "${attack}" "${setting}" &
        while (( $(jobs -rp | wc -l) >= MAX_JOBS )); do
          wait -n
        done
      done
    done
  done
done
wait

python tests/build_repaired_summary.py \
  --root "${ROOT}/tsc/outputs/repaired_k400_eval" --dataset k400
python tests/build_repaired_summary.py \
  --root "${ROOT}/tsc/outputs/repaired_ucf101_eval" --dataset ucf101
