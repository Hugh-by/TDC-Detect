from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path


PROTOCOL = "tdc-final-20260714"
SEED = 20260714
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
ROOT = Path("/root/autodl-tmp/tsc/final_protocols") / PROTOCOL / "manifests"


def read(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def select(rows: list[dict[str, str]], limit: int, label_key: str) -> list[dict[str, str]]:
    groups: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in rows:
        groups[row[label_key]].append(row)
    for label, values in groups.items():
        values.sort(key=lambda row: hashlib.sha256(f"{row['relative_path']}|{SEED}|fixed-subset".encode()).hexdigest())
    chosen = []
    depth = 0
    labels = sorted(groups)
    while len(chosen) < min(limit, len(rows)):
        added = False
        for label in labels:
            if depth < len(groups[label]):
                chosen.append(groups[label][depth]); added = True
                if len(chosen) == min(limit, len(rows)):
                    break
        if not added:
            break
        depth += 1
    return chosen


def write(path: Path, rows: list[dict[str, str]]) -> None:
    fields = list(rows[0])
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields); writer.writeheader(); writer.writerows(rows)


def main() -> None:
    for model in MODELS:
        calibration = read(ROOT / f"k400_{model}_calibration_selected.csv")
        # E8 tunes lambda on a small, class-stratified calibration-only set.
        # This subset is frozen before E8 starts and never overlaps the test set.
        write(ROOT / f"k400_{model}_calibration_fixed20.csv", select(calibration, 20, "label"))
        rows = read(ROOT / f"k400_{model}_test_selected.csv")
        fixed = select(rows, 200, "label")
        write(ROOT / f"k400_{model}_test_fixed200.csv", fixed)
        write(ROOT / f"k400_{model}_test_fixed100.csv", fixed[:100])
    ucf = [row for row in read(ROOT / "ucf101_group_disjoint.csv") if row["split"] == "test"]
    fixed = select(ucf, 100, "label")
    write(ROOT / "ucf101_test_fixed100.csv", fixed)
    summary = {"protocol_id": PROTOCOL, "seed": SEED, "files": {}}
    for path in sorted(ROOT.glob("*_fixed*.csv")):
        summary["files"][path.name] = {
            "rows": len(read(path)),
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        }
    (ROOT / "fixed_subset_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print("Saved K400 calibration fixed20, K400 test fixed200/100, and UCF101 test fixed100 manifests")


if __name__ == "__main__":
    main()
