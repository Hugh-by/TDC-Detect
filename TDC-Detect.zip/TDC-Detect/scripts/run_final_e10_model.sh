#!/usr/bin/env bash
set -euo pipefail
MODEL=$1
GPU=$2
P=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
OUTPUT=${ROOT}/outputs/${P}/E10/${MODEL}.csv
STATUS=$(python "${PROJECT}/scripts/validate_or_quarantine_final_raw.py" \
  --path "${OUTPUT}" --expected 800 --keys pair_id,attack \
  --finite measured_linf,psnr,mean_ssim,min_ssim \
  --quarantine-dir "${ROOT}/final_protocols/${P}/logs/recovery/E10")
[[ "${STATUS}" == "COMPLETE" ]] && exit 0
export CUDA_VISIBLE_DEVICES=${GPU} CUBLAS_WORKSPACE_CONFIG=:4096:8
cd "${PROJECT}"
python -m TSC_Detect.run_final_e10_perceptual \
  --manifest "${ROOT}/final_protocols/${P}/manifests/k400_${MODEL}_test_fixed200.csv" \
  --model "${MODEL}" --output "${OUTPUT}" \
  --device cuda:0 --resume
