#!/usr/bin/env bash
set -euo pipefail

P=tdc-final-20260714
ROOT=/root/autodl-tmp/tsc
PROTOCOL_ROOT=${ROOT}/final_protocols/${P}
OUTPUT_ROOT=${ROOT}/outputs/${P}
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
MODELS=(csn_r101 mvit_base_16x4 slowfast_r50 x3d_m)
cd "${PROJECT}"

event() { echo "$(date -Is) $*" | tee -a "${PROTOCOL_ROOT}/ops/events.log"; }
marker() { printf '%s\n' "$(date -Is)" > "${OUTPUT_ROOT}/$1"; }

event "PHASE_LAUNCH phase=POST_E1_PIPELINE_READINESS"
python scripts/audit_final_pipeline_readiness.py \
  --project "${PROJECT}" --protocol-root "${PROTOCOL_ROOT}" \
  --output "${PROTOCOL_ROOT}/gates/post_e1_pipeline_readiness.json"
event "PHASE_COMPLETE phase=POST_E1_PIPELINE_READINESS"

event "PHASE_LAUNCH phase=POST_E1_UNIT_TESTS"
python -m unittest discover -s tests -p 'test_*.py' -v
event "PHASE_COMPLETE phase=POST_E1_UNIT_TESTS"

event "PHASE_LAUNCH phase=E1_RAW_INTEGRITY_AUDIT"
python scripts/audit_final_e1_live.py \
  --state "${OUTPUT_ROOT}/E1_COMPLETE.json" --e1-root "${OUTPUT_ROOT}/E1" \
  --output "${PROTOCOL_ROOT}/gates/e1_completion_integrity.json"
event "PHASE_COMPLETE phase=E1_RAW_INTEGRITY_AUDIT"

event "PHASE_LAUNCH phase=E1_E5_CPU_EVALUATION"
mkdir -p "${OUTPUT_ROOT}/metrics"
python scripts/eval_final_e1_e5.py \
  --input-root "${OUTPUT_ROOT}/E1" \
  --output-root "${OUTPUT_ROOT}/metrics" \
  --bootstrap 1000
python - "${OUTPUT_ROOT}/metrics" <<'PY'
import pandas as pd, pathlib, sys
r=pathlib.Path(sys.argv[1])
expected={'E1_metrics.csv':720,'E1_paired_bootstrap_summary.csv':80,'E1_paired_bootstrap_replicates.csv':80000,'E2_leave_one_attack_out.csv':576,'E3_leave_one_model_out.csv':144,'E4_cross_dataset_transfer.csv':72,'E5_feature_group_ablation.csv':560}
for name,count in expected.items():
    d=pd.read_csv(r/name)
    if len(d)!=count or d.isna().any().any(): raise SystemExit(f'{name}: invalid rows or NaNs')
if set(pd.read_csv(r/'E1_paired_bootstrap_summary.csv').valid_replicates)!={1000}:
    raise SystemExit('bootstrap replicate count mismatch')
summary=pd.read_csv(r/'E1_paired_bootstrap_summary.csv')
replicates=pd.read_csv(r/'E1_paired_bootstrap_replicates.csv')
if not {'tdc_v2_ci_low','tdc_v2_ci_high','baseline_ci_low','baseline_ci_high','ci_low','ci_high','vlad2_difference_ci_low','vlad2_difference_ci_high','temporal_shuffle_lr_difference_ci_low','temporal_shuffle_lr_difference_ci_high'} <= set(summary):
    raise SystemExit('bootstrap CI columns are missing')
if not {'tdc_v2_auc','baseline_auc','difference','difference_vs_vlad2','difference_vs_temporal_shuffle_lr'} <= set(replicates):
    raise SystemExit('bootstrap replicate score columns are missing')
PY
marker E1_E5_METRICS_COMPLETE
event "PHASE_COMPLETE phase=E1_E5_CPU_EVALUATION"

event "PHASE_LAUNCH phase=E6"
mkdir -p "${OUTPUT_ROOT}/E6" "${PROTOCOL_ROOT}/logs/E6"
pids=()
for i in "${!MODELS[@]}"; do
  bash scripts/run_final_e6_model.sh "${MODELS[$i]}" "$i" >> "${PROTOCOL_ROOT}/logs/E6/${MODELS[$i]}.log" 2>&1 &
  pids+=("$!")
done
for pid in "${pids[@]}"; do wait "${pid}"; done
python scripts/eval_final_e6_e7.py --e1-root "${OUTPUT_ROOT}/E1" --e6-root "${OUTPUT_ROOT}/E6" --output-root "${OUTPUT_ROOT}/metrics"
python - "${OUTPUT_ROOT}" <<'PY'
import pandas as pd, pathlib, sys
r=pathlib.Path(sys.argv[1])
for f in (r/'E6').glob('*.csv'):
    if len(pd.read_csv(f)) != 1800: raise SystemExit(f'E6 row mismatch: {f}')
if len(pd.read_csv(r/'metrics/E6_attack_strength.csv')) != 64: raise SystemExit('E6 metric row mismatch')
PY
marker E6_COMPLETE
event "PHASE_COMPLETE phase=E6"

event "PHASE_LAUNCH phase=E7"
mkdir -p "${OUTPUT_ROOT}/E7" "${PROTOCOL_ROOT}/logs/E7"
pids=()
for i in "${!MODELS[@]}"; do
  bash scripts/run_final_e7_model.sh "${MODELS[$i]}" "$i" >> "${PROTOCOL_ROOT}/logs/E7/${MODELS[$i]}.log" 2>&1 &
  pids+=("$!")
done
for pid in "${pids[@]}"; do wait "${pid}"; done
python scripts/eval_final_e6_e7.py --e1-root "${OUTPUT_ROOT}/E1" --e7-root "${OUTPUT_ROOT}/E7" --output-root "${OUTPUT_ROOT}/metrics"
python - "${OUTPUT_ROOT}" <<'PY'
import pandas as pd, pathlib, sys
r=pathlib.Path(sys.argv[1])
for f in (r/'E7').glob('*.csv'):
    if len(pd.read_csv(f)) != 5400: raise SystemExit(f'E7 row mismatch: {f}')
if len(pd.read_csv(r/'metrics/E7_probe_cost_sensitivity.csv')) != 144: raise SystemExit('E7 metric row mismatch')
PY
marker E7_COMPLETE
event "PHASE_COMPLETE phase=E7"

while [ ! -x scripts/run_final_e8_e10.sh ]; do
  event "WAITING phase=E8_E10 reason=runner_not_ready"
  sleep 300
done
bash scripts/run_final_e8_e10.sh
