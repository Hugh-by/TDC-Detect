#!/usr/bin/env bash
set -euo pipefail

MODEL="${1:?model required}"
GPU="${2:?gpu required}"
ROOT=/root/autodl-tmp
CODE=${ROOT}/inspection_reference/root/TSC/VLAD-master
MANIFEST=${ROOT}/tsc/data/manifests/ucf101_repaired_c20_t10.csv
CLASSES=${ROOT}/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv
OUT=${ROOT}/tsc/outputs/repaired_ucf101_main
CALIB=${ROOT}/tsc/outputs/repaired_ucf101_calibration/${MODEL}_clean_calib.csv

cd "${CODE}"
export CUDA_VISIBLE_DEVICES="${GPU}"
export HF_HUB_OFFLINE=1
export TRANSFORMERS_OFFLINE=1

python -m TSC_Detect.run_tsc_detect \
  --manifest "${MANIFEST}" --manifest-splits calib \
  --class-names "${CLASSES}" --device cuda --action-model "${MODEL}" \
  --num-frames 32 --num-random 0 --max-clip-frames 8 --num-local-windows 4 \
  --score-mode max_evidence \
  --prompt-templates "a video of a person {}" "a video of {}" "an action of {}" \
  --resume --output-csv "${CALIB}"

run_attack() {
  local tag="$1" attack="$2" iters="$3"
  python -m TSC_Detect.run_tsc_attack_probe \
    --manifest "${MANIFEST}" --manifest-splits test \
    --class-names "${CLASSES}" --device cuda --action-model "${MODEL}" \
    --num-frames 32 --num-random 0 --max-clip-frames 8 --num-local-windows 4 \
    --score-mode max_evidence \
    --prompt-templates "a video of a person {}" "a video of {}" "an action of {}" \
    --attack "${attack}" --attack-split-name "${tag}" \
    --eps 0.03 --iters "${iters}" --alpha 0.00784313725490196 \
    --resume --output-csv "${OUT}/${MODEL}_${tag}_tsc_raw.csv"
}

run_attack fgsm_v fgsm 1
run_attack pgd_v pgd 40
run_attack ofa ofa 10
run_attack flick flick 10
