from __future__ import annotations

import argparse
import csv
import json
import py_compile
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path


PROTOCOL = "tdc-final-20260714"
MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
PYTHON_FILES = (
    "scripts/eval_final_e1_e5.py", "scripts/eval_final_e6_e7.py", "scripts/eval_final_e8_e10.py",
    "scripts/audit_final_pipeline_readiness.py", "scripts/audit_final_e1_live.py", "scripts/validate_or_quarantine_final_raw.py",
    "scripts/build_final_deliverables.py", "TSC_Detect/run_final_e6_strength.py",
    "TSC_Detect/run_final_e7_sensitivity.py", "TSC_Detect/run_final_e8_adaptive.py",
    "TSC_Detect/run_final_e9_runtime.py", "TSC_Detect/run_final_e10_perceptual.py",
)
SHELL_FILES = (
    "scripts/run_final_post_e1.sh", "scripts/run_final_e8_e10.sh",
    "scripts/run_final_e6_model.sh", "scripts/run_final_e7_model.sh",
    "scripts/run_final_e8_model.sh", "scripts/run_final_e9_condition.sh",
    "scripts/run_final_e10_model.sh", "scripts/show_final_protocol_progress.sh",
)


def count_csv(path: Path) -> int:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def check(name: str, passed: bool, evidence: object) -> dict[str, object]:
    return {"name": name, "pass": bool(passed), "evidence": evidence}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--protocol-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    checks: list[dict[str, object]] = []
    gate = json.loads((args.protocol_root / "gates/gate_report.json").read_text(encoding="utf-8"))
    checks.append(check("G1-G9 passed", gate.get("status") == "PASS", "gates/gate_report.json"))

    compile_errors = []
    for relative in PYTHON_FILES:
        path = args.project / relative
        try: py_compile.compile(str(path), doraise=True)
        except Exception as exc: compile_errors.append(f"{relative}: {exc}")
    checks.append(check("post-E1 Python files compile", not compile_errors, {"files": list(PYTHON_FILES), "errors": compile_errors}))
    shell = subprocess.run(["bash", "-n", *[str(args.project / value) for value in SHELL_FILES]], capture_output=True, text=True)
    executable = [value for value in SHELL_FILES if not (args.project / value).stat().st_mode & 0o111]
    checks.append(check("post-E1 shell files parse and are executable", shell.returncode == 0 and not executable, {"files": list(SHELL_FILES), "stderr": shell.stderr, "not_executable": executable}))

    manifests = args.protocol_root / "manifests"
    counts = {}
    for model in MODELS:
        for suffix, expected in (("test_fixed100", 100), ("test_fixed200", 200), ("calibration_fixed20", 20)):
            path = manifests / f"k400_{model}_{suffix}.csv"; counts[path.name] = count_csv(path)
            checks.append(check(f"manifest {path.name}", counts[path.name] == expected, counts[path.name]))
    ucf_path = manifests / "ucf101_test_fixed100.csv"; counts[ucf_path.name] = count_csv(ucf_path)
    checks.append(check("manifest ucf101_test_fixed100.csv", counts[ucf_path.name] == 100, counts[ucf_path.name]))

    for model in ("csn_r101", "mvit_base_16x4"):
        calibration = {row["relative_path"] for row in csv.DictReader((manifests / f"k400_{model}_calibration_fixed20.csv").open(encoding="utf-8"))}
        testing = {row["relative_path"] for row in csv.DictReader((manifests / f"k400_{model}_test_fixed100.csv").open(encoding="utf-8"))}
        checks.append(check(f"E8 calibration/test isolation {model}", not calibration & testing, sorted(calibration & testing)))
    subset_summary = json.loads((manifests / "fixed_subset_summary.json").read_text(encoding="utf-8"))
    checks.append(check("fixed subset hash summary", subset_summary.get("protocol_id") == PROTOCOL and len(subset_summary.get("files", {})) == 13, "manifests/fixed_subset_summary.json"))
    for config_name in ("protocol.json", "e8_adaptive_method.json", "e9_runtime_method.json", "e10_perceptual_method.json"):
        data = json.loads((args.protocol_root / "configs" / config_name).read_text(encoding="utf-8"))
        checks.append(check(f"config protocol {config_name}", data.get("protocol_id") == PROTOCOL, data.get("protocol_id")))

    unit = subprocess.run(
        ["python", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py", "-q"],
        cwd=args.project, capture_output=True, text=True,
    )
    checks.append(check("CPU unit tests", unit.returncode == 0, {"stdout": unit.stdout, "stderr": unit.stderr}))
    free = shutil.disk_usage(args.protocol_root).free
    checks.append(check("free data-disk capacity >= 20 GiB", free >= 20 * 2**30, {"free_bytes": free, "free_gib": free / 2**30}))
    expected_rows = {
        "E1": 140205, "E1_metrics": 720, "E1_bootstrap_summary": 80,
        "E1_bootstrap_replicates": 80000, "E2": 576, "E3": 144, "E4": 72,
        "E5": 560, "E6_raw_per_model": 1800, "E6_metrics": 64,
        "E7_raw_per_model": 5400, "E7_metrics": 144,
        "E8_raw_per_model": 480, "E8_metrics": 4,
        "E9_raw_per_condition": 2000, "E9_metrics": 32,
        "E10_raw_per_model": 800, "E10_integrity_metrics": 32, "E10_perceptual_metrics": 16,
    }
    report = {
        "protocol_id": PROTOCOL, "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
        "status": "PASS" if all(item["pass"] for item in checks) else "FAIL",
        "expected_rows": expected_rows, "checks": checks,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2, sort_keys=True))
    if report["status"] != "PASS": raise SystemExit(1)


if __name__ == "__main__":
    main()
