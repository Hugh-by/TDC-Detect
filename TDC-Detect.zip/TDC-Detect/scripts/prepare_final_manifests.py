from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


PROTOCOL_ID = "tdc-final-20260714"
SEED = 20260714
MODELS = ("csn_r101", "slowfast_r50", "x3d_m", "mvit_base_16x4")


def digest_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(({field: row.get(field, "") for field in fields} for row in rows))


def partition(relative_path: str) -> tuple[str, str]:
    value = digest_text(relative_path + str(SEED))
    fraction = int(value[:16], 16) / float(16**16)
    return ("calibration" if fraction < 0.70 else "test"), value


def stratified_select(rows: list[dict[str, object]], model: str, split: str, limit: int) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    by_class: dict[str, list[dict[str, object]]] = {}
    for row in rows:
        by_class.setdefault(str(row["label"]), []).append(row)
    for label, values in by_class.items():
        values.sort(key=lambda row: digest_text(f"{row['relative_path']}|{SEED}|{model}|{split}|selection"))

    selected: list[dict[str, object]] = []
    depth = 0
    labels = sorted(by_class)
    while len(selected) < min(limit, len(rows)):
        added = False
        for label in labels:
            values = by_class[label]
            if depth < len(values):
                selected.append(values[depth])
                added = True
                if len(selected) == min(limit, len(rows)):
                    break
        if not added:
            break
        depth += 1
    selected_paths = {str(row["relative_path"]) for row in selected}
    rejected = [row for row in rows if str(row["relative_path"]) not in selected_paths]
    return selected, rejected


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--exact-manifest", type=Path, required=True)
    parser.add_argument("--prediction-dir", type=Path, required=True)
    parser.add_argument("--ucf-manifest", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)

    exact = read_csv(args.exact_manifest)
    exact_by_path = {row["old_absolute_path"]: row for row in exact}
    assignments: list[dict[str, object]] = []
    for row in exact:
        split, split_hash = partition(row["relative_path"])
        assignments.append({
            "relative_path": row["relative_path"],
            "path": row["old_absolute_path"],
            "class_name": row["class_name"],
            "label_index": row["label_index"],
            "split": split,
            "split_sha256": split_hash,
            "exists": int(Path(row["old_absolute_path"]).is_file()),
        })
    write_csv(args.output_root / "k400_global_split.csv", assignments, list(assignments[0]))

    summary: dict[str, object] = {
        "protocol_id": PROTOCOL_ID,
        "seed": SEED,
        "exact_manifest": str(args.exact_manifest),
        "exact_manifest_sha256": file_sha256(args.exact_manifest),
        "global_rows": len(assignments),
        "global_split_counts": dict(Counter(str(row["split"]) for row in assignments)),
        "missing_files": sum(not int(row["exists"]) for row in assignments),
        "models": {},
    }
    assignment_by_rel = {str(row["relative_path"]): row for row in assignments}
    selected_paths: dict[str, dict[str, set[str]]] = {model: {} for model in MODELS}

    output_fields = [
        "protocol_id", "dataset", "action_model", "split", "path", "relative_path",
        "label", "label_index", "clean_pred", "clean_pred_name", "clean_conf",
        "clean_correct", "path_sha256", "selection_rank_sha256",
    ]
    for model in MODELS:
        prediction_path = args.prediction_dir / f"kinetics400_full_val_{model}_all.csv"
        predictions = read_csv(prediction_path)
        candidates: list[dict[str, object]] = []
        for prediction in predictions:
            exact_row = exact_by_path.get(prediction["path"])
            if exact_row is None or prediction.get("clean_correct") != "1" or prediction.get("error"):
                continue
            assignment = assignment_by_rel[exact_row["relative_path"]]
            candidates.append({
                "protocol_id": PROTOCOL_ID,
                "dataset": "k400",
                "action_model": model,
                "split": assignment["split"],
                "path": prediction["path"],
                "relative_path": exact_row["relative_path"],
                "label": exact_row["class_name"],
                "label_index": exact_row["label_index"],
                "clean_pred": prediction["pred_action"],
                "clean_pred_name": prediction["pred_action_name"],
                "clean_conf": prediction["conf_action"],
                "clean_correct": 1,
                "path_sha256": digest_text(exact_row["relative_path"]),
                "selection_rank_sha256": digest_text(f"{exact_row['relative_path']}|{SEED}|{model}|{assignment['split']}|selection"),
            })

        model_summary: dict[str, object] = {"prediction_sha256": file_sha256(prediction_path), "splits": {}}
        for split in ("calibration", "test"):
            eligible = [row for row in candidates if row["split"] == split]
            selected, rejected = stratified_select(eligible, model, split, 2000)
            selected.sort(key=lambda row: (str(row["label"]), str(row["selection_rank_sha256"])))
            rejected.sort(key=lambda row: (str(row["label"]), str(row["selection_rank_sha256"])))
            write_csv(args.output_root / f"k400_{model}_{split}_selected.csv", selected, output_fields)
            write_csv(args.output_root / f"k400_{model}_{split}_rejected.csv", rejected, output_fields)
            class_counts = Counter(str(row["label"]) for row in selected)
            count_rows = [{"class_name": label, "count": class_counts.get(label, 0)} for label in sorted({row["class_name"] for row in exact})]
            write_csv(args.output_root / f"k400_{model}_{split}_class_counts.csv", count_rows, ["class_name", "count"])
            selected_paths[model][split] = {str(row["relative_path"]) for row in selected}
            model_summary["splits"][split] = {
                "eligible": len(eligible), "selected": len(selected), "rejected": len(rejected),
                "represented_classes": len(class_counts),
            }
        summary["models"][model] = model_summary

    cross_leaks = []
    for train_model in MODELS:
        for test_model in MODELS:
            overlap = selected_paths[train_model]["calibration"] & selected_paths[test_model]["test"]
            if overlap:
                cross_leaks.append({"calibration_model": train_model, "test_model": test_model, "count": len(overlap)})
    summary["cross_model_calibration_test_overlaps"] = cross_leaks

    ucf = read_csv(args.ucf_manifest)
    normalized = []
    for row in ucf:
        normalized.append({
            "protocol_id": PROTOCOL_ID,
            "dataset": "ucf101",
            "split": "calibration" if row["split"] == "calib" else row["split"],
            "path": row["path"],
            "relative_path": row["relative_path"],
            "label": row["label"],
            "group": row["group"],
            "clip": row["clip"],
            "path_sha256": digest_text(row["relative_path"]),
        })
    write_csv(args.output_root / "ucf101_group_disjoint.csv", normalized, list(normalized[0]))
    ucf_groups = {split: sorted({int(row["group"]) for row in normalized if row["split"] == split}) for split in ("calibration", "test")}
    summary["ucf101"] = {
        "source_sha256": file_sha256(args.ucf_manifest),
        "split_counts": dict(Counter(str(row["split"]) for row in normalized)),
        "groups": ucf_groups,
        "group_overlap": sorted(set(ucf_groups["calibration"]) & set(ucf_groups["test"])),
    }
    (args.output_root / "manifest_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
