#!/usr/bin/env bash
set -u

ROOT=/root/autodl-tmp/tsc
PROTOCOL=tdc-final-20260714
echo "Protocol: ${PROTOCOL}"
echo "Gate report:"
python - "${ROOT}/final_protocols/${PROTOCOL}/gates/gate_report.json" <<'PY'
import json, pathlib, sys
p=pathlib.Path(sys.argv[1])
if not p.exists():
    print("  not generated")
else:
    r=json.loads(p.read_text())
    print(" ",r.get("status"))
    for name, gate in sorted(r.get("gates",{}).items()):
        print(f"  {name}: {'PASS' if gate.get('pass') else 'FAIL'}")
PY
echo "Campaign state:"
python - "${ROOT}/final_protocols/${PROTOCOL}/ops/supervisor_state.json" "${ROOT}/outputs/${PROTOCOL}" <<'PY'
import csv,datetime,json,pathlib,subprocess,sys,time
state_path=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2])
if state_path.exists():
    s=json.loads(state_path.read_text())
    print(f"  phase={s['phase']} updated={s['updated_at']}")
    print(f"  E1={s['overall_rows']}/{s['overall_expected_rows']} ({s['overall_progress']:.2%}), targets={s['completed_targets']}/{s['total_targets']}")
    for t in s['targets']:
        if not t['complete'] and t['rows']:
            print(f"    {t['model']} {t['dataset']}/{t['partition']}: {t['rows']}/{t['expected_rows']} ({t['progress']:.2%}), valid={t['valid']}")
    rates={}; etas={}
    for model in sorted({t['model'] for t in s['targets']}):
        targets=[t for t in s['targets'] if t['model']==model]
        current=sum(t['rows'] for t in targets); expected=sum(t['expected_rows'] for t in targets)
        files=[out/'E1'/t['file'] for t in targets if (out/'E1'/t['file']).exists()]
        births=[]
        for path in files:
            try: births.append(int(subprocess.check_output(['stat','-c','%W',str(path)],text=True).strip()))
            except Exception: pass
        elapsed=max((time.time()-min(x for x in births if x>0))/3600,1/60) if any(x>0 for x in births) else 0
        rate=current/elapsed if elapsed else 0; eta=(expected-current)/rate if rate else float('inf')
        rates[model]=rate; etas[model]=eta
        print(f"    rate {model}: {rate:.1f} rows/hour; unassisted ETA {eta:.1f} h")
    if all(name in etas for name in ('csn_r101','x3d_m')) and rates.get('csn_r101',0)>0:
        x3d_eta=etas['x3d_m']; csn_remaining=sum(t['expected_rows']-t['rows'] for t in s['targets'] if t['model']=='csn_r101')
        csn_at_steal=max(0,csn_remaining-rates['csn_r101']*x3d_eta)
        adjusted_csn=x3d_eta+csn_at_steal/(2*rates['csn_r101'])
        campaign=max(adjusted_csn,*(eta for model,eta in etas.items() if model!='csn_r101'))
        finish=datetime.datetime.now().astimezone()+datetime.timedelta(hours=campaign)
        print(f"  adjusted E1 ETA with GPU3→CSN work stealing: {campaign:.1f} h (about {finish:%Y-%m-%d %H:%M %z})")
markers=('E1_COMPLETE.json','E1_E5_METRICS_COMPLETE','E6_COMPLETE','E7_COMPLETE','E8_COMPLETE','E10_COMPLETE','E9_COMPLETE','E1_E10_COMPLETE','FINAL_EXPORT_COMPLETE')
print("  completion markers:")
for name in markers: print(f"    {name}: {'YES' if (out/name).exists() else 'no'}")
specs={'E6':1800,'E7':5400,'E8':480,'E9':2000,'E10':800}
for phase,expected in specs.items():
    root=out/phase
    files=sorted(root.glob('*.csv')) if root.exists() else []
    if files:
        values=[]
        for path in files:
            with path.open(encoding='utf-8',newline='') as h: count=sum(1 for _ in csv.DictReader(h))
            values.append(f"{path.name}={count}")
        print(f"  {phase} raw ({expected} rows/file nominal): "+", ".join(values))
PY
echo "GPU state:"
nvidia-smi --query-gpu=index,utilization.gpu,memory.used,memory.total --format=csv,noheader
echo "Active final-protocol processes:"
ps -eo pid,etime,args | grep -E 'tdc_final_supervisor|tdc_e1_work_stealer|run_final_(extract|e[0-9])' | grep -v grep || true
echo "Recent events:"
tail -n 12 "${ROOT}/final_protocols/${PROTOCOL}/ops/events.log" 2>/dev/null || true
