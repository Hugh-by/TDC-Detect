#!/usr/bin/env bash
set -euo pipefail

MODEL=${1:?model required}
GPU=${2:?gpu required}
PROTOCOL_ID=tdc-final-20260714
PROTOCOL_ROOT=/root/autodl-tmp/tsc/final_protocols/${PROTOCOL_ID}
OUTPUT_ROOT=/root/autodl-tmp/tsc/outputs/${PROTOCOL_ID}/E1
GATE_REPORT=${PROTOCOL_ROOT}/gates/gate_report.json
PROJECT=/root/autodl-tmp/inspection_reference/root/TSC/VLAD-master
CLASSES=/root/autodl-tmp/inspection_bundle/server_transfer_bundle_20260711/manifests/k400_validation_exact_17712.csv

python - "${GATE_REPORT}" "${PROTOCOL_ID}" <<'PY'
import json, sys
path, protocol = sys.argv[1:]
report = json.load(open(path, encoding="utf-8"))
if report.get("protocol_id") != protocol or report.get("status") != "PASS":
    raise SystemExit("Full E1 launch refused: G1-G9 are not all PASS")
PY

mkdir -p "${OUTPUT_ROOT}" "${PROTOCOL_ROOT}/logs/E1"
cd "${PROJECT}"
export CUDA_VISIBLE_DEVICES=${GPU}
export CUBLAS_WORKSPACE_CONFIG=:4096:8

run_one() {
  local dataset=$1
  local partition=$2
  local manifest=$3
  local output=${OUTPUT_ROOT}/${dataset}_${MODEL}_${partition}.csv
  python -m TSC_Detect.run_final_extract \
    --manifest "${manifest}" \
    --dataset "${dataset}" \
    --partition "${partition}" \
    --action-model "${MODEL}" \
    --class-names "${CLASSES}" \
    --output-csv "${output}" \
    --device cuda:0 \
    --resume
}

run_one k400 calibration "${PROTOCOL_ROOT}/manifests/k400_${MODEL}_calibration_selected.csv"
run_one k400 test "${PROTOCOL_ROOT}/manifests/k400_${MODEL}_test_selected.csv"
run_one ucf101 calibration "${PROTOCOL_ROOT}/manifests/ucf101_group_disjoint.csv"
run_one ucf101 test "${PROTOCOL_ROOT}/manifests/ucf101_group_disjoint.csv"

echo "${PROTOCOL_ID} E1 ${MODEL} COMPLETE"
