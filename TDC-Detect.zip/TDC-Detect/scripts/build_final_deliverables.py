from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import tarfile
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from eval_final_e1_e5 import PROTOCOL, TDC_V2, fit_model, threshold_at_clean_fpr


MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")
DATASETS = ("k400", "ucf101")
ATTACKS = ("fgsm", "pgd", "ofa-style", "flicker-style")
EXPECTED_METRICS = {
    "E1_metrics.csv": 720,
    "E1_paired_bootstrap_summary.csv": 80,
    "E1_paired_bootstrap_replicates.csv": 80000,
    "E2_leave_one_attack_out.csv": 576,
    "E3_leave_one_model_out.csv": 144,
    "E4_cross_dataset_transfer.csv": 72,
    "E5_feature_group_ablation.csv": 560,
    "E6_attack_strength.csv": 64,
    "E7_probe_cost_sensitivity.csv": 144,
    "E8_adaptive_metrics.csv": 4,
    "E8_selected_candidates.csv": 200,
    "E8_lambda_tuning.csv": 6,
    "E9_runtime_memory.csv": 32,
    "E10_main_attack_integrity.csv": 32,
    "E10_perceptual_quality.csv": 16,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def csv_rows(path: Path) -> int:
    with path.open(encoding="utf-8", newline="") as handle:
        return sum(1 for _ in csv.DictReader(handle))


def read_protocol_csv(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if len(frame) == 0 or "protocol_id" not in frame or set(frame.protocol_id) != {PROTOCOL}:
        raise ValueError(f"Invalid protocol/empty CSV: {path}")
    return frame


def expected_e1(protocol_root: Path) -> dict[str, int]:
    result: dict[str, int] = {}
    manifests = protocol_root / "manifests"
    ucf = pd.read_csv(manifests / "ucf101_group_disjoint.csv")
    for model in MODELS:
        for partition in ("calibration", "test"):
            result[f"k400_{model}_{partition}.csv"] = len(pd.read_csv(manifests / f"k400_{model}_{partition}_selected.csv")) * 5
            result[f"ucf101_{model}_{partition}.csv"] = int((ucf.split == partition).sum()) * 5
    return result


def validate(protocol_root: Path, output_root: Path) -> dict[str, object]:
    checks: list[dict[str, object]] = []
    gate = json.loads((protocol_root / "gates/gate_report.json").read_text(encoding="utf-8"))
    checks.append({"requirement": "G1-G9 launch gates", "pass": gate.get("status") == "PASS", "evidence": "gates/gate_report.json"})
    readiness = json.loads((protocol_root / "gates/post_e1_pipeline_readiness.json").read_text(encoding="utf-8"))
    checks.append({"requirement": "post-E1 E2-E10 pipeline readiness", "pass": readiness.get("status") == "PASS", "evidence": "gates/post_e1_pipeline_readiness.json"})
    e1_integrity = json.loads((protocol_root / "gates/e1_completion_integrity.json").read_text(encoding="utf-8"))
    checks.append({"requirement": "E1 full raw row/schema/pair/finite/budget integrity", "pass": e1_integrity.get("status") == "PASS", "evidence": "gates/e1_completion_integrity.json"})

    e1_expected = expected_e1(protocol_root)
    total_e1 = 0
    for name, expected in e1_expected.items():
        path = output_root / "E1" / name
        frame = read_protocol_csv(path); total_e1 += len(frame)
        valid = (
            len(frame) == expected
            and not frame.duplicated(["pair_id", "attack"]).any()
            and set(frame.attack) == {"clean", *ATTACKS}
            and np.isfinite(frame[TDC_V2].to_numpy(float)).all()
        )
        checks.append({"requirement": f"E1 {name}", "pass": bool(valid), "rows": len(frame), "expected": expected, "evidence": f"E1/{name}"})
    checks.append({"requirement": "E1 total rows", "pass": total_e1 == 140205, "rows": total_e1, "expected": 140205, "evidence": "E1/*.csv"})

    raw_specs = {
        "E6": (MODELS, lambda model: output_root / "E6" / f"{model}.csv", 1800, ["pair_id", "attack", "epsilon_255"]),
        "E7": (MODELS, lambda model: output_root / "E7" / f"{model}.csv", 5400, ["pair_id", "attack", "config"]),
        "E8": (("csn_r101", "mvit_base_16x4"), lambda model: output_root / "E8" / f"{model}_candidates.csv", 480, ["stage", "pair_id", "tradeoff_lambda", "restart"]),
        "E10": (MODELS, lambda model: output_root / "E10" / f"{model}.csv", 800, ["pair_id", "attack"]),
    }
    for experiment, (models, path_fn, expected, keys) in raw_specs.items():
        for model in models:
            path = path_fn(model); frame = read_protocol_csv(path)
            valid = len(frame) == expected and not frame.duplicated(keys).any()
            checks.append({"requirement": f"{experiment} {model} raw", "pass": bool(valid), "rows": len(frame), "expected": expected, "evidence": str(path.relative_to(output_root))})
    for dataset in DATASETS:
        for model in MODELS:
            path = output_root / "E9" / f"{dataset}_{model}.csv"; frame = read_protocol_csv(path)
            valid = len(frame) == 2000 and not frame.duplicated(["method", "repeat", "relative_path"]).any()
            checks.append({"requirement": f"E9 {dataset}/{model} raw", "pass": bool(valid), "rows": len(frame), "expected": 2000, "evidence": str(path.relative_to(output_root))})

    metrics_root = output_root / "metrics"
    for name, expected in EXPECTED_METRICS.items():
        path = metrics_root / name; frame = read_protocol_csv(path)
        numeric = frame.select_dtypes(include=[np.number]).to_numpy(float)
        valid = len(frame) == expected and np.isfinite(numeric).all()
        checks.append({"requirement": f"metric {name}", "pass": bool(valid), "rows": len(frame), "expected": expected, "evidence": f"metrics/{name}"})
    bootstrap = pd.read_csv(metrics_root / "E1_paired_bootstrap_summary.csv")
    reps = pd.read_csv(metrics_root / "E1_paired_bootstrap_replicates.csv")
    bootstrap_columns = {
        "tdc_v2_auc", "tdc_v2_ci_low", "tdc_v2_ci_high", "baseline_auc",
        "baseline_ci_low", "baseline_ci_high", "difference", "ci_low", "ci_high",
        "difference_vs_vlad2", "vlad2_difference_ci_low", "vlad2_difference_ci_high",
        "difference_vs_temporal_shuffle_lr", "temporal_shuffle_lr_difference_ci_low",
        "temporal_shuffle_lr_difference_ci_high",
    }
    replicate_columns = {
        "tdc_v2_auc", "baseline_auc", "difference", "difference_vs_vlad2",
        "difference_vs_temporal_shuffle_lr",
    }
    bootstrap_valid = (
        bootstrap_columns <= set(bootstrap) and replicate_columns <= set(reps)
        and set(bootstrap.valid_replicates) == {1000} and len(reps) == 80000
        and set(reps.groupby(["dataset", "model", "attack", "setting"]).size()) == {1000}
    )
    checks.append({"requirement": "exactly 1000 paired source bootstrap replicates per E1 comparison", "pass": bool(bootstrap_valid), "evidence": "metrics/E1_paired_bootstrap_*.csv"})
    metric_files = [metrics_root / name for name in EXPECTED_METRICS if name.endswith("metrics.csv") or name.startswith(("E2_", "E3_", "E4_", "E5_", "E6_", "E7_"))]
    both_classes = True
    for path in metric_files:
        frame = pd.read_csv(path)
        if {"n_clean", "n_adv"} <= set(frame):
            both_classes &= bool((frame.n_clean > 0).all() and (frame.n_adv > 0).all())
    checks.append({"requirement": "all evaluated conditions contain both classes", "pass": both_classes, "evidence": "metrics/*.csv:n_clean,n_adv"})
    passed = all(bool(item["pass"]) for item in checks)
    return {"protocol_id": PROTOCOL, "generated_at": datetime.now(timezone.utc).astimezone().isoformat(), "status": "PASS" if passed else "FAIL", "checks": checks}


def save_table(frame: pd.DataFrame, paper_root: Path, name: str) -> None:
    frame.to_csv(paper_root / f"{name}.csv", index=False)
    (paper_root / f"{name}.md").write_text(frame.to_markdown(index=False, floatfmt=".4f") + "\n", encoding="utf-8")
    (paper_root / f"{name}.tex").write_text(frame.to_latex(index=False, float_format=lambda x: f"{x:.4f}") + "\n", encoding="utf-8")


def generate_failure_cases(output_root: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    summaries: list[dict[str, object]] = []
    examples: list[pd.DataFrame] = []
    for dataset in DATASETS:
        for model in MODELS:
            cal = pd.read_csv(output_root / "E1" / f"{dataset}_{model}_calibration.csv")
            test = pd.read_csv(output_root / "E1" / f"{dataset}_{model}_test.csv")
            classifier = fit_model(cal, TDC_V2)
            threshold = threshold_at_clean_fpr(cal.is_adv.to_numpy(int), classifier.predict_proba(cal[TDC_V2].to_numpy(float))[:, 1])
            adv = test[test.attack != "clean"].copy()
            adv["detector_score"] = classifier.predict_proba(adv[TDC_V2].to_numpy(float))[:, 1]
            adv["false_negative"] = adv.detector_score <= threshold
            for attack, group in adv.groupby("attack", sort=True):
                successful = group[group.attack_success == 1]
                failures = successful[successful.false_negative]
                summaries.append({
                    "protocol_id": PROTOCOL, "dataset": dataset, "model": model, "attack": attack,
                    "test_adversarial": len(group), "attack_success_rate": float(group.attack_success.mean()),
                    "successful_attacks": len(successful), "successful_false_negatives": len(failures),
                    "false_negative_rate_on_successes": float(len(failures) / len(successful)) if len(successful) else 0.0,
                    "deployment_threshold": threshold,
                })
                if len(failures):
                    keep = [c for c in ("protocol_id", "dataset", "action_model", "relative_path", "attack", "clean_pred", "attacked_pred", "measured_linf", "detector_score") if c in failures]
                    sample = failures.sort_values("detector_score").head(3)[keep].copy()
                    sample.insert(0, "failure_rank", range(1, len(sample) + 1)); examples.append(sample)
    empty_example_columns = [
        "failure_rank", "protocol_id", "dataset", "action_model", "relative_path",
        "attack", "clean_pred", "attacked_pred", "measured_linf", "detector_score",
    ]
    return pd.DataFrame(summaries), pd.concat(examples, ignore_index=True) if examples else pd.DataFrame(columns=empty_example_columns)


def generate_paper(output_root: Path) -> dict[str, object]:
    metrics = output_root / "metrics"; paper = output_root / "paper"; paper.mkdir(parents=True, exist_ok=True)
    e1 = pd.read_csv(metrics / "E1_metrics.csv")
    bootstrap = pd.read_csv(metrics / "E1_paired_bootstrap_summary.csv")
    main = e1[(e1.attack == "pooled") & (e1.setting == "full")].copy()
    save_table(main, paper, "table_1_main_pooled_full")
    strongest = bootstrap[(bootstrap.attack == "pooled") & (bootstrap.setting == "full")].copy()
    save_table(strongest, paper, "table_2_paired_strongest_baseline")

    generalization_parts = []
    e2 = pd.read_csv(metrics / "E2_leave_one_attack_out.csv"); e2 = e2[(e2.method == "TDC-v2") & (e2.setting == "full")].copy(); e2["generalization"] = "leave-one-attack-out"; generalization_parts.append(e2)
    e3 = pd.read_csv(metrics / "E3_leave_one_model_out.csv"); e3 = e3[(e3.method == "TDC-v2") & (e3.setting == "full")].copy(); e3["generalization"] = "leave-one-model-out"; generalization_parts.append(e3)
    e4 = pd.read_csv(metrics / "E4_cross_dataset_transfer.csv"); e4 = e4[(e4.method == "TDC-v2") & (e4.setting == "full")].copy(); e4["generalization"] = "K400-to-UCF101"; generalization_parts.append(e4)
    generalization = pd.concat(generalization_parts, ignore_index=True, sort=False)
    save_table(generalization, paper, "table_3_generalization")
    e5 = pd.read_csv(metrics / "E5_feature_group_ablation.csv"); save_table(e5[(e5.attack == "pooled") & (e5.setting == "full")], paper, "table_4_ablation")
    e6 = pd.read_csv(metrics / "E6_attack_strength.csv"); save_table(e6[e6.setting == "full"], paper, "table_5_attack_strength")
    e7 = pd.read_csv(metrics / "E7_probe_cost_sensitivity.csv"); save_table(e7[e7.setting == "full"], paper, "table_6_probe_accuracy_cost")
    e8 = pd.read_csv(metrics / "E8_adaptive_metrics.csv"); save_table(e8, paper, "table_7_adaptive_attack")
    e9 = pd.read_csv(metrics / "E9_runtime_memory.csv"); save_table(e9, paper, "table_8_runtime_memory")
    e10i = pd.read_csv(metrics / "E10_main_attack_integrity.csv"); e10p = pd.read_csv(metrics / "E10_perceptual_quality.csv")
    save_table(e10i, paper, "table_9_attack_integrity"); save_table(e10p, paper, "table_10_perceptual_quality")
    absolute_fpr = main[main.method == "TDC-v2"][["protocol_id", "dataset", "model", "threshold_fpr", "threshold_tpr", "deployment_threshold", "n_clean", "n_adv"]]
    save_table(absolute_fpr, paper, "table_11_absolute_test_fpr")
    failure_summary, failure_examples = generate_failure_cases(output_root)
    save_table(failure_summary, paper, "table_12_failure_case_summary")
    save_table(failure_examples, paper, "table_13_failure_case_examples")

    # Plot 1: main pooled AUC.
    pivot = main.pivot_table(index="method", columns="dataset", values="roc_auc", aggfunc="mean").sort_values("k400", ascending=False)
    ax = pivot.plot(kind="bar", figsize=(11, 5), ylim=(0, 1), ylabel="Mean ROC-AUC", rot=35)
    ax.set_title("E1 pooled full-test detection"); ax.grid(axis="y", alpha=.25); plt.tight_layout()
    for suffix in ("png", "pdf"): plt.savefig(paper / f"figure_1_main_auc.{suffix}", dpi=200)
    plt.close()
    # Plot 2: strength curves.
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), sharey=True)
    for axis, attack in zip(axes, ("fgsm", "pgd")):
        subset = e6[(e6.setting == "full") & (e6.attack == attack)]
        for model, group in subset.groupby("model"):
            axis.plot(group.epsilon_255, group.roc_auc, marker="o", label=model)
        axis.set(title=attack.upper(), xlabel=r"$\epsilon$ (/255)", ylabel="ROC-AUC", ylim=(0, 1)); axis.grid(alpha=.25)
    axes[1].legend(fontsize=8); fig.tight_layout()
    for suffix in ("png", "pdf"): fig.savefig(paper / f"figure_2_attack_strength.{suffix}", dpi=200)
    plt.close(fig)
    # Plot 3: probe accuracy/cost mean.
    probe = e7[e7.setting == "full"].groupby("config", as_index=False).agg(roc_auc=("roc_auc", "mean"), relative_cost=("relative_score_cost", "mean"), global_views=("global_views", "first"), local_windows=("local_windows", "first"))
    fig, ax = plt.subplots(figsize=(7, 5)); ax.scatter(probe.relative_cost, probe.roc_auc)
    for _, row in probe.iterrows(): ax.annotate(row.config, (row.relative_cost, row.roc_auc), fontsize=8)
    ax.set(xlabel="Relative detector cost", ylabel="Mean ROC-AUC", title="E7 probe accuracy-cost sensitivity", ylim=(0, 1)); ax.grid(alpha=.25); fig.tight_layout()
    for suffix in ("png", "pdf"): fig.savefig(paper / f"figure_3_probe_cost.{suffix}", dpi=200)
    plt.close(fig)
    # Plot 4: runtime overhead.
    runtime = e9.groupby("method", as_index=False)[["relative_overhead_vs_action", "relative_overhead_vs_strict_vlad"]].mean().sort_values("relative_overhead_vs_action")
    fig, ax = plt.subplots(figsize=(8, 4)); x=np.arange(len(runtime)); width=.38
    ax.bar(x-width/2, runtime.relative_overhead_vs_action, width, label="vs action-only")
    ax.bar(x+width/2, runtime.relative_overhead_vs_strict_vlad, width, label="vs Strict VLAD")
    ax.set_xticks(x, runtime.method, rotation=25); ax.set(ylabel="Mean relative overhead", title="E9 isolated runtime overhead"); ax.legend(); ax.grid(axis="y", alpha=.25); fig.tight_layout()
    for suffix in ("png", "pdf"): fig.savefig(paper / f"figure_4_runtime_overhead.{suffix}", dpi=200)
    plt.close(fig)

    main_mean = float(main[main.method == "TDC-v2"].roc_auc.mean())
    held_attack_mean = float(e2.roc_auc.mean()); model_transfer_mean = float(e3.roc_auc.mean()); domain_mean = float(e4.roc_auc.mean())
    adaptive_full = e8[e8.setting == "full"]
    tdc_runtime = e9[e9.method == "tdc_v2"]
    positive = int((strongest.difference > 0).sum())
    positive_vlad2 = int((strongest.difference_vs_vlad2 > 0).sum())
    positive_shuffle = int((strongest.difference_vs_temporal_shuffle_lr > 0).sum())
    ledger = pd.DataFrame([
        {"section": "Abstract", "claim_id": "A1", "claim": f"Under independent pooled full tests, TDC-v2 mean ROC-AUC across eight dataset-model conditions was {main_mean:.4f}.", "evidence_file": "table_1_main_pooled_full.csv", "cell_filter": "method=TDC-v2", "metric": "mean(roc_auc)"},
        {"section": "Abstract", "claim_id": "A2", "claim": f"Held-out-attack TDC-v2 mean ROC-AUC was {held_attack_mean:.4f} under E2.", "evidence_file": "table_3_generalization.csv", "cell_filter": "generalization=leave-one-attack-out", "metric": "mean(roc_auc)"},
        {"section": "Abstract", "claim_id": "A3", "claim": f"The bounded adaptive EOT/BPDA stress test achieved mean joint attack-and-evasion rate {adaptive_full.joint_success_evasion_rate.mean():.4f}.", "evidence_file": "table_7_adaptive_attack.csv", "cell_filter": "setting=full", "metric": "mean(joint_success_evasion_rate)"},
        {"section": "Introduction", "claim_id": "I1", "claim": "The evaluated object is the frozen action model's 16/32-frame model-input clip; no claim is made about all decoded frames.", "evidence_file": "FINAL_RERUN_CONTRACT_20260714.md", "cell_filter": "Sections 2-3", "metric": "scope"},
        {"section": "Results", "claim_id": "R1", "claim": f"TDC-v2 had positive AUC difference from the strongest matched baseline in {positive}/8 pooled full conditions.", "evidence_file": "table_2_paired_strongest_baseline.csv", "cell_filter": "all rows", "metric": "count(difference>0)"},
        {"section": "Results", "claim_id": "R1b", "claim": f"TDC-v2 had positive paired AUC difference versus VLAD-2 in {positive_vlad2}/8 and versus Temporal Shuffle-LR in {positive_shuffle}/8 pooled full conditions.", "evidence_file": "table_2_paired_strongest_baseline.csv", "cell_filter": "all rows", "metric": "count(difference_vs_vlad2>0),count(difference_vs_temporal_shuffle_lr>0)"},
        {"section": "Results", "claim_id": "R2", "claim": f"Leave-one-model-out mean ROC-AUC was {model_transfer_mean:.4f}.", "evidence_file": "table_3_generalization.csv", "cell_filter": "generalization=leave-one-model-out", "metric": "mean(roc_auc)"},
        {"section": "Results", "claim_id": "R3", "claim": f"K400-to-UCF101 transfer mean ROC-AUC was {domain_mean:.4f}.", "evidence_file": "table_3_generalization.csv", "cell_filter": "generalization=K400-to-UCF101", "metric": "mean(roc_auc)"},
        {"section": "Results", "claim_id": "R4", "claim": "Attack-strength behavior is reported for FGSM and PGD at 2/4/8/16 per 255.", "evidence_file": "table_5_attack_strength.csv", "cell_filter": "all rows", "metric": "roc_auc, attack_success_rate"},
        {"section": "Results", "claim_id": "R5", "claim": "Probe sensitivity reports accuracy jointly with seconds/video and relative cost for all nine frozen configurations.", "evidence_file": "table_6_probe_accuracy_cost.csv", "cell_filter": "all rows", "metric": "roc_auc,mean_score_seconds,relative_score_cost"},
        {"section": "Results", "claim_id": "R6", "claim": f"TDC-v2 isolated mean runtime overhead was {tdc_runtime.relative_overhead_vs_action.mean():.2f}x versus action-only and {tdc_runtime.relative_overhead_vs_strict_vlad.mean():.2f}x versus Strict VLAD.", "evidence_file": "table_8_runtime_memory.csv", "cell_filter": "method=tdc_v2", "metric": "mean(relative_overhead_vs_action),mean(relative_overhead_vs_strict_vlad)"},
        {"section": "Results", "claim_id": "R7", "claim": "Absolute test FPR and TPR at the calibration-fixed operating point are reported in the main results package.", "evidence_file": "table_11_absolute_test_fpr.csv", "cell_filter": "all rows", "metric": "threshold_fpr,threshold_tpr"},
        {"section": "Results", "claim_id": "R8", "claim": "Successful undetected examples and false-negative rates are explicitly reported as failure cases.", "evidence_file": "table_12_failure_case_summary.csv;table_13_failure_case_examples.csv", "cell_filter": "all rows", "metric": "false_negative_rate_on_successes"},
        {"section": "Conclusion", "claim_id": "C1", "claim": "Conclusions are limited to post-hoc detection on frozen model-input clips and to the tested attacks, models, datasets, and adaptive budget.", "evidence_file": "FINAL_RERUN_CONTRACT_20260714.md;result_to_claim_ledger.csv", "cell_filter": "Sections 2,8,11", "metric": "scope"},
    ])
    save_table(ledger, paper, "result_to_claim_ledger")
    required = f"""# Main-paper required results ({PROTOCOL})

This file is generated only from `{PROTOCOL}` artifacts. It is the minimum main-paper checklist; do not move these items exclusively to supplementary material.

## Independent-test evidence

- TDC-v2 pooled full-test mean ROC-AUC: **{main_mean:.4f}** across 2 datasets × 4 models.
- Positive paired AUC difference versus the strongest matched baseline: **{positive}/8** pooled full conditions. Use the condition-specific 95% CIs in `table_2_paired_strongest_baseline`.
- Positive paired difference versus VLAD-2: **{positive_vlad2}/8**; versus Temporal Shuffle-LR: **{positive_shuffle}/8**. Report their condition-specific paired 95% CIs from the same table.

## Generalization and adaptive scope

- Leave-one-attack-out mean ROC-AUC: **{held_attack_mean:.4f}**.
- Leave-one-model-out mean ROC-AUC: **{model_transfer_mean:.4f}**.
- K400→UCF101 mean ROC-AUC: **{domain_mean:.4f}**.
- Adaptive joint success-and-evasion rate: **{adaptive_full.joint_success_evasion_rate.mean():.4f}**. State explicitly that CLIP/semantic paths use BPDA and the attack is not an exact full-detector gradient.

## Operating point, failure cases, and cost

- Put absolute test FPR/TPR from `table_11_absolute_test_fpr` in the main paper.
- Discuss failures using `table_12_failure_case_summary` and at least representative rows from `table_13_failure_case_examples`.
- TDC-v2 isolated runtime overhead: **{tdc_runtime.relative_overhead_vs_action.mean():.2f}×** versus action-only and **{tdc_runtime.relative_overhead_vs_strict_vlad.mean():.2f}×** versus Strict VLAD; report absolute seconds/video, Temporal Shuffle-relative overhead, and peak memory from `table_8_runtime_memory`.

## Claim control

Use `result_to_claim_ledger` as the authoritative empirical claim set. Do not use “universal”, “real-time”, “attack-agnostic”, or “deployment-ready”.
"""
    (paper / "MAIN_PAPER_REQUIRED_RESULTS.md").write_text(required, encoding="utf-8")
    return {"main_mean_auc": main_mean, "positive_vs_strongest": positive, "paper_files": len(list(paper.iterdir()))}


def copy_code(project: Path, destination: Path) -> None:
    for source_root in (project / "TSC_Detect", project / "scripts", project / "tests"):
        for source in source_root.rglob("*"):
            if not source.is_file(): continue
            if source.suffix not in {".py", ".sh"}: continue
            relative = source.relative_to(project)
            target = destination / relative; target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, target)


def build_archive(protocol_root: Path, output_root: Path, audit: dict[str, object], project: Path, export_dir: Path) -> tuple[Path, str]:
    building = export_dir.with_name(export_dir.name + ".building")
    if building.exists(): shutil.rmtree(building)
    if export_dir.exists(): shutil.rmtree(export_dir)
    building.mkdir(parents=True)
    for name in ("configs", "environment", "gates", "manifests"):
        shutil.copytree(protocol_root / name, building / "protocol" / name)
    shutil.copytree(
        protocol_root / "logs", building / "protocol/logs",
        ignore=shutil.ignore_patterns("pids.txt", "recovery"),
    )
    events = protocol_root / "ops/events.log"
    if events.exists():
        shutil.copy2(events, building / "protocol/logs/events.log")
    shutil.copy2(Path("/root/autodl-tmp/FINAL_RERUN_CONTRACT_20260714.md"), building / "FINAL_RERUN_CONTRACT_20260714.md")
    for name in ("E1", "E6", "E7", "E8", "E9", "E10", "metrics", "paper", "audit"):
        shutil.copytree(output_root / name, building / "results" / name)
    copy_code(project, building / "code")
    orchestration = building / "code/orchestration"; orchestration.mkdir(parents=True, exist_ok=True)
    for source in (Path("/root/autodl-tmp/tdc_final_supervisor.py"), Path("/root/autodl-tmp/tdc_e1_work_stealer.py")):
        shutil.copy2(source, orchestration / source.name)
    readme = f"""# TDC-Detect final export

Protocol: `{PROTOCOL}`  
Completion audit: `results/audit/completion_audit.json` (PASS)  

Contents include frozen code, manifests, hashes, logs, raw E1/E6-E10 features, E1-E10 metrics, environment evidence, paper tables/figures, the result-to-claim ledger, and the frozen contract. Runtime markers, supervisor locks/state snapshots, old repaired outputs, and stale progress notes are intentionally excluded.
"""
    (building / "README.md").write_text(readme, encoding="utf-8")
    initial_files = [path for path in building.rglob("*") if path.is_file()]
    manifest = {"protocol_id": PROTOCOL, "created_at": datetime.now(timezone.utc).astimezone().isoformat(), "files_listed_in_sha256s": len(initial_files) + 1, "completion_status": audit["status"]}
    (building / "archive_manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    files = sorted(path for path in building.rglob("*") if path.is_file())
    sums = [f"{sha256(path)}  {path.relative_to(building)}" for path in files]
    (building / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")
    building.replace(export_dir)
    archive = export_dir.with_suffix(".tar.gz")
    temporary = archive.with_suffix(archive.suffix + ".tmp")
    if temporary.exists(): temporary.unlink()
    with tarfile.open(temporary, "w:gz") as tar:
        tar.add(export_dir, arcname=export_dir.name)
    temporary.replace(archive)
    digest = sha256(archive)
    archive.with_suffix(archive.suffix + ".sha256").write_text(f"{digest}  {archive.name}\n", encoding="utf-8")
    return archive, digest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--protocol-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--export-dir", type=Path, default=Path("/root/autodl-tmp/TDC_Detect_Final_Export_20260714"))
    args = parser.parse_args()
    if args.protocol_root.name != PROTOCOL or args.output_root.name != PROTOCOL:
        raise ValueError("Refusing to mix protocol roots")
    audit = validate(args.protocol_root, args.output_root)
    audit_root = args.output_root / "audit"; audit_root.mkdir(parents=True, exist_ok=True)
    (audit_root / "completion_audit.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    pd.DataFrame(audit["checks"]).to_csv(audit_root / "completion_audit.csv", index=False)
    if audit["status"] != "PASS":
        raise SystemExit("Completion audit failed; final archive was not created")
    summary = generate_paper(args.output_root)
    (audit_root / "paper_generation_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    archive, digest = build_archive(args.protocol_root, args.output_root, audit, Path(__file__).resolve().parents[1], args.export_dir)
    final = {"protocol_id": PROTOCOL, "status": "PASS", "export_directory": str(args.export_dir), "archive": str(archive), "archive_sha256": digest}
    (audit_root / "final_export.json").write_text(json.dumps(final, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(final, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
