from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from eval_final_e1_e5 import PROTOCOL, TDC_V2, fit_model, metric_row, threshold_at_clean_fpr


MODELS = ("csn_r101", "mvit_base_16x4", "slowfast_r50", "x3d_m")


def e1_calibration(root: Path, model: str) -> pd.DataFrame:
    frame = pd.read_csv(root / f"k400_{model}_calibration.csv")
    if set(frame.protocol_id) != {PROTOCOL}: raise ValueError("E1 protocol mismatch")
    return frame


def evaluate_e6(e1_root: Path, source_root: Path) -> pd.DataFrame:
    rows = []
    for model in MODELS:
        train = e1_calibration(e1_root, model)
        classifier = fit_model(train, TDC_V2)
        cal_scores = classifier.predict_proba(train[TDC_V2].to_numpy(float))[:, 1]
        threshold = threshold_at_clean_fpr(train.is_adv.to_numpy(int), cal_scores)
        frame = pd.read_csv(source_root / f"{model}.csv")
        clean = frame[frame.attack == "clean"]
        for attack in ("fgsm", "pgd"):
            for strength in (2, 4, 8, 16):
                adv_all = frame[(frame.attack == attack) & (frame.epsilon_255 == strength)]
                for setting in ("full", "success-only"):
                    adv = adv_all if setting == "full" else adv_all[adv_all.attack_success == 1]
                    ids = set(adv.pair_id)
                    test_clean = clean if setting == "full" else clean[clean.pair_id.isin(ids)]
                    test = pd.concat([test_clean, adv], ignore_index=True)
                    scores = classifier.predict_proba(test[TDC_V2].to_numpy(float))[:, 1]
                    rows.append({
                        "protocol_id": PROTOCOL, "experiment": "E6", "model": model,
                        "attack": attack, "epsilon_255": strength, "setting": setting,
                        "attack_success_rate": float(adv_all.attack_success.mean()),
                        "mean_linf": float(adv_all.measured_linf.mean()),
                        **metric_row(test.is_adv.to_numpy(int), scores, threshold),
                    })
    return pd.DataFrame(rows)


def evaluate_e7(e1_root: Path, source_root: Path) -> pd.DataFrame:
    rows = []
    for model in MODELS:
        train = e1_calibration(e1_root, model)
        classifier = fit_model(train, TDC_V2)
        cal_scores = classifier.predict_proba(train[TDC_V2].to_numpy(float))[:, 1]
        threshold = threshold_at_clean_fpr(train.is_adv.to_numpy(int), cal_scores)
        frame = pd.read_csv(source_root / f"{model}.csv")
        costs = frame.groupby("config").score_seconds.mean().to_dict()
        base_cost = costs["g1_l0"]
        for config in sorted(frame.config.unique()):
            config_frame = frame[frame.config == config]
            clean = config_frame[config_frame.attack == "clean"]
            for attack in ("pgd", "flicker-style"):
                adv_all = config_frame[config_frame.attack == attack]
                for setting in ("full", "success-only"):
                    adv = adv_all if setting == "full" else adv_all[adv_all.attack_success == 1]
                    ids = set(adv.pair_id)
                    test_clean = clean if setting == "full" else clean[clean.pair_id.isin(ids)]
                    test = pd.concat([test_clean, adv], ignore_index=True)
                    scores = classifier.predict_proba(test[TDC_V2].to_numpy(float))[:, 1]
                    rows.append({
                        "protocol_id": PROTOCOL, "experiment": "E7", "model": model,
                        "attack": attack, "config": config, "global_views": int(test.global_views.iloc[0]),
                        "local_windows": int(test.local_windows.iloc[0]), "setting": setting,
                        "attack_success_rate": float(adv_all.attack_success.mean()),
                        "mean_score_seconds": float(costs[config]),
                        "relative_score_cost": float(costs[config] / base_cost),
                        **metric_row(test.is_adv.to_numpy(int), scores, threshold),
                    })
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--e1-root", type=Path, required=True)
    parser.add_argument("--e6-root", type=Path)
    parser.add_argument("--e7-root", type=Path)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args(); args.output_root.mkdir(parents=True, exist_ok=True)
    if args.e6_root:
        evaluate_e6(args.e1_root, args.e6_root).to_csv(args.output_root / "E6_attack_strength.csv", index=False)
    if args.e7_root:
        evaluate_e7(args.e1_root, args.e7_root).to_csv(args.output_root / "E7_probe_cost_sensitivity.csv", index=False)


if __name__ == "__main__": main()
