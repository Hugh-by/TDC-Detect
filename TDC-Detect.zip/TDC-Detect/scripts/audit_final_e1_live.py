from __future__ import annotations

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

from eval_final_e1_e5 import FIXED_METHODS, PROTOCOL, TDC_V2, TS_FEATURES


ATTACKS = {"clean", "fgsm", "pgd", "ofa-style", "flicker-style"}
SETTINGS = {
    "fgsm": (8 / 255, 8 / 255, 1), "pgd": (8 / 255, 2 / 255, 40),
    "ofa-style": (8 / 255, 2 / 255, 10), "flicker-style": (8 / 255, 2 / 255, 10),
}
FINITE_FIELDS = tuple(dict.fromkeys([
    *TDC_V2, *FIXED_METHODS.values(), *TS_FEATURES,
    "strict_vlad1", "strict_vlad2", "prompt_matched_vlad",
    "score", "vlad1_original_prob", "vlad2_onehot_pred", "pred_uniform",
    "conf_uniform", "num_views", "ts_defense_vote_pred", "num_shuffle_views",
]))


def audit_file(path: Path, expected: int) -> dict[str, object]:
    errors: list[str] = []
    seen: set[tuple[str, str]] = set()
    pair_attacks: dict[str, set[str]] = defaultdict(set)
    attack_counts: Counter[str] = Counter()
    rows = 0
    with path.open(encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or ())
        required = {
            "protocol_id", "pair_id", "attack", "is_adv", "measured_linf", "epsilon",
            "alpha", "steps", "attack_seed", "clip_frames", "clean_pred", "clean_conf",
            "attacked_pred", "attacked_conf", "attack_success", "selected_frame", *FINITE_FIELDS,
        }
        if not required <= fields:
            errors.append(f"missing_fields={sorted(required-fields)}")
        for row in reader:
            rows += 1
            pair_id, attack = row.get("pair_id", ""), row.get("attack", "")
            key = (pair_id, attack)
            if row.get("protocol_id") != PROTOCOL: errors.append(f"row{rows}:protocol")
            if not pair_id or attack not in ATTACKS: errors.append(f"row{rows}:key_or_attack")
            if key in seen: errors.append(f"row{rows}:duplicate={key}")
            seen.add(key); pair_attacks[pair_id].add(attack); attack_counts[attack] += 1
            try:
                if not all(math.isfinite(float(row[name])) for name in FINITE_FIELDS):
                    errors.append(f"row{rows}:nonfinite_feature")
            except (KeyError, TypeError, ValueError):
                errors.append(f"row{rows}:invalid_feature")
            if attack == "clean":
                if row.get("is_adv") not in {"0", "0.0"}: errors.append(f"row{rows}:clean_label")
            else:
                try:
                    linf = float(row["measured_linf"])
                    if not math.isfinite(linf) or linf > 8 / 255 + 1 / 255 + 1e-8:
                        errors.append(f"row{rows}:linf={linf}")
                except (KeyError, TypeError, ValueError):
                    errors.append(f"row{rows}:invalid_linf")
                if row.get("is_adv") not in {"1", "1.0"}: errors.append(f"row{rows}:adv_label")
                try:
                    expected_epsilon, expected_alpha, expected_steps = SETTINGS[attack]
                    if abs(float(row["epsilon"])-expected_epsilon) > 1e-12: errors.append(f"row{rows}:epsilon")
                    if abs(float(row["alpha"])-expected_alpha) > 1e-12: errors.append(f"row{rows}:alpha")
                    if int(float(row["steps"])) != expected_steps: errors.append(f"row{rows}:steps")
                    if int(float(row["attack_seed"])) < 0: errors.append(f"row{rows}:attack_seed")
                    clip_frames = int(float(row["clip_frames"])); clean_pred = int(float(row["clean_pred"])); attacked_pred = int(float(row["attacked_pred"]))
                    clean_conf = float(row["clean_conf"]); attacked_conf = float(row["attacked_conf"])
                    if clip_frames not in {16, 32} or not (0 <= clean_pred < 400 and 0 <= attacked_pred < 400): errors.append(f"row{rows}:pred_or_clip")
                    if not (math.isfinite(clean_conf) and math.isfinite(attacked_conf) and 0 <= clean_conf <= 1 and 0 <= attacked_conf <= 1): errors.append(f"row{rows}:confidence")
                    if int(float(row["attack_success"])) != int(clean_pred != attacked_pred): errors.append(f"row{rows}:success_mismatch")
                    if attack == "ofa-style":
                        selected = int(float(row["selected_frame"]))
                        if not 0 <= selected < clip_frames: errors.append(f"row{rows}:selected_frame")
                except (KeyError, TypeError, ValueError):
                    errors.append(f"row{rows}:invalid_attack_metadata")
            if len(errors) >= 100:
                break
    incomplete = {pair: sorted(ATTACKS-values) for pair, values in pair_attacks.items() if values != ATTACKS}
    missing_clean = sum("clean" not in values for values in pair_attacks.values())
    if rows > expected: errors.append(f"rows_exceed_expected={rows}>{expected}")
    if missing_clean: errors.append(f"pairs_missing_clean={missing_clean}")
    # A live writer may have exactly one trailing partial pair. More indicates a resume hole.
    if len(incomplete) > (0 if rows == expected else 1):
        errors.append(f"nontrailing_incomplete_pairs={len(incomplete)}")
    return {
        "file": path.name, "rows": rows, "expected_rows": expected,
        "complete": rows == expected, "unique_pairs": len(pair_attacks),
        "incomplete_pairs": len(incomplete), "incomplete_pair_examples": dict(list(incomplete.items())[:3]),
        "attack_counts": dict(sorted(attack_counts.items())), "errors": errors,
        "valid": not errors,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--state", type=Path, required=True)
    parser.add_argument("--e1-root", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    state = json.loads(args.state.read_text(encoding="utf-8"))
    details = []
    for target in state["targets"]:
        path = args.e1_root / target["file"]
        if path.exists(): details.append(audit_file(path, int(target["expected_rows"])))
    report = {
        "protocol_id": PROTOCOL, "generated_at": datetime.now(timezone.utc).astimezone().isoformat(),
        "files_present": len(details), "rows_scanned": sum(item["rows"] for item in details),
        "valid_files": sum(item["valid"] for item in details),
        "status": "PASS" if all(item["valid"] for item in details) else "FAIL",
        "files": details,
    }
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True); args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    if report["status"] != "PASS": raise SystemExit(1)


if __name__ == "__main__":
    main()
