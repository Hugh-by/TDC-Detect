"""Verify the sealed release payload with the Python standard library."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]


def main():
    manifest = json.loads((ROOT / 'provenance/file_manifest.json').read_text(encoding='utf8'))
    errors = []
    parsed = 0
    for item in manifest:
        path = ROOT / item['path']
        if not path.is_file():
            errors.append(f"Missing: {item['path']}")
            continue
        payload = path.read_bytes()
        if len(payload) != item['bytes'] or hashlib.sha256(payload).hexdigest() != item['sha256']:
            errors.append(f"Changed: {item['path']}")
        if path.suffix == '.py':
            try:
                ast.parse(payload.decode('utf-8-sig'), filename=item['path'])
                parsed += 1
            except (UnicodeError, SyntaxError) as exc:
                errors.append(f"Invalid Python: {item['path']}: {exc}")
    if errors:
        raise SystemExit('\n'.join(errors))
    print(f'PASS: {len(manifest)} files verified; {parsed} Python files parsed.')


if __name__ == '__main__':
    main()
